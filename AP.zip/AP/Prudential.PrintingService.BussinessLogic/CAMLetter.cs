﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Prudential.PrintingService.BussinessLogic
{
    public class CAMLetter : Letter
    {
        public CAMLetter(string data_file_name, string data_file_path, string report_path, string database_file_path, string data_base_file_path_source)
            : base(data_file_name, data_file_path, report_path, database_file_path, data_base_file_path_source)
        {
            ImportData(data_file_name, data_file_path);
        }

        internal override void ImportData(string file_name, string path)
        {
            base.ImportData(file_name, path);
        }
    }
}
