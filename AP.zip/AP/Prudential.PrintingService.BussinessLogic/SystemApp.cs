﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.IO;
using System.Threading;

namespace Prudential.PrintingService.BussinessLogic
{
    public static class SystemApp
    {
        public static void ExceptionManual(Exception ex)
        {
            //Ultilities.Logging(String.Format("Prudential.PrintingService.BussinessLogic.SystemApp - Error:{0}", ex.Message));

            if (ex.Message.ToLower().Contains("unspecified error")
                    || ex.Message.ToLower().Contains("logon failed")
                    || ex.Message.Contains("more tables")
                    || ex.Message.ToLower().Contains("system resource exceeded")
                    || ex.Message.ToLower().Contains("0x80004005")
                   // || ex.Message.Contains("Attempted to divide by zero.")
                    )
            {
                Restart();
            }
        }

        public static void Restart()
        {
            Process proc = null;
            try
            {
                Ultilities.Logging(String.Format("Restart App VNPrint..."));
                Thread.Sleep(2000);
                string targetDir = Directory.GetCurrentDirectory();
                Ultilities.Logging("targetDir... {0}", targetDir + "\\RestartApp.bat");

                proc = new Process();
                proc.StartInfo.WorkingDirectory = targetDir;
                proc.StartInfo.FileName = "RestartApp.bat";
                //proc.StartInfo.Arguments = string.Format("10");//this is argument
                proc.StartInfo.CreateNoWindow = false;
                proc.Start();
                proc.WaitForExit();
            }
            catch (Exception ex)
            {
                Ultilities.Logging(String.Format("Prudential.PrintingService.BussinessLogic.SystemApp Exception Occurred :{0}, {1}", ex.Message, ex.StackTrace.ToString()));
            }
        }

        public static bool CheckPrinterName(string PrinterName)
        {
            foreach (string item in System.Drawing.Printing.PrinterSettings.InstalledPrinters)
	        {
                if (PrinterName.ToLower() == item.ToLower())
                    return true;
	        }
            return false;
        }
    }
}
