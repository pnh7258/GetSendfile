﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace Prudential.PrintingService.BussinessLogic.RMeta
{
    [Serializable]
    [XmlType("RFileCMArchives")]
    public class RFileCMArchiveListing
    {
        private List<RFileCMArchive> rfiles;

        public RFileCMArchiveListing()
        {
            rfiles = new List<RFileCMArchive>();
        }

        [XmlElement("RFile")]
        public List<RFileCMArchive> RFileMetaDatas { get; set; }
    }

    public class RFileCMArchive
    {
        [XmlAttribute]
        public string LetterType { get; set; }
        [XmlAttribute]
        public string FieldName { get; set; }
    }

    public class RFileCMArchives
    {
        private static List<RFileCMArchive> rfiles;

        public static void Initialize(string xml)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(RFileCMArchiveListing), null, null, new XmlRootAttribute("RFileCMArchives"), "");
            StringReader reader = new StringReader(xml);

            var listing = (RFileCMArchiveListing)serializer.Deserialize(reader);
            rfiles = listing.RFileMetaDatas;
        }

        public static RFileCMArchive GetFieldNum(string letterType)
        {
            return rfiles.FirstOrDefault(r => r.LetterType == letterType);
        }
    }
}
