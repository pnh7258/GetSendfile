﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace Prudential.PrintingService.BussinessLogic.RMeta {
    [Serializable]
    [XmlType("RFileMetaDatas")]
    public class RFileMetaDataListing {
        private List<RFileMetaData> rfiles;

        public RFileMetaDataListing() {
            rfiles = new List<RFileMetaData>();
        }

        [XmlElement("RFile")]
        public List<RFileMetaData> RFileMetaDatas { get; set; }
    }

    [Serializable]
    public class RFileMetaData {
        [XmlAttribute]
        public string FileName { get; set; }
        [XmlAttribute]
        public string LetterType { get; set; }
        [XmlAttribute]
        public string Unicode { get; set; }
        [XmlAttribute]
        public string PrintBothSlide { get; set; }
        [XmlAttribute]
        public string PruConnect { get; set; }
    }

    public class RFileMetaDatas {
        private static List<RFileMetaData> rfiles;

        public static void Initialize(string xml) {
            XmlSerializer serializer = new XmlSerializer(typeof(RFileMetaDataListing), null, null, new XmlRootAttribute("RFileMetaDatas"), "");
            StringReader reader = new StringReader(xml);

            var listing = (RFileMetaDataListing)serializer.Deserialize(reader);
            rfiles = listing.RFileMetaDatas;
        }

        public static RFileMetaData GetUnicode(string letterType) {
            return rfiles.FirstOrDefault(r => r.LetterType == letterType && r.Unicode == "1");
        }

        public static RFileMetaData GetBothSlide(string letterType) {
            return rfiles.FirstOrDefault(r => r.LetterType == letterType && r.PrintBothSlide == "1");
        }

        public static RFileMetaData GetPruConnect(string letterType)
        {
            return rfiles.FirstOrDefault(r => r.LetterType == letterType && r.PruConnect == "1");
        }

        public static List<RFileMetaData> GetList() {
            return rfiles;
        }
    }
}
