﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading;
using log4net;
namespace Prudential.PrintingService.BussinessLogic
{
    public class VNLetter : Letter
    {
        private static readonly ILog log = LogManager.GetLogger(typeof(VNLetter));
        public VNLetter(string data_file_name, string data_file_path, string report_path, string database_file_path, string data_base_file_path_source)
            : base(data_file_name, data_file_path, report_path, database_file_path,data_base_file_path_source)
        {
            Initial();
            ImportData(data_file_name, data_file_path);
        }

        internal override void ImportData(string file_name, string path)
        {
            string series = file_name.Split('.')[0].Split('-')[1];
            var file_name_path = path + file_name;
            StreamReader reader = null;
            int iGroup = 0;
            string sqlExcute = string.Empty;

            try
            {
                var fileStream = new FileStream(file_name_path, FileMode.Open, FileAccess.Read, FileShare.None);
                reader = new StreamReader(fileStream);
                string line = "";

                List<string> lstCommand = new List<string>();
                while ((line = reader.ReadLine()) != null)
                {
                    if (line.StartsWith("#") || line.Length < 2)
                    {
                        continue;
                    }
                    if (line.Length < 2) continue;
                    //if (FieldName == string.Empty) FieldName = ConvertTextToFieldDB(line.Split('|').Count() - 1);

                    //Replace all Delimiter character (|) with (",") to prepare the SQL String,
                    //used for inserting a text line into correlative table.
                    line = line.Replace("\"", "\"\"");
                    line = line.Replace("|", "\",\"");
                    line = line.Replace(",\"\",", ",NULL,");
                    line = line.Substring(0, line.Length - 2);

                    line = Boolean.Parse(this.IsUnicode) ? CommonFunction.CommonFunction.VIQR2Unicode(line) : CommonFunction.CommonFunction.VIQR2VNI(line);
                    if (line.Substring(0, 4) != "NULL")
                        line = "(" + series + ",\"" + line + ")";
                    else
                        line = "(" + series + "," + line + ")";

                    //line = "INSERT INTO " + this.LetterType + FieldName + " Values " + line;
                    line = "INSERT INTO " + this.LetterType + " Values " + line;
                    //line = "INSERT INTO " + this.LetterType + " Values " + line;
                    line = line.Replace(",\"\",", ",NULL,");
                    lstCommand.Add(line);
                }

                if (lstCommand.Count() == 0) this.ExMessage = "Data no data";
                else 
                    Ultilities.InsertData(this.DataBaseFilePath, lstCommand.ToArray());

                reader.Close();

                fileStream.Close();
            }
            catch (Exception ex) {
                log.ErrorFormat("Error: {0}", ex);
                SystemApp.ExceptionManual(ex);
                try
                {
                    ExMessage = ex.Message; // Insert Error
                    if (reader != null)
                        reader.Close();
                }
                catch
                {
                    throw;
                }
                //throw;
            }
        }

        internal override void GetLetterInfo(string file_name, string path)
        {
            string series = file_name.Split('.')[0].Split('-')[1];
            var file_name_path = path + file_name;
            StreamReader reader = null;

            try
            {
                var fileStream = new FileStream(file_name_path, FileMode.Open, FileAccess.Read, FileShare.None);
                reader = new StreamReader(fileStream);
                string line = "";
                string[] row_data = null;

                while ((line = reader.ReadLine()) != null)
                {
                    if (line.StartsWith("#"))
                    {
                        line = line.Replace("#", "");
                        row_data = line.Split('|');

                        this.LetterType = row_data[0];
                        this.PrinterName = row_data[1] == "ZPLRLT" ? row_data[1] + "_a3" : (Ultilities.GetLetterTaxInvoice(this.DataBaseFilePath, row_data[0]) ? row_data[1] + "_T" : row_data[1]);
                        this.UserName = row_data[2];
                        this.Serial = series;
                        this.PrintDate = row_data[3];

                        if (!Ultilities.CompactDataBase(this.DataBaseFilePath, this.DataBaseFilePathSource))
                            Ultilities.RemoveData(this.DataBaseFilePath, this.LetterType);
                    }
                    else
                        break;
                }
                reader.Close();

                fileStream.Close();
            }
            catch (Exception ex)
            {
                log.ErrorFormat("Error: {0}", ex);
                SystemApp.ExceptionManual(ex);
                try
                {
                    if (reader != null)
                        reader.Close();
                }
                catch
                {
                    throw;
                }
                throw;
            }
        }
    }
}
