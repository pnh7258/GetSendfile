﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Prudential.PrintingService.DataAccess;
using log4net;
using System.Data.OleDb;
using System.Threading;
using Prudential.PrintingService.BussinessLogic.IO;
using Prudential.PrintingService.BussinessLogic.RMeta;
namespace Prudential.PrintingService.BussinessLogic
{
    public static class Ultilities
    {
        private static ILog _logger;
        private static readonly ILog log = LogManager.GetLogger(typeof(Ultilities));

        public static string CompactDatabase(string database_file_path)
        {
            PruDBHelp pru = new PruDBHelp(database_file_path);
            string table_name = "";
            string SQL = "";
            string result = "";
            DataTable schema = pru.GetSchema();
            List<string> lstCommand = new List<string>();
            pru.Close();
            int j = 0;
            for (int i = 0; i < schema.Rows.Count; i++)
            {
                table_name = schema.Rows[i][2].ToString();
                if (table_name != "Alphabet" && table_name != "MSysACEs" && table_name != "MSysIMEXColumns"
                    && table_name != "MSysIMEXSpecs" && table_name != "MSysModules"
                    && table_name != "MSysModules2" && table_name != "MSysObjects"
                    && table_name != "MSysQueries" && table_name != "MSysRelationships"
                    && table_name != "polno" && table_name != "Signee" && table_name != "TaxInvoiceForms" && table_name != "TV905" && table_name != "TV904")
                {
                    pru = new PruDBHelp(database_file_path);
                    SQL = "Delete from " + table_name;
                    lstCommand.Add(SQL);
                    j++;
                    result += j.ToString() + "Compact table " + table_name + "\n";
                }
            }

            pru.ExecuteNonQuery(lstCommand.ToArray(), CommandType.Text);

            return result;
        }
        /*
        public static bool CompactDataBase_01(string database_file_path)
        {
            try
            {
                if (database_file_path.Contains("2"))
                    return false;
                object[] oParams;
                object objJRO =
                  Activator.CreateInstance(Type.GetTypeFromProgID("JRO.JetEngine"));
                oParams = new object[] { "Provider=Microsoft.Jet.OLEDB.4.0;Data" + " Source=C:\\vnprint\\spool\\vnreport.mdb;Jet OLEDB:Engine Type=5", "Provider=Microsoft.Jet.OLEDB.4.0;Data" + " Source=C:\\vnprint\\vnreport.mdb;Jet OLEDB:Engine Type=5" };
                //invoke a CompactDatabase method of a JRO object
                //pass Parameters array
                objJRO.GetType().InvokeMember("CompactDatabase",
                    System.Reflection.BindingFlags.InvokeMethod,
                    null,
                    objJRO,
                    oParams);
                //database is compacted now
                //to a new file C:\\tempdb.mdw
                //let's copy it over an old one and delete it

                System.IO.File.Delete("C:\\vnprint\\spool\\vnreport.mdb");
                System.IO.File.Copy("C:\\vnprint\\vnreport.mdb", "C:\\vnprint\\spool\\vnreport.mdb");
                System.IO.File.Delete("C:\\vnprint\\vnreport.mdb");

                //clean up (just in case)
                System.Runtime.InteropServices.Marshal.ReleaseComObject(objJRO);
                objJRO = null;
                Logging("Compact DataBase successful!");
                return true;
            }
            catch (Exception ex)
            {
                string mess = ex.Message.ToString();
                Logging("Compact DataBase fail: " + mess);
                return false;
            }
        }
        */
        public static bool DeleteAndCopy_DB(string database_file_path, string data_base_file_path_source)
        {
            try
            {
                if (!String.IsNullOrEmpty(data_base_file_path_source) && !String.IsNullOrEmpty(database_file_path))
                {

                    File.Copy(data_base_file_path_source, database_file_path, true);
                    Logging("M&D successful: " + database_file_path);//Compact DataBase successful!
                }
                else
                    Logging("M&D successful: Don't Backup DB");//Compact DataBase successful!
                return true;
            }
            catch (Exception ex)
            {
                string mess = ex.Message.ToString();
                Logging("Delete And Move failed: " + mess);
                return false;
            }
        }

        public static bool CompactDataBase_01(string database_file_path)
        {
            try
            {
                /*
                string compact_path = string.Empty;
                if (database_file_path.Contains("2"))
                    File.Copy("C:\\vnprint\\spool3\\vnreport.mdb", "C:\\vnprint\\spool2\\vnreport.mdb", true);
                else
                    File.Copy("C:\\vnprint\\spool3\\vnreport.mdb", "C:\\vnprint\\spool\\vnreport.mdb", true);
               */
                string compact_path = string.Empty;
                if (database_file_path.Contains("2"))
                    compact_path = "C:\\vnprint\\compact02\\vnreport.mdb";
                else if (database_file_path.Contains("3"))
                    compact_path = "C:\\vnprint\\compact03\\vnreport.mdb";
                else if (database_file_path.Contains("4"))
                    compact_path = "C:\\vnprint\\compact04\\vnreport.mdb";
                else
                    compact_path = "C:\\vnprint\\compact\\vnreport.mdb";
                if (!Directory.Exists("C:\\vnprint\\compact"))
                    Directory.CreateDirectory("C:\\vnprint\\compact");
                if (!Directory.Exists("C:\\vnprint\\compact02"))
                    Directory.CreateDirectory("C:\\vnprint\\compact02");
                if (!Directory.Exists("C:\\vnprint\\compact03"))
                    Directory.CreateDirectory("C:\\vnprint\\compact03");
                if (!Directory.Exists("C:\\vnprint\\compact04"))
                    Directory.CreateDirectory("C:\\vnprint\\compact04");
                object[] oParams;
                object objJRO =
                  Activator.CreateInstance(Type.GetTypeFromProgID("JRO.JetEngine"));
                oParams = new object[] { "Provider=Microsoft.Jet.OLEDB.4.0;Data" + " Source=" + database_file_path + ";Jet OLEDB:Engine Type=5", "Provider=Microsoft.Jet.OLEDB.4.0;Data" + " Source=" + compact_path + ";Jet OLEDB:Engine Type=5" };
                //invoke a CompactDatabase method of a JRO object
                //pass Parameters array
                objJRO.GetType().InvokeMember("CompactDatabase",
                    System.Reflection.BindingFlags.InvokeMethod,
                    null,
                    objJRO,
                    oParams);
                //database is compacted now
                //to a new file C:\\tempdb.mdw
                //let's copy it over an old one and delete it

                System.IO.File.Delete(database_file_path);
                System.IO.File.Copy(compact_path, database_file_path, true);
                System.IO.File.Delete(compact_path);

                //clean up (just in case)
                System.Runtime.InteropServices.Marshal.ReleaseComObject(objJRO);
                objJRO = null;

                Logging("Compact DataBase successful!");
                return true;
            }
            catch (Exception ex)
            {
                string mess = ex.Message.ToString();
                Logging("Compact DataBase fail: " + mess);
                return false;
            }
        }

        public static bool CompactDataBase(string database_file_path, string data_base_file_path_source)
        {
            try
            {
                if (!String.IsNullOrEmpty(data_base_file_path_source) && !String.IsNullOrEmpty(database_file_path)
                    && data_base_file_path_source.ToLower() != database_file_path.ToLower())
                {
                    if (File.Exists(database_file_path))
                    {
                        System.GC.Collect();
                        System.GC.WaitForPendingFinalizers();
                        if (File.Exists(database_file_path.Replace(".mdb", ".ldb")))
                            File.Delete(database_file_path.Replace(".mdb", ".ldb"));
                        File.Delete(database_file_path);
                    }
                    File.Copy(data_base_file_path_source, database_file_path, true);
                }
                return true;
            }
            catch (Exception ex)
            {
                string mess = ex.Message.ToString();
                //Logging("Delete And Move failed: " + mess);
                return false;
            }
        }

        public static bool CompactDataBase_VNPost(string database_file_path, string data_base_file_path_source)
        {
            try
            {
                if (!String.IsNullOrEmpty(data_base_file_path_source) && !String.IsNullOrEmpty(database_file_path)
                    && data_base_file_path_source.ToLower() != database_file_path.ToLower())
                {
                    if (File.Exists(database_file_path))
                    {
                        System.GC.Collect();
                        System.GC.WaitForPendingFinalizers();
                        if (File.Exists(database_file_path.Replace(".mdb", ".ldb")))
                            File.Delete(database_file_path.Replace(".mdb", ".ldb"));
                        File.Delete(database_file_path);
                    }
                    File.Copy(data_base_file_path_source, database_file_path, true);
                }
                return true;
            }
            catch (Exception ex)
            {
                log.ErrorFormat("{0}", ex.ToString());
                Thread.Sleep(2000);
                return CompactDataBase_VNPost(database_file_path, data_base_file_path_source);
            }
        }

        public static void Logging(string log)
        {
            //EventLog.WriteEntry("CAMPrintingService", log);
            log4net.Config.XmlConfigurator.Configure();
            _logger = LogManager.GetLogger("RollingLogFileAppender");
            _logger.InfoFormat(log);
            //_logger.Debug(log);
        }

        public static void Logging(string log, params string[] spram)
        {
            //EventLog.WriteEntry("CAMPrintingService", log);
            log4net.Config.XmlConfigurator.Configure();
            _logger = LogManager.GetLogger("RollingLogFileAppender");
            _logger.InfoFormat(String.Format(log, spram));
            //_logger.Debug(log);
        }

        public static bool GetLetterTaxInvoice(string database_file_path, string letterType)
        {
            PruDBHelp pru = new PruDBHelp(database_file_path);
            //DataTable dt = pru.GetSchema();
            //string[] strCommand = new string[dt.Rows.Count];
            //for (int i = 0; i < dt.Rows.Count; i++) {
            //    strCommand[i] = "DELETE * FROM " + dt.Rows[i]["TABLE_NAME"].ToString();
            //}

            //pru.ExecuteNonQuery(strCommand, CommandType.Text);

            string commandText = "select * from TaxInvoiceForms where ReportName='" + letterType + "'";
            OleDbDataReader row = null;
            bool bResult = false;
            try
            {
                bResult = pru.CheckTaxInvoice(commandText, CommandType.Text);
            }
            catch (Exception)
            {
                row = null;
            }

            return bResult;
        }

        public static void RemoveAllData(string database_file_path)
        {
            PruDBHelp pru = new PruDBHelp(database_file_path);
            DataTable dt = pru.GetSchema();
            string[] strCommand = new string[dt.Rows.Count];
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                strCommand[i] = "DELETE * FROM " + dt.Rows[i]["TABLE_NAME"].ToString();
            }

            pru.ExecuteNonQuery(strCommand, CommandType.Text);
        }

        public static void RemoveData(string database_file_path, string table_name, string series)
        {
            PruDBHelp pru = new PruDBHelp(database_file_path);
            if(series == string.Empty)
                pru.ExecuteNonQuery("DELETE * FROM " + table_name, CommandType.Text);
            else
                pru.ExecuteNonQuery("DELETE * FROM " + table_name + " WHERE field0 = " + series, CommandType.Text);
        }

        public static void RemoveData(string database_file_path, string table_name)
        {
            PruDBHelp pru = new PruDBHelp(database_file_path);
            pru.ExecuteNonQuery("DELETE * FROM " + table_name, CommandType.Text);
        }

        public static void InsertData(string database_file_path, string sql)
        {
            PruDBHelp pru = new PruDBHelp(database_file_path);

            pru.ExecuteNonQuery(sql, CommandType.Text);
        }

        public static void InsertData(string database_file_path, string[] sqls)
        {
            PruDBHelp pru = new PruDBHelp(database_file_path);

            pru.ExecuteNonQuery(sqls, CommandType.Text);
        }

        public static bool RenamePrinter(string pathfile, string printername)
        {
            if (!File.Exists(pathfile))
                return false;

            var fileStream = new FileStream(pathfile, FileMode.Open, FileAccess.Read, FileShare.None);
            StreamReader reader = new StreamReader(fileStream);
            string row = reader.ReadLine();
            string[] rowdatas = row.Split('|');
            rowdatas[1] = printername;
            row = String.Join("|", rowdatas) + System.Environment.NewLine;
            row += reader.ReadToEnd();
            string newfile = pathfile.Replace(".l", "0.R");

            log.ErrorFormat("ReCreate File Error: {0}", newfile);
            Thread.Sleep(1000);

            if(newfile.Length < 20)
                File.WriteAllText(newfile, row);

            reader.Close();
            reader.Dispose();
            return true;
        }

        public static void CreateVelociTemp(string database_file_path)
        {
            PruDBHelp pru = new PruDBHelp(database_file_path);
            try
            {
                pru.ExecuteNonQuery("DROP TABLE VelociTemp", CommandType.Text);
            }
            catch
            {

            }

            try
            {
                pru = new PruDBHelp(database_file_path);
                pru.ExecuteNonQuery("CREATE TABLE VelociTemp (Field1 VARCHAR(40) NOT NULL)", CommandType.Text);
            }
            catch
            {

            }
        }

        public static string GetProposalNo(string database_file_path, string letterType, string criterion)
        {
            string strProposalNo = string.Empty;
            string FieldNo = string.Empty;
            switch (letterType.ToLower())
            {
                case "zexcrat":
                    FieldNo = "Field1";
                    break;
                default:
                    break;
            }

            if (FieldNo != string.Empty)
            {
                string mSQL = "Select Top 1 " + FieldNo + " From " + letterType + " where field0 = " + criterion;

                PruDBHelp pru = new PruDBHelp(database_file_path);
                pru.ExecuteNonQuery(mSQL, CommandType.Text);
                pru = new PruDBHelp(database_file_path);
                DataTable dt = pru.ExecuteDataTable(mSQL, CommandType.Text);
                if (dt.Rows.Count > 0)
                {
                    strProposalNo = dt.Rows[0][0].ToString();
                }
            }
            return strProposalNo;
        }

        //public static DataTable GetProposalNo(string database_file_path, Letter letter)
        //{
        //    string mSQL = "";
        //    string report_name = letter.LetterType.ToUpper();

        //    if (report_name == "ZAPLPC")
        //    {
        //        mSQL = "INSERT INTO VelociTemp (Field1)  SELECT distinct Field1 From ZAPLPC";
        //        letter.PolicyNoField = "Field1";
        //    }

        //    if (report_name == "ZAPL2")
        //    {
        //        mSQL = "INSERT INTO VelociTemp (Field1)  SELECT distinct Field1 From ZAPL2";
        //        letter.PolicyNoField = "Field1";
        //    }

        //    if (report_name == "ZAPL1")
        //    {
        //        mSQL = "INSERT INTO VelociTemp (Field1)  SELECT distinct Field1 From ZAPL1";
        //        letter.PolicyNoField = "Field1";
        //    }

        //    if (report_name.Substring(0, 4) == "ZLAP")
        //    {
        //        mSQL = "INSERT INTO  VelociTemp (Field1) SELECT distinct Field8 From " + report_name;
        //        letter.PolicyNoField = "Field8";
        //    }

        //    if (report_name == "ZFULCFM")
        //    {
        //        mSQL = "INSERT INTO  VelociTemp (Field1) SELECT distinct Field1 From " + report_name;
        //        letter.PolicyNoField = "Field1";
        //    }

        //    if (report_name == "ZFSURLET1")
        //    {
        //        mSQL = "INSERT INTO  VelociTemp (Field1) SELECT distinct Field1 From " + report_name;
        //        letter.PolicyNoField = "Field1";
        //    }

        //    if (report_name == "HRSTLET")
        //        mSQL = "INSERT INTO  VelociTemp (Field1) SELECT distinct Field1 From " + report_name;


        //    if (report_name == "HBILCHG")
        //    {
        //        mSQL = "INSERT INTO  VelociTemp (Field1) SELECT distinct Field1 From " + report_name;
        //        letter.PolicyNoField = "Field1";
        //    }

        //    if (report_name == "ZCFMLET")
        //    {
        //        mSQL = "INSERT INTO  VelociTemp (Field1) SELECT distinct Field5 From " + report_name;
        //        letter.PolicyNoField = "Field5";
        //    }

        //    if (report_name == "ZBONUSUR")
        //    {
        //        mSQL = "INSERT INTO  VelociTemp (Field1) SELECT distinct Field1 From " + report_name;
        //        letter.PolicyNoField = "Field1";
        //    }

        //    if (report_name == "ZREDUL")
        //    {
        //        mSQL = "INSERT INTO  VelociTemp (Field1) SELECT distinct Field2 From " + report_name;
        //        letter.PolicyNoField = "Field2";
        //    }

        //    if (report_name == "ZLAPUL")
        //    {
        //        mSQL = "INSERT INTO  VelociTemp (Field1) SELECT distinct Field2 From " + report_name;
        //        letter.PolicyNoField = "Field2";
        //    }
        //    if (report_name == "ZPRUCASH")
        //    {
        //        mSQL = "INSERT INTO  VelociTemp (Field1) SELECT distinct Field1 From " + report_name;
        //        letter.PolicyNoField = "Field1";
        //    }

        //    if (report_name == "ZMANDL")
        //    {
        //        mSQL = "INSERT INTO  VelociTemp (Field1) SELECT distinct Field8 From " + report_name;
        //        letter.PolicyNoField = "Field8";
        //    }

        //    if (report_name == "ZEXPLT")
        //    {
        //        mSQL = "INSERT INTO  VelociTemp (Field1) SELECT distinct Field7 From " + report_name;
        //        letter.PolicyNoField = "Field7";
        //    }
        //    if (report_name == "ZAFCLT")
        //    {
        //        mSQL = "INSERT INTO  VelociTemp (Field1) SELECT distinct Field3 From " + report_name;
        //        letter.PolicyNoField = "Field3";
        //    }
        //    if (report_name == "ZEUCASH")
        //    {
        //        mSQL = "INSERT INTO  VelociTemp (Field1) SELECT distinct Field1 From " + report_name;
        //        letter.PolicyNoField = "Field1";
        //    }

        //    if (report_name == "ZEUCASH")
        //    {
        //        mSQL = "INSERT INTO  VelociTemp (Field1) SELECT distinct Field1 From " + report_name;
        //        letter.PolicyNoField = "Field1";
        //    }

        //    if (report_name == "ZADDR02")
        //    {
        //        mSQL = "INSERT INTO  VelociTemp (Field1) SELECT distinct Field2 From " + report_name;
        //        letter.PolicyNoField = "Field2";
        //    }

        //    if (report_name == "ZCFMLET")
        //    {
        //        mSQL = "INSERT INTO  VelociTemp (Field1) SELECT distinct Field5 From " + report_name;
        //        letter.PolicyNoField = "Field5";
        //    }

        //    if (report_name == "HRSTLET")
        //    {
        //        mSQL = "INSERT INTO  VelociTemp (Field1) SELECT distinct Field1 From " + report_name;
        //        letter.PolicyNoField = "Field1";
        //    }

        //    if (report_name == "ZRINUL")
        //    {
        //        mSQL = "INSERT INTO  VelociTemp (Field1) SELECT distinct Field3 From " + report_name;
        //        letter.PolicyNoField = "Field3";
        //    }

        //    if (report_name == "ZRINVLRB")
        //    {
        //        mSQL = "INSERT INTO  VelociTemp (Field1) SELECT distinct Field1 From " + report_name;
        //        letter.PolicyNoField = "Field1";
        //    }

        //    if (report_name == "ZRINVLRR")
        //    {
        //        mSQL = "INSERT INTO  VelociTemp (Field1) SELECT distinct Field1 From " + report_name;
        //        letter.PolicyNoField = "Field1";
        //    }

        //    if (report_name == "HBILCHG")
        //    {
        //        mSQL = "INSERT INTO  VelociTemp (Field1) SELECT distinct Field1 From " + report_name;
        //        letter.PolicyNoField = "Field1";
        //    }

        //    if (report_name == "ZFULCFM")
        //    {
        //        mSQL = "INSERT INTO  VelociTemp (Field1) SELECT distinct Field1 From " + report_name;
        //        letter.PolicyNoField = "Field1";
        //    }

        //    if (report_name == "ZBNCLET3")
        //    {
        //        mSQL = "INSERT INTO  VelociTemp (Field1) SELECT distinct Field1 From " + report_name;
        //        letter.PolicyNoField = "Field1";
        //    }

        //    if (report_name == "ZBNCLET1")
        //    {
        //        mSQL = "INSERT INTO  VelociTemp (Field1) SELECT distinct Field10 From " + report_name;
        //        letter.PolicyNoField = "Field10";
        //    }

        //    if (report_name == "ZMASWDB")
        //    {
        //        mSQL = "INSERT INTO  VelociTemp (Field1) SELECT distinct Field1 From " + report_name;
        //        letter.PolicyNoField = "Field1";
        //    }

        //    if (report_name == "ZCMJLET")
        //    {
        //        mSQL = "INSERT INTO  VelociTemp (Field1) SELECT distinct Field1 From " + report_name;
        //        letter.PolicyNoField = "Field1";
        //    }

        //    if (report_name == "ULSTMTNB")
        //    {
        //        mSQL = "INSERT INTO  VelociTemp (Field1) SELECT distinct Field1 From " + report_name;
        //        letter.PolicyNoField = "Field1";
        //    }

        //    if (report_name == "ULSTMTPS")
        //    {
        //        mSQL = "INSERT INTO  VelociTemp (Field1) SELECT distinct Field1 From " + report_name;
        //        letter.PolicyNoField = "Field1";
        //    }

        //    if (report_name == "ZPRMREDL")
        //    {
        //        mSQL = "INSERT INTO  VelociTemp (Field1) SELECT distinct Field1 From " + report_name;
        //        letter.PolicyNoField = "Field1";
        //    }

        //    //new
        //    if (report_name == "ZVLAVL")
        //    {
        //        mSQL = "INSERT INTO  VelociTemp (Field1) SELECT distinct Field2 From " + report_name;
        //        letter.PolicyNoField = "Field2";
        //    }

        //    if (report_name == "ZVRDVL")
        //    {
        //        mSQL = "INSERT INTO  VelociTemp (Field1) SELECT distinct Field1 From " + report_name;
        //        letter.PolicyNoField = "Field1";
        //    }

        //    if (report_name == "ZVRDVLR")
        //    {
        //        mSQL = "INSERT INTO  VelociTemp (Field1) SELECT distinct Field1 From " + report_name;
        //        letter.PolicyNoField = "Field1";
        //    }

        //    if (report_name == "ZPHLUL")
        //    {
        //        mSQL = "INSERT INTO  VelociTemp (Field1) SELECT distinct Field2 From " + report_name;
        //        letter.PolicyNoField = "Field2";
        //    }

        //    if (report_name == "ZUPHUL")
        //    {
        //        mSQL = "INSERT INTO  VelociTemp (Field1) SELECT distinct Field2 From " + report_name;
        //        letter.PolicyNoField = "Field2";
        //    }

        //    if (report_name == "ZURDUL")
        //    {
        //        mSQL = "INSERT INTO  VelociTemp (Field1) SELECT distinct Field1 From " + report_name;
        //        letter.PolicyNoField = "Field1";
        //    }
        //    if (report_name == "ZAUPPC")
        //    {
        //        mSQL = "INSERT INTO  VelociTemp (Field1) SELECT distinct Field1 From " + report_name;
        //        letter.PolicyNoField = "Field1";
        //    }

        //    if (report_name == "ZEXCCAL")
        //    {
        //        mSQL = "INSERT INTO  VelociTemp (Field1) SELECT distinct Field37 From " + report_name;
        //        letter.PolicyNoField = "Field37";
        //    }
        //    if (report_name == "ZEXCRAT")
        //    {
        //        mSQL = "INSERT INTO  VelociTemp (Field1) SELECT distinct Field37 From " + report_name;
        //        letter.PolicyNoField = "Field37";
        //    }

        //    if (report_name == "ZELT")
        //    {
        //        mSQL = "INSERT INTO  VelociTemp (Field1) SELECT distinct Field1 From " + report_name;
        //        letter.PolicyNoField = "Field1";
        //    }

        //    PruDBHelp pru = new PruDBHelp(database_file_path);
        //    pru.ExecuteNonQuery(mSQL, CommandType.Text);
        //    pru = new PruDBHelp(database_file_path);
        //    return pru.ExecuteDataTable("SELECT Field1 FROM VelociTemp", CommandType.Text);
        //}

        public static DataTable GetProposalNo(string database_file_path, Letter letter)
        {
            RFileCMArchives.Initialize(File.ReadAllText(FileUtils.MapExecutingAssemblyPath("RMeta\\RFileCMArchive.xml")));
             string mSQL = "";
            string report_name = letter.LetterType.ToUpper();

            RFileCMArchive record = RFileCMArchives.GetFieldNum(report_name);

            mSQL = String.Format("INSERT INTO VelociTemp (Field1) SELECT distinct {0} From {1}", record.FieldName, report_name);
            letter.PolicyNoField = record.FieldName;

            PruDBHelp pru = new PruDBHelp(database_file_path);
            pru.ExecuteNonQuery(mSQL, CommandType.Text);
            pru = new PruDBHelp(database_file_path);
            return pru.ExecuteDataTable("SELECT Field1 FROM VelociTemp", CommandType.Text);
        }
    }
}
