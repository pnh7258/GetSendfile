﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Prudential.PrintingService.DataAccess;
using Prudential.PrintingService.BussinessLogic.RMeta;
using Prudential.PrintingService.BussinessLogic.IO;
using System.ComponentModel;

namespace Prudential.PrintingService.BussinessLogic {
    public class Letter {
        public string LetterType { get; set; }
        public string PrinterName { get; set; }
        public string UserName { get; set; }
        public string Serial { get; set; }
        public string ReportName { get { return LetterType + ".rpt"; } }
        public string ReportPath { get; set; }
        public string DataFilePath { get; set; }
        public string DataBaseFilePath { get; set; }
        public string DataFileName { get; set; }
        public string PolicyNoField { get; set; }
        public string PrintDate { get; set; }
        public string DataBaseFilePathSource { get; set; }
        public string PDFPath { get; set; }
        public string IsUnicode { get; set; }
        public string IsBothSlides { get; set; }
        public string IsPruConnect { get; set; }
        public string ExMessage { get; set; }

        public Letter(string data_file_name, string data_file_path, string report_path, string database_file_path, string data_base_file_path_source) {
            DataFilePath = data_file_path;
            DataFileName = data_file_name;
            ReportPath = report_path;
            DataBaseFilePath = database_file_path;
            DataBaseFilePathSource = data_base_file_path_source;
        }

        internal virtual void Initial()
        {
            GetLetterInfo(DataFileName, DataFilePath);

            if (File.Exists(FileUtils.MapExecutingAssemblyPath("RMeta\\RFileMetaData.xml")))
            {
                RFileMetaDatas.Initialize(File.ReadAllText(FileUtils.MapExecutingAssemblyPath("RMeta\\RFileMetaData.xml")));
                IsUnicode = (RFileMetaDatas.GetUnicode(this.LetterType) != null).ToString();
                IsBothSlides = (RFileMetaDatas.GetBothSlide(this.LetterType) != null).ToString();
                IsPruConnect = (RFileMetaDatas.GetPruConnect(this.LetterType) != null).ToString();
            }
            else
            {
                IsUnicode = "false";
                IsBothSlides = "fasle";
                IsBothSlides = "false";
            }
        }

        public void Delete() {
            File.Delete(DataFilePath + DataFileName);
        }

        public void ErrorBackup(string DataFileErrorBackupPath) {
            string filename = DataFileErrorBackupPath + DataFileName.Substring(0, DataFileName.Length - 2) + ".R";

            if (File.Exists(filename))
                File.Delete(filename);

            File.Move(DataFilePath + DataFileName, filename);
        }

        internal virtual void ImportData(string file_name, string path) {
            var file_name_path = path + file_name;
            StreamReader reader = null;

            try {
                var fileStream = new FileStream(file_name_path, FileMode.Open, FileAccess.Read, FileShare.None);
                reader = new StreamReader(fileStream);
                string line = "";
                List<string> lstCommand = new List<string>();
                while ((line = reader.ReadLine()) != null) {
                    if (line.StartsWith("#")) {
                        continue;
                    }
                    if (line.Length < 2) continue;

                    //Replace all Delimiter character (|) with (",") to prepare the SQL String,
                    //used for inserting a text line into correlative table.
                    line = line.Replace("|", "\",\"");
                    line = line.Replace("\"\"", "NULL");
                    line = line.Substring(0, line.Length - 2);

                    //line = VIQR2VNI(line);

                    if (line.Substring(0, 4) != "NULL")
                        line = "(" + this.Serial + ",\"" + line + ")";
                    else
                        line = "(" + this.Serial + "," + line + ")";

                    line = "INSERT INTO " + this.LetterType + " Values " + line;
                    lstCommand.Add(line);
                    //Ultilities.InsertData(this.DataBaseFilePath, line);
                }
                Ultilities.InsertData(this.DataBaseFilePath, lstCommand.ToArray());
                reader.Close();

                fileStream.Close();
            }
            catch (Exception ex) {
                Ultilities.Logging(String.Format("Prudential.PrintingService.BussinessLogic - Error: {0}", ex));
                try {
                    if (reader != null)
                        reader.Close();
                }
                catch {
                    throw;
                }
                throw;
            }
        }

        internal virtual void GetLetterInfo(string file_name, string path)
        {
            string series = file_name.Split('.')[0].Split('-')[1];
            var file_name_path = path + file_name;
            StreamReader reader = null;

            try {
                var fileStream = new FileStream(file_name_path, FileMode.Open, FileAccess.Read, FileShare.None);
                reader = new StreamReader(fileStream);
                string line = "";
                string[] row_data = null;

                while ((line = reader.ReadLine()) != null) {
                    if (line.StartsWith("#")) {
                        line = line.Replace("#", "");
                        row_data = line.Split('|');

                        this.LetterType = row_data[0];
                        this.PrinterName = row_data[1] == "ZPLRLT"? row_data[1] + "_a3" : (Ultilities.GetLetterTaxInvoice(this.DataBaseFilePath, row_data[0]) ? row_data[1] + "_T" : row_data[1]);
                        this.UserName = row_data[2];
                        this.Serial = series;
                        this.PrintDate = row_data[3];

                        if (!Ultilities.CompactDataBase(this.DataBaseFilePath, this.DataBaseFilePathSource))
                            Ultilities.RemoveData(this.DataBaseFilePath, this.LetterType);
                    }
                    else
                        break;
                }
                reader.Close();

                fileStream.Close();

                //int i = 0;
                //int j = 1;
                //int z = j / i;
            }
            catch (Exception ex) {
                Ultilities.Logging(String.Format("Prudential.PrintingService.BussinessLogic.Letter - Error: {0}", ex));
                SystemApp.ExceptionManual(ex);
                try {
                    if (reader != null)
                        reader.Close();
                }
                catch {
                    throw;
                }
                throw;
            }
        }
    }
}
