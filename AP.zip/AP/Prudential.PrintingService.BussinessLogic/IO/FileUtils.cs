﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;

namespace Prudential.PrintingService.BussinessLogic.IO {
    public class FileUtils {
        public static void Copy(string sourceFileName, string destinationDirectory) {
            string fileName = Path.GetFileName(sourceFileName);
            File.Copy(sourceFileName, Path.Combine(destinationDirectory, fileName), true);
        }
        public static string MapExecutingAssemblyPath(string relativePath) {
            Uri uri = new Uri(Assembly.GetExecutingAssembly().CodeBase);
            var appDirectory = Path.GetDirectoryName(uri.LocalPath);
            return Path.GetFullPath(Path.Combine(appDirectory, relativePath));
        }
    }
}
