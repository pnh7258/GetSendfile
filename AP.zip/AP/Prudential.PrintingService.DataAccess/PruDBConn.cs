﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;

namespace Prudential.PrintingService.DataAccess
{
    public class PruDBConn
    {
        private static string _ConnString = string.Empty;

        public static string ConnString
        {
            get
            {
                if (_ConnString == string.Empty)
                {
                    var database = ConfigurationManager.AppSettings["DataBasePath"];
                    _ConnString = @"Provider=Microsoft.Jet.OleDb.4.0;Data Source=" + database + ";Persist Security Info=False;";
                }
                return _ConnString;
            }
        }
    }
}
