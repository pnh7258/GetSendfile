﻿using System;
using System.Collections;
using System.Data;
using System.Reflection;
using System.Globalization;
using System.Data.SqlClient;
namespace Prudential.PrintingService.DataAccess
{
	/// <summary>
	/// TnDataHelper.
	/// </summary>
	public class DataHelper
	{
		/// <summary>
		/// 
		/// </summary>
		public static readonly DateTime NullDateValue = new DateTime(2999, 1, 1);

		/// <summary>
		/// 
		/// </summary>
		/// <param name="value"></param>
		/// <param name="nullValue"></param>
		/// <param name="valueIfNull"></param>
		/// <returns></returns>
		public static object GetValueFrom(
			object value, 
			object nullValue,
			object valueIfNull) 
		{
			if (object.Equals(value, nullValue)) 
			{
				return valueIfNull;
			}
			return value;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="value"></param>
		/// <param name="valueIfNull"></param>
		/// <returns></returns>
		public static object GetValueFrom(
			object value, 
			object valueIfNull) {

			return GetValueFrom(value, null, valueIfNull);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="record"></param>
		/// <param name="fieldName"></param>
		/// <param name="valueIfNull"></param>
		/// <returns></returns>
		public static object GetValueFrom(
			IDataRecord record, 
			string fieldName,
			object valueIfNull) 
		{
			return GetValueFrom(record[fieldName], DBNull.Value, valueIfNull);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="record"></param>
		/// <param name="fieldName"></param>
		/// <param name="valueIfNull"></param>
		/// <returns></returns>
		public static object GetValueFrom(
			DataRow record, 
			string fieldName,
			object valueIfNull) 
		{
			return GetValueFrom(record[fieldName], DBNull.Value, valueIfNull);
		}
		/// <summary>
		/// 
		/// </summary>
		/// <param name="record"></param>
		/// <param name="fieldName"></param>
		/// <returns></returns>
		public static object GetValueFrom(
			IDataRecord record, 
			string fieldName) 
		{
			return GetValueFrom(record[fieldName], DBNull.Value, null);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="record"></param>
		/// <param name="fieldName"></param>
		/// <returns></returns>
		public static object GetValueFrom(
			DataRow record, 
			string fieldName) 
		{
			return GetValueFrom(record[fieldName], DBNull.Value, null);
		}
		/// <summary>
		/// 
		/// </summary>
		/// <param name="row"></param>
		/// <param name="fieldName"></param>
		/// <param name="value"></param>
		public static void SetValueTo(
			DataRow row, 
			string fieldName,
			object value) 
		{
			row[fieldName] = GetValueFrom(value, null, DBNull.Value);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="row"></param>
		/// <param name="fieldName"></param>
		/// <param name="value"></param>
		/// <param name="valueIfNull"></param>
		public static void SetValueTo(
			DataRow row, 
			string fieldName,
			object value,
			object valueIfNull) 
		{
			row[fieldName] = GetValueFrom(value, null, valueIfNull);
		}
		/// <summary>
		/// Get default(empty) constructor info of a type
		/// </summary>
		/// <param name="type"></param>
		/// <returns></returns>
		public static ConstructorInfo GetConstructor(Type type) 
		{
			return type.GetConstructor(Type.EmptyTypes);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="dateTimeStr"></param>
		/// <param name="format"></param>
		/// <returns></returns>
		public static DateTime ParseDateTime(string dateTimeStr, string format) 
		{
			try {
				return DateTime.ParseExact(
					dateTimeStr, 
					format, 
					CultureInfo.CurrentCulture.DateTimeFormat);
			} catch {}
			return NullDateValue;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="dateTimeStr"></param>
		/// <returns></returns>
		public static string ParseDateTimeToNormal(string dateTimeStr) {
			int pos = dateTimeStr.IndexOf('/');
			if (pos==4)
				return ParseDateTime(dateTimeStr, "yyyy/MM/dd", "dd/MM/yyyy");
			return dateTimeStr;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="dateTimeStr"></param>
		/// <returns></returns>
		public static string ParseDateTimeToInverse(string dateTimeStr) {
			return ParseDateTime(dateTimeStr, "dd/MM/yyyy", "yyyy/MM/dd");
		}
		/// <summary>
		/// 
		/// </summary>
		/// <param name="dateTimeStr"></param>
		/// <param name="sourceFormat"></param>
		/// <param name="destFormat"></param>
		/// <returns></returns>
		public static string ParseDateTime(string dateTimeStr, string sourceFormat, string destFormat) {
			string ret = "";
			try {
				DateTime dt = DateTime.ParseExact(
					dateTimeStr, 
					sourceFormat, 
					CultureInfo.CurrentCulture.DateTimeFormat);
				ret = dt.ToString(destFormat);
			} catch {}
			return ret;
		}


		/// <summary>
		/// 
		/// </summary>
		/// <param name="time"></param>
		/// <returns></returns>
		public static bool IsNullValue(DateTime time) {
			return (time == NullDateValue);
		}

		/// <summary>
		/// Check the column is a foreignKey or not
		/// </summary>
		/// <param name="column"></param>
		/// <param name="parentColumn"></param>
		/// <returns></returns>
		public static bool IsForeignKey(DataColumn column, out DataColumn parentColumn) {
			parentColumn = null;
			foreach (DataRelation rel in column.Table.ParentRelations) {
				if (
					rel.ChildColumns.Length==1 &&
					rel.ParentColumns.Length==1 &&
					rel.ChildColumns[0] == column) {
					parentColumn = rel.ParentColumns[0];
					return true;
				}
			}

			return false;
		}


		/// <summary>
		/// Check the column is a PrimaryKey or not
		/// </summary>
		/// <param name="column"></param>
		/// <returns></returns>
		public static bool IsPrimaryKey(DataColumn column) {
			return column.Table.PrimaryKey!=null &&
				column.Table.PrimaryKey.Length==1 &&
				column.Table.PrimaryKey[0].ColumnName==column.ColumnName;
		}

		/// <summary>
		/// Get the default value of the type replace for the null value
		/// </summary>
		/// <param name="type"></param>
		/// <returns></returns>
		public static object GetDefaultValue(Type type) {
			if (type==typeof(string)) {
				return string.Empty;
			}
			else if (type==typeof(DateTime)) {
				return NullDateValue;
			}
			else if (type==typeof(double)) {
				return (double)0;
			}
			else if (type==typeof(float)) {
				return (float)0;
			}
			else if (type==typeof(Decimal)) {
				return (Decimal)0;
			}
			else if (type==typeof(long)) {
				return (long)0;
			}
			else if (type==typeof(ulong)) {
				return (ulong)0;
			}
			else if (type==typeof(int)) {
				return (int)0;
			}
			else if (type==typeof(uint)) {
				return (uint)0;
			}
			else if (type==typeof(short)) {
				return (short)0;
			}
			else if (type==typeof(ushort)) {
				return (ushort)0;
			}
			else if (type==typeof(byte)) {
				return (byte)0;
			}
			else if (type==typeof(bool)) {
				return false;
			}
			return null;
		}


		/// <summary>
		/// 
		/// </summary>
		/// <param name="type"></param>
		/// <returns></returns>
		public static string GetDefaultValueExp(Type type) {
			if (type==typeof(string)) {
				return "string.Empty";
			}
			else if (type==typeof(DateTime)) {
				return "TnDataHelper.NullDateValue";
			}
			else if (type==typeof(double)) {
				return "(double)0";
			}
			else if (type==typeof(float)) {
				return "(float)0";
			}
			else if (type==typeof(Decimal)) {
				return "(Decimal)0";
			}
			else if (type==typeof(long)) {
				return "(long)0";
			}
			else if (type==typeof(ulong)) {
				return "(ulong)0";
			}
			else if (type==typeof(int)) {
				return "(int)0";
			}
			else if (type==typeof(uint)) {
				return "(uint)0";
			}
			else if (type==typeof(short)) {
				return "(short)0";
			}
			else if (type==typeof(ushort)) {
				return "(ushort)0";
			}
			else if (type==typeof(byte)) {
				return "(byte)0";
			}
			else if (type==typeof(bool)) {
				return "false";
			}
			return "null";
		}

		/// <summary>
		/// Map from System Type to DbType
		/// </summary>
		/// <param name="type"></param>
		/// <returns></returns>
		public static DbType MapType(Type type) {
			if (type==typeof(string)) {
				return DbType.String;
			}
			else if (type==typeof(DateTime)) {
				return DbType.DateTime;
			}
			else if (type==typeof(double)) {
				return DbType.Double;
			}
			else if (type==typeof(float)) {
				return DbType.Single;
			}
			else if (type==typeof(Decimal)) {
				return DbType.Decimal;
			}
			else if (type==typeof(long)) {
				return DbType.Int64;
			}
			else if (type==typeof(ulong)) {
				return DbType.UInt64;
			}
			else if (type==typeof(int)) {
				return DbType.Int32;
			}
			else if (type==typeof(uint)) {
				return DbType.UInt32;
			}
			else if (type==typeof(short)) {
				return DbType.Int16;
			}
			else if (type==typeof(ushort)) {
				return DbType.UInt16;
			}
			else if (type==typeof(byte)) {
				return DbType.Byte;
			}
			else if (type==typeof(bool)) {
				return DbType.Boolean;
			}
			else if (type==typeof(byte[])) {
				return DbType.Binary;
			}
			return DbType.String;
		}



		/// <summary>
		/// 
		/// </summary>
		/// <param name="index"></param>
		/// <param name="options"></param>
		/// <returns></returns>
		public static object Choose(int index, params object[] options) {
			return options[index];
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="index"></param>
		/// <param name="options"></param>
		/// <returns></returns>
		public static string Choose(int index, params string[] options) {
			return options[index];
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="condition"></param>
		/// <param name="trueValue"></param>
		/// <param name="falseValue"></param>
		/// <returns></returns>
		public static object IIF(bool condition, object trueValue, object falseValue) {
			return condition ? trueValue : falseValue;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="condition"></param>
		/// <param name="trueValue"></param>
		/// <param name="falseValue"></param>
		/// <returns></returns>
		public static string IIF(bool condition, string trueValue, string falseValue) {
			return condition ? trueValue : falseValue;
		}


		/// <summary>
		/// Normalize the dataset
		/// </summary>
		/// <param name="ds"></param>
		public static void Normalize(DataSet ds) {
			foreach (DataTable table in ds.Tables) {
				foreach (DataColumn column in table.Columns) {
					if (!column.AutoIncrement && column.DefaultValue==null) {
						column.DefaultValue = GetDefaultValue(column.DataType);
					}
					if (!column.Unique) {
						column.AllowDBNull = true;
					}
				}
			}
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="reader"></param>
		/// <param name="table"></param>
		/// <param name="fieldCount"></param>
		/// <returns></returns>
		public static DataRow CreateNewRow(IDataReader reader, DataTable table, int fieldCount) {
			DataRow row = table.NewRow();
			for (int i=0; i<fieldCount; i++) {
				row[i] = reader[i];
			}
			return row;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="reader"></param>
		/// <param name="table"></param>
		/// <returns></returns>
		public static DataRow CreateNewRow(IDataReader reader, DataTable table) {
			return CreateNewRow(reader, table, reader.FieldCount);

		}
		/// <summary>
		/// 
		/// </summary>
		/// <param name="reader"></param>
		/// <param name="table"></param>
		/// <param name="rowType"></param>
		/// <returns></returns>
		public static Array CreateNewRows(IDataReader reader, DataTable table, Type rowType) {
			int fieldCount = reader.FieldCount;
			ArrayList list = new ArrayList();
			while (reader.Read()) {
				DataRow row = table.NewRow();
				for (int i=0; i<fieldCount; i++) {
					row[i] = reader[i];
				}
				list.Add(row);
			}
			return list.ToArray(rowType);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="table"></param>
		/// <param name="condition"></param>
		/// <returns></returns>
		public static DataRow SelectRow(DataTable table, string condition) {
			DataRow[] rows = table.Select(condition);
			if (rows!=null && rows.Length>0)
				return rows[0];
			return null;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="line"></param>
		/// <param name="delim"></param>
		/// <param name="trimParts"></param>
		/// <returns></returns>
		public static string[] SplitText(string line, char[] delim, bool trimParts) {
			string[] parts = line.Split(delim);
			if (parts!=null && parts.Length>0) {
				if (trimParts) {
					for (int i=0; i<parts.Length; i++) {
						parts[i] = parts[i].Trim();
					}
				}
			}
			return parts;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="svalue"></param>
		/// <returns></returns>
		public static Decimal ToDecimal(string svalue) {
			try {
				return Decimal.Parse(svalue);
			} catch {}
			return 0;
		}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="svalue"></param>
        /// <returns></returns>
        public static Decimal ToDecimal(object ovalue)
        {
            try
            {
                return (decimal) ovalue;
            }
            catch { }
            return 0;
        }
		/// <summary>
		/// 
		/// </summary>
		/// <param name="svalue"></param>
		/// <returns></returns>
		public static long ToLong(string svalue) {
			try {
				return long.Parse(svalue);
			} catch {}
			return 0;
		}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="svalue"></param>
        /// <returns></returns>
        public static int ToInt(string svalue)
        {
            try
            {
                return int.Parse(svalue);
            }
            catch { }
            return 0;
        }

		/// <summary>
		/// 
		/// </summary>
		/// <param name="value"></param>
		/// <returns></returns>
		public static bool IsEmpty(string value) {
			return (value==null) || (value.Length==0);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="value"></param>
		/// <returns></returns>
		public static bool IsEmpty(decimal value) {
			return (value==0);
		}

		#region Reading Vetnamese number
		/// <summary>
		/// 
		/// </summary>
		/// <param name="numberString"></param>
		/// <returns></returns>
		static int ValInt(string numberString) {
			numberString = numberString.Trim();
			if (numberString!="")
				return int.Parse(numberString);
			return 0;
		}


		/// <summary>
		/// 
		/// </summary>
		/// <param name="numberString"></param>
		/// <returns></returns>
		public static string ReadVietNumber(string numberString) {
			string chuso;
			int kitucanthem;
			int dodai ;

			string baso ;
			int n ;
			bool kgtram ;
			string c;
    
			numberString.Trim();
			dodai = numberString.Length;
			kitucanthem = 3 - (dodai % 3);
			chuso = new string('0', kitucanthem) + numberString;

			n = chuso.Length/3;
			//'Me.txtXUATCHUOI = ""

			c = "";
			for (int i=0; i<chuso.Length-2; i+=3) {
				kgtram = ValInt(chuso.Substring(0, i).Trim())>0;
				baso = chuso.Substring(i, 3);
				c = c + " " + 
					DOC3SO(baso, kgtram).Trim() + " " + 
					IIF(ValInt(baso)==0, "", HANG(n));
				if (n > 0) {
					n = n - 1;
				}
			}
			
			//c = c.Trim().ToUpper();
			// Modified 14 July, 2006 by Vo Minh Tam
			c = c + " đồng chẵn";
			c = c.Trim().ToUpper();

			return c;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="baso"></param>
		/// <param name="kgtram"></param>
		/// <returns></returns>
		static string DOC3SO(string baso , bool kgtram) {
			string ch_tr ,ch_ch, ch_dv;
			int tr , ch , dv ;
			
			dv = ValInt(baso.Substring(2, 1));
			ch = ValInt(baso.Substring(1, 1));
			tr = ValInt(baso.Substring(0, 1));

			ch_tr = IIF(kgtram && (tr==0) && (ch>0 || dv>0), "không trăm", IIF(tr>0, DOC1SO(tr) + " trăm", ""));
			ch_ch = IIF(ch>1, DOC1SO(ch) + " mươi", IIF(ch==1, "mười", IIF((dv>0 && tr>0) || (tr==0 && kgtram && dv>0), "lẻ", "")));
			ch_dv = IIF(dv==1 && ch>1, "mốt", IIF(dv==5 && ch>0, "lăm", DOC1SO(dv)));

			return ch_tr + " " + ch_ch + " " + ch_dv;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="num"></param>
		/// <returns></returns>
		static string DOC1SO(int num) {
			if (num > 0) {
				return Choose(num-1, "một", "hai", "ba", "bốn", "năm", "sáu", "bảy", "tám", "chín");
			}
			return "";
		}
		/// <summary>
		/// 
		/// </summary>
		/// <param name="so"></param>
		/// <returns></returns>
		static string HANG(int so ) {
			return Choose(so-1, "", "ngàn", "triệu", "tỉ", "ngàn tỉ", "triệu tỉ", "tỉ tỉ");
		}
		#endregion


		/// <summary>
		/// 
		/// </summary>
		/// <param name="rows"></param>
		public static void DeleteAllRows(IList rows) {
			if (rows==null || rows.Count==0)
				return;

			int count = rows.Count;
			for (int i=0; i<count; i++) {
				try  {
					((DataRow)rows[i]).Delete();
				} 
				catch {}
			}
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="ds"></param>
		/// <param name="tableName"></param>
		/// <param name="filter"></param>
		/// <param name="fieldName"></param>
		/// <param name="fieldValue"></param>
		public static void SetAllRows(DataSet ds, string tableName, string filter, string fieldName, object fieldValue) {
			if (!ds.Tables.Contains(tableName))
				return;

			DataTable table = ds.Tables[tableName];
			DataRow[] rows = table.Select(filter);
			if (rows==null || rows.Length==0)
				return;

			for (int i=0; i<rows.Length; i++) {
				try  {
					rows[i][fieldName] = fieldValue;
				} 
				catch {}
			}
		}

        #region Methods
               
        /// <summary>
        /// Gets connection string to master database
        /// </summary>
        /// <param name="connetionString">A connection string</param>
        /// <returns></returns>
        public static string GetMasterConnectionString(string connetionString)
        {
            var builder = new SqlConnectionStringBuilder(connetionString);
            builder.InitialCatalog = "master";
            return builder.ToString();
        }

        /// <summary>
        /// Gets database name from connection string
        /// </summary>
        /// <param name="connetionString">A connection string</param>
        /// <returns></returns>
        public static string GetDatabaseName(string connetionString)
        {
            var builder = new SqlConnectionStringBuilder(connetionString);
            return builder.InitialCatalog;
        }
              

        /// <summary>
        /// Gets a boolean value of a data reader by a column name
        /// </summary>
        /// <param name="rdr">Data reader</param>
        /// <param name="columnName">Column name</param>
        /// <returns>A boolean value</returns>
        public static bool GetBoolean(IDataReader rdr, string columnName)
        {
            int index = rdr.GetOrdinal(columnName);
            if (rdr.IsDBNull(index))
            {
                return false;
            }
            return Convert.ToBoolean(rdr[index]);
        }

        /// <summary>
        /// Gets a byte array of a data reader by a column name
        /// </summary>
        /// <param name="rdr">Data reader</param>
        /// <param name="columnName">Column name</param>
        /// <returns>A byte array</returns>
        public static byte[] GetBytes(IDataReader rdr, string columnName)
        {
            int index = rdr.GetOrdinal(columnName);
            if (rdr.IsDBNull(index))
            {
                return null;
            }
            return (byte[])rdr[index];
        }

        /// <summary>
        /// Gets a datetime value of a data reader by a column name
        /// </summary>
        /// <param name="rdr">Data reader</param>
        /// <param name="columnName">Column name</param>
        /// <returns>A date time</returns>
        [Obsolete("This method will be removed from future Versions. Use GetUtcDateTime", true)]
        public static DateTime GetDateTime(IDataReader rdr, string columnName)
        {
            int index = rdr.GetOrdinal(columnName);
            if (rdr.IsDBNull(index))
            {
                return DateTime.MinValue;
            }
            return (DateTime)rdr[index];
        }

        /// <summary>
        /// Gets an UTC datetime value of a data reader by a column name
        /// </summary>
        /// <param name="rdr">Data reader</param>
        /// <param name="columnName">Column name</param>
        /// <returns>A date time</returns>
        public static DateTime GetUtcDateTime(IDataReader rdr, string columnName)
        {
            int index = rdr.GetOrdinal(columnName);
            if (rdr.IsDBNull(index))
            {
                return DateTime.MinValue;
            }
            return DateTime.SpecifyKind((DateTime)rdr[index], DateTimeKind.Utc);
        }

        /// <summary>
        /// Gets a nullable datetime value of a data reader by a column name
        /// </summary>
        /// <param name="rdr">Data reader</param>
        /// <param name="columnName">Column name</param>
        /// <returns>A date time if exists; otherwise, null</returns>
        [Obsolete("This method will be removed from future Versions. Use GetUtcDateTime", true)]
        public static DateTime? GetNullableDateTime(IDataReader rdr, string columnName)
        {
            int index = rdr.GetOrdinal(columnName);
            if (rdr.IsDBNull(index))
            {
                return null;
            }
            return (DateTime)rdr[index];
        }

        /// <summary>
        /// Gets a nullable UTC datetime value of a data reader by a column name
        /// </summary>
        /// <param name="rdr">Data reader</param>
        /// <param name="columnName">Column name</param>
        /// <returns>A date time if exists; otherwise, null</returns>
        public static DateTime? GetNullableUtcDateTime(IDataReader rdr, string columnName)
        {
            int index = rdr.GetOrdinal(columnName);
            if (rdr.IsDBNull(index))
            {
                return null;
            }
            return DateTime.SpecifyKind((DateTime)rdr[index], DateTimeKind.Utc);
        }

        /// <summary>
        /// Gets a decimal value of a data reader by a column name
        /// </summary>
        /// <param name="rdr">Data reader</param>
        /// <param name="columnName">Column name</param>
        /// <returns>A decimal value</returns>
        public static decimal GetDecimal(IDataReader rdr, string columnName)
        {
            int index = rdr.GetOrdinal(columnName);
            if (rdr.IsDBNull(index))
            {
                return decimal.Zero;
            }
            return Convert.ToDecimal(rdr[index]);
        }

        /// <summary>
        /// Gets a double value of a data reader by a column name
        /// </summary>
        /// <param name="rdr">Data reader</param>
        /// <param name="columnName">Column name</param>
        /// <returns>A double value</returns>
        public static double GetDouble(IDataReader rdr, string columnName)
        {
            int index = rdr.GetOrdinal(columnName);
            if (rdr.IsDBNull(index))
            {
                return 0.0;
            }
            return (double)rdr[index];
        }

        /// <summary>
        /// Gets a GUID value of a data reader by a column name
        /// </summary>
        /// <param name="rdr">Data reader</param>
        /// <param name="columnName">Column name</param>
        /// <returns>A GUID value</returns>
        public static Guid GetGuid(IDataReader rdr, string columnName)
        {
            int index = rdr.GetOrdinal(columnName);
            if (rdr.IsDBNull(index))
            {
                return Guid.Empty;
            }
            return (Guid)rdr[index];
        }

        /// <summary>
        /// Gets an integer value of a data reader by a column name
        /// </summary>
        /// <param name="rdr">Data reader</param>
        /// <param name="columnName">Column name</param>
        /// <returns>An integer value</returns>
        public static int GetInt(IDataReader rdr, string columnName)
        {
            int index = rdr.GetOrdinal(columnName);
            if (rdr.IsDBNull(index))
            {
                return 0;
            }
            return (int)rdr[index];
        }

        /// <summary>
        /// Gets a nullable integer value of a data reader by a column name
        /// </summary>
        /// <param name="rdr">Data reader</param>
        /// <param name="columnName">Column name</param>
        /// <returns>A nullable integer value</returns>
        public static int? GetNullableInt(IDataReader rdr, string columnName)
        {
            int index = rdr.GetOrdinal(columnName);
            if (rdr.IsDBNull(index))
            {
                return null;
            }
            return (int)rdr[index];
        }

        /// <summary>
        /// Gets a string of a data reader by a column name
        /// </summary>
        /// <param name="rdr">Data reader</param>
        /// <param name="columnName">Column name</param>
        /// <returns>A string value</returns>
        public static string GetString(IDataReader rdr, string columnName)
        {
            int index = rdr.GetOrdinal(columnName);
            if (rdr.IsDBNull(index))
            {
                return string.Empty;
            }
            return (string)rdr[index];
        }
        #endregion
    }
}

