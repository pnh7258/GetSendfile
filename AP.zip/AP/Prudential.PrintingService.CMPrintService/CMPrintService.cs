﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Timers;


namespace Prudential.PrintingService.CMPrintService
{
    partial class CMPrintService : ServiceBase
    {
        private System.Timers.Timer timer;
        public CMPrintService()
        {
            // Thiết lập thuộc tính ServiceBase.ServiceName.
            ServiceName = "CMPrintService";
            // Cấu hình các thông điệp điều khiển.
            CanStop = true;
            CanPauseAndContinue = true;
            // Cấu hình việc ghi các sự kiện quan trọng vào
            // nhật ký Application.
            AutoLog = true;
        }
        private void PrintingFire(object sender, ElapsedEventArgs e)
        {
            try
            {
                timer.Stop();
                EventLog.WriteEntry(String.Format("CMPrintService firing"));
                //new Prudential.PrintingService.Engine.Process.Process().Start("Prudential.PrintingService.BussinessLogic.VNLetter");
            }
            catch (Exception ex)
            {
                EventLog.WriteEntry(ex.Message);
            }
        }

        protected override void OnStart(string[] args)
        {
            double interval;
            try
            {
                interval = System.Double.Parse(args[0]);
                interval = Math.Max(1000, interval);
            }
            catch
            {
                interval = 5000;
            }
            EventLog.WriteEntry(String.Format("CMPrintService starting. " +
            "Writing log entries every {0} milliseconds...", interval));

            timer = new Timer();
            timer.Interval = interval;
            timer.AutoReset = true;
            timer.Elapsed += new ElapsedEventHandler(PrintingFire);
            timer.Start();
        }

        protected override void OnStop()
        {
            EventLog.WriteEntry("CMPrintService stopping...");
            timer.Stop();

            timer.Dispose();
            timer = null;
        }

        protected override void OnPause()
        {
            if (timer != null)
            {
                EventLog.WriteEntry("CMPrintService pausing...");
                timer.Stop();
            }
        }

        protected override void OnContinue()
        {
            if (timer != null)
            {
                EventLog.WriteEntry("CMPrintService resuming...");
                timer.Start();
            }
        }
    }
}
