﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Management;

namespace Prudential.PrintingService.AppPrint
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome CM Archive!");
            /*
            Prudential.PrintingService.Engine.Process.Process proc = new Engine.Process.Process();
            //proc.Start("Prudential.PrintingService.BussinessLogic.CAMLetter");
            proc.Start("Prudential.PrintingService.BussinessLogic.VNLetter");
                       */
            Prudential.PrintingService.Engine.Process.Comsumer proc = new Engine.Process.Comsumer();
            proc.AssemblyLetter = "Prudential.PrintingService.BussinessLogic.VNLetter";
            proc.Start();
        }
    }
}
