﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;

namespace Prudential.VNPrint {
    partial class VNPrintServices : ServiceBase {
        VNPrintApplication app = new VNPrintApplication();

        public VNPrintServices() {
            InitializeComponent();
            
        }

        public void Start(string[] args) {
            base.OnStart(args);
        }

        protected override void OnStart(string[] args) {
            try {
                app = new VNPrintApplication();
                app.Initialize();
                app.Run();
            }
            catch (Exception e) {
            }
        }

        protected override void OnStop() {
            app.Stop();
            // TODO: Add code here to perform any tear-down necessary to stop your service.
        }
    }
}
