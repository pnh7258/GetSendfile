﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prudential.VNPrint
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        //[STAThread]
        static void Main(params string[] args)
        {
            KillProcess();
            //Application.EnableVisualStyles();
            //Application.SetCompatibleTextRenderingDefault(false);
            //Application.Run(new VNPrint());

            //VNPrintServices vNPrintServices = new VNPrintServices();
            //if (!Environment.UserInteractive) {
            //    var servicesToRun = new ServiceBase[] { vNPrintServices };
            //    ServiceBase.Run(servicesToRun);
            //    return;
            //}
            //else {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new VNPrint());
                //vNPrintServices.Start(args);
            //}
            //Console.WriteLine("Closing");
        }

        static void KillProcess() {
            Process currentpocess = Process.GetCurrentProcess();
            Process [] proc = Process.GetProcessesByName("Prudential.VNPrint");
            foreach (var item in proc) {
                if (item.Id != currentpocess.Id) {
                    item.Kill();
                }
            }
        }
    }
}
