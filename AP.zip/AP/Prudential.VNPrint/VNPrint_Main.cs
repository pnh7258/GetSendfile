﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.Collections.Specialized;
using System.IO;
using System.Configuration;
using System.Threading;
using Prudential.PrintingService.Engine;
using Prudential.PrintingService.BussinessLogic.RMeta;
using Prudential.PrintingService.BussinessLogic.IO;
using Prudential.PrintingService.BussinessLogic;

namespace Prudential.VNPrint
{
    public partial class VNPrint : Form
    {
        public VNPrint()
        {
            InitializeComponent();
            label1.Text = "";
            //start timer
            timer1.Start();

            // Compact DB
            //DeleteAllDB();

            //start process printing
            ProcessPrinting();

            // Replace File l => R
            btnReplace_Click(false);
        }

        static Queue thread1_queue = Queue.Synchronized(new Queue());
        static Queue thread2_queue = Queue.Synchronized(new Queue());
        static Queue thread3_queue = Queue.Synchronized(new Queue());
        static Queue thread4_queue = Queue.Synchronized(new Queue());
        static Queue thread5_queue = Queue.Synchronized(new Queue());
        static Queue thread6_queue = Queue.Synchronized(new Queue());
        static Queue thread7_queue = Queue.Synchronized(new Queue());
        static Queue thread8_queue = Queue.Synchronized(new Queue());
        static Queue thread9_queue = Queue.Synchronized(new Queue());
        static string PathFile;
        static Queue GetQueue(string thread_name)
        {
            switch (thread_name)
            {
                case "Thread1Config":
                    return thread1_queue;
                case "Thread2Config":
                    return thread2_queue;
                case "Thread3Config":
                    return thread3_queue;
                case "Thread4Config":
                    return thread4_queue;
                case "Thread5Config":
                    return thread5_queue;
                case "Thread6Config":
                    return thread6_queue;
                case "Thread7Config":
                    return thread7_queue;
                case "Thread8Config":
                    return thread8_queue;
                case "Thread9Config":
                    return thread9_queue;
                default:
                    return null;
            }
        }

        public static void ProcessPrinting()
        {
            try
            {
                string data_file_path = "";
                string database_file_path = "";
                string database_file_path_source = "";
                string report_path = "";
                string data_file_error_backup_path = "";
                string assembly_letter = "";
                string is_email_alert = "";
                string smtp_server = "";
                string smtp_port = "";
                string email_alert_from = "";
                string email_alert_to = "";
                NameValueCollection printer_config_list = new NameValueCollection();

                //RFileMetaDatas.Initialize(File.ReadAllText(FileUtils.MapExecutingAssemblyPath("RMeta\\RFileMetaData.xml")));


                //COMMON
                //var smtpconfigs = ConfigurationManager.GetSection("SmtpConfig") as NameValueCollection;
                //if (smtpconfigs != null)
                //{
                //    is_email_alert = smtpconfigs["IsEmailAlert"];
                //    smtp_server = smtpconfigs["SmtpServer"];
                //    smtp_port = smtpconfigs["SmtpPort"];
                //    email_alert_from = smtpconfigs["EmailAlertFrom"];
                //    email_alert_to = smtpconfigs["EmailAlertTo"];
                //}

                printer_config_list = ConfigurationManager.GetSection("PrinterConfig") as NameValueCollection;
                List<string> other_rs = new List<string>();

                string dbCompat = ConfigurationManager.AppSettings["DataBasePathSource"];

                //THREAD COMSUMER
                var threadconfigs = ConfigurationManager.GetSection("ThreadConfig") as NameValueCollection;
                foreach (string config in threadconfigs)
                {
                    var threadconfig = ConfigurationManager.GetSection(config) as NameValueCollection;
                    if (threadconfig != null)
                    {
                        data_file_path = threadconfig["DataFilePath"];
                        database_file_path = threadconfig["DataBasePath"];
                        PathFile = data_file_path;
                        report_path = threadconfig["ReportPath"];
                        data_file_error_backup_path = threadconfig["DataFileErrorBackupPath"];
                        assembly_letter = threadconfig["AssemblyLetter"];

                        other_rs.AddRange(threadconfig["FileR"].Split(';'));

                        var consumer = new Prudential.PrintingService.Engine.Process.Comsumer(GetQueue(config));
                        consumer.AssemblyLetter = assembly_letter;
                        consumer.DataFileErrorBackupPath = data_file_error_backup_path;
                        consumer.DataFilePath = data_file_path;
                        consumer.DataBaseFilePath = database_file_path;
                        consumer.DataBaseFilePathSource = dbCompat;

                        consumer.ReportPath = report_path;
                        consumer.PrinterConfigList = printer_config_list;
                        consumer.IsEmailAlert = is_email_alert;
                        consumer.EmailAlertFrom = email_alert_from;
                        consumer.EmailAlertTo = email_alert_to;
                        consumer.SmtpPort = smtp_port;
                        consumer.SmtpServer = smtp_server;
                        //consumer.rFiles = RFileMetaDatas.GetList();

                        Thread consumer_thread = new Thread(new ThreadStart(consumer.Start));
                        consumer_thread.Start();


                    }
                }
                Thread thread = new Thread(() => Producer(data_file_path, other_rs, ConfigurationManager.GetSection("ThreadConfig") as NameValueCollection));
                thread.Start();

            }
            catch (Exception ex)
            {
                string mess = ex.Message.ToString();
                Common.Logging(String.Format("VNPrint_Main - ProcessPrinting: {0} \n{1}", ex.Message, ex));

                // Auto Laught after 1'
                Thread.Sleep(60000);
                ProcessPrinting();
            }
        }

        public static void Producer(string data_file_path, List<string> other_rs, NameValueCollection threadconfigs)
        {
            try
            {
                string[] file_rs;
                string first_filename;
                string filename_new;

                List<string> ArrExist = new List<string>();
                //int iCheckOut = 0;
                while (true)
                {
                    //iCheckOut++;
                    //if (iCheckOut == 30) {
                    //    iCheckOut = 0;
                    //    Common.Logging("VNPrint Running...!!!");
                    //}

                    string[] filenames = Directory.GetFiles(data_file_path, "*.R").OrderBy(d => new FileInfo(d).CreationTime).Select(f => Path.GetFileName(f)).ToArray();
                    if (filenames.Count() > 0) {
                        Common.Logging(String.Format("Find {0} files *.R: ", filenames.Count()));

                        foreach (string filename in filenames) {
                            filename_new = filename.Substring(0,filename.Length - 2)  + ".l";
                            try {
                                if (File.Exists(data_file_path + filename_new))
                                    File.Delete(data_file_path + filename_new);
                                File.Move(data_file_path + filename, data_file_path + filename_new);
                            }
                            catch (Exception ex) {
                                Common.Logging(String.Format("VNPrint_Main - Producer: {0} \n{1}", ex.Message, ex));
                                continue;
                            }

                            first_filename = filename_new.Split('-')[0];

                            try {
                                foreach (string config in threadconfigs) {
                                    var threadconfig = ConfigurationManager.GetSection(config) as NameValueCollection;
                                    if (threadconfig != null) {
                                        file_rs = threadconfig["FileR"].Split(';');

                                        foreach (string file_r in file_rs) {
                                            if (file_r == "Other") {
                                                if (other_rs.Contains(first_filename) == false) {
                                                    if (!GetQueue(config).Contains(filename_new)) {
                                                        GetQueue(config).Enqueue(filename_new);
                                                        Console.WriteLine(String.Format("Push Thread {0} File {1}", config, filename_new));
                                                    }
                                                }
                                            }

                                            if (first_filename.Equals(file_r) == true) {
                                                if (!GetQueue(config).Contains(filename_new)) {
                                                    GetQueue(config).Enqueue(filename_new);
                                                    Console.WriteLine(String.Format("Push Thread {0} File {1}", config, filename_new));
                                                }
                                            }
                                        }
                                    }

                                }
                            }
                            catch {

                            }
                        }
                    }
                    Thread.Sleep(1000);
                   
                }
            }
            catch (Exception ex)
            {
                string mess = ex.Message.ToString();
                Common.Logging(String.Format("VNPrint_Main - Producer: {0} \n{1}", ex.Message, ex));
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                label1.Text = String.Format("{0:HH:mm:ss}", DateTime.Now);
            }
            catch (Exception ex)
            {
                string mess = ex.Message.ToString();
            }
        }

        private void VNPrint_FormClosed(object sender, FormClosedEventArgs e)
        {
            try
            {
                System.Diagnostics.Process[] allProcs = System.Diagnostics.Process.GetProcesses();
                foreach (System.Diagnostics.Process proc in allProcs)
                {
                    if (proc.ProcessName.Contains("Prudential.VNPrint"))
                    {
                        proc.Kill();
                    }
                }
            }
            catch (Exception ex)
            {
                string mess = ex.Message.ToString();
                Common.Logging("VNPrint_FormClosed: " + mess);
            }
        }

        private void button1_Click(object sender, EventArgs e) {
            if (Form.ModifierKeys == Keys.Control) {
                btnReplace_Click(true);
            }
            else {
                try {
                    //check file .R exist
                    if (CheckExistRFolder()) {
                        MessageBox.Show("Khong the compact, vi con file .R", "Warning");
                        return;
                    }

                    var threadconfigs = ConfigurationManager.GetSection("ThreadConfig") as NameValueCollection;
                    string dbCompat = ConfigurationManager.AppSettings["DataBasePathSource"];
                    string dbAccess = string.Empty;
                    foreach (string config in threadconfigs) {
                        var threadconfig = ConfigurationManager.GetSection(config) as NameValueCollection;
                        if (threadconfig != null) {
                            dbAccess = threadconfig["DataBasePath"];
                            if (File.Exists(dbAccess)) {
                                System.GC.Collect();
                                System.GC.WaitForPendingFinalizers();
                                File.Delete(dbAccess);
                            }
                            File.Copy(dbCompat, dbAccess, true);
                        }
                    }

                    MessageBox.Show("VNPrint_Compact DataBase: Successed");
                    Common.Logging("VNPrint_Compact DataBase: Successed ");
                }
                catch (Exception ex) {
                    MessageBox.Show("VNPrint_Compact DataBase_Fail: " + ex.Message);
                    string mess = ex.Message.ToString();
                    Common.Logging("VNPrint_Compact DataBase_Fail: " + ex.Message);
                }
            }
        }

        public void DeleteAllDB() {
            try {
                string dbCompat = ConfigurationManager.AppSettings["DataBasePathSource"];
                var threadconfigs = ConfigurationManager.GetSection("ThreadConfig") as NameValueCollection;
                foreach (string config in threadconfigs) {
                    var threadconfig = ConfigurationManager.GetSection(config) as NameValueCollection;
                    if (threadconfig != null) {
                        string dbAccess = threadconfig["DataBasePath"];
                        Ultilities.CompactDataBase(dbAccess, dbCompat);
                    }
                }
            }
            catch (Exception ex) {
                Common.Logging("VNPrint_Compact DataBase_Fail: " + ex.Message);
            }            
        }

        private void btnReplace_Click(bool showpopup) {
            try {
                string PdfPath = ConfigurationManager.AppSettings["PdfPath"];

                var threadconfigs = ConfigurationManager.GetSection("ThreadConfig") as NameValueCollection;
                string dataFilePatch = string.Empty;
                foreach (string config in threadconfigs) {
                    var threadconfig = ConfigurationManager.GetSection(config) as NameValueCollection;
                    if (threadconfig != null) {
                        dataFilePatch = threadconfig["DataFilePath"];
                        DirectoryInfo d = new DirectoryInfo(dataFilePatch);
                        FileInfo[] Files = d.GetFiles("*.l");
                        foreach (FileInfo file in Files) {
                            string fileNew = file.Directory + "\\" + file.Name.Substring(0, file.Name.Length - 2) + ".R";
                            if (!File.Exists(fileNew))
                                File.Move(file.FullName, fileNew);
                            else
                                File.Delete(file.FullName);
                        }
                    }
                }

                if (showpopup) MessageBox.Show("Replace file .l Success!!!");
                else Common.Logging("Replace file .l Success!!!");
                Thread.Sleep(2000);
            }
            catch (Exception ex) {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        bool CheckExistRFolder()
        {
            try
            {
                string[] filenames = Directory.GetFiles(PathFile, "*.R").Select(f => Path.GetFileName(f)).ToArray();
                if (filenames.Length > 0)
                    return true;
                return false;
            }
            catch (Exception ex)
            {
                string mess = ex.Message.ToString();
                Common.Logging("VNPrint_CheckExistRFolder: " + mess);
                return false;
            }
        }

        public static void Closed() {
            thread1_queue.Clear();
            thread2_queue.Clear();
            thread3_queue.Clear();
            thread4_queue.Clear();
            thread5_queue.Clear();
            thread6_queue.Clear();
            thread7_queue.Clear();
            thread8_queue.Clear();
            thread9_queue.Clear();
        }
    }
}
