﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Prudential.PrintingService.Engine;

namespace Prudential.VNPrint {
    public class VNPrintApplication {
        private bool initSuccess;

        public VNPrintApplication() {
            
        }

        public virtual void Initialize() { 
        
        }

        public virtual void Run() {
            VNPrint.ProcessPrinting();
        }

        public virtual void Stop() {
            VNPrint.Closed();
            //try {
            //    System.Diagnostics.Process[] allProcs = System.Diagnostics.Process.GetProcesses();
            //    foreach (System.Diagnostics.Process proc in allProcs) {
            //        if (proc.ProcessName.Contains("Prudential.VNPrint")) {
            //            proc.Kill();
            //        }
            //    }
            //}
            //catch (Exception ex) {
            //    string mess = ex.Message.ToString();
            //    Common.Logging("Stop VNPrint Service: " + mess);
            //}
        }

        #region 

        #endregion
    }
}
