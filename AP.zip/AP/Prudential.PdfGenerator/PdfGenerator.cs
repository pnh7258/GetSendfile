﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;

namespace Prudential.PdfGenerator
{
    public class PdfGenerator
    {
        public void PdfGeneration()
        {
            try
            {
                string temp = "C:\\PDF\\ZMANDL_189_00037496898.PDF@C:\\vnprint\\report\\ZAPLPC.rpt@189@00037496@ZAPLPC@Field1@20140719010951@C:\\vnprint\\spool\\vnreport.mdb";
                string[] arrArgs = temp.Split('@');
                string out_file = arrArgs[0].ToString().Trim();
                string report_name_path = arrArgs[1].ToString().Trim();
                string criterion = arrArgs[2].ToString().Trim();
                string policy_no = arrArgs[3].ToString().Trim();
                string LetterType = arrArgs[4].ToString().Trim();
                string PolicyNoField = arrArgs[5].ToString().Trim();
                string currenttime = arrArgs[6].ToString().Trim();
                string DataBaseFilePath = arrArgs[7].ToString().Trim();
                //File.WriteAllText(@"C:\vnprint\ProcessLog.txt", args[0].ToString());
                var report = new ReportDocument();
                report.Load(report_name_path, OpenReportMethod.OpenReportByDefault);
                IntialReport(report, report_name_path, criterion, policy_no, LetterType, PolicyNoField, currenttime, DataBaseFilePath);
                report.VerifyDatabase();
                report.ExportToDisk(ExportFormatType.PortableDocFormat, out_file);
                //clear
                report.Close();
                report.Dispose();
                report = null;
            }catch(Exception ex)
            {
                string mess = ex.Message.ToString();
            }
        }
        private static void IntialReport(ReportDocument report, string report_name_path, string criterion, string policy_no, string letter_type, string policy_no_field, string currenttime, string database_file_path)
        {
            foreach (Table table in report.Database.Tables)
            {
                table.Location = database_file_path;
            }

            foreach (ReportDocument subreport in report.Subreports)
            {
                foreach (Table table in subreport.Database.Tables)
                {
                    table.Location = database_file_path;
                }
            }

            //Set values
            foreach (FormulaFieldDefinition formula in report.DataDefinition.FormulaFields)
            {
                if (formula.Name == "criterion")
                {
                    formula.Text = criterion;
                }

                if (formula.Name == "currenttime")
                {
                    formula.Text = "\"" + currenttime + "\"";
                }
            }

            string currentRecordSelection = report.RecordSelectionFormula;
            string policyNoFormular = "{" + letter_type + "." + policy_no_field + "} = \"" + policy_no + "\"";

            string newRecordSelection = "";
            if (string.IsNullOrWhiteSpace(currentRecordSelection))
            {
                newRecordSelection = policyNoFormular;
            }
            else
            {
                newRecordSelection = string.Format("({0}) and ({1})", currentRecordSelection, policyNoFormular);
            }

            report.RecordSelectionFormula = newRecordSelection;
        }       
    }
}
