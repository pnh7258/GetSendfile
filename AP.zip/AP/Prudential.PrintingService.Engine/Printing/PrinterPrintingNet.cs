﻿using System;
using System.Linq;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Threading;
using Prudential.PrintingService.BussinessLogic;
using System.Configuration;
using System.IO;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System.Drawing.Printing;

// Use Crytal Report for .NET
// lbt.khang@prudential.com.vn
namespace Prudential.PrintingService.Engine.Printing
{
    public static class PrinterPrintingNet
    {
        public static bool Print(Letter letter)
        {
            try {
                using (var report = new ReportDocument()) {
                    PrintDocument pDoc = new PrintDocument();
                    PrintLayoutSettings PrintLayout = new PrintLayoutSettings();

                    string report_name_path = letter.ReportPath + letter.ReportName;
                    string criterion = letter.Serial;
                    string print_date = letter.PrintDate.Trim();
                    string[] arrTime = print_date.Split(' ');
                    string[] arrddmmyy = arrTime[0].ToString().Split('/');
                    string[] arrhhmm = arrTime[1].ToString().Split(':');
                    string currenttime = arrddmmyy[2] + arrddmmyy[1] + arrddmmyy[0] + arrhhmm[0] + arrhhmm[1] + arrhhmm[2];

                    report.Load(report_name_path, OpenReportMethod.OpenReportByDefault);
                    IntialReport(report, report_name_path, criterion, letter.LetterType, currenttime, letter.DataBaseFilePath, letter.UserName);

                    report.ExportOptions.ExportDestinationType = ExportDestinationType.NoDestination;

                    #region Truong hop can set Margin
                    //PageMargins margins;
                    //// Get the PageMargins structure and set the 
                    //// margins for the report.
                    //margins = report.PrintOptions.PageMargins;
                    //margins.bottomMargin = 0;
                    //margins.leftMargin = 0;
                    //margins.rightMargin = 0;
                    //margins.topMargin = 0;
                    //// Apply the page margins.
                    //report.PrintOptions.ApplyPageMargins(margins);
                    #endregion

                    //Select Printer
                    report.PrintOptions.PrinterName = letter.PrinterName;
                    if (report.PrintOptions.PaperSize == CrystalDecisions.Shared.PaperSize.PaperLetter)
                        report.PrintOptions.PaperSize = CrystalDecisions.Shared.PaperSize.PaperA4;
                    //report.PrintOptions.DissociatePageSizeAndPrinterPaperSize = true;

                    //if (bool.Parse(letter.IsBothSlides)) {
                    PrinterSettings printerSetting = new PrinterSettings();
                    printerSetting.PrinterName = letter.PrinterName;
                    
                    if (bool.Parse(letter.IsBothSlides) && printerSetting.CanDuplex == true) {
                        printerSetting.Duplex = Duplex.Vertical;
                        //Common.Logging("Print both to slides: true");
                    }
                    else if (bool.Parse(letter.IsBothSlides) && printerSetting.CanDuplex == false)
                        Common.Logging("Print both to slides: false");
                    /*
                    PageSettings pageSetting = new PageSettings(printerSetting);
                    if (letter.PrinterName.Contains("_T")) {
                        //report.PrintOptions.PaperOrientation = PaperOrientation.Portrait;
                        //pageSetting.Landscape = false;
                    }
                    else {
                        //report.PrintOptions.PaperOrientation = PaperOrientation.Landscape;
                        //pageSetting.Landscape = true;
                    }
                    */

                    if (letter.PrinterName.Contains("_T")) {
                        report.PrintToPrinter(1, true, 1, 1000);
                    }
                    else {
                        report.PrintToPrinter(printerSetting, new PageSettings(printerSetting), false);
                    }
                    


                    //report.PrintToPrinter(1, true, 1, 1000);
                    //}
                    //else {
                    //    report.PrintToPrinter(1, true, 1, 100);
                    //}
                    return true;
                }
            }
            catch (Exception ex)
            {
                letter.ExMessage = ex.Message;
                Common.Logging(String.Format("Error: {0}", ex));
                return false;
            }
        }

        private static void IntialReport(ReportDocument report, string report_name_path, string criterion, string letter_type, string currenttime, string database_file_path, string username)
        {
            foreach (Table table in report.Database.Tables)
            {
                table.Location = database_file_path;
            }

            foreach (ReportDocument subreport in report.Subreports)
            {
                foreach (Table table in subreport.Database.Tables)
                {
                    table.Location = database_file_path;
                }
            }

            //Set values
            foreach (FormulaFieldDefinition formula in report.DataDefinition.FormulaFields)
            {
                if (formula.Name.ToLower() == "criterion")
                {
                    formula.Text = criterion;
                }

                else if (formula.Name.ToLower() == "currenttime")
                {
                    formula.Text = currenttime;
                }

                else if (formula.Name.ToLower() == "userprint")
                {
                    formula.Text = "'" + username + "'";
                }
            }
        }        

    }
}
