﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.ReportSource;
using CrystalDecisions.Shared;
using Prudential.PrintingService.BussinessLogic;
// Use Crytal Report for .NET
// lbt.khang@prudential.com.vn
namespace Prudential.PrintingService.Engine.Printing
{
    public static class PrinterPrinting
    {
        public static void Print(Letter letter)
        {
            try
            {
                //Initial report
                string report_name_path = letter.ReportPath + letter.ReportName;
                string criterion = letter.Serial;
                string print_date = letter.PrintDate.Trim();
                string[] arrTime = print_date.Split(' ');
                string[] arrddmmyy = arrTime[0].ToString().Split('/');
                string[] arrhhmm = arrTime[1].ToString().Split(':');
                string currenttime = arrddmmyy[2] + arrddmmyy[1] + arrddmmyy[0] + arrhhmm[0] + arrhhmm[1] + arrhhmm[2];
                //  ReportDocument crReportDocument = IntialReport(letter.ReportPath + letter.ReportName, letter.Serial, currTime);
                var crReportDocument = new ReportDocument();
                crReportDocument.Load(report_name_path, OpenReportMethod.OpenReportByDefault);
                IntialReport(crReportDocument, report_name_path, criterion, letter.LetterType, currenttime, letter.DataBaseFilePath, letter.UserName);
                crReportDocument.ExportOptions.ExportDestinationType = ExportDestinationType.NoDestination;
                string out_file = "C:\\vnprint\\pdf\\" + letter.LetterType + "-" + criterion + ".pdf";
                crReportDocument.Refresh();
                crReportDocument.ExportToDisk(ExportFormatType.PortableDocFormat, out_file);
                crReportDocument.Close();
                crReportDocument.Dispose();
                crReportDocument = null;
                PrintPdfToPrinter(out_file, letter.PrinterName);             
                //delete file pdf
                //if (File.Exists(out_file))
               // {
               //     File.Delete(out_file);
              //  }
               // crReportDocument.PrintToPrinter(1, true, 1, 100);
                Common.Logging("File: " + letter.DataFilePath + letter.DataFileName + " successful - " + letter.UserName.ToString() + " - " + letter.PrinterName + " - " + DateTime.Now.ToString("dd/mm/yyyy hh:mm:ss"));
            }
            catch (Exception ex)
            {
                string mess = ex.Message.ToString();
                Common.Logging("File: " + letter.DataFilePath + letter.DataFileName + " failed - " + letter.UserName.ToString() + " - " + letter.PrinterName + " - " + mess);
            }
        }

        public static void PrintPdfToPrinter(string FilePath, string PrinterName)
        {
            try
            {
                var datapostconfigs = ConfigurationManager.GetSection("PdfConfig") as NameValueCollection;

                System.Diagnostics.Process proc = new System.Diagnostics.Process();
                proc.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                proc.StartInfo.Verb = "PrintTo";
                
                proc.StartInfo.FileName = datapostconfigs["AdobePDFProcess"];
                proc.StartInfo.Arguments = String.Format(@"/p /h {0}", FilePath);
                proc.StartInfo.UseShellExecute = false;
                proc.StartInfo.CreateNoWindow = true;
                proc.Start();
                proc.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;

                if (proc.HasExited == false) {
                    proc.WaitForExit(10000);
                }

                proc.EnableRaisingEvents = true;

                proc.Close();
                KillAdobe("AcroRd32");
            }
            catch (Exception ex)
            {
                string mess = ex.Message.ToString();
            }
        }

        private static bool KillAdobe(string name) {
            foreach (System.Diagnostics.Process clsProcess in System.Diagnostics.Process.GetProcesses().Where(
                         clsProcess => clsProcess.ProcessName.StartsWith(name))) {
                clsProcess.Kill();
                return true;
            }
            return false;
        }

        private static void IntialReport(ReportDocument report, string report_name_path, string criterion, string letter_type, string currenttime, string database_file_path, string username)
        {
            foreach (Table table in report.Database.Tables)
            {
                table.Location = database_file_path;
            }

            foreach (ReportDocument subreport in report.Subreports)
            {
                foreach (Table table in subreport.Database.Tables)
                {
                    table.Location = database_file_path;
                }
            }

            //Set values
            foreach (FormulaFieldDefinition formula in report.DataDefinition.FormulaFields)
            {
                if (formula.Name == "criterion")
                {
                    formula.Text = criterion;
                }
                else if (formula.Name == "currenttime")
                {
                    formula.Text = currenttime;
                }
                else if (formula.Name == "userprint")
                {
                    formula.Text = "'" + username + "'";
                }
            }
        }   
    }
}
