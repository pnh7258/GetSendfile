﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.ReportSource;
using CrystalDecisions.Shared;
using Prudential.PrintingService.BussinessLogic;
using System.IO;
using System.Diagnostics;

// Use Crytal Report for .NET
// lbt.khang@prudential.com.vn
namespace Prudential.PrintingService.Engine.Printing
{
    public static class PrinterPrintingEx
    {

        //public static void Print2(string report_name_path, string criterion, string printer_name)
        //{
        //    //Initial report
        //    //CRAXDRT.Report crReportDocument = IntialReport(report_name_path, criterion);

        //    int criterion_ex = int.Parse(criterion);

        //    CRAXDRT.Application crxApplication = new CRAXDRT.Application();
        //    CRAXDRT.Report crReportDocument = new CRAXDRT.Report();

        //    crReportDocument = crxApplication.OpenReport(report_name_path, CRAXDRT.CROpenReportMethod.crOpenReportByDefault);

        //    //Set values
        //    //for (int i = 1; i < 1000000; i++)
        //    //{
        //    //    if (crReportDocument.FormulaFields[i].FormulaFieldName == "criterion")
        //    //    {
        //    //        crReportDocument.FormulaFields[i].Text = criterion_ex.ToString();
        //    //        Thread.Sleep(10000);
        //    //        break;
        //    //    }
        //    //}
        //    //crReportDocument.Database.Verify();
        //    crReportDocument.PaperOrientation = CRAXDRT.CRPaperOrientation.crDefaultPaperOrientation;


        //    //Select Printer        
        //    crReportDocument.SelectPrinter("", printer_name, "");
        //    //crReportDocument.SelectPrinter("winspool", printer_name, "Ne00:");

        //    crReportDocument.ExportOptions.DestinationType = CRAXDRT.CRExportDestinationType.crEDTNoDestination;

        //    //Print   
        //    crReportDocument.ExportOptions.DestinationType = CRAXDRT.CRExportDestinationType.crEDTDiskFile;
        //    crReportDocument.ExportOptions.PDFExportAllPages = true;
        //    crReportDocument.ExportOptions.FormatType = CRAXDRT.CRExportFormatType.crEFTPortableDocFormat;
        //    crReportDocument.PaperOrientation = CRAXDRT.CRPaperOrientation.crDefaultPaperOrientation;
        //    crReportDocument.ExportOptions.DestinationType = CRAXDRT.CRExportDestinationType.crEDTNoDestination;
        //    crReportDocument.Application.OpenReport(report_name_path, CRAXDRT.CROpenReportMethod.crOpenReportByTempCopy);

        //    crReportDocument.Database.Verify();
        //    //Set values
        //    for (int i = 1; i < 1000000; i++)
        //    {
        //        if (crReportDocument.FormulaFields[i].FormulaFieldName == "criterion")
        //        {
        //            crReportDocument.FormulaFields[i].Text = criterion_ex.ToString();
        //            Thread.Sleep(10000);
        //            break;
        //        }
        //    }
        //    crReportDocument.VerifyOnEveryPrint = true;

        //    crReportDocument.Database.Verify();
        //    crReportDocument.PrintOut(false,1, false, 1, 100);

        //    crReportDocument = null;
        //    crxApplication = null;
        //}

        //public static void Print(string report_name_path, string criterion, string printer_name)
        //public static bool Print(Letter letter)
        //{
        //    try
        //    {
        //        //Initial report
        //        //CRAXDRT.Report crReportDocument = IntialReport(report_name_path, criterion);
        //        string report_name_path = letter.ReportPath + letter.ReportName;
        //        string criterion = letter.Serial;
        //        string printer_name = letter.PrinterName;
        //        string print_date = letter.PrintDate.Trim();
        //        string[] arrTime = print_date.Split(' ');
        //        string[] arrddmmyy = arrTime[0].ToString().Split('/');
        //        string[] arrhhmm = arrTime[1].ToString().Split(':');
        //        string currenttime = arrddmmyy[2] + arrddmmyy[1] + arrddmmyy[0] + arrhhmm[0] + arrhhmm[1] + arrhhmm[2];

        //        int criterion_ex = int.Parse(criterion);

        //        // Check Printer Valid
        //        if (SystemApp.CheckPrinterName(printer_name) == false)
        //        {
        //            Common.Logging(String.Format("Can't not find Printer Name {0}", printer_name));
        //            return false;
        //        }

        //        CRAXDRT.Application crxApplication = new CRAXDRT.Application();
        //        CRAXDRT.Report crReportDocument = new CRAXDRT.Report();
        //        crReportDocument = crxApplication.OpenReport(report_name_path, CRAXDRT.CROpenReportMethod.crOpenReportByDefault);
        //        //crReportDocument = crxApplication.OpenReport(report_name_path);

        //        //{
        //        //    CRAXDRT.DatabaseTables crxTables = crReportDocument.Database.Tables;
        //        //    foreach (CRAXDRT.DatabaseTable item in crxTables)
        //        //    {
        //        //        item.Location = letter.DataBaseFilePath;
        //        //    }
        //        //}

        //        //crReportDocument.Database.Verify();
        //        crReportDocument.PaperOrientation = CRAXDRT.CRPaperOrientation.crDefaultPaperOrientation;
        //        //if (letter.PrinterName.Contains("_T")) {
        //        //crReportDocument.PaperOrientation = CRAXDRT.CRPaperOrientation.crLandscape;
        //        //crReportDocument.PaperSize = CRAXDRT.CRPaperSize.crPaperA5;
        //        //}
        //        //else {
        //        //crReportDocument.PaperOrientation = CRAXDRT.CRPaperOrientation.crPortrait;
        //        //crReportDocument.PaperSize = CRAXDRT.CRPaperSize.crPaperA4;
        //        //}

        //        //Select Printer        
        //        //crReportDocument.SelectPrinter("", printer_name, "");
        //        crReportDocument.SelectPrinter("winspool", printer_name, "Ne00:");

        //        crReportDocument.ExportOptions.DestinationType = CRAXDRT.CRExportDestinationType.crEDTNoDestination;

        //        //Print
        //        crReportDocument.ExportOptions.DestinationType = CRAXDRT.CRExportDestinationType.crEDTDiskFile;
        //        crReportDocument.ExportOptions.PDFExportAllPages = true;
        //        crReportDocument.ExportOptions.FormatType = CRAXDRT.CRExportFormatType.crEFTPortableDocFormat;
        //        crReportDocument.PaperOrientation = CRAXDRT.CRPaperOrientation.crDefaultPaperOrientation;
        //        if (bool.Parse(letter.IsBothSlides))
        //        {
        //            crReportDocument.PrinterDuplex = CRAXDRT.CRPrinterDuplexType.crPRDPVertical;
        //        }
        //        crReportDocument.ExportOptions.DestinationType = CRAXDRT.CRExportDestinationType.crEDTNoDestination;
        //        crReportDocument.Application.OpenReport(report_name_path, CRAXDRT.CROpenReportMethod.crOpenReportByDefault);

        //        crReportDocument.Database.Verify();

        //        //Set values
        //        for (int i = 1; i < 1000000; i++)
        //        {
        //            if (crReportDocument.FormulaFields[i].FormulaFieldName.ToLower() == "criterion")
        //            {
        //                crReportDocument.FormulaFields[i].Text = criterion_ex.ToString();
        //                Thread.Sleep(100);
        //                break;
        //            }
        //            else if (crReportDocument.FormulaFields[i].FormulaFieldName.ToLower() == "currenttime")
        //            {
        //                crReportDocument.FormulaFields[i].Text = currenttime.ToString();
        //                Thread.Sleep(100);
        //                break;
        //            }
        //        }

        //        crReportDocument.VerifyOnEveryPrint = true;

        //        crReportDocument.Database.Verify();
        //        crReportDocument.Database.Verify();
        //        crReportDocument.Database.Verify();
        //        crReportDocument.Database.Verify();
        //        //crReportDocument.PrintOut(Type.Missing, 1, Type.Missing, 1, 1000);
        //        crReportDocument.PrintOutEx(false, 1, true, 1, 10000, null);

        //        //foreach (CRAXDRT.DatabaseTable item in crxTables)
        //        //{
        //        //    item.Location = "C:\\vnprint\\spool\\vnreport_.mdb";
        //        //}

        //        crReportDocument = null;
        //        crxApplication = null;


        //        return true;
        //    }
        //    catch (Exception ex)
        //    {
        //        letter.ExMessage = ex.Message;
        //        Common.Logging("VNPrint-Error: " + ex);
        //        if (ex.Message.Contains("Unspecified error")
        //            || ex.Message.Contains("Logon failed"))
        //        {
        //            Common.Logging("VNPrint-Error: Restart App!!!");
        //            Restart();
        //        }
        //        return false;
        //    }
        //}

        public static bool Print(Letter letter)
        {
            try
            {
                //Initial report
                //CRAXDRT.Report crReportDocument = IntialReport(report_name_path, criterion);
                string report_name_path = letter.ReportPath + letter.ReportName;
                string criterion = letter.Serial;
                string printer_name = letter.PrinterName;
                string print_date = letter.PrintDate.Trim();
                string[] arrTime = print_date.Split(' ');
                string[] arrddmmyy = arrTime[0].ToString().Split('/');
                string[] arrhhmm = arrTime[1].ToString().Split(':');
                string currenttime = arrddmmyy[2] + arrddmmyy[1] + arrddmmyy[0] + arrhhmm[0] + arrhhmm[1] + arrhhmm[2];

                int criterion_ex = int.Parse(criterion);

                // Check Printer Valid
                if (SystemApp.CheckPrinterName(printer_name) == false)
                {
                    Common.Logging(String.Format("Can't not find Printer Name {0}", printer_name));
                    return false;
                }

                CRAXDRT.Application crxApplication = new CRAXDRT.Application();
                CRAXDRT.Report crReportDocument = new CRAXDRT.Report();
                
                //CRAXDRT.SubreportObject crxSubreportObject = null; 
                //CRAXDRT.Report crxSubreport = null;
                //CRAXDRT.Sections crxSections = null;  
                //CRAXDRT.Section crxSection = null; 
                //CRAXDRT.Database crxDatabase = null; 
                //CRAXDRT.DatabaseTables crxDatabaseTables = null;


                crReportDocument = crxApplication.OpenReport(report_name_path, CRAXDRT.CROpenReportMethod.crOpenReportByDefault);
                //crReportDocument = crxApplication.OpenReport(report_name_path);
                //crxSections = crReportDocument.Sections;

                //// Set DB to report
                //{
                //    crxDatabaseTables = crReportDocument.Database.Tables;
                //    foreach (CRAXDRT.DatabaseTable item in crxDatabaseTables)
                //    {
                //        item.Location = letter.DataBaseFilePath;
                //    }
                //}

                //// Set DB to Subreport
                //foreach (CRAXDRT.Section crxSection in crxSections)
                //{
                //    foreach (object item1 in crxSection.ReportObjects)
                //    {
                //        crxSubreportObject = item1 as CRAXDRT.SubreportObject;
                //        if (crxSubreportObject != null)
                //        {
                //            crxSubreport = crxSubreportObject.OpenSubreport();
                //            crxDatabase = crxSubreport.Database;
                //            crxDatabaseTables = crxDatabase.Tables;

                //            foreach (CRAXDRT.DatabaseTable item2 in crxDatabaseTables)
                //            {
                //                item2.Location = letter.DataBaseFilePath;
                //            }
                //        }
                //    }
                //}

                //crReportDocument.Database.Verify();
                crReportDocument.PaperOrientation = CRAXDRT.CRPaperOrientation.crDefaultPaperOrientation;
                
                //Select Printer        
                //crReportDocument.SelectPrinter("", printer_name, "");
                crReportDocument.SelectPrinter("winspool", printer_name, "Ne00:");

                crReportDocument.ExportOptions.DestinationType = CRAXDRT.CRExportDestinationType.crEDTNoDestination;

                //Print
                crReportDocument.ExportOptions.DestinationType = CRAXDRT.CRExportDestinationType.crEDTDiskFile;
                crReportDocument.ExportOptions.PDFExportAllPages = true;
                crReportDocument.ExportOptions.FormatType = CRAXDRT.CRExportFormatType.crEFTPortableDocFormat;
                crReportDocument.PaperOrientation = CRAXDRT.CRPaperOrientation.crDefaultPaperOrientation;
                if (bool.Parse(letter.IsBothSlides))
                {
                    crReportDocument.PrinterDuplex = CRAXDRT.CRPrinterDuplexType.crPRDPVertical;
                }
                crReportDocument.ExportOptions.DestinationType = CRAXDRT.CRExportDestinationType.crEDTNoDestination;
                crReportDocument.Application.OpenReport(report_name_path, CRAXDRT.CROpenReportMethod.crOpenReportByDefault);

                crReportDocument.Database.Verify();

                //Set values
                foreach (CRAXDRT.FormulaFieldDefinition item in crReportDocument.FormulaFields)
	            {
                    if (item.FormulaFieldName.ToLower() == "criterion")
                    {
                        item.Text = criterion_ex.ToString();
                    }
                    else if (item.FormulaFieldName.ToLower() == "currenttime")
                    {
                        item.Text = currenttime.ToString();
                    }
                    else if (item.FormulaFieldName.ToLower() == "userprint")
                    {
                        item.Text = "'" + letter.UserName + "'";
                    }
	            }  

                crReportDocument.VerifyOnEveryPrint = true;

                crReportDocument.Database.Verify();
                //crReportDocument.PrintOut(Type.Missing, 1, Type.Missing, 1, 1000);
                crReportDocument.PrintOutEx(false, 1, true, 1, 10000, null);
                crxApplication = null;
                crReportDocument = null;
                //crxSubreportObject = null;
                //crxSubreport = null;
                //crxSections = null;
                //crxDatabase = null;
                //crxDatabaseTables = null;

                return true;
            }
            catch (Exception ex)
            {
                letter.ExMessage = ex.Message;
                Common.Logging("VNPrint-Error: " + ex.Message);
                if (ex.Message.ToLower().Contains("unspecified error")
                    || ex.Message.ToLower().Contains("logon failed")
                    || ex.Message.ToLower().Contains("cannot open any more tables")
                    )
                {
                    Common.Logging("VNPrint-Error: Restart App!!!");
                    Restart();
                }
                return false;
            }
        }

        public static void Restart()
        {
            System.Diagnostics.Process proc = null;
            try
            {
                string targetDir = Directory.GetCurrentDirectory();
                proc = new System.Diagnostics.Process();
                proc.StartInfo.WorkingDirectory = targetDir;
                proc.StartInfo.FileName = "RestartApp.bat";
                //proc.StartInfo.Arguments = string.Format("10");//this is argument
                proc.StartInfo.CreateNoWindow = false;
                proc.Start();
                proc.WaitForExit();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception Occurred :{0},{1}", ex.Message, ex.StackTrace.ToString());
            }
        }

        //private static CRAXDRT.Report IntialReport(string report_name_path, string criterion, string currenttime)
        //{
        //    CRAXDRT.Application crxApplication = new CRAXDRT.Application();
        //    CRAXDRT.Report report = new CRAXDRT.Report();

        //    report = crxApplication.OpenReport(report_name_path, CRAXDRT.CROpenReportMethod.crOpenReportByDefault);

        //    //Set values
        //    for (int i = 1; i < report.FormulaFields.Count; i++)
        //    {
        //        if (report.FormulaFields[i].FormulaFieldName.ToLower() == "criterion")
        //        {
        //            report.FormulaFields[i].Text = criterion;
        //            break;
        //        }
        //        else if (report.FormulaFields[i].FormulaFieldName.ToLower() == "currenttime") {
        //            report.FormulaFields[i].Text = currenttime;
        //            break;
        //        }
        //    }

        //    report.Database.Verify();
        //    report.PaperOrientation = CRAXDRT.CRPaperOrientation.crDefaultPaperOrientation;

        //    return report;
        //}
    }
}
