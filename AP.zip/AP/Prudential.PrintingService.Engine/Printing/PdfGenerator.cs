﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System.IO;

namespace Prudential.PrintingService.Engine.Printing
{
    public class PdfGenerator
    {
        public bool ExcutePdfGenerator(string args)
        {
            var report = new ReportDocument();
            try
            {
                string[] arrArgs = args.Split('|');
                string out_file = arrArgs[0];
                string report_name_path = arrArgs[1];
                string criterion = arrArgs[2];
                string policy_no = arrArgs[3];
                string LetterType = arrArgs[4];
                string PolicyNoField = arrArgs[5];
                string currenttime = arrArgs[6];
                string DataBaseFilePath = arrArgs[7];
                string UserName = arrArgs[8];

                // remove file Before Generator PDF
                if (File.Exists(out_file))
                    File.Delete(out_file);

                report.Load(report_name_path, OpenReportMethod.OpenReportByDefault);
                IntialReport(report, report_name_path, criterion, policy_no, LetterType, PolicyNoField, currenttime, DataBaseFilePath, UserName);
                report.VerifyDatabase();
                report.ExportToDisk(ExportFormatType.PortableDocFormat, out_file);
               
                return true;
            }
            catch (Exception ex)
            {
                string strEx = ex.Message.ToString();
                Common.Logging("Export PDF Error: " + strEx);
                return false;
            }
            finally
            {
                if(report != null)
                    Dispose(report);
            }
        }

        private  void IntialReport(ReportDocument report, string report_name_path, string criterion, string policy_no, string letter_type, string policy_no_field, string currenttime, string database_file_path, string username)
        {
            foreach (Table table in report.Database.Tables)
            {
                table.Location = database_file_path;
            }

            foreach (ReportDocument subreport in report.Subreports)
            {
                foreach (Table table in subreport.Database.Tables)
                {
                    table.Location = database_file_path;
                }
            }

            //Set values
            foreach (FormulaFieldDefinition formula in report.DataDefinition.FormulaFields)
            {
                if (formula.Name.ToLower() == "criterion")
                {
                    formula.Text = criterion;
                }
                else if (formula.Name.ToLower() == "currenttime")
                {
                    formula.Text = currenttime;
                }
                else if (formula.Name.ToLower() == "userprint")
                {
                    formula.Text = "'" + username + "'";
                }
            }

            string currentRecordSelection = report.RecordSelectionFormula;
            string policyNoFormular = "{" + letter_type + "." + policy_no_field + "} = \"" + policy_no + "\"";

            string newRecordSelection = "";
            if (string.IsNullOrWhiteSpace(currentRecordSelection))
            {
                newRecordSelection = policyNoFormular;
            }
            else
            {
                newRecordSelection = string.Format("({0}) and ({1})", currentRecordSelection, policyNoFormular);
            }

            report.RecordSelectionFormula = newRecordSelection;
        }

        private void Dispose(ReportDocument report)
        {
            foreach (Table table in report.Database.Tables)
            {
                table.Dispose();
            }

            foreach (ReportDocument subreport in report.Subreports)
            {
                foreach (Table table in subreport.Database.Tables)
                {
                    table.Dispose();
                }

                subreport.Close();
                subreport.Dispose();
            }
            report.Close();
            report.Dispose();
            report = null;
        }
    }
}
