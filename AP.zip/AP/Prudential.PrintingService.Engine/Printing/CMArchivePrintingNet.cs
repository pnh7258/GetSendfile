﻿using System;
using System.Linq;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Threading;
using Prudential.PrintingService.BussinessLogic;
using System.Configuration;
using System.IO;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.ServiceProcess;
 
namespace Prudential.PrintingService.Engine.Printing
{
    public static class CMArchivePrintingNet
    {
        public static bool Print(Letter letter)
        {
            string policy_no = "";
            string veloci_ind_path = "";
            string velociPDFpath = "";
            string velociPDFpath_01 = "";
            string pdfGeneratorExePath = "";
            try
            {
                var cmconfigs = ConfigurationManager.GetSection("CmConfig") as NameValueCollection;
                if (cmconfigs != null)
                {
                    veloci_ind_path = cmconfigs["VelociINDTempPath"];
                    velociPDFpath = cmconfigs["VelociPDFPath"];
                    velociPDFpath_01 = cmconfigs["VelociINDPath"];
                    pdfGeneratorExePath = cmconfigs["PdfGeneratorExe"];
                }

                //Common.Logging("CreateVelociTemp");
                BussinessLogic.Ultilities.CreateVelociTemp(letter.DataBaseFilePath);
                var pol_list = BussinessLogic.Ultilities.GetProposalNo(letter.DataBaseFilePath, letter);

                string report_name_path = letter.ReportPath + letter.ReportName;
                string criterion = letter.Serial;
                string out_file = "";
                string fileIND = DateTime.Now.ToString("dd_MM_yyyy_hh_mm_ss_tt_") + letter.DataFileName.Split('.')[0] + ".IND";
                //Common.Logging("FileStream");
                var fileStream = new FileStream(veloci_ind_path + fileIND, FileMode.OpenOrCreate, FileAccess.Write, FileShare.None);
                StreamWriter stream_writer = new StreamWriter(fileStream);
                stream_writer.WriteLine(letter.LetterType);

                string print_date = letter.PrintDate.Trim();
                string[] arrTime = print_date.Split(' ');
                string[] arrddmmyy = arrTime[0].ToString().Split('/');
                string[] arrhhmm = arrTime[1].ToString().Split(':');
                string currenttime = arrddmmyy[2] + arrddmmyy[1] + arrddmmyy[0] + arrhhmm[0] + arrhhmm[1] + arrhhmm[2];

                for (int i = 0; i < pol_list.Rows.Count; i++)
                {
                    policy_no = pol_list.Rows[i][0].ToString();
                    //Initial report
                    //Common.Logging("IntialReport");
                    /*
                    var report = new ReportDocument();
                    out_file = velociPDFpath + letter.LetterType + "_" + letter.Serial + "_" + policy_no + ".PDF";
                    report.Load(report_name_path, OpenReportMethod.OpenReportByDefault);
                    IntialReport(report, report_name_path, criterion, policy_no, letter.LetterType, letter.PolicyNoField, currenttime, letter.DataBaseFilePath);
                    Common.Logging("Processing report " + report_name_path + " criterion: " + criterion + " policy: " + policy_no);
                    report.VerifyDatabase();
                    report.ExportToDisk(ExportFormatType.PortableDocFormat, out_file);
                    */
                    //--------------------------------------------------------------------------------------
                    //create process excute .pdf generator
                    string strArgs = string.Empty;
                    out_file = velociPDFpath + letter.LetterType + "_" + letter.Serial + "_" + policy_no + ".PDF";
                    strArgs = out_file + "|" + report_name_path + "|" + criterion + "|" + policy_no + "|" + letter.LetterType + "|" + letter.PolicyNoField + "|" + currenttime + "|" + letter.DataBaseFilePath + "|" + letter.UserName;
               //     PdfGeneratorLib.PdfGenerator _ref = new PdfGeneratorLib.PdfGenerator();
              //      string strRs = _ref.ExcutePdfGenerator(strArgs);
                //    var startInfo = new ProcessStartInfo(@"C:\Mydata\Data(D)\Working\Project\VNPost\Source\SAP_CrytalsReport\Printing\Prudential.PdfGeneratorExe\bin\Debug\Prudential.PdfGeneratorExe.exe");
                    //var startInfo = new ProcessStartInfo(@"C:\vnprint\CMArchiveThread\Prudential.PdfGeneratorExe.exe");  PdfGeneratorExe
                  //  var startInfo = new ProcessStartInfo(@"C:\vnprint\cmservice\Prudential.PdfGeneratorExe.exe");
                    //var startInfo = new ProcessStartInfo(pdfGeneratorExePath);
                    //startInfo.Arguments = strArgs;
                    //startInfo.CreateNoWindow = true;
                    //startInfo.UseShellExecute = false;
                    //System.Diagnostics.Process p = System.Diagnostics.Process.Start(startInfo);
                    //p.WaitForExit();

                    PdfGenerator _ref = new PdfGenerator();
                    _ref.ExcutePdfGenerator(strArgs);

                    Common.Logging("Processing report " + report_name_path + " criterion: " + criterion + " policy: " + policy_no);
                    //--------------------------------------------------------------------------------------

                    stream_writer.WriteLine(@"|" + out_file + "|" + policy_no + "|" + DateTime.Now.ToString("dd/MM/yyyy") + "|");
                }
                stream_writer.Close();
                fileStream.Close();
                //move .IND
                if (Directory.Exists(velociPDFpath_01))
                {
                    File.Move(veloci_ind_path + fileIND, velociPDFpath_01 + fileIND);
                }
                return true;
            }
            catch (Exception ex)
            {
                Common.Logging("File: " + letter.DataFileName + ", Policy No: " + policy_no + ". " + ex.Message);
                throw;
            }
        }

        public static string ExcutePdfGenerator(string args)
        {
            try
            {
                string[] arrArgs = args.Split('|');
                string out_file = arrArgs[0];
                string report_name_path = arrArgs[1];
                string criterion = arrArgs[2];
                string policy_no = arrArgs[3];
                string LetterType = arrArgs[4];
                string PolicyNoField = arrArgs[5];
                string currenttime = arrArgs[6];
                string DataBaseFilePath = arrArgs[7];

                var report = new ReportDocument();
                report.Load(report_name_path, OpenReportMethod.OpenReportByDefault);
                IntialReport(report, report_name_path, criterion, policy_no, LetterType, PolicyNoField, currenttime, DataBaseFilePath);
                report.VerifyDatabase();
                report.ExportToDisk(ExportFormatType.PortableDocFormat, out_file);
                //clear
                report.Close();
                report.Dispose();
                report = null;
                return "True";
            }
            catch (Exception ex)
            {
                string strEx = ex.Message.ToString();
                return strEx;
            }
        }

        private static void IntialReport(ReportDocument report, string report_name_path, string criterion, string policy_no, string letter_type, string policy_no_field, string currenttime, string database_file_path)
        {
            foreach (Table table in report.Database.Tables)
            {
                table.Location = database_file_path;
            }

            foreach (ReportDocument subreport in report.Subreports)
            {
                foreach (Table table in subreport.Database.Tables)
                {
                    table.Location = database_file_path;
                }
            }

            //Set values
            foreach (FormulaFieldDefinition formula in report.DataDefinition.FormulaFields)
            {
                if (formula.Name.ToLower().Trim() == "criterion")
                {
                    formula.Text = criterion;                  
                }

                if (formula.Name.ToLower().Trim() == "currenttime")
                {
                    formula.Text = "\"" + currenttime + "\""; 
                }
            }

            string currentRecordSelection = report.RecordSelectionFormula;
            string policyNoFormular = "{" + letter_type + "." + policy_no_field + "} = \"" + policy_no + "\"";

            string newRecordSelection = "";
            if (string.IsNullOrWhiteSpace(currentRecordSelection))
            {
                newRecordSelection = policyNoFormular;
            }
            else
            {
                newRecordSelection = string.Format("({0}) and ({1})", currentRecordSelection, policyNoFormular);
            }

            report.RecordSelectionFormula = newRecordSelection;
        }        

        private static void GetFileAndWrite()
        {
            
        }
    }
}
