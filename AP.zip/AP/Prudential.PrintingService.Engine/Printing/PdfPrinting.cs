﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using Prudential.PrintingService.BussinessLogic;
// Use Crytal Report ActiveX control because PDF format
// lbt.khang@prudential.com.vn
 
namespace Prudential.PrintingService.Engine.Printing
{
    public static class PdfPrinting
    {
        public static bool Print(Letter letter) {
            try {
                string data_post_ssh_host = "";
                string data_post_ssh_port = "";
                string data_post_ssh_username = "";
                string data_post_sshpassword = "";
                string zip_pass_word = "";
                string pdf_path = ConfigurationManager.AppSettings["PdfPath"];

                //var datapostconfigs = ConfigurationManager.GetSection("PdfConfig") as NameValueCollection;
                //if (datapostconfigs != null) {
                //    data_post_ssh_host = datapostconfigs["DataPostSshHost"]; // => string.emty thi ko truyen
                //    data_post_ssh_port = datapostconfigs["DataPostSshPort"];
                //    data_post_ssh_username = datapostconfigs["DataPostSshUsername"];
                //    data_post_sshpassword = datapostconfigs["DataPostSshPassword"];
                //    zip_pass_word = datapostconfigs["ZipPassWord"];
                //    pdf_path = datapostconfigs["PdfPath"];
                //}

                using (var report = new ReportDocument()) {
                    string report_name_path = letter.ReportPath + letter.ReportName;
                    string criterion = letter.Serial;
                    string print_date = letter.PrintDate.Trim();
                    string[] arrTime = print_date.Split(' ');
                    string[] arrddmmyy = arrTime[0].ToString().Split('/');
                    string[] arrhhmm = arrTime[1].ToString().Split(':');
                    string currenttime = arrddmmyy[2] + arrddmmyy[1] + arrddmmyy[0] + arrhhmm[0] + arrhhmm[1] + arrhhmm[2];

                    report.Load(report_name_path, OpenReportMethod.OpenReportByDefault);
                    IntialReport(report, report_name_path, criterion, letter.LetterType, currenttime, letter.DataBaseFilePath, letter.UserName);
                    string out_file = pdf_path + letter.DataFileName.Replace(".R", "").Replace(".l", "").Trim() + ".PDF";
                    report.ExportOptions.ExportDestinationType = ExportDestinationType.NoDestination;
                    report.Refresh();
                    report.ExportToDisk(ExportFormatType.PortableDocFormat, out_file);
                    foreach (ReportDocument item in report.Subreports) {
                        item.Close();
                        item.Dispose();
                    }
                    
                    report.Close();
                    report.Dispose();
                    // report = null;
                    /*
                    ExportOptions exportOpts = new ExportOptions();
                    PdfRtfWordFormatOptions pdfRtfWordOpts = ExportOptions.CreatePdfRtfWordFormatOptions();
                    DiskFileDestinationOptions destinationOpts = ExportOptions.CreateDiskFileDestinationOptions();
                    exportOpts.ExportFormatOptions = pdfRtfWordOpts;
                    exportOpts.ExportFormatType = ExportFormatType.PortableDocFormat;
                    destinationOpts.DiskFileName = out_file;
                    exportOpts.ExportDestinationOptions = destinationOpts;
                    exportOpts.ExportDestinationType = ExportDestinationType.DiskFile;
                    report.Export(exportOpts);
                     */
                    Common.Logging("PdfPrinting-Print: " + letter.DataFilePath + letter.DataFileName + " successful - " + letter.UserName.ToString() + " - " + letter.PrinterName + " - " + DateTime.Now.ToString("dd/mm/yyyy hh:mm:ss"));
                }
                return true;
            }
            catch (Exception ex) {
                letter.ExMessage = ex.Message.ToString();
                Common.Logging("PdfPrinting-Print: " + letter.DataFilePath + letter.DataFileName + " successful - " + letter.UserName.ToString() + " - " + letter.PrinterName + " - " + letter.ExMessage);
                return false;
            }
        }

        //public static void Print(string report_name_path, string criterion, string out_file) {
        //    //Initial report
        //    CRAXDRT.Report crReportDocument = IntialReport(report_name_path, criterion);

        //    crReportDocument.ExportOptions.DestinationType = CRAXDRT.CRExportDestinationType.crEDTDiskFile;
        //    crReportDocument.ExportOptions.DiskFileName = out_file;
        //    crReportDocument.ExportOptions.PDFExportAllPages = true;
        //    crReportDocument.ExportOptions.FormatType = CRAXDRT.CRExportFormatType.crEFTPortableDocFormat;

        //    crReportDocument.Database.Verify();
        //    crReportDocument.Database.Verify();
        //    crReportDocument.Database.Verify();
        //    crReportDocument.Database.Verify();

        //    crReportDocument.Export(false);
        //}

        //public static void Print(Letter letter) {
        //    try {
        //        string data_post_ssh_host = "";
        //        string data_post_ssh_port = "";
        //        string data_post_ssh_username = "";
        //        string data_post_sshpassword = "";
        //        string zip_pass_word = "";
        //        string pdf_path = "";

        //        var datapostconfigs = ConfigurationManager.GetSection("PdfConfig") as NameValueCollection;
        //        if (datapostconfigs != null) {
        //            data_post_ssh_host = datapostconfigs["DataPostSshHost"];
        //            data_post_ssh_port = datapostconfigs["DataPostSshPort"];
        //            data_post_ssh_username = datapostconfigs["DataPostSshUsername"];
        //            data_post_sshpassword = datapostconfigs["DataPostSshPassword"];
        //            zip_pass_word = datapostconfigs["ZipPassWord"];
        //            pdf_path = datapostconfigs["PdfPath"];
        //        }

        //        string report_name_path = letter.ReportPath + letter.ReportName;
        //        string criterion = letter.Serial;
        //        string out_file = pdf_path + letter.DataFileName.Replace(".R", "").Trim() + ".PDF";

        //        //Initial report
        //        CRAXDRT.Report crReportDocument = IntialReport(report_name_path, criterion);

        //        crReportDocument.ExportOptions.DestinationType = CRAXDRT.CRExportDestinationType.crEDTDiskFile;
        //        crReportDocument.ExportOptions.DiskFileName = out_file;
        //        crReportDocument.ExportOptions.PDFExportAllPages = true;
        //        crReportDocument.ExportOptions.FormatType = CRAXDRT.CRExportFormatType.crEFTPortableDocFormat;

        //        crReportDocument.Database.Verify();
        //        crReportDocument.Database.Verify();
        //        crReportDocument.Database.Verify();
        //        crReportDocument.Database.Verify();

        //        crReportDocument.Export(false);
        //        Common.Logging("PdfPrinting-Print: " + letter.DataFilePath + letter.DataFileName.Replace(".R", "").Trim() + " successful - " + DateTime.Now.ToString("dd/mm/yyyy hh:mm:ss"));
        //    }
        //    catch (Exception ex) {
        //        string mess = ex.Message.ToString();
        //        Common.Logging("PdfPrinting-Print: " + letter.DataFileName + ". " + ex.Message);
        //    }
        //}


        //private static CRAXDRT.Report IntialReport(string report_name_path, string criterion) {
        //    CRAXDRT.Application crxApplication = new CRAXDRT.Application();
        //    CRAXDRT.Report report = new CRAXDRT.Report();
        //    report = crxApplication.OpenReport(report_name_path, CRAXDRT.CROpenReportMethod.crOpenReportByDefault);

        //    //Set values
        //    for (int i = 1; i < report.FormulaFields.Count; i++) {
        //        if (report.FormulaFields[i].FormulaFieldName.Trim().ToLower() == "criterion") {
        //            Common.Logging("Processing report " + report_name_path + " criterion " + criterion);
        //            report.FormulaFields[i].Text = criterion;
        //            Thread.Sleep(10000);
        //            break;
        //        }
        //    }

        //    report.Database.Verify();
        //    Thread.Sleep(1000);
        //    report.Database.Verify();
        //    report.PaperOrientation = CRAXDRT.CRPaperOrientation.crDefaultPaperOrientation;
        //    report.Database.Verify();
        //    return report;
        //}

        private static void IntialReport(ReportDocument report, string report_name_path, string criterion, string letter_type, string currenttime, string database_file_path, string userName)
        {
            foreach (Table table in report.Database.Tables) {
                table.Location = database_file_path;
            }

            foreach (ReportDocument subreport in report.Subreports) {
                foreach (Table table in subreport.Database.Tables) {
                    table.Location = database_file_path;
                }
            }

            //Set values
            foreach (FormulaFieldDefinition formula in report.DataDefinition.FormulaFields) {
                if (formula.Name == "criterion") {
                    formula.Text = criterion;
                }
                else if (formula.Name.Trim().ToLower() == "currenttime") {
                    formula.Text = currenttime;
                }
                else if (formula.Name.Trim().ToLower() == "userprint")
                {
                    formula.Text = "'" + userName + "'";
                }
            }
        }   
    }
}
