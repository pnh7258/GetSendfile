﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using Prudential.PrintingService.BussinessLogic;
// Use Crytal Report ActiveX control because PDF format
// lbt.khang@prudential.com.vn
 
namespace Prudential.PrintingService.Engine.Printing
{
    public static class PrinterPrintingThroughPdf
    {
        public static void Print(string report_name_path, string criterion, string out_file)
        {
            //Initial report
            CRAXDRT.Report crReportDocument = IntialReport(report_name_path, criterion);
            
            crReportDocument.ExportOptions.DestinationType = CRAXDRT.CRExportDestinationType.crEDTDiskFile;
            crReportDocument.ExportOptions.DiskFileName = out_file;
            crReportDocument.ExportOptions.PDFExportAllPages = true;
            crReportDocument.ExportOptions.FormatType = CRAXDRT.CRExportFormatType.crEFTPortableDocFormat;

            crReportDocument.Database.Verify();
            crReportDocument.Database.Verify();
            crReportDocument.Database.Verify();
            crReportDocument.Database.Verify();

            crReportDocument.Export(false);


        }        

        private static CRAXDRT.Report IntialReport(string report_name_path, string criterion)
        {
            CRAXDRT.Application crxApplication = new CRAXDRT.Application();
            CRAXDRT.Report report = new CRAXDRT.Report();
            report = crxApplication.OpenReport(report_name_path, CRAXDRT.CROpenReportMethod.crOpenReportByDefault);

            //Set values
            for (int i = 1; i < report.FormulaFields.Count; i++)
            {
                if (report.FormulaFields[i].FormulaFieldName.Trim().ToLower() == "criterion")
                {
                    Common.Logging("Processing report " + report_name_path + " criterion " + criterion);
                    report.FormulaFields[i].Text = criterion;
                    Thread.Sleep(1000);
                    break;
                }
            }
            
            report.Database.Verify();           
            report.Database.Verify();
            report.PaperOrientation = CRAXDRT.CRPaperOrientation.crDefaultPaperOrientation;
            report.Database.Verify();
            return report;
        }
    }
}
