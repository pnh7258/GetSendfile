﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using Prudential.PrintingService.BussinessLogic;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.ReportSource;
using CrystalDecisions.Shared;
// Use Crytal Report ActiveX control because PDF format
// lbt.khang@prudential.com.vn
 
namespace Prudential.PrintingService.Engine.Printing
{
    public static class GeneralPrinting
    {
        public static void Print2(string report_name_path, string criterion, string printer_name)
        {
            //Initial report
            ReportDocument crReportDocument = IntialReport(report_name_path, criterion);
            crReportDocument.ExportOptions.ExportDestinationType = ExportDestinationType.NoDestination;

            //Select Printer
            crReportDocument.PrintOptions.PrinterName = printer_name;

            //Print            
            //crReportDocument.ExportOptions. = CRAXDRT.CRExportFormatType.crEFTPortableDocFormat;
            //crReportDocument.PaperOrientation = CRAXDRT.CRPaperOrientation.crDefaultPaperOrientation;
            //crReportDocument.Application.OpenReport(report_name_path, CRAXDRT.CROpenReportMethod.crOpenReportByDefault);
            //crReportDocument.ExportOptions.DestinationType = CRAXDRT.CRExportDestinationType.crEDTNoDestination;

            crReportDocument.VerifyDatabase();
            crReportDocument.VerifyDatabase();
            crReportDocument.VerifyDatabase();
            crReportDocument.Refresh();
            crReportDocument.PrintToPrinter(1, true, 1, 100); 
        }

        public static void Print(Letter letter)
        {
            string report_name_path = letter.ReportPath + letter.ReportName;
            string criterion = letter.Serial;
            string printer_name = letter.PrinterName;
            //Initial report
            ReportDocument crReportDocument = IntialReport(report_name_path, criterion);
            crReportDocument.ExportOptions.ExportDestinationType = ExportDestinationType.NoDestination;

            //Select Printer
            crReportDocument.PrintOptions.PrinterName = printer_name;

            //Print            
            //crReportDocument.ExportOptions. = CRAXDRT.CRExportFormatType.crEFTPortableDocFormat;
            //crReportDocument.PaperOrientation = CRAXDRT.CRPaperOrientation.crDefaultPaperOrientation;
            //crReportDocument.Application.OpenReport(report_name_path, CRAXDRT.CROpenReportMethod.crOpenReportByDefault);
            //crReportDocument.ExportOptions.DestinationType = CRAXDRT.CRExportDestinationType.crEDTNoDestination;

            crReportDocument.VerifyDatabase();
            crReportDocument.VerifyDatabase();
            crReportDocument.VerifyDatabase();
            crReportDocument.Refresh();
            crReportDocument.PrintToPrinter(1, true, 1, 100);
        } 

        private static ReportDocument IntialReport(string report_name_path, string criterion)
        {
            ReportDocument crReportDocument = new ReportDocument();

            crReportDocument.Load(report_name_path, OpenReportMethod.OpenReportByDefault);

            //Set values 
            crReportDocument.DataDefinition.FormulaFields["criterion"].Text = criterion;

            crReportDocument.VerifyDatabase();
            crReportDocument.PrintOptions.PaperOrientation = PaperOrientation.DefaultPaperOrientation;
            return crReportDocument;
        }
    }
}
