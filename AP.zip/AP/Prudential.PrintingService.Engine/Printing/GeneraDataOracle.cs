﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Linq;
using System.Text;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using Prudential.PrintingService.BussinessLogic;
using Oracle.DataAccess.Client; // ODP.NET Oracle managed provider
using Oracle.DataAccess.Types;
using System.Data;
using System.IO;
using System.Threading;

namespace Prudential.PrintingService.Engine.Printing
{
    public class GeneraDataOracle
    {
        public static bool Print(Letter letter)
        {
            try
            {
                string connectionString = "";
                string pdf_path = "";

                var oracleconfigs = ConfigurationManager.GetSection("OracleConfig") as NameValueCollection;
                if (oracleconfigs != null)
                {
                    connectionString = oracleconfigs["ConnectionString"];
                    pdf_path = oracleconfigs["PdfPath"];
                }
                else
                    return true;

                using (var report = new ReportDocument())
                {
                    string report_name_path = letter.ReportPath + letter.ReportName;
                    string criterion = letter.Serial;
                    string print_date = letter.PrintDate.Trim();
                    string[] arrTime = print_date.Split(' ');
                    string[] arrddmmyy = arrTime[0].ToString().Split('/');
                    string[] arrhhmm = arrTime[1].ToString().Split(':');
                    string currenttime = arrddmmyy[2] + arrddmmyy[1] + arrddmmyy[0] + arrhhmm[0] + arrhhmm[1] + arrhhmm[2];

                    // GetPolNo
                    string ProposalNo = GetProposalNo(letter.DataBaseFilePath, letter.LetterType, letter.Serial);

                    report.Load(report_name_path, OpenReportMethod.OpenReportByDefault);
                    IntialReport(report, report_name_path, criterion, letter.LetterType, currenttime, letter.DataBaseFilePath, letter.UserName);
                    string out_file = pdf_path + letter.DataFileName.Replace(".R", "").Replace(".l", "").Trim() + ".PDF";
                    report.ExportOptions.ExportDestinationType = ExportDestinationType.NoDestination;
                    report.Refresh();
                    report.ExportToDisk(ExportFormatType.PortableDocFormat, out_file);
                    Dispose(report);

                    //SaveToOracle(out_file, connectionString, letter.LetterType, ProposalNo);

                    new Thread(() => ThreadSaveToOracle(out_file, connectionString, letter.LetterType, ProposalNo)).Start();

                    //Common.Logging("PdfPrinting-Print: " + letter.DataFilePath + letter.DataFileName + " successful - " + letter.UserName.ToString() + " - " + letter.PrinterName + " - " + DateTime.Now.ToString("dd/mm/yyyy hh:mm:ss"));
                    return true;
                }
            }
            catch (Exception ex)
            {
                letter.ExMessage = ex.Message.ToString();
                Common.Logging("PdfPrinting-Print: " + letter.DataFilePath + letter.DataFileName + " Fail - " + letter.UserName.ToString() + " - " + letter.PrinterName + " - " + letter.ExMessage);
                return false;
            }
        }


        private static void IntialReport(ReportDocument report, string report_name_path, string criterion, string letter_type, string currenttime, string database_file_path, string username)
        {
            foreach (Table table in report.Database.Tables)
            {
                table.Location = database_file_path;
            }

            foreach (ReportDocument subreport in report.Subreports)
            {
                foreach (Table table in subreport.Database.Tables)
                {
                    table.Location = database_file_path;
                }
            }

            //Set values
            foreach (FormulaFieldDefinition formula in report.DataDefinition.FormulaFields)
            {
                if (formula.Name == "criterion")
                {
                    formula.Text = criterion;
                }
                else if (formula.Name.Trim().ToLower() == "currenttime")
                {
                    formula.Text = currenttime;
                }
                else if (formula.Name.Trim().ToLower() == "userprint")
                {
                    formula.Text = "'" + username + "'";
                }
            }
        }

        private static void Dispose(ReportDocument report)
        {
            foreach (Table table in report.Database.Tables)
            {
                table.Dispose();
            }

            foreach (ReportDocument subreport in report.Subreports)
            {
                foreach (Table table in subreport.Database.Tables)
                {
                    table.Dispose();
                }
            }

            report.Close();
            report.Dispose();
        }

        private static void ThreadSaveToOracle(string pathfile, string connectionString, string letterType, string ProposalNo)
        {
            while (true)
            {
                if (File.Exists(pathfile))
                {
                    try
                    {
                        if (SaveToOracle(pathfile, connectionString, letterType, ProposalNo))
                            File.Delete(pathfile);
                        else
                            Thread.Sleep(10000);
                    }
                    catch (Exception ex)
                    {
                        Common.Logging(String.Format("Prudential.PrintingService.Engine.Printing.GeneraDataOracle - Fail: {0}", ex.ToString()));
                        Thread.Sleep(10000);
                    }
                }
                else
                    break;
            }
        }

        private static bool SaveToOracle(string pathfile, string connectionString, string letterType, string ProposalNo)
        {

            try
            {
                bool isFinish = false;
                string PolNo = string.Empty;
                #region Get PolNo
                {
                    string strQuery = @"SELECT chdrnum FROM chdrpf WHERE repnum = :repnum AND validflag IN ('1','3')";
                    OracleParameter[] OParams = new OracleParameter[]{
                        new OracleParameter("repnum", OracleDbType.Varchar2, ProposalNo, ParameterDirection.Input)
                    };
                    DataTable dt = null;
                    ExecuteSQL(connectionString, strQuery, OParams, out dt);

                    PolNo = dt.Rows.Count > 0 ? dt.Rows[0][0].ToString() : string.Empty;
                }
                #endregion

                bool isExist = false;
                #region Check Policy
                {
                    //string strQuery = @"DELETE from LETTER_DATA WHERE PROPOSAL_NUM = :PROPOSAL_NUM AND LETTER_TYPE = :letterType";
                    string strQuery = @"Select COUNT(1) from LETTER_DATA WHERE PROPOSAL_NUM = :PROPOSAL_NUM AND LETTER_TYPE = :letterType";
                    OracleParameter[] OParams = new OracleParameter[]{
                        new OracleParameter("PROPOSAL_NUM", OracleDbType.Varchar2, ProposalNo, ParameterDirection.Input),
                        new OracleParameter("letterType", OracleDbType.Varchar2, letterType, ParameterDirection.Input)
                    };
                    DataTable dt = null;
                    ExecuteSQL(connectionString, strQuery, OParams, out dt);

                    isExist = Int32.Parse(dt.Rows[0][0].ToString()) > 0;
                }
                #endregion

                #region Insert Letters
                {
                    FileStream fs = new System.IO.FileStream(pathfile, FileMode.Open, FileAccess.Read, FileShare.Read);
                    byte[] b = new byte[fs.Length];
                    fs.Read(b, 0, Convert.ToInt32(fs.Length));
                    fs.Close();

                    string strQuery = string.Empty;
                    OracleParameter[] OParams = null;
                    if (!isExist)
                    {

                        strQuery = @"INSERT INTO LETTER_DATA (ID, PROPOSAL_NUM, POLICY_NUM, LETTER_TYPE, DATA_FILE, CONTENT_TYPE, REQUEST_DATE, UPDATED_DATE) VALUES (SEQ_LETTERS_ID.nextval, :PROPOSAL_NUM, :POLICY_NUM, :LETTER_TYPE, :DATA_FILE, :CONTENT_TYPE, :REQUEST_DATE, :UPDATED_DATE)";
                        OParams = new OracleParameter[]{
                            new OracleParameter("PROPOSAL_NUM", OracleDbType.Varchar2, ProposalNo, ParameterDirection.Input),
                            new OracleParameter("POLICY_NUM", OracleDbType.Varchar2, PolNo, ParameterDirection.Input),
                            new OracleParameter("LETTER_TYPE", OracleDbType.Varchar2, letterType, ParameterDirection.Input),
                            new OracleParameter("DATA_FILE", OracleDbType.Blob, b, ParameterDirection.Input),
                            new OracleParameter("CONTENT_TYPE", OracleDbType.Varchar2, "application/pdf", ParameterDirection.Input),
                            new OracleParameter("REQUEST_DATE", OracleDbType.Int32, Int32.Parse(DateTime.Now.ToString("yyyyMMdd")), ParameterDirection.Input),
                            new OracleParameter("UPDATED_DATE", OracleDbType.Date, DateTime.Now, ParameterDirection.Input)
                        };
                        isFinish = ExecuteNonSQL(connectionString, strQuery, OParams);
                    }
                    else
                    {
                        strQuery = @"UPDATE LETTER_DATA 
                                        SET DATA_FILE = :DATA_FILE, 
                                            REQUEST_DATE = :REQUEST_DATE,
                                            UPDATED_DATE = :UPDATED_DATE
                                    WHERE 
                                        PROPOSAL_NUM = :PROPOSAL_NUM
                                        AND LETTER_TYPE = :LETTER_TYPE";

                        OParams = new OracleParameter[]{
                            new OracleParameter("DATA_FILE", OracleDbType.Blob, b, ParameterDirection.Input),
                            new OracleParameter("REQUEST_DATE", OracleDbType.Int32, Int32.Parse(DateTime.Now.ToString("yyyyMMdd")), ParameterDirection.Input),
                            new OracleParameter("UPDATED_DATE", OracleDbType.Date, DateTime.Now, ParameterDirection.Input),
                            new OracleParameter("PROPOSAL_NUM", OracleDbType.Varchar2, ProposalNo, ParameterDirection.Input),
                            new OracleParameter("LETTER_TYPE", OracleDbType.Varchar2, letterType, ParameterDirection.Input)
                        };
                        isFinish = ExecuteNonSQL(connectionString, strQuery, OParams);
                    }
                }
                return isFinish;
                #endregion
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private static string GetProposalNo(string database_file_path, string letterType, string criterion)
        {
            string strResult = Prudential.PrintingService.BussinessLogic.Ultilities.GetProposalNo(database_file_path, letterType, criterion);
            return strResult;
        }

        private static void ExecuteSQL(string connectionString, string Query, OracleParameter[] param, out DataTable dt)
        {
            OracleConnection conn = new OracleConnection(connectionString);  // C#
            OracleCommand cmd = new OracleCommand();
            dt = new DataTable();
            try
            {
                conn.Open();
                cmd.Connection = conn;
                cmd.CommandText = Query;
                cmd.CommandType = CommandType.Text;
                foreach (var item in param)
                {
                    cmd.Parameters.Add(item);
                }
                OracleDataReader dr = cmd.ExecuteReader();

                dt.Load(dr);
            }
            catch (Exception ex)
            {
                throw ex;
                //Common.Logging(String.Format("Oracle - Error: {0}", ex.Message));
            }
            finally
            {
                cmd.Connection.Close();
                cmd.Connection.Dispose();
                conn.Close();
                conn.Dispose();
            }
        }

        private static bool ExecuteNonSQL(string connectionString, string Query, OracleParameter[] param)
        {
            OracleConnection conn = new OracleConnection(connectionString);  // C#
            OracleCommand cmd = new OracleCommand();
            try
            {
                conn.Open();
                cmd.Connection = conn;
                cmd.CommandText = Query;
                cmd.CommandType = CommandType.Text;
                foreach (var item in param)
                {
                    cmd.Parameters.Add(item);
                }
                int iCheck = cmd.ExecuteNonQuery();
                return iCheck > 0;
            }
            catch (Exception ex)
            {
                throw ex;
                //Common.Logging(String.Format("Oracle - Error: {0}", ex.Message));
                //return false;
            }
            finally
            {
                cmd.Connection.Close();
                cmd.Connection.Dispose();
                conn.Close();
                conn.Dispose();
            }
        }
    }
}
