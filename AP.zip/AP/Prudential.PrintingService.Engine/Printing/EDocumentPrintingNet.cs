﻿using System;
using System.Linq;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Threading;
using Prudential.PrintingService.BussinessLogic;
using System.Configuration;
using System.IO;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.ServiceProcess;
 
namespace Prudential.PrintingService.Engine.Printing
{
    public static class EDocumentPrintingNet
    {
        public static bool Print(Letter letter)
        {
            string policy_no = "";
            string velociPDFpath = "";
            try
            {
                var cmconfigs = ConfigurationManager.GetSection("CmConfig") as NameValueCollection;
                if (cmconfigs != null)
                {
                    velociPDFpath = cmconfigs["VelociPDFPath"];
                }

                //Common.Logging("CreateVelociTemp");
                BussinessLogic.Ultilities.CreateVelociTemp(letter.DataBaseFilePath);
                var pol_list = BussinessLogic.Ultilities.GetProposalNo(letter.DataBaseFilePath, letter);

                string report_name_path = letter.ReportPath + letter.ReportName;
                string criterion = letter.Serial;
                string out_file = "";

                string print_date = letter.PrintDate.Trim();
                string[] arrTime = print_date.Split(' ');
                string[] arrddmmyy = arrTime[0].ToString().Split('/');
                string[] arrhhmm = arrTime[1].ToString().Split(':');
                string currenttime = arrddmmyy[2] + arrddmmyy[1] + arrddmmyy[0] + arrhhmm[0] + arrhhmm[1] + arrhhmm[2];

                for (int i = 0; i < pol_list.Rows.Count; i++)
                {
                    policy_no = pol_list.Rows[i][0].ToString();
                   
                    //create process excute .pdf generator
                    string strArgs = string.Empty;
                    out_file = velociPDFpath + letter.LetterType + "_" + letter.Serial + "_" + policy_no + "_" + currenttime + ".PDF";
                    strArgs = out_file + "|" + report_name_path + "|" + criterion + "|" + policy_no + "|" + letter.LetterType + "|" + letter.PolicyNoField + "|" + currenttime + "|" + letter.DataBaseFilePath+ "|" + letter.UserName;

                    PdfGenerator _ref = new PdfGenerator();
                    _ref.ExcutePdfGenerator(strArgs);

                    Common.Logging("Processing report " + report_name_path + " criterion: " + criterion + " policy: " + policy_no);
                }
             
                return true;
            }
            catch (Exception ex)
            {
                Common.Logging("File: " + letter.DataFileName + ", Policy No: " + policy_no + ". " + ex.Message);
                throw;
            }
        }   
    }
}
