﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Threading;
using Prudential.PrintingService.BussinessLogic;
using System.Configuration;
using System.IO;
// Use Crytal Report ActiveX control because PDF format
// lbt.khang@prudential.com.vn
 
namespace Prudential.PrintingService.Engine.Printing
{
    public static class CMArchivePrinting
    {
        public static void Print(Letter letter)
        {
            string policy_no = "";
            string veloci_ind_path = "";
            string velociPDFpath = "";
            try
            {
                var cmconfigs = ConfigurationManager.GetSection("CmConfig") as NameValueCollection;
                if (cmconfigs != null)
                {
                    veloci_ind_path = cmconfigs["VelociINDPath"];
                    velociPDFpath = cmconfigs["VelociPDFPath"];
                }

                Common.Logging("CreateVelociTemp");
                BussinessLogic.Ultilities.CreateVelociTemp(letter.DataBaseFilePath);
                var pol_list = BussinessLogic.Ultilities.GetPolNo(letter.DataBaseFilePath, letter);
                
                string report_name_path = letter.ReportPath + letter.ReportName;
                string criterion = letter.Serial;
                string out_file = "";
                string fileIND = DateTime.Now.ToString("dd_MM_yyyy_hh_mm_ss_tt_") + letter.DataFileName.Split('.')[0] + ".IND";
                Common.Logging("FileStream");
                var fileStream = new FileStream(veloci_ind_path + fileIND, FileMode.OpenOrCreate, FileAccess.Write, FileShare.None);
                StreamWriter stream_writer = new StreamWriter(fileStream);
                stream_writer.WriteLine(letter.LetterType);
                
                string print_date = letter.PrintDate.Trim();
                string[] arrTime = print_date.Split(' ');
                string[] arrddmmyy = arrTime[0].ToString().Split('/');
                string[] arrhhmm = arrTime[1].ToString().Split(':');
                string currenttime = arrddmmyy[2] + arrddmmyy[1] + arrddmmyy[0] + arrhhmm[0] + arrhhmm[1] + arrhhmm[2];
                for (int i = 0; i < pol_list.Rows.Count; i++)
                {
                    CRAXDRT.Application crxApplication = new CRAXDRT.Application();
                    policy_no = pol_list.Rows[i][0].ToString();
                    //Initial report
                    Common.Logging("IntialReport");
                    CRAXDRT.Report crReportDocument = IntialReport(crxApplication, report_name_path, criterion, policy_no, letter.LetterType, letter.PolicyNoField, currenttime, letter.DataBaseFilePath);
                    crReportDocument.ExportOptions.DestinationType = CRAXDRT.CRExportDestinationType.crEDTDiskFile;

                    
                    out_file = velociPDFpath + letter.LetterType + "_" + letter.Serial + "_" + policy_no + ".PDF";
                    crReportDocument.ExportOptions.DiskFileName = out_file;
                    crReportDocument.ExportOptions.PDFExportAllPages = true;
                    crReportDocument.ExportOptions.FormatType = CRAXDRT.CRExportFormatType.crEFTPortableDocFormat;

                    crReportDocument.Database.Verify();
                    crReportDocument.Database.Verify();
                    crReportDocument.Database.Verify();
                    crReportDocument.Database.Verify();
                    Common.Logging("Processing report " + report_name_path + " criterion: " + criterion + " policy: " + policy_no);
                    
                    crReportDocument.Export(false);
                    stream_writer.WriteLine(@"|" + out_file + "|" + policy_no + "|" + DateTime.Now.ToString("dd/MM/yyyy") + "|");
                    Thread.Sleep(1000);
                    crReportDocument = null;
                    crxApplication = null;
                }
                stream_writer.Close();
                fileStream.Close();               
                
            }
            catch(Exception ex)
            {
                Common.Logging("File: " + letter.DataFileName + ", Policy No: " + policy_no + ". " + ex.Message);
                throw;
            }
        }

        private static CRAXDRT.Report IntialReport(CRAXDRT.Application crxApplication, string report_name_path, string criterion, string policy_no, string letter_type, string policy_no_field, string currenttime, string database_file_path)
        {            
            CRAXDRT.Report report = new CRAXDRT.Report();
            report = crxApplication.OpenReport(report_name_path, CRAXDRT.CROpenReportMethod.crOpenReportByDefault);
            
            foreach (CRAXDRT.DatabaseTable table in report.Database.Tables) {
               // table.Location = database_file_path;
                //Thread.Sleep(500);
                //Common.Logging("table.Location" + database_file_path);
            }            

            //Set values
            for (int i = 1; i <= report.FormulaFields.Count; i++) 
            {
                Common.Logging("Set values");
                if (report.FormulaFields[i].FormulaFieldName.Trim().ToLower() == "criterion")
                {
                    report.FormulaFields[i].Text = criterion;
                    Thread.Sleep(500);
                    break;
                }
            }
            #region time printint - get time from .R
            //string[] arrTime = print_date.Split(' ');
            //string[] arrddmmyy = arrTime[0].ToString().Split('/');
            //string[] arrhhmm = arrTime[1].ToString().Split(':');
            for (int i = 1; i <= report.FormulaFields.Count; i++)
            {
                if (report.FormulaFields[i].FormulaFieldName.Trim().ToLower() == "currenttime")
                {
                  // Common.Logging("Processing report " + report_name_path + " currenttime ");
                   // string currenttime = arrddmmyy[2] + arrddmmyy[1] + arrddmmyy[0] + arrhhmm[0] + arrhhmm[1] + arrhhmm[2];
                    report.FormulaFields[i].Text = "\"" + currenttime + "\"";
                    Thread.Sleep(500);
                    break;
                }
            }
            #endregion

            string currentRecordSelection = report.RecordSelectionFormula;
            string policyNoFormular = "{" + letter_type + "." + policy_no_field + "} = \"" + policy_no + "\"";

            string newRecordSelection = "";
            if (string.IsNullOrEmpty(currentRecordSelection))
            {
                newRecordSelection = policyNoFormular;
            }
            else
            {
                newRecordSelection = string.Format("({0}) and ({1})", currentRecordSelection, policyNoFormular);
            }
            
            report.RecordSelectionFormula = newRecordSelection;
            Thread.Sleep(1000);
            report.Database.Verify();          
            Thread.Sleep(1000);
            report.Database.Verify();
            report.PaperOrientation = CRAXDRT.CRPaperOrientation.crDefaultPaperOrientation;
            report.Database.Verify();
            return report;
        }

        private static void GetFileAndWrite()
        {
            
        }
    }
}
