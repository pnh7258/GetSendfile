﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Threading;
using Prudential.PrintingService.BussinessLogic;
using System.Configuration;
using System.IO;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;

namespace Prudential.PrintingService.Engine.Printing
{
    public static class DataPostPrinting
    {        
        public static bool Print(Letter letter)
        {            
            try
            {
                string report_name_path = letter.ReportPath + letter.ReportName;
                string criterion = letter.Serial;
                string data_post_ssh_host ="";
                string data_post_ssh_port = "";
                string data_post_ssh_username = "";
                string data_post_sshpassword = "";
                string zip_pass_word = "";
                string pdf_path = "";
                //bool sendfile = false;

                var datapostconfigs = ConfigurationManager.GetSection("PdfConfig") as NameValueCollection;
                if (datapostconfigs != null)
                {
                    data_post_ssh_host = datapostconfigs["DataPostSshHost"];
                    data_post_ssh_port = datapostconfigs["DataPostSshPort"];
                    data_post_ssh_username = datapostconfigs["DataPostSshUsername"];
                    data_post_sshpassword = datapostconfigs["DataPostSshPassword"];
                    zip_pass_word = datapostconfigs["ZipPassWord"];
                    pdf_path = datapostconfigs["PdfPath"];
                    //sendfile = Boolean.Parse(datapostconfigs["Sendfile"]);
                }

                string print_date = letter.PrintDate.Trim();
                string[] arrTime = print_date.Split(' ');
                string[] arrddmmyy = arrTime[0].ToString().Split('/');
                string[] arrhhmm = arrTime[1].ToString().Split(':');
                string currTime = arrddmmyy[2] + arrddmmyy[1] + arrddmmyy[0] + arrhhmm[0] + arrhhmm[1] + arrhhmm[2];

                var report = new ReportDocument();
                report.Load(report_name_path, OpenReportMethod.OpenReportByDefault);

                IntialReport(report, report_name_path, criterion, letter.Serial, letter.LetterType, letter.PolicyNoField, currTime, letter.DataBaseFilePath, letter.UserName);
                report.ExportOptions.ExportDestinationType = ExportDestinationType.NoDestination;

                string out_file = pdf_path + letter.LetterType + "_" + currTime + "_" + criterion + ".PDF";
                
                report.VerifyDatabase();
                report.ExportToDisk(ExportFormatType.PortableDocFormat, out_file);
                //clear
                report.Close();
                report.Dispose();
                report = null;

                try {
                    SshnetFileTransfer ssh = new SshnetFileTransfer(data_post_ssh_host
                     , int.Parse(data_post_ssh_port)
                     , data_post_ssh_username
                     , data_post_sshpassword
                  );
                    Stream stream = ZipFile(out_file, zip_pass_word); //new FileStream(out_file, FileMode.Open);
                    string currTimeSys = DateTime.Now.ToString("HH:mm:ss").Replace(":", "").Trim();
                    ssh.Write(ConfigurationManager.AppSettings["DataPostSshFolder"] + letter.LetterType + "_" + currTime + "_" + currTimeSys + "_" + criterion + ".zip", stream);
                    stream.Close();
                    stream = null;
                    ssh = null;
                    return true;
                }
                catch (Exception e) {
                    Common.Logging("Sendfile: fail - " + letter.DataFileName + ". " + e.Message);
                    return false;
                }
            }
            catch(Exception ex)
            {
                Common.Logging("File: " + letter.DataFileName + ". " + ex.Message);
                return false;
            }
        }

        private static Stream ZipFile(string localfilename, string zippassword)
        {
            Stream stream = new MemoryStream();
            Prudential.PrintingService.Engine.Compression.Zipper.CreateFromFile(localfilename, stream, zippassword);
            stream.Seek(0, SeekOrigin.Begin);
            return stream;
        }

        #region comment
        //private static CRAXDRT.Report IntialReport(string report_name_path, string criterion,string currentTime)
        //{
        //    CRAXDRT.Application crxApplication = new CRAXDRT.Application();
        //    CRAXDRT.Report report = new CRAXDRT.Report();
        //    report = crxApplication.OpenReport(report_name_path, CRAXDRT.CROpenReportMethod.crOpenReportByDefault);
            
        //    //Set values
        //    for (int i = 1; i <= report.FormulaFields.Count; i++)
        //    {
        //        if (report.FormulaFields[i].FormulaFieldName.Trim().ToLower() == "currenttime")
        //        {
        //            Common.Logging("Processing report " + report_name_path + " timer " + DateTime.Now.ToString("yyyyMMdd") + DateTime.Now.ToString("hhmmss"));
        //           // currentTime = DateTime.Now.ToString("yyyyMMdd") + DateTime.Now.ToString("hhmmss");
        //            //report.FormulaFields[i].Text = currentTime;
        //            report.FormulaFields[i].Text = "\"" + currentTime + "\"";
        //            Thread.Sleep(10000);
        //            break;
        //        }
        //    }

        //    for (int i = 1; i <= report.FormulaFields.Count; i++)
        //    {
        //        if (report.FormulaFields[i].FormulaFieldName.Trim().ToLower() == "criterion")
        //        {
        //            Common.Logging("Processing report " + report_name_path + " criterion " + criterion);
        //            report.FormulaFields[i].Text = criterion;
        //            Thread.Sleep(10000);
        //            break;
        //        }
        //    }

        //    report.Database.Verify();
        //    Thread.Sleep(1000);
        //    report.Database.Verify();
        //    report.PaperOrientation = CRAXDRT.CRPaperOrientation.crDefaultPaperOrientation;
        //    report.Database.Verify();
        //    return report;
        //}
        #endregion

        private static void IntialReport(ReportDocument report, string report_name_path, string criterion, string policy_no, string letter_type, string policy_no_field, string currenttime, string database_file_path, string username) {
            foreach (Table table in report.Database.Tables) {
                table.Location = database_file_path;
            }

            foreach (ReportDocument subreport in report.Subreports) {
                foreach (Table table in subreport.Database.Tables) {
                    table.Location = database_file_path;
                }
            }


            //Set values
            foreach (FormulaFieldDefinition formula in report.DataDefinition.FormulaFields) {
                if (formula.Name.Trim().ToLower().Equals("criterion")){
                    formula.Text = criterion;
                }
                else if (formula.Name.ToLower().Trim().Equals("currenttime")){
                    formula.Text = currenttime;
                }
                else if (formula.Name.ToLower().Trim().Equals("userprint"))
                {
                    formula.Text = "'" + username + "'";
                }
            }

            //string currentRecordSelection = report.RecordSelectionFormula;
            //string policyNoFormular = "{" + letter_type + "." + policy_no_field + "} = \"" + policy_no + "\"";

            //string newRecordSelection = "";
            //if (string.IsNullOrWhiteSpace(currentRecordSelection)) {
            //    newRecordSelection = policyNoFormular;
            //}
            //else {
            //    newRecordSelection = string.Format("({0}) and ({1})", currentRecordSelection, policyNoFormular);
            //}

            //report.RecordSelectionFormula = newRecordSelection;

        }     
    }
}
