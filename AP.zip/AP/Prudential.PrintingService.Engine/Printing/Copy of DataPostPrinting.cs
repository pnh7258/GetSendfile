﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Threading;
using Prudential.PrintingService.BussinessLogic;
using System.Configuration;
using System.IO;

namespace Prudential.PrintingService.Engine.Printing
{
    public static class DataPostPrinting
    {        
        public static void Print(Letter letter)
        {            
            try
            {
                string report_name_path = letter.ReportPath + letter.ReportName;
                string criterion = letter.Serial;
                string data_post_ssh_host ="";
                string data_post_ssh_port = "";
                string data_post_ssh_username = "";
                string data_post_sshpassword = "";
                string zip_pass_word = "";
                string pdf_path = "";

                var datapostconfigs = ConfigurationManager.GetSection("PdfConfig") as NameValueCollection;
                if (datapostconfigs != null)
                {
                    data_post_ssh_host = datapostconfigs["DataPostSshHost"];
                    data_post_ssh_port = datapostconfigs["DataPostSshPort"];
                    data_post_ssh_username = datapostconfigs["DataPostSshUsername"];
                    data_post_sshpassword = datapostconfigs["DataPostSshPassword"];
                    zip_pass_word = datapostconfigs["ZipPassWord"];
                    pdf_path = datapostconfigs["PdfPath"];
                }

                string print_date = letter.PrintDate.Trim();
                string[] arrTime = print_date.Split(' ');
                string[] arrddmmyy = arrTime[0].ToString().Split('/');
                string[] arrhhmm = arrTime[1].ToString().Split(':');
                string currTime = arrddmmyy[2] + arrddmmyy[1] + arrddmmyy[0] + arrhhmm[0] + arrhhmm[1] + arrhhmm[2];

                CRAXDRT.Report crReportDocument = IntialReport(report_name_path, criterion,currTime);
                string out_file = pdf_path + letter.LetterType + "_" + currTime + "_" + criterion + ".PDF";

                crReportDocument.ExportOptions.DestinationType = CRAXDRT.CRExportDestinationType.crEDTDiskFile;
                crReportDocument.ExportOptions.DiskFileName = out_file;
                crReportDocument.ExportOptions.PDFExportAllPages = true;
                crReportDocument.ExportOptions.FormatType = CRAXDRT.CRExportFormatType.crEFTPortableDocFormat;

                crReportDocument.Database.Verify();
                crReportDocument.Database.Verify();
                crReportDocument.Database.Verify();
                crReportDocument.Database.Verify();
                crReportDocument.Export(false);

                SshnetFileTransfer ssh = new SshnetFileTransfer(data_post_ssh_host
                 , int.Parse(data_post_ssh_port)
                 , data_post_ssh_username
                 , data_post_sshpassword
              );
                /*
                SshnetFileTransfer ssh = new SshnetFileTransfer(
                    ConfigurationManager.AppSettings["DataPostSshHost"]
                   , int.Parse(ConfigurationManager.AppSettings["DataPostSshPort"])
                   , ConfigurationManager.AppSettings["DataPostSshUsername"]
                   , ConfigurationManager.AppSettings["DataPostSshPassword"]
                );
                 * */

                //SshnetFileTransfer ssh = new SshnetFileTransfer(
                //    "sendfiles.prudential.com.vn"
                //   , 2222
                //   , "pruvnpprint01"
                //   , "88f271QP"
                //);

                //SshnetFileTransfer ssh = new SshnetFileTransfer(
                //    "128.235.107.59"
                //   , 22
                //   , "pru"
                //   , "123"
                //);

                /*
                FileStream stream = new FileStream(out_file, FileMode.Open);
                ssh.Write("/pending/" + letter.LetterType + "_" + DateTime.Now.ToString("yyyyMMdd") + "_" + criterion + ".PDF", stream);
                stream.Close();
                stream = null;
                ssh = null; ---BK---*/

                Stream stream = ZipFile(out_file, zip_pass_word); //new FileStream(out_file, FileMode.Open);
                string currTimeSys = DateTime.Now.ToString("HH:mm:ss").Replace(":", "").Trim();
                ssh.Write("/pending/" + letter.LetterType + "_" + currTime + "_" + currTimeSys + "_" + criterion + ".zip", stream);
                stream.Close();
                stream = null;
                ssh = null;
            }
            catch(Exception ex)
            {
                Common.Logging("File: " + letter.DataFileName + ". " + ex.Message);
                //throw;
            }
        }

        private static Stream ZipFile(string localfilename, string zippassword)
        {
            Stream stream = new MemoryStream();
            Prudential.PrintingService.Engine.Compression.Zipper.CreateFromFile(localfilename, stream, zippassword);
            stream.Seek(0, SeekOrigin.Begin);
            return stream;
        }

        private static CRAXDRT.Report IntialReport(string report_name_path, string criterion,string currentTime)
        {
            CRAXDRT.Application crxApplication = new CRAXDRT.Application();
            CRAXDRT.Report report = new CRAXDRT.Report();
            report = crxApplication.OpenReport(report_name_path, CRAXDRT.CROpenReportMethod.crOpenReportByDefault);
            
            //Set values
            for (int i = 1; i <= report.FormulaFields.Count; i++)
            {
                if (report.FormulaFields[i].FormulaFieldName.Trim().ToLower() == "currenttime")
                {
                    Common.Logging("Processing report " + report_name_path + " timer " + DateTime.Now.ToString("yyyyMMdd") + DateTime.Now.ToString("hhmmss"));
                   // currentTime = DateTime.Now.ToString("yyyyMMdd") + DateTime.Now.ToString("hhmmss");
                    //report.FormulaFields[i].Text = currentTime;
                    report.FormulaFields[i].Text = "\"" + currentTime + "\"";
                    Thread.Sleep(10000);
                    break;
                }
            }

            for (int i = 1; i <= report.FormulaFields.Count; i++)
            {
                if (report.FormulaFields[i].FormulaFieldName.Trim().ToLower() == "criterion")
                {
                    Common.Logging("Processing report " + report_name_path + " criterion " + criterion);
                    report.FormulaFields[i].Text = criterion;
                    Thread.Sleep(10000);
                    break;
                }
            }

            report.Database.Verify();
            Thread.Sleep(1000);
            report.Database.Verify();
            report.PaperOrientation = CRAXDRT.CRPaperOrientation.crDefaultPaperOrientation;
            report.Database.Verify();
            return report;
        }       
    }
}
