﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using Prudential.PrintingService.BussinessLogic;
 
namespace Prudential.PrintingService.Engine.Printing
{
    public static class NonePrinting
    {        
        public static void Print(Letter letter)
        {
            
        }
    }
}
