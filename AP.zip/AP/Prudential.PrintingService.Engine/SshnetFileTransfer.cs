﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using log4net;
using Renci.SshNet;

namespace Prudential.PrintingService.Engine
{
    public class SshnetFileTransfer
    {
        private string host;
        private string username;
        private string password;
        private int port;

        public SshnetFileTransfer(string host, int port, string username, string password)
        {
            this.host = host;
            this.port = port;
            this.username = username;
            this.password = password;
        }

        public string PathCombine(string path, string name)
        {
            return path + '/' + name;
        }

        public Stream OpenRead(string remoteFilePath)
        {
            MemoryStream stream = new MemoryStream();

            using (SftpClient sftp = new SftpClient(host, port, username, password))
            {
                sftp.Connect();
                sftp.DownloadFile(remoteFilePath, stream);
                sftp.Disconnect();
            }

            Common.Logging("Downloaded: " + remoteFilePath + ", size: " + stream.Length + " B");

            stream.Seek(0, SeekOrigin.Begin);
            return stream;
        }
        public void Write(string remoteFilePath, Stream stream)
        {
            using (SftpClient sftp = new SftpClient(host, port, username, password))
            {
                sftp.Connect();
                sftp.UploadFile(stream, remoteFilePath);
                sftp.Disconnect();
            }
        }

        public void MoveFile(string oldFileName, string newFileName)
        {
            using (SftpClient sftpClient = new SftpClient(host, port, username, password))
            {
                sftpClient.Connect();
                sftpClient.RenameFile(oldFileName, newFileName);
                sftpClient.Disconnect();
            }
        }
        public void DeleteFile(string filename)
        {
            using (SftpClient sftpClient = new SftpClient(host, port, username, password))
            {
                sftpClient.Connect();
                sftpClient.DeleteFile(filename);
                sftpClient.Disconnect();
            }
        }

        public void CreateDirectory(string remotePath)
        {
            string[] partials = remotePath.Split(new char[] { '/' }, StringSplitOptions.RemoveEmptyEntries);

            using (SftpClient sftp = new SftpClient(host, port, username, password))
            {
                sftp.Connect();
                foreach (string dir in partials)
                {
                    if (!sftp.Exists(dir))
                    {
                        sftp.CreateDirectory(dir);
                    }
                    sftp.ChangeDirectory(dir);
                }
                sftp.Disconnect();
            }
        }
        public bool Exists(string remoteDirectoryPath)
        {
            bool result = true;

            using (SftpClient sftp = new SftpClient(host, port, username, password))
            {
                sftp.Connect();
                result = sftp.Exists(remoteDirectoryPath);
                sftp.Disconnect();
            }
            return result;
        }
    }
}
