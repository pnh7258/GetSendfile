﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using Ionic;
//using System.Threading.Tasks;

namespace Prudential.PrintingService.Engine.Compression
{
    public class NetfxZipper :IZipper {
        public void CreateFromDirectory(string sourceDirectoryName, Stream output) {
            using (ZipArchive zip = new ZipArchive(output, ZipArchiveMode.Create, true)) {
                foreach (string file in Directory.GetFiles(sourceDirectoryName, "*", SearchOption.TopDirectoryOnly)) {
                    zip.CreateEntryFromFile(file, Path.GetFileName(file));
                }
            }
        }
        public void CreateFromDirectory(string sourceDirectoryName, Stream output, string password) {
            throw new NotSupportedException();
        }


        public void CreateFromFile(string sourceFileName, Stream output, string password)
        {
            throw new NotImplementedException();
        }
    }
}
