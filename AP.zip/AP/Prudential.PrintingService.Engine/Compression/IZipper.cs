﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
//using System.Threading.Tasks;

namespace Prudential.PrintingService.Engine.Compression
{
    public interface IZipper {
        void CreateFromDirectory(string sourceDirectoryName, Stream output);
        void CreateFromDirectory(string sourceDirectoryName, Stream output, string password);
        void CreateFromFile(string sourceFileName, Stream output, string password);
    }
}
