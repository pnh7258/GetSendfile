﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
//using System.Threading.Tasks;
using Ionic.Zip;

namespace Prudential.PrintingService.Engine.Compression
{
    public class DotNetZipper : IZipper 
    {
        public void CreateFromDirectory(string sourceDirectoryName, Stream output, string password) 
        {
            using (ZipFile zip = new ZipFile()) 
            {
                if (!string.IsNullOrEmpty(password)) 
                {
                    zip.Password = password;
                    zip.Encryption = EncryptionAlgorithm.WinZipAes256;
                }

                foreach (string file in Directory.GetFiles(sourceDirectoryName, "*", SearchOption.TopDirectoryOnly)) 
                {
                    zip.AddFile(file, string.Empty);
                }

                zip.Save(output);
            }
        }
        public void CreateFromDirectory(string sourceDirectoryName, System.IO.Stream output) 
        {
            CreateFromDirectory(sourceDirectoryName, output, null);
        }


        public void CreateFromFile(string sourceFileName, Stream output, string password)
        {
            using (ZipFile zip = new ZipFile())
            {
                if (!string.IsNullOrEmpty(password))
                {
                    zip.Password = password;
                    zip.Encryption = EncryptionAlgorithm.WinZipAes256;
                }               
                
                zip.AddFile(sourceFileName, string.Empty);

                zip.Save(output);
            }
        }
    }
}
