﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
//using System.Threading.Tasks;

namespace Prudential.PrintingService.Engine.Compression
{
    public static class Zipper 
    {
        public static IZipper instance = new DotNetZipper();

        public static void SetZipper(IZipper zipper) 
        {
            Zipper.instance = zipper;
        }

        public static void CreateFromDirectory(string sourceDirectoryName, Stream output) 
        {
            instance.CreateFromDirectory(sourceDirectoryName, output);
        }

        public static void CreateFromDirectory(string sourceDirectoryName, Stream output, string password) 
        {
            instance.CreateFromDirectory(sourceDirectoryName, output, password);
        }

        public static void CreateFromFile(string sourceFileName, Stream output, string password)
        {
            instance.CreateFromFile(sourceFileName, output, password);
        }
    }
}
