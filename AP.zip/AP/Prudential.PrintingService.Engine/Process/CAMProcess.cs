﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Reflection;

using Prudential.PrintingService.BussinessLogic;
using Prudential.PrintingService.Engine.Printing;
namespace Prudential.PrintingService.Engine.Process
{
    public class CAMProcess: Process
    {
        public CAMProcess()
        {
            
        }
        public override void Start(string assembly_name)
        {
            Debugger.Break();
            while (1 == 1)
            {
                //Test
                //PdfPrinting.Print(@"C:\CbdPrint\reports\ZCFMLET.rpt", "0", @"C:\CbdPrint\PDF\ZCFMLET.pdf");

                try
                {

                    //Common.Logging(@"PrinterPrinting.PrintTest(C:\CbdPrint\reports\ZCFMLET.rpt, 0, PPITP001);");
                    //GeneralPrinting.Print2(@"C:\CbdPrint\reports\ZCFMLET.rpt", "0", @"C:\CbdPrint\PDF\ZCFMLET.rpt" + ".PDF");
                    //GeneralPrinting.Print(@"C:\CbdPrint\reports\ZCFMLET.rpt", "0", @"C:\CbdPrint\PDF\ZCFMLET.rpt" + ".PDF");
                    //Debugger.Break();
                    //GeneralPrinting.Print(@"C:\CbdPrint\reports\ZCFMLET.rpt", "0", "PPITP001");

                    //Type type = Type.GetType("Prudential.PrintingService.Engine.Printing.PrinterPrintingEx");
                    //MethodInfo info = type.GetMethod("Print");
                    //string[] obj = new string[3];
                    //obj[0] = @"C:\CbdPrint\reports\ZCFMLET.rpt";
                    //obj[1] = "0";
                    //obj[2] = "HP Color LaserJet 4500 PCL6";

                    //info.Invoke(null, obj);
                }
                catch (Exception e)
                {
                    Common.Logging(e.Message);
                }
                //End Test
                try
                {
                    string[] filenames = Directory.GetFiles(DataFilePath, "*.R").Select(f => Path.GetFileName(f)).ToArray();

                    foreach (string filename in filenames)
                    {
                        try
                        {
                            Common.Logging("Processing file " + filename);

                            Type assembly_type = Type.GetType(assembly_name, false, true);


                            Letter letter = (Letter)Activator.CreateInstance(assembly_type, new string[] { filename, DataFilePath, ReportPath, PdfPath });
                        
                            //Letter letter = new CAMLetter(filename, DataFilePath, ReportPath, PdfPath);

                            Type type = null;
                            MethodInfo info = null;

                            string[] obj = new string[3];
                            obj[0] = letter.ReportPath + letter.ReportName;
                            obj[1] = letter.Serial;
                            obj[2] = letter.PrinterName;

                            switch (letter.PrinterName)
                            {
                                case "PDF":
                                    //PdfPrinting.Print(letter.ReportPath + letter.ReportName, letter.Serial, letter.PDFPath + letter.DataFileName + ".PDF");
                                    type = Type.GetType(PdfPrintingLibrary);
                                    info = type.GetMethod("Print");
                                    obj[2] = letter.PDFPath + letter.DataFileName + ".PDF";
                                    info.Invoke(null, obj);
                                    break;
                                case "NOPR":
                                case "NOPRINT":
                                    break;
                                default:
                                    Common.Logging("Load report file " + filename + " to printer " + letter.PrinterName);
                                    GeneralPrinting.Print(letter.ReportPath + letter.ReportName, letter.Serial, letter.PrinterName);
                                    //PrinterPrintingEx.Print(letter.ReportPath + letter.ReportName, letter.Serial, letter.PrinterName);
                                    //type = Type.GetType(PrinterPrintingLibrary);
                                    //info = type.GetMethod("Print");
                                    //info.Invoke(null, obj);
                                    break;
                            }
                            letter.Delete();
                            //Ultilities.RemoveData(letter.LetterType, letter.Serial);
                            Common.Logging("Finished file " + filename);
                        }
                        catch (Exception ex)
                        {
                            Common.Logging(ex.Message);
                            continue;
                        }
                    }
                    Thread.Sleep(1000);
                }
                catch (Exception ex)
                {
                    Common.Logging(ex.Message);
                    continue;
                }
            }
        }
    }
}
