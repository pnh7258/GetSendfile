﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Configuration;
using System.IO;
using System.Diagnostics;
using System.ServiceProcess;
using Prudential.PrintingService.BussinessLogic;
using System.ComponentModel;
using System.Data;
using System.Reflection;
using System.Threading;
using Prudential.PrintingService.Engine.Printing;

namespace Prudential.PrintingService.Engine.Process
{
    public class Process
    {
        public string DataFilePath { get; set; }
        public string DatabasePath { get; set; }
        public string ReportPath { get; set; }
        public string PdfPath { get; set; }

        public string PdfPrintingLibrary { get; set; }
        public string PrinterPrintingLibrary { get; set; }

        public NameValueCollection ConfigList { get; set; }

        public Process()
        {
            DataFilePath = ConfigurationManager.AppSettings["DataFilePath"];
            ReportPath = ConfigurationManager.AppSettings["ReportPath"];
            PdfPath = ConfigurationManager.AppSettings["PDFPath"];
            PdfPrintingLibrary = ConfigurationManager.AppSettings["PdfPrintingLibrary"];
            PrinterPrintingLibrary = ConfigurationManager.AppSettings["PrinterPrintingLibrary"];
            DatabasePath = ConfigurationManager.AppSettings["DatabasePath"];
            ConfigList = ConfigurationManager.AppSettings;
        }

        public virtual void Start(string assembly_name)
        {
            string printing_assembly = "";
            //Debugger.Break();
            while (1 == 1)
            {
                try
                {
                    string[] filenames = Directory.GetFiles(DataFilePath, "*.R").Select(f => Path.GetFileName(f)).ToArray();

                    foreach (string filename in filenames)
                    {
                        try
                        {
                            Common.Logging("Processing file " + filename);

                            //Type assembly_type = Type.GetType(assembly_name);
                            Type assembly_type = Assembly.Load("Prudential.PrintingService.BussinessLogic").GetType(assembly_name);

                            Letter letter = (Letter)Activator.CreateInstance(assembly_type, new string[] { filename, DataFilePath, ReportPath, DatabasePath, DatabasePath });
                            //Letter letter = new CAMLetter(filename, DataFilePath, ReportPath, PdfPath);

                            if (String.IsNullOrEmpty(letter.ExMessage) == true) {
                                Type type = null;
                                MethodInfo info = null;

                                try {
                                    printing_assembly = ConfigList[letter.PrinterName];

                                    if (printing_assembly == null) {
                                        printing_assembly = ConfigList["PRINTER"];
                                    }
                                }
                                catch {
                                    printing_assembly = ConfigList["PRINTER"];
                                }

                                bool isSuccess = false;
                                string Method = printing_assembly.Split('.').Last();
                                switch (Method.ToLower())
                                {
                                    case "pdfprinting":
                                        isSuccess = PdfPrinting.Print(letter);
                                        break;
                                    case "printerprintingex":
                                        isSuccess = PrinterPrintingEx.Print(letter);
                                        break;
                                    case "printerprintingnet":
                                        isSuccess = PrinterPrintingNet.Print(letter);
                                        break;
                                    case "generadataoracle":
                                        isSuccess = GeneraDataOracle.Print(letter);
                                        break;
                                    case "datapostprinting":
                                        isSuccess = DataPostPrinting.Print(letter);
                                        break;
                                    default:
                                        isSuccess = true;
                                        break;
                                }

                                #region cmt
                                //type = Type.GetType(printing_assembly);
                                //Letter[] arg = new Letter[1];
                                //arg[0] = letter;
                                //info = type.GetMethod("Print", new[] { typeof(Letter) });
                                //if (info == null)
                                //{
                                //    Common.Logging("Ambiguous match found when accessing dll");
                                //    Thread.Sleep(1000);
                                //    continue;
                                //}

                                //info.Invoke(null, arg);

                                //// Remove Data After Success
                                //// Exception when seri = 0
                                //if (Int64.Parse(letter.Serial) != 0)
                                //    Prudential.PrintingService.BussinessLogic.Ultilities.RemoveData(letter.DataBaseFilePath, letter.LetterType, letter.Serial);

                                #endregion

                                if(isSuccess)
                                    Common.Logging("Successed file " + filename);
                                else
                                    Common.Logging("Error file " + filename + " : " + letter.ExMessage);
                            }
                            else
                                Common.Logging("Error file " + filename + " : " + letter.ExMessage);


                            letter.Delete();
                        }
                        catch (Exception ex)
                        {
                            Common.Logging(ex.Message);
                            Thread.Sleep(10000);
                            continue;
                        }

                        Thread.Sleep(1000);
                    }                    
                }
                catch (Exception ex)
                {
                    Common.Logging(ex.Message);
                    continue;
                }
            }
        }
    }
}
