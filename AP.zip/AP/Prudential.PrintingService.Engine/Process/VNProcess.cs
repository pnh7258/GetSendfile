﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading;
using Prudential.PrintingService.BussinessLogic;
using Prudential.PrintingService.Engine.Printing;
namespace Prudential.PrintingService.Engine.Process
{
    public class VNProcess:Process
    {
        public VNProcess()
        {
            
        }
        public override void Start(string assembly_name)
        {           
            while (1 == 1)
            {
                try
                {
                    string[] filenames = Directory.GetFiles(DataFilePath, "*.R").Select(f => Path.GetFileName(f)).ToArray();

                    foreach (string filename in filenames)
                    {
                        try
                        {
                            Common.Logging("Processing file " + filename);

                            //Letter letter = new VNLetter(filename, DataFilePath, ReportPath, PdfPath);
                            Type assembly_type = Type.GetType(assembly_name, false, true);

                            Letter letter = (Letter)Activator.CreateInstance(assembly_type, new string[] { filename, DataFilePath, ReportPath, PdfPath });
                        
                            switch (letter.PrinterName)
                            {
                                case "PDF":
                                    PdfPrinting.Print(letter.ReportPath + letter.ReportName, letter.Serial, letter.PDFPath + letter.DataFileName + ".PDF");
                                    break;
                                case "NOPR":
                                case "NOPRINT":
                                    break;
                                default:
                                    PrinterPrinting.Print(letter.ReportPath + letter.ReportName, letter.Serial, letter.PrinterName);
                                    break;
                            }                            
                            letter.Delete();
                            //Ultilities.RemoveData(letter.LetterType, letter.Serial);
                            Common.Logging("Finished file " + filename);
                        }
                        catch (Exception ex)
                        {
                            Common.Logging(ex.Message);
                            continue;
                        }
                    }
                    Thread.Sleep(1000);
                }
                catch (Exception ex)
                {
                    Common.Logging(ex.Message);
                    continue;
                }
            }
        }
    }
}
