﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Configuration;
using System.IO;
using System.Diagnostics;
using System.ServiceProcess;
using Prudential.PrintingService.BussinessLogic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Reflection;
using System.Threading;
using Prudential.PrintingService.BussinessLogic;
using Prudential.PrintingService.Engine.Printing;
using System.Runtime.InteropServices;
using Prudential.PrintingService.BussinessLogic.RMeta;
using System.Threading.Tasks;
using log4net;
namespace Prudential.PrintingService.Engine.Process
{
    public class Comsumer
    {
        private static readonly ILog log = LogManager.GetLogger(typeof(Comsumer));
        public Queue queue = new Queue();
        public string DataFilePath { get; set; }
        public string DataBaseFilePath { get; set; }
        public string ReportPath { get; set; }
        public string PDFPath { get; set; }
        public string DataFileErrorBackupPath { get; set; }
        public string DataBaseFilePathSource { get; set; }

        public string IsEmailAlert { get; set; }
        public string SmtpServer { get; set; }
        public string SmtpPort { get; set; }
        public string EmailAlertFrom { get; set; }
        public string EmailAlertTo { get; set; }
        public string AssemblyLetter { get; set; }
        public string isUnicode { get; set; }
        // public List<RFileMetaData> rFiles { get; set; }
        public NameValueCollection PrinterConfigList { get; set; }

        public Comsumer()
        {

        }

        public Comsumer(Queue q)
        {
            this.queue = q;
        }
        public virtual void Start()
        {
            this.Start(this.AssemblyLetter);
        }

        public virtual void Start(string assembly_name)
        {
            string printing_assembly = "";

            while (true)
            {
                Letter letter = null;
                try
                {
                    //string[] filenames = Directory.GetFiles(DataFilePath, "*.R").Select(f => Path.GetFileName(f)).ToArray();
                    if (this.queue.Count <= 0)
                    {
                        Thread.Sleep(1000);
                        continue;
                    }

                    Console.WriteLine("Pre - Dequeue: " + this.queue.Count.ToString());
                    string filename = (string)this.queue.Dequeue();
                    Console.WriteLine("Dequeue: " + filename + ", count:" + this.queue.Count.ToString());

                    try
                    {
                        Common.Logging("Processing file " + filename + " at queue: " + this.queue.GetHashCode());

                        Type assembly_type = Assembly.Load("Prudential.PrintingService.BussinessLogic").GetType(assembly_name);

                        letter = (Letter)Activator.CreateInstance(assembly_type, new string[] { filename, DataFilePath, ReportPath, DataBaseFilePath, DataBaseFilePathSource });

                        if (String.IsNullOrEmpty(letter.ExMessage) == true)
                        {
                            //Type type = null;
                            //MethodInfo info = null;
                            try
                            {
                                printing_assembly = PrinterConfigList[letter.PrinterName];

                                if (printing_assembly == null)
                                {
                                    printing_assembly = PrinterConfigList["PRINTER"];
                                }
                            }
                            catch
                            {
                                printing_assembly = PrinterConfigList["PRINTER"];
                            }

                            //type = Type.GetType(printing_assembly);

                            bool isSuccess = false;
                            string Method = printing_assembly.Split('.').Last();
                           
                            switch (Method.ToLower())
                            {
                                case "pdfprinting":
                                    isSuccess = PdfPrinting.Print(letter);
                                    break;
                                case "printerprintingex":
                                    isSuccess = PrinterPrintingEx.Print(letter);
                                    break;
                                case "printerprintingnet":
                                    isSuccess = PrinterPrintingNet.Print(letter);
                                    break;
                                case "generadataoracle":
                                    isSuccess = GeneraDataOracle.Print(letter);
                                    break;
                                case "generadataoracle_v2":
                                    isSuccess = GeneraDataOracle_V2.Print(letter);
                                    break;
                                case "datapostprinting":
                                    isSuccess = DataPostPrinting.Print(letter);
                                    break;
                                case "cmarchiveprintingnet":
                                    isSuccess = CMArchivePrintingNet.Print(letter);
                                    break;
                                case "edocumentprintingnet":
                                    isSuccess = EDocumentPrintingNet.Print(letter);
                                    break;
                                default:
                                    isSuccess = true;
                                    break;
                            }

                            if (isSuccess && Boolean.Parse(letter.IsPruConnect) == true)
                            {
                                bool isGenerateOr = GeneraDataOracle.Print(letter);
                                //if(isGenerateOr == false)
                                //    Common.Logging("Error GeneraDataOracle Ex -" + filename + " : " + letter.ExMessage.ToLower());

                                if (isGenerateOr == false && letter.ExMessage.ToLower().Contains("path specified"))
                                    Ultilities.RenamePrinter(letter.DataFilePath + letter.DataFileName, "NOPRINT");
                            }

                            if (isSuccess == false)
                            {
                                letter.ErrorBackup(this.DataFileErrorBackupPath);
                                Common.Logging("Error file " + filename + " : " + letter.ExMessage);
                            }
                            else
                                Common.Logging("Successed-Print: " + letter.DataFilePath + letter.DataFileName + " successful - " + letter.UserName.ToString() + " - " + letter.PrinterName + " - " + DateTime.Now.ToString("dd/mm/yyyy hh:mm:ss"));

                            letter.Delete();
                        }
                        else
                        {
                            if (letter.ExMessage == "Data no data")
                                letter.Delete();
                            else
                                letter.ErrorBackup(this.DataFileErrorBackupPath);
                            Common.Logging("Error file " + filename + " : " + letter.ExMessage);
                        }
                    }
                    catch (Exception ex)
                    {
                        // Backup khi Error
                        if (letter != null)
                            letter.ErrorBackup(this.DataFileErrorBackupPath);

                        if (ex.InnerException != null)
                            Common.Logging(ex.InnerException.Message);
                        else
                            Common.Logging(ex.Message);

                        Common.Logging(String.Format("Prudential.PrintingService.Engine.Process.Comsumer - Error: {0}", ex));

                        if (IsEmailAlert == "true")
                        {
                            try
                            {
                                if (ex.InnerException != null)
                                    Common.EmailTo(SmtpServer, SmtpPort, EmailAlertFrom, EmailAlertTo.Split(','), filename + ". Error detail: " + ex.InnerException.Message);
                                else
                                    Common.EmailTo(SmtpServer, SmtpPort, EmailAlertFrom, EmailAlertTo.Split(','), filename + ". Error detail: " + ex.Message);
                            }
                            catch
                            {

                            }
                        }

                        Thread.Sleep(1000);
                        continue;
                    }

                    Thread.Sleep(1000);
                }
                catch (Exception ex)
                {
                    Common.Logging(String.Format("Prudential.PrintingService.Engine.Process.Comsumer - Error: {0}\n{1}", ex.Message, ex));
                    continue;
                }
            }
        }

    }
}
