﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.IO;
using System.Net.Mail; 
using log4net;

namespace Prudential.PrintingService.Engine
{
    public static class Common
    {
        private static ILog _logger;
               
        public static void RenameFile(string old_path, string new_path)
        {
            File.Move(old_path, new_path);
        }

        public static void MoveFile(string old_path, string new_path)
        {
            File.Move(old_path, new_path);
        }

        public static void DeleteFile(string path)
        {
            File.Delete(path);
        }

        public static void EmailTo(string smtp_server, string smtp_port, string from, string[] to, string body)
        {
            SmtpClient SmtpServer = new SmtpClient();
            //SmtpServer.Credentials = new System.Net.NetworkCredential("lbt.khang@prudential.com.vn", "*****");
            SmtpServer.Port = int.Parse(smtp_port);
            SmtpServer.Host = smtp_server;
            SmtpServer.EnableSsl = false;
            MailMessage mail = new MailMessage();
            mail.From = new MailAddress(from);
            for (int i = 0; i < to.Length; i++ )
                mail.To.Add(to[i]);

            mail.Subject = "CM Archive Error";
            mail.Body = body;
            mail.IsBodyHtml = true;
            mail.DeliveryNotificationOptions = DeliveryNotificationOptions.OnFailure;
            SmtpServer.Send(mail);
        }
        public static void Logging(string log)
        {
            //EventLog.WriteEntry("CAMPrintingService", log);
            log4net.Config.XmlConfigurator.Configure();
            _logger = LogManager.GetLogger("RollingLogFileAppender");
            _logger.Error(log);
            //_logger.Debug(log);
            Console.WriteLine(log);
        }

        private static string[] Aviqr = {"''","a(`", "A(`", "a(?", "A(?", "a(~", "A(~", "a('", "A('", "a(.", "A(.", 
                                "a^`", "A^`", "a^?", "A^?", "a^~", "A^~", "a^'", "A^'", "a^.", "A^.", 
                                "e^`", "E^`", "e^?", "E^?", "e^~", "E^~", "e^'", "E^'", "e^.", "E^.", 
                                "o^`", "O^`", "o^?", "O^?", "o^~", "O^~", "o^'", "O^'", "o^.", "O^.", 
                                "o+`", "O+`", "o+?", "O+?", "o+~", "O+~", "o+'", "O+'", "o+.", "O+.", 
                                "o*`", "O*`", "o*?", "O*?", "o*~", "O*~", "o*'", "O*'", "o*.", "O*.", 
                                "u+`", "U+`", "u+?", "U+?", "u+~", "U+~", "u+'", "U+'", "u+.", "U+.", 
                                "u*`", "U*`", "u*?", "U*?", "u*~", "U*~", "u*'", "U*'", "u*.", "U*.", 
                                "A(", "A^", "E^", "O^", "O+", "U+", "U*", "DD", "-D", "Dd", "a(", "a^",
                                "e^", "o^", "o+", "o*", "u+", "u*", "dd", "-d", "d-", "a`", "A`", 
                                "a?", "A?", "a~", "A~", "a'", "A'", "a.", "A.", "e`", "E`", 
                                "e?", "E?", "e~", "E~", "e'", "E'", "e.", "E.", "i`", "I`", 
                                "i?", "I?", "i~", "I~", "i'", "I'", "i.", "I.", "o`", "O`", 
                                "o?", "O?", "o~", "O~", "o'", "O'", "o.", "O.", "u`", "U`", 
                                "u?", "U?", "u~", "U~", "u'", "U'", "u.", "U.", "y`", "Y`", 
                                "y?", "Y?", "y~", "Y~", "y'", "Y'", "y.", "Y."};

        private static string[] Auni = {"'",Convert.ToChar(7857).ToString(), Convert.ToChar(7856).ToString(), Convert.ToChar(7859).ToString(), Convert.ToChar(7858).ToString(), Convert.ToChar(7861).ToString(), Convert.ToChar(7860).ToString(), Convert.ToChar(7855).ToString(), Convert.ToChar(7854).ToString(), Convert.ToChar(7863).ToString(), Convert.ToChar(7862).ToString(), 
            Convert.ToChar(7847).ToString(), Convert.ToChar(7846).ToString(), Convert.ToChar(7849).ToString(), Convert.ToChar(7848).ToString(), Convert.ToChar(7851).ToString(), Convert.ToChar(7850).ToString(), Convert.ToChar(7845).ToString(), Convert.ToChar(7844).ToString(), Convert.ToChar(7853).ToString(), Convert.ToChar(7852).ToString(), 
            Convert.ToChar(7873).ToString(), Convert.ToChar(7872).ToString(), Convert.ToChar(7875).ToString(), Convert.ToChar(7874).ToString(), Convert.ToChar(7877).ToString(), Convert.ToChar(7876).ToString(), Convert.ToChar(7871).ToString(), Convert.ToChar(7870).ToString(), Convert.ToChar(7879).ToString(), Convert.ToChar(7878).ToString(), 
            Convert.ToChar(7891).ToString(), Convert.ToChar(7890).ToString(), Convert.ToChar(7893).ToString(), Convert.ToChar(7892).ToString(), Convert.ToChar(7895).ToString(), Convert.ToChar(7894).ToString(), Convert.ToChar(7889).ToString(), Convert.ToChar(7888).ToString(), Convert.ToChar(7897).ToString(), Convert.ToChar(7896).ToString(), 
            Convert.ToChar(7901).ToString(), Convert.ToChar(7900).ToString(), Convert.ToChar(7903).ToString(), Convert.ToChar(7902).ToString(), Convert.ToChar(7905).ToString(), Convert.ToChar(7904).ToString(), Convert.ToChar(7899).ToString(), Convert.ToChar(7898).ToString(), Convert.ToChar(7907).ToString(), Convert.ToChar(7906).ToString(), 
            Convert.ToChar(7901).ToString(), Convert.ToChar(7900).ToString(), Convert.ToChar(7903).ToString(), Convert.ToChar(7902).ToString(), Convert.ToChar(7905).ToString(), Convert.ToChar(7904).ToString(), Convert.ToChar(7899).ToString(), Convert.ToChar(7898).ToString(), Convert.ToChar(7907).ToString(), Convert.ToChar(7906).ToString(), 
            Convert.ToChar(7915).ToString(), Convert.ToChar(7914).ToString(), Convert.ToChar(7917).ToString(), Convert.ToChar(7916).ToString(), Convert.ToChar(7919).ToString(), Convert.ToChar(7918).ToString(), Convert.ToChar(7913).ToString(), Convert.ToChar(7912).ToString(), Convert.ToChar(7921).ToString(), Convert.ToChar(7920).ToString(), 
            Convert.ToChar(7915).ToString(), Convert.ToChar(7914).ToString(), Convert.ToChar(7917).ToString(), Convert.ToChar(7916).ToString(), Convert.ToChar(7919).ToString(), Convert.ToChar(7918).ToString(), Convert.ToChar(7913).ToString(), Convert.ToChar(7912).ToString(), Convert.ToChar(7921).ToString(), Convert.ToChar(7920).ToString(), 
            Convert.ToChar(258).ToString(), Convert.ToChar(194).ToString(), Convert.ToChar(202).ToString(), Convert.ToChar(212).ToString(), Convert.ToChar(416).ToString(), Convert.ToChar(431).ToString(), Convert.ToChar(431).ToString(), Convert.ToChar(272).ToString(), Convert.ToChar(272).ToString(), Convert.ToChar(272).ToString(), Convert.ToChar(259).ToString(), Convert.ToChar(226).ToString(), 
            Convert.ToChar(234).ToString(), Convert.ToChar(244).ToString(), Convert.ToChar(417).ToString(), Convert.ToChar(417).ToString(), Convert.ToChar(432).ToString(), Convert.ToChar(432).ToString(), Convert.ToChar(273).ToString(), Convert.ToChar(273).ToString(), Convert.ToChar(273).ToString(), Convert.ToChar(224).ToString(), Convert.ToChar(192).ToString(), 
            Convert.ToChar(7843).ToString(), Convert.ToChar(7842).ToString(), Convert.ToChar(227).ToString(), Convert.ToChar(195).ToString(), Convert.ToChar(225).ToString(), Convert.ToChar(193).ToString(), Convert.ToChar(7841).ToString(), Convert.ToChar(7840).ToString(), Convert.ToChar(232).ToString(), Convert.ToChar(200).ToString(), 
            Convert.ToChar(7867).ToString(), Convert.ToChar(7866).ToString(), Convert.ToChar(7869).ToString(), Convert.ToChar(7868).ToString(), Convert.ToChar(233).ToString(), Convert.ToChar(201).ToString(), Convert.ToChar(7865).ToString(), Convert.ToChar(7864).ToString(), Convert.ToChar(236).ToString(), Convert.ToChar(204).ToString(), 
            Convert.ToChar(7881).ToString(), Convert.ToChar(7880).ToString(), Convert.ToChar(297).ToString(), Convert.ToChar(296).ToString(), Convert.ToChar(237).ToString(), Convert.ToChar(205).ToString(), Convert.ToChar(7883).ToString(), Convert.ToChar(7882).ToString(), Convert.ToChar(242).ToString(), Convert.ToChar(210).ToString(),
            Convert.ToChar(7887).ToString(), Convert.ToChar(7886).ToString(), Convert.ToChar(245).ToString(), Convert.ToChar(213).ToString(), Convert.ToChar(243).ToString(), Convert.ToChar(211).ToString(), Convert.ToChar(7885).ToString(), Convert.ToChar(7884).ToString(), Convert.ToChar(249).ToString(), Convert.ToChar(217).ToString(),
            Convert.ToChar(7911).ToString(), Convert.ToChar(7910).ToString(), Convert.ToChar(361).ToString(), Convert.ToChar(360).ToString(), Convert.ToChar(250).ToString(), Convert.ToChar(218).ToString(), Convert.ToChar(7909).ToString(), Convert.ToChar(7908).ToString(), Convert.ToChar(7923).ToString(), Convert.ToChar(7922).ToString(),
            Convert.ToChar(7927).ToString(), Convert.ToChar(7926).ToString(), Convert.ToChar(7929).ToString(), Convert.ToChar(7928).ToString(), Convert.ToChar(253).ToString(), Convert.ToChar(221).ToString(), Convert.ToChar(7925).ToString(), Convert.ToChar(7924).ToString()};

        public static string VIQR2Unicode(string strUnicode)
        {
            if (strUnicode == null) return "";

            // string[] Aurl = { "com", "net", "org", "htm", "html", "asp", "swf", "jpg", "gif" };

            strUnicode = strUnicode.Replace(" ", " ");
            strUnicode = strUnicode.Replace("‘", "'");
            strUnicode = strUnicode.Replace("’", "'");


            for (int i = 0; i < Aviqr.Length; i++)
            {
                strUnicode = strUnicode.Replace(Aviqr[i], Auni[i]);
            }

            return strUnicode;
        }
    }
}
