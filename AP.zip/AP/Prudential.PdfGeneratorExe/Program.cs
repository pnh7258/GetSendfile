﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Prudential.PrintingService.Engine.Printing;

namespace Prudential.PdfGeneratorExe
{
    class Program
    {
        static void Main(string[] args)
        {
           
            PdfGenerator _ref = new PdfGenerator();
           _ref.ExcutePdfGenerator(args[0].ToString());
          //  PdfGeneratorLib.PdfGenerator _ref = new PdfGeneratorLib.PdfGenerator();
          //  _ref.ExcutePdfGenerator(args[0].ToString());
        }
    }
}
