﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using Prudential.PrintingService.Engine;

namespace Prudential.PrintingService.MultiThreadAppPrinting
{
    public class AppPrinting
    {
        static Queue thread1_queue = Queue.Synchronized(new Queue());
        static Queue thread2_queue = Queue.Synchronized(new Queue());
        static Queue thread3_queue = Queue.Synchronized(new Queue());
        static Queue thread4_queue = Queue.Synchronized(new Queue());
        static Queue thread5_queue = Queue.Synchronized(new Queue());
        static Queue thread6_queue = Queue.Synchronized(new Queue());
        static Queue thread7_queue = Queue.Synchronized(new Queue());
        static Queue thread8_queue = Queue.Synchronized(new Queue());
        static Queue thread9_queue = Queue.Synchronized(new Queue());
        static Thread consumer_thread = null;
        static string PathFile;

        public static void StartServicePrinting()
        {
            try
            {
                ProcessPrinting();
            }catch(Exception ex)
            {
                string mess = ex.Message.ToString();
            }
        }
        static Queue GetQueue(string thread_name)
        {
            switch (thread_name)
            {
                case "Thread1Config":
                    return thread1_queue;
                case "Thread2Config":
                    return thread2_queue;
                case "Thread3Config":
                    return thread3_queue;
                case "Thread4Config":
                    return thread4_queue;
                case "Thread5Config":
                    return thread5_queue;
                case "Thread6Config":
                    return thread6_queue;
                case "Thread7Config":
                    return thread7_queue;
                case "Thread8Config":
                    return thread8_queue;
                case "Thread9Config":
                    return thread9_queue;
                default:
                    return null;
            }
        }

        public static void ProcessPrinting()
        {
            try
            {
                string data_file_path = "";
                string database_file_path = "";
                string report_path = "";
                string data_file_error_backup_path = "";
                string assembly_letter = "";
                string is_email_alert = "";
                string smtp_server = "";
                string smtp_port = "";
                string email_alert_from = "";
                string email_alert_to = "";
                string database_file_path_source = "";
                NameValueCollection printer_config_list = new NameValueCollection();

                //COMMON
                var smtpconfigs = ConfigurationManager.GetSection("SmtpConfig") as NameValueCollection;
                if (smtpconfigs != null)
                {
                    is_email_alert = smtpconfigs["IsEmailAlert"];
                    smtp_server = smtpconfigs["SmtpServer"];
                    smtp_port = smtpconfigs["SmtpPort"];
                    email_alert_from = smtpconfigs["EmailAlertFrom"];
                    email_alert_to = smtpconfigs["EmailAlertTo"];
                }

                printer_config_list = ConfigurationManager.GetSection("PrinterConfig") as NameValueCollection;
                List<string> other_rs = new List<string>();

                //THREAD COMSUMER
                var threadconfigs = ConfigurationManager.GetSection("ThreadConfig") as NameValueCollection;
                foreach (string config in threadconfigs)
                {
                    var threadconfig = ConfigurationManager.GetSection(config) as NameValueCollection;
                    if (threadconfig != null)
                    {
                        data_file_path = threadconfig["DataFilePath"];
                        database_file_path = threadconfig["DataBasePath"];
                        PathFile = data_file_path;
                        report_path = threadconfig["ReportPath"];
                        data_file_error_backup_path = threadconfig["DataFileErrorBackupPath"];
                        assembly_letter = threadconfig["AssemblyLetter"];
                        database_file_path_source = threadconfig["DataPathFileSource"];

                        other_rs.AddRange(threadconfig["FileR"].Split(';'));

                        var consumer = new Prudential.PrintingService.Engine.Process.Comsumer(GetQueue(config));
                        consumer.AssemblyLetter = assembly_letter;
                        consumer.DataFileErrorBackupPath = data_file_error_backup_path;
                        consumer.DataFilePath = data_file_path;
                        consumer.DataBaseFilePath = database_file_path;
                        consumer.ReportPath = report_path;
                        consumer.PrinterConfigList = printer_config_list;
                        consumer.IsEmailAlert = is_email_alert;
                        consumer.EmailAlertFrom = email_alert_from;
                        consumer.EmailAlertTo = email_alert_to;
                        consumer.SmtpPort = smtp_port;
                        consumer.SmtpServer = smtp_server;
                        consumer.DataBaseFilePathSource = database_file_path_source;

                        Thread consumer_thread = new Thread(new ThreadStart(consumer.Start));
                        consumer_thread.Start();
                    }
                }
                Thread thread = new Thread(() => Producer(data_file_path, other_rs, ConfigurationManager.GetSection("ThreadConfig") as NameValueCollection));
                thread.Start();
            }
            catch (Exception ex)
            {
                string mess = ex.Message.ToString();
                Common.Logging("CMArchive - ProcessPrinting: " + ex.Message);
            }
        }

        public static void Producer(string data_file_path, List<string> other_rs, NameValueCollection threadconfigs)
        {
            try
            {
                string[] file_rs;
                string first_filename;
                string filename_new = string.Empty;

                List<string> ArrExist = new List<string>();
                while (true)
                {
                    string[] filenames = Directory.GetFiles(data_file_path, "*.R").Select(f => Path.GetFileName(f)).ToArray();
                    foreach (string filename in filenames)
                    {
                        /*
                        if (ArrExist.Contains(filename))
                            continue;
                        else
                            ArrExist.Add(filename);
                        */

                        first_filename = filename.Split('-')[0];

                        //filename_new = filename + ".l";
                        //File.Move(data_file_path + filename, data_file_path + filename_new);

                        //first_filename = filename_new.Split('-')[0];


                        filename_new = filename.Substring(0, filename.Length - 2) + ".l";
                        try
                        {
                            if (File.Exists(data_file_path + filename_new))
                                File.Delete(data_file_path + filename_new);
                            File.Move(data_file_path + filename, data_file_path + filename_new);
                        }
                        catch (Exception ex)
                        {
                            Common.Logging(String.Format("VNPrint_Main - Producer: {0} \n{1}", ex.Message, ex));
                            continue;
                        }

                        try
                        {
                            foreach (string config in threadconfigs)
                            {
                                var threadconfig = ConfigurationManager.GetSection(config) as NameValueCollection;
                                if (threadconfig != null)
                                {
                                    file_rs = threadconfig["FileR"].Split(';');

                                    foreach (string file_r in file_rs)
                                    {
                                        if (file_r == "Other")
                                        {
                                            if (other_rs.Contains(first_filename) == false)
                                            {
                                                if (!GetQueue(config).Contains(filename_new))
                                                {
                                                    GetQueue(config).Enqueue(filename_new);
                                                    Console.WriteLine("Push " + filename_new);
                                                }
                                            }
                                        }

                                        if (first_filename.Equals(file_r) == true)
                                        {
                                            if (!GetQueue(config).Contains(filename_new))
                                            {
                                                GetQueue(config).Enqueue(filename_new);
                                                Console.WriteLine("Push " + filename_new);
                                            }
                                        }
                                    }
                                }

                            }
                        }
                        catch
                        {

                        }
                    }

                    Thread.Sleep(1000);
                }
            }
            catch (Exception ex)
            {
                string mess = ex.Message.ToString();
                Common.Logging("CMArchive - Producer: " + ex.Message);
            }
        }

    }
}
