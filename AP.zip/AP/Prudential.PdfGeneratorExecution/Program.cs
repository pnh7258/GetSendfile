﻿using System;
using System.Linq;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Threading;
using System.Configuration;
using System.IO;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System.Diagnostics;
using System.Runtime.InteropServices;
using Prudential.PrintingService.Engine.Printing;

namespace Prudential.PdfGeneratorExecution
{
    class PdfGeneratorExecution
    {
     //   private static ILog _logger;

        static void Main(string[] args)
        {
            CMArchivePrintingNet.ExcutePdfGenerator(args[0].ToString());
         //   PdfGeneratorLib.PdfGenerator _ref = new PdfGeneratorLib.PdfGenerator();
        //    string strRs = _ref.ExcutePdfGenerator(args[0].ToString());
           // Console.WriteLine(strRs);
           // Console.ReadLine();
            /*
            string[] arrArgs = args[0].ToString().Split('|');
            string out_file = arrArgs[0];
            string report_name_path = arrArgs[1];
            string criterion = arrArgs[2];
            string policy_no = arrArgs[3];
            string LetterType = arrArgs[4];
            string PolicyNoField = arrArgs[5];
            string currenttime = arrArgs[6];
            string DataBaseFilePath = arrArgs[7];
            try
            {
                var report = new ReportDocument();
                report.Load(report_name_path, OpenReportMethod.OpenReportByDefault);
                IntialReport(report, report_name_path, criterion, policy_no, LetterType, PolicyNoField, currenttime, DataBaseFilePath);
                report.VerifyDatabase();
                report.ExportToDisk(ExportFormatType.PortableDocFormat, out_file);
                //clear
                report.Close();
                report.Dispose();
                report = null;
              //  string
            }
            catch (Exception ex)
            {
               // Logging(ex.Message.ToString());
                Console.WriteLine(ex.InnerException.ToString());
                Console.ReadLine();
               // Console.WriteLine(ex.Message.ToString());
            }
            finally
            {

            }*/
        
        }
        /*
        public static void Logging(string log)
        {
            //EventLog.WriteEntry("CAMPrintingService", log);
            log4net.Config.XmlConfigurator.Configure();
            _logger = LogManager.GetLogger("RollingLogFileAppender");
            _logger.Error(log);
            //_logger.Debug(log);
        }
        */

        private static void IntialReport(ReportDocument report, string report_name_path, string criterion, string policy_no, string letter_type, string policy_no_field, string currenttime, string database_file_path)
        {
            foreach (Table table in report.Database.Tables)
            {
                table.Location = database_file_path;
            }

            foreach (ReportDocument subreport in report.Subreports)
            {
                foreach (Table table in subreport.Database.Tables)
                {
                    table.Location = database_file_path;
                }
            }

            //Set values
            foreach (FormulaFieldDefinition formula in report.DataDefinition.FormulaFields)
            {
                if (formula.Name == "criterion")
                {
                    formula.Text = criterion;
                }

                if (formula.Name == "currenttime")
                {
                    formula.Text = "\"" + currenttime + "\"";
                }
            }

            string currentRecordSelection = report.RecordSelectionFormula;
            string policyNoFormular = "{" + letter_type + "." + policy_no_field + "} = \"" + policy_no + "\"";

            string newRecordSelection = "";
            if (string.IsNullOrWhiteSpace(currentRecordSelection))
            {
                newRecordSelection = policyNoFormular;
            }
            else
            {
                newRecordSelection = string.Format("({0}) and ({1})", currentRecordSelection, policyNoFormular);
            }

            report.RecordSelectionFormula = newRecordSelection;
        }       
    }
}
