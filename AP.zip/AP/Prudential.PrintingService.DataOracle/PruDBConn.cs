﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prudential.PrintingService.DataOracle
{
    public class PruDBConn
    {
        private static string _ConnString = string.Empty;

        public static string ConnString {
            get {
                if (_ConnString == string.Empty) {
                    var database = ConfigurationManager.AppSettings["DataBasePath"];
                    _ConnString = @"Provider=Microsoft.Jet.OleDb.4.0;Data Source=" + database + ";Persist Security Info=False;";
                }
                return _ConnString;
            }
        }
    }
}
