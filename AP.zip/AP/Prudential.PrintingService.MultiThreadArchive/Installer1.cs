﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Configuration.Install;
using System.Linq;
using System.Reflection;
using System.ServiceProcess;

namespace Prudential.PrintingService.MultiThreadArchive
{
    [RunInstaller(true)]
    public partial class Installer1 : System.Configuration.Install.Installer
    {
        public Installer1()
        {
           // InitializeComponent();
            ServiceProcessInstaller serviceProcessInstaller = new ServiceProcessInstaller();
            ServiceInstaller serviceInstaller = new ServiceInstaller();

            //# Service Account Information
            serviceProcessInstaller.Account = ServiceAccount.LocalSystem;
            serviceProcessInstaller.Username = null;
            serviceProcessInstaller.Password = null;

            //# Service Information
            //var serviceName = GetConfigurationValue("ServiceName");
            var serviceName = "Prudential.Services.CMArchive";
            serviceInstaller.DisplayName = serviceName;
            serviceInstaller.StartType = ServiceStartMode.Manual;

            //# This must be identical to the WindowsService.ServiceBase name
            //# set in the constructor of WindowsService.cs
            serviceInstaller.ServiceName = serviceName;

            this.Installers.Add(serviceProcessInstaller);
            this.Installers.Add(serviceInstaller);
        }

        private string GetConfigurationValue(string key) {
            try
            {
                return ConfigurationManager.AppSettings[key].ToString();
            }
            catch (Exception ex)
            {
                throw new IndexOutOfRangeException ("Settings collection does not contain the requested key: " + ex);
            }
            
            //Assembly service = Assembly.GetAssembly(typeof(Installer));
            //Configuration config = ConfigurationManager.OpenExeConfiguration(service.Location);
            //if (config.AppSettings.Settings[key] != null) {
            //    return config.AppSettings.Settings[key].Value;
            //}
            //else {
            //    throw new IndexOutOfRangeException
            //        ("Settings collection does not contain the requested key: " + key);
            //}
        }

        //public override void Install(IDictionary stateSaver) {
        //    var serviceName = GetConfigurationValue("ServiceName");
        //    this.serviceInstaller1.DisplayName = serviceName;
        //    this.serviceInstaller1.ServiceName = serviceName;

        //    base.Install(stateSaver);
        //}

        //public override void Uninstall(IDictionary savedState) {
        //    var serviceName = GetConfigurationValue("ServiceName");
        //    this.serviceInstaller1.DisplayName = serviceName;
        //    this.serviceInstaller1.ServiceName = serviceName;

        //    base.Uninstall(savedState);
        //}
    }
}
