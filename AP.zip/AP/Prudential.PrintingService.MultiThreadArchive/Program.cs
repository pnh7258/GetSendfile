﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.ServiceProcess;
using System.Text;

namespace Prudential.PrintingService.MultiThreadArchive {
    static class Program {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main(params string[] args) {
            CMArchiveService cmArchive = new CMArchiveService();
            if (!Environment.UserInteractive) {
                var servicesToRun = new ServiceBase[] { cmArchive };
                ServiceBase.Run(servicesToRun);
                return;
            }
            else {
                cmArchive.Start(args);
            }
            Console.WriteLine("Closing");
        }
    }
}
