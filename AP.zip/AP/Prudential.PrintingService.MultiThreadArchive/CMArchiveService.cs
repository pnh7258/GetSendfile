﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading;

namespace Prudential.PrintingService.MultiThreadArchive {
    public partial class CMArchiveService : ServiceBase {
        public CMArchiveService() {
            InitializeComponent();
        }

        public void Start(string[] args) { OnStart(args); }

        protected override void OnStart(string[] args) {
            try {
                foreach (var process in Process.GetProcessesByName("Prudential.PrintingService.MultiThreadArchive.exe"))
                {
                    process.Kill();
                }

                AppPrinting.StartServicePrinting();
            }
            catch (Exception ex) {
                string mess = ex.Message.ToString();
            }
        }

        protected override void OnStop() {
            try {
                foreach (var process in Process.GetProcessesByName("Prudential.PrintingService.MultiThreadArchive.exe")) {
                    process.Kill();
                }
            }
            catch (Exception ex) {
                string mess = ex.Message.ToString();
            }
        }

    }
}
