﻿//------------------------------------------------------------------------------
// The contents of this file are subject to the nopCommerce Public License Version 1.0 ("License"); you may not use this file except in compliance with the License.
// You may obtain a copy of the License at  http://www.nopCommerce.com/License.aspx. 
// 
// Software distributed under the License is distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. 
// See the License for the specific language governing rights and limitations under the License.
// 
// The Original Code is nopCommerce.
// The Initial Developer of the Original Code is NopSolutions.
// All Rights Reserved.
// 
// Contributor(s): _______. 
//------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Configuration.Provider;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Xml;

namespace Prudential.PrintingService.Common
{
    /// <summary>
    /// Represents a common helper
    /// </summary>
    public partial class CommonHelper
    {
        #region Methods

        /// <summary>
        /// 
        /// </summary>
        /// <param name="svalue"></param>
        /// <returns></returns>
        public static Decimal ToDecimal(string svalue)
        {
            try
            {
                return Decimal.Parse(svalue);
            }
            catch { }
            return 0;
        }

        public static string ToCurrency(object svalue)
        {
            try
            {
                return String.Format("{0:0,0 ĐỒNG }", svalue).Replace(',', '.');
            }
            catch { }
            return "0 ĐỒNG";
        }

        public static string FormatDate(string svalue)
        {
            try
            {
                return svalue.Substring(0, 4) + "/" + svalue.Substring(4, 2) + "/" + svalue.Substring(6, 2);
            }
            catch { }
            return "N/A";
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="svalue"></param>
        /// <returns></returns>
        public static long ToLong(string svalue)
        {
            try
            {
                return long.Parse(svalue);
            }
            catch { }
            return 0;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="svalue"></param>
        /// <returns></returns>
        public static int ToInt(string svalue)
        {
            try
            {
                return int.Parse(svalue);
            }
            catch { }
            return 0;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static bool IsEmpty(string value)
        {
            return (value == null) || (value.Length == 0);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static bool IsEmpty(decimal value)
        {
            return (value == 0);
        }

        /// <summary>
        /// Verifies that a string is in valid e-mail format
        /// </summary>
        /// <param name="Email">Email to verify</param>
        /// <returns>true if the string is a valid e-mail address and false if it's not</returns>
        public static bool IsValidEmail(string Email)
        {
            bool result = false;
            if (String.IsNullOrEmpty(Email))
                return result;
            Email = Email.Trim();
            result = Regex.IsMatch(Email, @"^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$");
            return result;
        }

        /// <summary>
        /// Gets query string value by name
        /// </summary>
        /// <param name="Name">Parameter name</param>
        /// <returns>Query string value</returns>
        public static string QueryString(string Name)
        {
            string result = string.Empty;
            if (HttpContext.Current != null && HttpContext.Current.Request.QueryString[Name] != null)
                result = HttpContext.Current.Request.QueryString[Name].ToString();
            return result;
        }

        /// <summary>
        /// Gets boolean value from query string 
        /// </summary>
        /// <param name="Name">Parameter name</param>
        /// <returns>Query string value</returns>
        public static bool QueryStringBool(string Name)
        {
            string resultStr = QueryString(Name).ToUpperInvariant();
            return (resultStr == "YES" || resultStr == "TRUE" || resultStr == "1");
        }

        /// <summary>
        /// Gets integer value from query string 
        /// </summary>
        /// <param name="Name">Parameter name</param>
        /// <returns>Query string value</returns>
        public static int QueryStringInt(string Name)
        {
            string resultStr = QueryString(Name).ToUpperInvariant();
            int result;
            Int32.TryParse(resultStr, out result);
            return result;
        }

        /// <summary>
        /// Gets integer value from query string 
        /// </summary>
        /// <param name="Name">Parameter name</param>
        /// <param name="DefaultValue">Default value</param>
        /// <returns>Query string value</returns>
        public static int QueryStringInt(string Name, int DefaultValue)
        {
            string resultStr = QueryString(Name).ToUpperInvariant();
            if (resultStr.Length > 0)
            {
                return Int32.Parse(resultStr);
            }
            return DefaultValue;
        }

        /// <summary>
        /// Gets Decimal value from query string 
        /// </summary>
        /// <param name="Name">Parameter name</param>
        /// <param name="DefaultValue">Default value</param>
        /// <returns>Query string value</returns>
        public static Decimal QueryStringDecimal(string Name, Decimal DefaultValue)
        {
            string resultStr = QueryString(Name).ToUpperInvariant();
            if (resultStr.Length > 0)
            {
                return Decimal.Parse(resultStr);
            }
            return DefaultValue;
        }

        /// <summary>
        /// Gets GUID value from query string 
        /// </summary>
        /// <param name="Name">Parameter name</param>
        /// <returns>Query string value</returns>
        public static Guid? QueryStringGUID(string Name)
        {
            string resultStr = QueryString(Name).ToUpperInvariant();
            Guid? result = null;
            try
            {
                result = new Guid(resultStr);
            }
            catch
            {
            }
            return result;
        }

        /// <summary>
        /// Gets Form String
        /// </summary>
        /// <param name="Name"></param>
        /// <returns></returns>
        public static string GetFormString(string Name)
        {
            string result = string.Empty;
            if (HttpContext.Current != null && HttpContext.Current.Request[Name] != null)
                result = HttpContext.Current.Request[Name].ToString();
            return result;
        }

        /// <summary>
        /// Set meta http equiv (eg. redirects)
        /// </summary>
        /// <param name="page">Page</param>
        /// <param name="httpEquiv">Http Equiv</param>
        /// <param name="Content">Content</param>
        public static void SetMetaHttpEquiv(Page page, string httpEquiv, string Content)
        {
            if (page.Header == null)
                return;

            HtmlMeta meta = new HtmlMeta();
            if (page.Header.FindControl("meta" + httpEquiv) != null)
            {
                meta = (HtmlMeta)page.Header.FindControl("meta" + httpEquiv);
                meta.Content = Content;
            }
            else
            {
                meta.ID = "meta" + httpEquiv;
                meta.HttpEquiv = httpEquiv;
                meta.Content = Content;
                page.Header.Controls.Add(meta);
            }
        }

        /// <summary>
        /// Selects item
        /// </summary>
        /// <param name="List">List</param>
        /// <param name="Value">Value to select</param>
        public static void SelectListItem(DropDownList List, object Value)
        {
            if (List.Items.Count != 0)
            {
                var selectedItem = List.SelectedItem;
                if (selectedItem != null)
                    selectedItem.Selected = false;
                if (Value != null)
                {
                    selectedItem = List.Items.FindByValue(Value.ToString());
                    if (selectedItem != null)
                        selectedItem.Selected = true;
                }
            }
        }

        /// <summary>
        /// Gets server variable by name
        /// </summary>
        /// <param name="Name">Name</param>
        /// <returns>Server variable</returns>
        public static string ServerVariables(string Name)
        {
            string tmpS = String.Empty;
            try
            {
                if (HttpContext.Current.Request.ServerVariables[Name] != null)
                {
                    tmpS = HttpContext.Current.Request.ServerVariables[Name].ToString();
                }
            }
            catch
            {
                tmpS = String.Empty;
            }
            return tmpS;
        }

        /// <summary>
        /// Gets a value indicating whether requested page is an admin page
        /// </summary>
        /// <returns>A value indicating whether requested page is an admin page</returns>
        public static bool IsAdmin()
        {
            string thisPageURL = GetThisPageURL(false);
            if (string.IsNullOrEmpty(thisPageURL))
                return false;

            string adminUrl1 = GetStoreLocation(false) + "administration";
            string adminUrl2 = GetStoreLocation(true) + "administration";
            bool flag1 = thisPageURL.ToLowerInvariant().StartsWith(adminUrl1.ToLower());
            bool flag2 = thisPageURL.ToLowerInvariant().StartsWith(adminUrl2.ToLower());
            bool isAdmin = flag1 || flag2;
            return isAdmin;
        }

        /// <summary>
        /// Gets a value indicating whether current connection is secured
        /// </summary>
        /// <returns>true - secured, false - not secured</returns>
        public static bool IsCurrentConnectionSecured()
        {
            bool useSSL = false;
            if (HttpContext.Current != null && HttpContext.Current.Request != null)
            {
                useSSL = HttpContext.Current.Request.IsSecureConnection;
                //when your hosting uses a load balancer on their server then the Request.IsSecureConnection is never got set to true, use the statement below
                //just uncomment it
                //useSSL = HttpContext.Current.Request.ServerVariables["HTTP_CLUSTER_HTTPS"] == "on" ? true : false;
            }

            return useSSL;
        }

        /// <summary>
        /// Gets this page name
        /// </summary>
        /// <returns></returns>
        public static string GetThisPageURL(bool includeQueryString)
        {
            string URL = string.Empty;
            if (HttpContext.Current == null)
                return URL;

            if (includeQueryString)
            {
                bool useSSL = IsCurrentConnectionSecured();
                string storeHost = GetStoreHost(useSSL);
                if (storeHost.EndsWith("/"))
                    storeHost = storeHost.Substring(0, storeHost.Length - 1);
                URL = storeHost + HttpContext.Current.Request.RawUrl;
            }
            else
            {
                URL = HttpContext.Current.Request.Url.GetLeftPart(UriPartial.Path);
            }
            return URL;
        }

        /// <summary>
        /// Gets store location
        /// </summary>
        /// <returns>Store location</returns>
        public static string GetStoreLocation()
        {
            bool useSSL = IsCurrentConnectionSecured();
            return GetStoreLocation(useSSL);
        }

        /// <summary>
        /// Gets store location
        /// </summary>
        /// <param name="UseSSL">Use SSL</param>
        /// <returns>Store location</returns>
        public static string GetStoreLocation(bool UseSSL)
        {
            string result = GetStoreHost(UseSSL);
            if (result.EndsWith("/"))
                result = result.Substring(0, result.Length - 1);
            result = result + HttpContext.Current.Request.ApplicationPath;
            if (!result.EndsWith("/"))
                result += "/";

            return result;
        }

        /// <summary>
        /// Gets store admin location
        /// </summary>
        /// <returns>Store admin location</returns>
        public static string GetStoreAdminLocation()
        {
            bool useSSL = IsCurrentConnectionSecured();
            return GetStoreAdminLocation(useSSL);
        }

        /// <summary>
        /// Gets store admin location
        /// </summary>
        /// <param name="UseSSL">Use SSL</param>
        /// <returns>Store admin location</returns>
        public static string GetStoreAdminLocation(bool UseSSL)
        {
            string result = GetStoreLocation(UseSSL);
            result += "Administration/";

            return result;
        }

        /// <summary>
        /// Gets store host location
        /// </summary>
        /// <param name="UseSSL">Use SSL</param>
        /// <returns>Store host location</returns>
        public static string GetStoreHost(bool UseSSL)
        {
            string result = "http://" + ServerVariables("HTTP_HOST");
            if (!result.EndsWith("/"))
                result += "/";

            if (UseSSL)
            {
                if (!String.IsNullOrEmpty(ConfigurationManager.AppSettings["SharedSSL"]))
                {
                    result = ConfigurationManager.AppSettings["SharedSSL"];
                }
                else
                {
                    result = result.Replace("http:/", "https:/");
                }
            }

            if (!result.EndsWith("/"))
                result += "/";

            return result;
        }

        /// <summary>
        /// Reloads current page
        /// </summary>
        public static void ReloadCurrentPage()
        {
            bool useSSL = IsCurrentConnectionSecured();
            ReloadCurrentPage(useSSL);
        }

        /// <summary>
        /// Reloads current page
        /// </summary>
        /// <param name="UseSSL">Use SSL</param>
        public static void ReloadCurrentPage(bool UseSSL)
        {
            string storeHost = GetStoreHost(UseSSL);
            if (storeHost.EndsWith("/"))
                storeHost = storeHost.Substring(0, storeHost.Length - 1);
            string URL = storeHost + HttpContext.Current.Request.RawUrl;
            HttpContext.Current.Response.Redirect(URL);
        }

        /// <summary>
        /// Modifies query string
        /// </summary>
        /// <param name="url">Url to modify</param>
        /// <param name="queryStringModification">Query string modification</param>
        /// <param name="targetLocationModification">Target location modification</param>
        /// <returns>New url</returns>
        public static string ModifyQueryString(string url, string queryStringModification, string targetLocationModification)
        {
            string str = string.Empty;
            string str2 = string.Empty;
            if (url.Contains("#"))
            {
                str2 = url.Substring(url.IndexOf("#") + 1);
                url = url.Substring(0, url.IndexOf("#"));
            }
            if (url.Contains("?"))
            {
                str = url.Substring(url.IndexOf("?") + 1);
                url = url.Substring(0, url.IndexOf("?"));
            }
            if (!string.IsNullOrEmpty(queryStringModification))
            {
                if (!string.IsNullOrEmpty(str))
                {
                    var dictionary = new Dictionary<string, string>();
                    foreach (string str3 in str.Split(new char[] { '&' }))
                    {
                        if (!string.IsNullOrEmpty(str3))
                        {
                            string[] strArray = str3.Split(new char[] { '=' });
                            if (strArray.Length == 2)
                            {
                                dictionary[strArray[0]] = strArray[1];
                            }
                            else
                            {
                                dictionary[str3] = null;
                            }
                        }
                    }
                    foreach (string str4 in queryStringModification.Split(new char[] { '&' }))
                    {
                        if (!string.IsNullOrEmpty(str4))
                        {
                            string[] strArray2 = str4.Split(new char[] { '=' });
                            if (strArray2.Length == 2)
                            {
                                dictionary[strArray2[0]] = strArray2[1];
                            }
                            else
                            {
                                dictionary[str4] = null;
                            }
                        }
                    }
                    var builder = new StringBuilder();
                    foreach (string str5 in dictionary.Keys)
                    {
                        if (builder.Length > 0)
                        {
                            builder.Append("&");
                        }
                        builder.Append(str5);
                        if (dictionary[str5] != null)
                        {
                            builder.Append("=");
                            builder.Append(dictionary[str5]);
                        }
                    }
                    str = builder.ToString();
                }
                else
                {
                    str = queryStringModification;
                }
            }
            if (!string.IsNullOrEmpty(targetLocationModification))
            {
                str2 = targetLocationModification;
            }
            return (url + (string.IsNullOrEmpty(str) ? "" : ("?" + str)) + (string.IsNullOrEmpty(str2) ? "" : ("#" + str2)));
        }

        /// <summary>
        /// Remove query string from url
        /// </summary>
        /// <param name="url">Url to modify</param>
        /// <param name="queryString">Query string to remove</param>
        /// <returns>New url</returns>
        public static string RemoveQueryString(string url, string queryString)
        {
            string str = string.Empty;
            if (url.Contains("?"))
            {
                str = url.Substring(url.IndexOf("?") + 1);
                url = url.Substring(0, url.IndexOf("?"));
            }
            if (!string.IsNullOrEmpty(queryString))
            {
                if (!string.IsNullOrEmpty(str))
                {
                    Dictionary<string, string> dictionary = new Dictionary<string, string>();
                    foreach (string str3 in str.Split(new char[] { '&' }))
                    {
                        if (!string.IsNullOrEmpty(str3))
                        {
                            string[] strArray = str3.Split(new char[] { '=' });
                            if (strArray.Length == 2)
                            {
                                dictionary[strArray[0]] = strArray[1];
                            }
                            else
                            {
                                dictionary[str3] = null;
                            }
                        }
                    }
                    dictionary.Remove(queryString);

                    var builder = new StringBuilder();
                    foreach (string str5 in dictionary.Keys)
                    {
                        if (builder.Length > 0)
                        {
                            builder.Append("&");
                        }
                        builder.Append(str5);
                        if (dictionary[str5] != null)
                        {
                            builder.Append("=");
                            builder.Append(dictionary[str5]);
                        }
                    }
                    str = builder.ToString();
                }
            }
            return (url + (string.IsNullOrEmpty(str) ? "" : ("?" + str)));
        }

        /// <summary>
        /// Ensures that requested page is secured (https://)
        /// </summary>
        public static void EnsureSSL()
        {
            if (!IsCurrentConnectionSecured())
            {
                bool useSSL = false;
                if (!String.IsNullOrEmpty(ConfigurationManager.AppSettings["UseSSL"]))
                    useSSL = Convert.ToBoolean(ConfigurationManager.AppSettings["UseSSL"]);
                if (useSSL)
                {
                    //if (!HttpContext.Current.Request.Url.IsLoopback)
                    //{
                    ReloadCurrentPage(true);
                    //}
                }
            }
        }

        /// <summary>
        /// Ensures that requested page is not secured (http://)
        /// </summary>
        public static void EnsureNonSSL()
        {
            if (IsCurrentConnectionSecured())
            {
                ReloadCurrentPage(false);
            }
        }

        /// <summary>
        /// Sets cookie
        /// </summary>
        /// <param name="cookieName">Cookie name</param>
        /// <param name="cookieValue">Cookie value</param>
        /// <param name="ts">Timespan</param>
        public static void SetCookie(String cookieName, string cookieValue, TimeSpan ts)
        {
            try
            {
                HttpCookie cookie = new HttpCookie(cookieName);
                cookie.Value = HttpContext.Current.Server.UrlEncode(cookieValue);
                DateTime dt = DateTime.Now;
                cookie.Expires = dt.Add(ts);
                HttpContext.Current.Response.Cookies.Add(cookie);
            }
            catch (Exception exc)
            {
                Debug.WriteLine(exc.Message);
            }
        }

        /// <summary>
        /// Gets cookie string
        /// </summary>
        /// <param name="cookieName">Cookie name</param>
        /// <param name="decode">Decode cookie</param>
        /// <returns>Cookie string</returns>
        public static String GetCookieString(String cookieName, bool decode)
        {
            if (HttpContext.Current.Request.Cookies[cookieName] == null)
            {
                return String.Empty;
            }
            try
            {
                string tmp = HttpContext.Current.Request.Cookies[cookieName].Value.ToString();
                if (decode)
                    tmp = HttpContext.Current.Server.UrlDecode(tmp);
                return tmp;
            }
            catch
            {
                return String.Empty;
            }
        }

        /// <summary>
        /// Gets boolean value from cookie
        /// </summary>
        /// <param name="cookieName">Cookie name</param>
        /// <returns>Result</returns>
        public static bool GetCookieBool(String cookieName)
        {
            string str1 = GetCookieString(cookieName, true).ToUpperInvariant();
            return (str1 == "TRUE" || str1 == "YES" || str1 == "1");
        }

        /// <summary>
        /// Gets integer value from cookie
        /// </summary>
        /// <param name="cookieName">Cookie name</param>
        /// <returns>Result</returns>
        public static int GetCookieInt(String cookieName)
        {
            string str1 = GetCookieString(cookieName, true);
            if (!String.IsNullOrEmpty(str1))
                return Convert.ToInt32(str1);
            else
                return 0;
        }

        /// <summary>
        /// Gets boolean value from NameValue collection
        /// </summary>
        /// <param name="config">NameValue collection</param>
        /// <param name="valueName">Name</param>
        /// <param name="defaultValue">Default value</param>
        /// <returns>Result</returns>
        public static bool ConfigGetBooleanValue(NameValueCollection config, string valueName, bool defaultValue)
        {
            bool result;
            string str1 = config[valueName];
            if (str1 == null)
                return defaultValue;
            if (!bool.TryParse(str1, out result))
                throw new Exception(string.Format("Value must be boolean {0}", valueName));
            return result;
        }

        /// <summary>
        /// Gets integer value from NameValue collection
        /// </summary>
        /// <param name="config">NameValue collection</param>
        /// <param name="valueName">Name</param>
        /// <param name="defaultValue">Default value</param>
        /// <param name="zeroAllowed">Zero allowed</param>
        /// <param name="maxValueAllowed">Max value allowed</param>
        /// <returns>Result</returns>
        public static int ConfigGetIntValue(NameValueCollection config, string valueName, int defaultValue, bool zeroAllowed, int maxValueAllowed)
        {
            int result;
            string str1 = config[valueName];
            if (str1 == null)
                return defaultValue;
            if (!int.TryParse(str1, out result))
            {
                if (zeroAllowed)
                {
                    throw new Exception(string.Format("Value must be non negative integer {0}", valueName));
                }
                throw new Exception(string.Format("Value must be positive integer {0}", valueName));
            }
            if (zeroAllowed && (result < 0))
                throw new Exception(string.Format("Value must be non negative integer {0}", valueName));
            if (!zeroAllowed && (result <= 0))
                throw new Exception(string.Format("Value must be positive integer {0}", valueName));
            if ((maxValueAllowed > 0) && (result > maxValueAllowed))
                throw new Exception(string.Format("Value too big {0}", valueName));
            return result;
        }

        /// <summary>
        /// Write XML to response
        /// </summary>
        /// <param name="xml">XML</param>
        /// <param name="Filename">Filename</param>
        public static void WriteResponseXML(string xml, string Filename)
        {
            if (!String.IsNullOrEmpty(xml))
            {
                XmlDocument document = new XmlDocument();
                document.LoadXml(xml);
                XmlDeclaration decl = document.FirstChild as XmlDeclaration;
                if (decl != null)
                {
                    decl.Encoding = "utf-8";
                }
                HttpResponse response = HttpContext.Current.Response;
                response.Clear();
                response.Charset = "utf-8";
                response.ContentType = "text/xml";
                response.AddHeader("content-disposition", string.Format("attachment; filename={0}", Filename));
                response.BinaryWrite(Encoding.UTF8.GetBytes(document.InnerXml));
                response.End();
            }
        }

        /// <summary>
        /// Write text to response
        /// </summary>
        /// <param name="txt">text</param>
        /// <param name="Filename">Filename</param>
        public static void WriteResponseTXT(string txt, string Filename)
        {
            if (!String.IsNullOrEmpty(txt))
            {
                HttpResponse response = HttpContext.Current.Response;
                response.Clear();
                response.Charset = "utf-8";
                response.ContentType = "text/plain";
                response.AddHeader("content-disposition", string.Format("attachment; filename={0}", Filename));
                response.BinaryWrite(Encoding.UTF8.GetBytes(txt));
                response.End();
            }
        }

        /// <summary>
        /// Write XLS file to response
        /// </summary>
        /// <param name="filePath">File path</param>
        /// <param name="targetFileName">Target file name</param>
        public static void WriteResponseXLS(string filePath, string targetFileName)
        {
            if (!String.IsNullOrEmpty(filePath))
            {
                HttpResponse response = HttpContext.Current.Response;
                response.Clear();
                response.Charset = "utf-8";
                response.ContentType = "text/xls";
                response.AddHeader("content-disposition", string.Format("attachment; filename={0}", targetFileName));
                response.BinaryWrite(File.ReadAllBytes(filePath));
                response.End();
            }
        }

        /// <summary>
        /// Write PDF file to response
        /// </summary>
        /// <param name="filePath">File napathme</param>
        /// <param name="targetFileName">Target file name</param>
        /// <remarks>For BeatyStore project</remarks>
        public static void WriteResponsePDF(string filePath, string targetFileName)
        {
            if (!String.IsNullOrEmpty(filePath))
            {
                HttpResponse response = HttpContext.Current.Response;
                response.Clear();
                response.Charset = "utf-8";
                response.ContentType = "text/pdf";
                response.AddHeader("content-disposition", string.Format("attachment; filename={0}", targetFileName));
                response.BinaryWrite(File.ReadAllBytes(filePath));
                response.End();
            }
        }

        /// <summary>
        /// Generate random digit code
        /// </summary>
        /// <param name="Length">Length</param>
        /// <returns>Result string</returns>
        public static string GenerateRandomDigitCode(int Length)
        {
            var random = new Random();
            string s = "";
            for (int i = 0; i < Length; i++)
                s = String.Concat(s, random.Next(10).ToString());
            return s;
        }

        /// <summary>
        /// Convert enum for front-end
        /// </summary>
        /// <param name="s">Input string</param>
        /// <returns>Covnerted string</returns>
        public static string ConvertEnum(string s)
        {
            string result = string.Empty;
            char[] letters = s.ToCharArray();
            foreach (char c in letters)
                if (c.ToString() != c.ToString().ToLower())
                    result += " " + c.ToString();
                else
                    result += c.ToString();
            return result;
        }

        /// <summary>
        /// Fills drop down list with values of enumaration
        /// </summary>
        /// <param name="List">Dropdownlist</param>
        /// <param name="enumType">Enumeration</param>
        public static void FillDropDownWithEnum(DropDownList List, Type enumType)
        {
            if (List == null)
            {
                throw new ArgumentNullException("List");
            }
            if (enumType == null)
            {
                throw new ArgumentNullException("enumType");
            }
            if (!enumType.IsEnum)
            {
                throw new ArgumentException("enumType must be enum type");
            }

            List.Items.Clear();
            string[] strArray = Enum.GetNames(enumType);
            foreach (string str2 in strArray)
            {
                int enumValue = (int)Enum.Parse(enumType, str2, true);
                ListItem ddlItem = new ListItem(CommonHelper.ConvertEnum(str2), enumValue.ToString());
                List.Items.Add(ddlItem);
            }
        }

        public static string VIQR2Unicode(string strVIQR)
        {
            string[] Aviqr = {"''","a(`", "A(`", "a(?", "A(?", "a(~", "A(~", "a('", "A('", "a(.", "A(.", 
            "a^`", "A^`", "a^?", "A^?", "a^~", "A^~", "a^'", "A^'", "a^.", "A^.", 
            "e^`", "E^`", "e^?", "E^?", "e^~", "E^~", "e^'", "E^'", "e^.", "E^.", 
            "o^`", "O^`", "o^?", "O^?", "o^~", "O^~", "o^'", "O^'", "o^.", "O^.", 
            "o+`", "O+`", "o+?", "O+?", "o+~", "O+~", "o+'", "O+'", "o+.", "O+.", 
            "o*`", "O*`", "o*?", "O*?", "o*~", "O*~", "o*'", "O*'", "o*.", "O*.", 
            "u+`", "U+`", "u+?", "U+?", "u+~", "U+~", "u+'", "U+'", "u+.", "U+.", 
            "u*`", "U*`", "u*?", "U*?", "u*~", "U*~", "u*'", "U*'", "u*.", "U*.", 
            "A(", "A^", "E^", "O^", "O+", "U+", "U*", "DD", "-D", "Dd", "a(", "a^",
            "e^", "o^", "o+", "o*", "u+", "u*", "dd", "-d", "d-", "a`", "A`", 
            "a?", "A?", "a~", "A~", "a'", "A'", "a.", "A.", "e`", "E`", 
            "e?", "E?", "e~", "E~", "e'", "E'", "e.", "E.", "i`", "I`", 
            "i?", "I?", "i~", "I~", "i'", "I'", "i.", "I.", "o`", "O`", 
            "o?", "O?", "o~", "O~", "o'", "O'", "o.", "O.", "u`", "U`", 
            "u?", "U?", "u~", "U~", "u'", "U'", "u.", "U.", "y`", "Y`", 
            "y?", "Y?", "y~", "Y~", "y'", "Y'", "y.", "Y."};


            char[] Auni = {'\'',(char)7857, (char)7856, (char)7859, (char)7858, (char)7861, (char)7860, (char)7855, (char)7854, (char)7863, (char)7862, 
            (char)7847, (char)7846, (char)7849, (char)7848, (char)7851, (char)7850, (char)7845, (char)7844, (char)7853, (char)7852, 
            (char)7873, (char)7872, (char)7875, (char)7874, (char)7877, (char)7876, (char)7871, (char)7870, (char)7879, (char)7878, 
            (char)7891, (char)7890, (char)7893, (char)7892, (char)7895, (char)7894, (char)7889, (char)7888, (char)7897, (char)7896, 
            (char)7901, (char)7900, (char)7903, (char)7902, (char)7905, (char)7904, (char)7899, (char)7898, (char)7907, (char)7906, 
            (char)7901, (char)7900, (char)7903, (char)7902, (char)7905, (char)7904, (char)7899, (char)7898, (char)7907, (char)7906, 
            (char)7915, (char)7914, (char)7917, (char)7916, (char)7919, (char)7918, (char)7913, (char)7912, (char)7921, (char)7920, 
            (char)7915, (char)7914, (char)7917, (char)7916, (char)7919, (char)7918, (char)7913, (char)7912, (char)7921, (char)7920, 
            (char)258, (char)194, (char)202, (char)212, (char)416, (char)431, (char)431, (char)272, (char)272, (char)272, (char)259, (char)226, 
            (char)234, (char)244, (char)417, (char)417, (char)432, (char)432, (char)273, (char)273, (char)273, (char)224, (char)192, 
            (char)7843, (char)7842, (char)227, (char)195, (char)225, (char)193, (char)7841, (char)7840, (char)232, (char)200, 
            (char)7867, (char)7866, (char)7869, (char)7868, (char)233, (char)201, (char)7865, (char)7864, (char)236, (char)204, 
            (char)7881, (char)7880, (char)297, (char)296, (char)237, (char)205, (char)7883, (char)7882, (char)242, (char)210,
            (char)7887, (char)7886, (char)245, (char)213, (char)243, (char)211, (char)7885, (char)7884, (char)249, (char)217,
            (char)7911, (char)7910, (char)361, (char)360, (char)250, (char)218, (char)7909, (char)7908, (char)7923, (char)7922,
            (char)7927, (char)7926, (char)7929, (char)7928, (char)253, (char)221, (char)7925, (char)7924};

            if (strVIQR == null) return "";

            strVIQR = strVIQR.Replace(" ", " ");
            strVIQR = strVIQR.Replace("‘", "'");
            strVIQR = strVIQR.Replace("’", "'");


            for (int i = 0; i < Aviqr.Length; i++)
            {
                strVIQR = strVIQR.Replace(Aviqr[i], char.ToString(Auni[i]));
            }
            return strVIQR; // 
        }

        private static string SPACE = " ";
        private static string ZERO_1 = "KHÔNG";
        private static string ZERO_2 = "LẺ";
        private static string ONE_1 = "MỘT";
        private static string ONE_2 = "MỐT";
        private static string TWO = "HAI";
        private static string THREE = "BA";
        private static string FOUR = "BỐN";
        private static string FIVE_1 = "NĂM";
        private static string FIVE_2 = "LĂM";
        private static string SIX = "SÁU";
        private static string SEVEN = "BẢY";
        private static string EIGHT = "TÁM";
        private static string NINE = "CHÍN";
        private static string TEN_1 = "MƯỜI";
        private static string TEN_2 = "MƯƠI";
        private static string HUNDRED = "TRĂM";
        private static string THOUSAND = "NGHÌN";
        private static string MILLION = "TRIỆU";
        private static string BILLION = "TỶ";
        private static string ALERT = "LỚN HƠN 999";
        private static string SIGNS = "ÂM ";


        public static string pad(string p_originStr, int p_len, string p_padStr, bool p_start)
        {
            if (p_originStr == null) return null;
            if (p_padStr == null || p_padStr.Length == 0)
            {
                p_padStr = SPACE;
            }
            string strResult = p_originStr;
            while (strResult.Length < p_len)
            {
                if (p_start)
                {
                    strResult = p_padStr + strResult;
                }
                else
                {
                    strResult += p_padStr;
                }
            }
            return strResult;
        }

        public static string padLeft(string p_originStr, int p_len, string p_padStr)
        {
            return pad(p_originStr, p_len, p_padStr, true);
        }

        public static string padRight(string p_originStr, int p_len, string p_padStr)
        {
            return pad(p_originStr, p_len, p_padStr, false);
        }

        public static string join(string p_strToken, string[] p_arrStr)
        {
            if (p_arrStr == null)
            {
                return null;
            }
            StringBuilder sb = new StringBuilder();

            for (int i = 0; i < (p_arrStr.Length - 1); i++)
            {
                sb.Append(p_arrStr[i]);
                sb.Append(p_strToken);
            }
            sb.Append(p_arrStr[p_arrStr.Length - 1]);
            return (sb.ToString());
        }

        //== convert 3-digit number into Vietnamese words, will be used by n-digit
        private static string number2Words(int p_number, long p_remain)
        {
            if (p_number >= 1000)
            {
                return ALERT;
            }

            StringBuilder sbResult = new StringBuilder();

            string[] arrUnitsInWords = {ZERO_1
                , ONE_1, TWO, THREE
                , FOUR, FIVE_1, SIX
                , SEVEN, EIGHT, NINE};

            int iTemp = p_number;
            int iHundreds = iTemp / 100;
            iTemp %= 100;
            int iTens = iTemp / 10;
            int iUnits = iTemp % 10;

            if (iHundreds > 0 || p_remain > 0)
            {
                sbResult.Append(arrUnitsInWords[iHundreds]);
                sbResult.Append(" " + HUNDRED);
            }

            if (iTens == 0)
            {
                if (iUnits > 0 && sbResult.Length > 0)
                {
                    sbResult.Append(" ");
                    sbResult.Append(ZERO_2);
                }
            }
            else if (iTens == 1)
            {
                if (sbResult.Length > 0)
                {
                    sbResult.Append(" ");
                }
                sbResult.Append(TEN_1);
            }
            else
            {
                if (sbResult.Length > 0)
                {
                    sbResult.Append(" ");
                }
                sbResult.Append(arrUnitsInWords[iTens]);
                sbResult.Append(" " + TEN_2);
            }

            if (iUnits == 1)
            {
                if (sbResult.Length > 0)
                {
                    sbResult.Append(" ");
                }
                if (iTens > 1)
                {
                    sbResult.Append(ONE_2);
                }
                else
                {
                    sbResult.Append(ONE_1);
                }
            }
            else if (iUnits == 5)
            {
                if (sbResult.Length > 0)
                {
                    sbResult.Append(" ");
                }
                if (iTens > 0)
                {
                    sbResult.Append(FIVE_2);
                }
                else
                {
                    sbResult.Append(FIVE_1);
                }
            }
            else if (iUnits > 0)
            {
                if (sbResult.Length > 0)
                {
                    sbResult.Append(" ");
                }
                sbResult.Append(arrUnitsInWords[iUnits]);
            }

            return sbResult.ToString();
        }

        //== convert n-digit number into Vietnamese words, by using 3-digit number conversion function
        public static string number2Words(long p_number)
        {
            StringBuilder sbResult = new StringBuilder();
            string[] arrSeperatorsInWords = { "", " " + THOUSAND + " ", " " + MILLION + " ", " " + BILLION + " " };

            long lTemp = Math.Abs(p_number);
            int index = 0;
            int iThreeNumbers = 0;

            string strThreeNumbersInWords = null;

            while (lTemp != 0)
            {
                iThreeNumbers = (int)(lTemp % 1000);
                lTemp /= 1000;

                if (iThreeNumbers > 0)
                {
                    strThreeNumbersInWords = number2Words(iThreeNumbers, lTemp);
                    sbResult.Insert(0, arrSeperatorsInWords[index]);
                    sbResult.Insert(0, strThreeNumbersInWords);
                }
                index++;
            }
            if (p_number < 0)
                sbResult = sbResult.Insert(0, SIGNS);

            return sbResult.ToString();
        }
        #endregion
    }
}
