﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Prudential.PrintingService.CompactDatabase
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Starting compact database.");
            string result = Prudential.PrintingService.BussinessLogic.Ultilities.CompactDatabase("");
            Console.WriteLine(result);
            Console.WriteLine("Finished compact database.");
        }
    }
}
