﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Timers;

namespace Prudential.PrintingService.DataPostService {
    partial class DataPostService : ServiceBase {
        private System.Timers.Timer timer;
        public DataPostService() {
            // Thiết lập thuộc tính ServiceBase.ServiceName.
            ServiceName = ConfigurationManager.AppSettings["ServiceName"].ToString();// "DataPostService";
            // Cấu hình các thông điệp điều khiển.
            CanStop = true;
            CanPauseAndContinue = true;
            // Cấu hình việc ghi các sự kiện quan trọng vào
            // nhật ký Application.
            AutoLog = true;
        }

        private void PrintingFire(object sender, ElapsedEventArgs e) {
            try {
                timer.Stop();
                EventLog.WriteEntry(String.Format("DataPostServiceService firing"));
                new Prudential.PrintingService.Engine.Process.Process().Start("Prudential.PrintingService.BussinessLogic.VNLetter");
            }
            catch (Exception ex) {
                EventLog.WriteEntry(ex.Message);
            }
        }

        public void Start(string[] args) { OnStart(args); }

        protected override void OnStart(string[] args) {
            double interval;
            try
            {
                interval = System.Double.Parse(args[0]);
                interval = Math.Max(10000, interval);
            }
            catch
            {
                interval = 5000;
            }
            EventLog.WriteEntry(String.Format("DataPostService starting. " +
            "Writing log entries every {0} milliseconds...", interval));

            timer = new Timer();
            timer.Interval = interval;
            timer.AutoReset = true;
            timer.Elapsed += new ElapsedEventHandler(PrintingFire);
            timer.Start();
            //new Prudential.PrintingService.Engine.Process.Process().Start("Prudential.PrintingService.BussinessLogic.VNLetter");
        }

        public void StartDebug(string[] args) {
            new Prudential.PrintingService.Engine.Process.Process().Start("Prudential.PrintingService.BussinessLogic.VNLetter");
        }

        protected override void OnStop() {
            EventLog.WriteEntry("DataPostService stopping...");
            timer.Stop();

            timer.Dispose();
            timer = null;
        }

        protected override void OnPause() {
            if (timer != null) {
                EventLog.WriteEntry("DataPostService pausing...");
                timer.Stop();
            }
        }

        protected override void OnContinue() {
            if (timer != null) {
                EventLog.WriteEntry("DataPostService resuming...");
                timer.Start();
            }
        }
    }
}
