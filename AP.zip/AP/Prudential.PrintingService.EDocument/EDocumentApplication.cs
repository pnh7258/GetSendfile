﻿using log4net;
using log4net.Config;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Prudential.PrintingService.EDocument
{
    public class EDocumentApplication
    {
        private static readonly ILog log = LogManager.GetLogger(typeof(EDocumentApplication));
        private static string PdfPath;
        //private static string WorkingPath;
        private static string FailPath;
        private static string ServiceName;

        public EDocumentApplication()
        {
            Log4netSetup();

            log.Info("//////////////////////////////////////");
            log.InfoFormat("{0} starts. Build {1}.", "", "");
            log.Info("Initialize service...");

            Initialize();

            new Thread(()=> MoveDirectory()).Start();
            new Thread(() => Producer()).Start();
        }

        private static void Log4netSetup()
        {
            XmlConfigurator.Configure();
        }

        public void Initialize()
        {
            NameValueCollection apps = ConfigurationManager.AppSettings;
            PdfPath = apps["PdfPath"];
            //WorkingPath = apps["WorkingPath"];
            FailPath = apps["FailPath"];
            ServiceName = apps["ServiceName"];

            EDocumentJob.PdfPath = PdfPath;
            //EDocumentJob.WorkingPath = WorkingPath;
            EDocumentJob.FailPath = apps["FailPath"];
        }

        public static void Producer()
        {
            try
            {
                string[] file_rs;
                string first_filename;
                //string filename_new;

                List<string> ArrExist = new List<string>();
                //int iCheckOut = 0;
                while (true)
                {

                    string[] filenames = Directory.GetFiles(PdfPath, "*.PDF").Select(f => Path.GetFileName(f)).ToArray();
                    if (filenames.Count() > 0)
                    {
                        log.InfoFormat("Find {0} files *.PDF: ", filenames.Count());
                        foreach (string filename in filenames)
                        {
                            //filename_new = filename.Substring(0, filename.Length - 3) + ".PDF";
                            //try
                            //{
                            //    if (File.Exists(WorkingPath + filename))
                            //        File.Delete(WorkingPath + filename);
                            //    File.Move(PdfPath + filename, WorkingPath + filename);
                            //}
                            //catch (Exception ex)
                            //{
                            //    log.InfoFormat("EDocument - Producer: {0} \n{1}", ex.Message, ex);
                            //    continue;
                            //}

                            //first_filename = filename.Split('-')[0];
                            EDocumentJob.Execute(PdfPath + filename);
                            //new Thread(() => EDocumentJob.Execute(first_filename)).Start();
                        }
                    }
                    Thread.Sleep(2000);

                }
            }
            catch (Exception ex)
            {
                string mess = ex.Message.ToString();
                log.InfoFormat("EDocument - Producer: {0} \n{1}", ex.Message, ex);
            }
        }

        public static void MoveDirectory()
        {
            string directoryName = PdfPath;
            try
            {
                while (true)
                {
                    DirectoryInfo dirInfo = new DirectoryInfo(directoryName);
                    if (dirInfo.Exists == false)
                        Directory.CreateDirectory(directoryName);

                    List<String> MyMusicFiles = Directory.GetFiles(FailPath, "*.PDF", SearchOption.TopDirectoryOnly).ToList();

                    foreach (string file in MyMusicFiles)
                    {
                        FileInfo mFile = new FileInfo(file);
                        // to remove name collusion
                        if (new FileInfo(dirInfo + "\\" + mFile.Name).Exists == false)
                            mFile.MoveTo(dirInfo + "\\" + mFile.Name);
                    }

                    Thread.Sleep(60000);
                }
            }
            catch (Exception ex)
            {
                
            }
        }
    }
}
