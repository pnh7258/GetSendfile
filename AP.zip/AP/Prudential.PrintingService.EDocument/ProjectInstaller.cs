﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Configuration.Install;
using System.Linq;
using System.Reflection;

namespace Prudential.PrintingService.EDocument
{
    [RunInstaller(true)]
    public partial class ProjectInstaller : System.Configuration.Install.Installer
    {
        public ProjectInstaller()
        {
            InitializeComponent();
        }

        private string GetConfigurationValue(string key)
        {
            Assembly service = Assembly.GetAssembly(typeof(ProjectInstaller));
            Configuration config = ConfigurationManager.OpenExeConfiguration(service.Location);
            if (config.AppSettings.Settings[key] != null)
            {
                return config.AppSettings.Settings[key].Value;
            }
            else
            {
                throw new IndexOutOfRangeException
                    ("Settings collection does not contain the requested key: " + key);
            }
        }

        public override void Install(IDictionary stateSaver)
        {
            var serviceName = GetConfigurationValue("ServiceName");
            this.serviceInstaller1.DisplayName = serviceName;
            this.serviceInstaller1.ServiceName = serviceName;

            base.Install(stateSaver);
        }

        public override void Uninstall(IDictionary savedState)
        {
            var serviceName = GetConfigurationValue("ServiceName");
            this.serviceInstaller1.DisplayName = serviceName;
            this.serviceInstaller1.ServiceName = serviceName;

            base.Uninstall(savedState);
        }
    }
}
