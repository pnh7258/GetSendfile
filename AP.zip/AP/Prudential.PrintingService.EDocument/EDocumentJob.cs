﻿using log4net;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;

namespace Prudential.PrintingService.EDocument
{
    public class EDocumentJob
    {
        private static readonly ILog log = LogManager.GetLogger(typeof(EDocumentJob));
        public static string PdfPath;
        //public static string WorkingPath;
        public static string FailPath;

        public EDocumentJob()
        {

        }

        public static void Execute(string file)
        {
            string FileName = string.Empty;
            string FileExtension = string.Empty;
            string NewFilename = string.Empty;
            string PathFile = string.Empty;
            string ErrorMessage = string.Empty;

            try
            {
                FileName = Path.GetFileName(file);
                FileExtension = Path.GetExtension(file);
                //NewFilename = FileName.Split('.')[0] + ".PDF";
                //PathFile = file.Substring(0, file.Length - file.Split('\\')[file.Split('\\').Count() - 1].Length);

                string[] arrs = FileName.Substring(0, FileName.Length - (FileExtension.Length)).Split('_');

                ServiceSendLetter.EDigitializationServiceClient client = new ServiceSendLetter.EDigitializationServiceClient();
                client.Open();
                ServiceSendLetter.request required = new ServiceSendLetter.request();

                //required.letterDate = DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Utc);// DateTime.Parse("2010-08-20T15:00:00Z", null, System.Globalization.DateTimeStyles.RoundtripKind); ;
                required.letterDate = DateTime.ParseExact(arrs[3], "yyyyMMddHHmmss", CultureInfo.InvariantCulture).ToString("yyyy-MM-ddTHH:mm:ss.fffzz00"); // new DateTime(2016, 05, 10, 11, 20, 20, 0);
                required.system = "VNPrint";
                required.user = "VNPrint";
                required.letterType = arrs[0];
                required.attachmentFileName = arrs[0] + "_" + arrs[1] + "_" + arrs[2] + ".PDF";// FileName;
                required.policyNumber = arrs[2];

                byte[] bytes = System.IO.File.ReadAllBytes(file);
                System.IO.File.WriteAllBytes(file, bytes);

                required.letterAttachment = bytes;
                ServiceSendLetter.response response = client.sendLeter(required);
                Thread.Sleep(2000);
                client.Close();
                client.Abort();
                

                if (response.code == "999" || response.code == "004")
                {
                    File.Delete(file);
                    log.InfoFormat("EDocumentJob - Success: {0} - {1}: {2}", FileName, response.code, response.errors[0]);
                }
                else
                {
                    ErrorBackup(FileName, response.code);
                    log.ErrorFormat("EDocumentJob - Fail: {0} - {1}: {2}", FileName, response.code, response.errors[0]);
                }
            }
            catch (Exception ex)
            {
                ErrorBackup(FileName, string.Empty);
                log.ErrorFormat("EDocumentJob - Error: {0} - {1}", FileName, ex.Message);
            }
        }

        public static void ErrorBackup(string FileName, string sErrorhandle)
        {
            try
            {
                string fail_Folder = FailPath;

                if (!String.IsNullOrEmpty(sErrorhandle))
                {
                    fail_Folder = FailPath + sErrorhandle + "\\";
                }

                if (!Directory.Exists(fail_Folder))
                {
                    Directory.CreateDirectory(fail_Folder);
                }

                if (File.Exists(fail_Folder + FileName))
                    File.Delete(fail_Folder + FileName);

                File.Move(PdfPath + FileName, fail_Folder + FileName);
            }
            catch (Exception ex)
            {
                log.ErrorFormat("ErrorBackup - Error: {0}", ex.Message);
            }
        }
    }
}
