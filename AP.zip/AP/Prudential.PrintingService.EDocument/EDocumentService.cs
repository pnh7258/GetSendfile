﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;

namespace Prudential.PrintingService.EDocument
{
    partial class EDocumentService : ServiceBase
    {
        public EDocumentService()
        {
            InitializeComponent();

            // Thiết lập thuộc tính ServiceBase.ServiceName.
            ServiceName = ConfigurationManager.AppSettings["ServiceName"].ToString();// "DataPostService";
            // Cấu hình các thông điệp điều khiển.
            CanStop = true;
            CanPauseAndContinue = true;
            // Cấu hình việc ghi các sự kiện quan trọng vào
            // nhật ký Application.
            AutoLog = true;
        }

        protected override void OnStart(string[] args)
        {
            EDocumentApplication app = new EDocumentApplication();
            // TODO: Add code here to start your service.
        }

        protected override void OnStop()
        {
            // TODO: Add code here to perform any tear-down necessary to stop your service.
        }
    }
}
