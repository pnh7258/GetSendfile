﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KN.BusinessLogic;
using KN.Screens;

namespace KN.Proposals
{
    public class Proposal
    {
        public string ProposalNo { get; set; }
        public string code { get; set; }
        public string name { get; set; }

        public Proposal()
        {
            //this.screens = screens;
        }

        public Proposal(string Code, string Name)
        {
            this.code = Code;
            this.name = Name;
            //this.screens = ScreenManager.GetScreens(this.code);
        }

        public virtual void Fire()
        {
 
        }

        public virtual void FireRider(RiderCollection riders, string Role)
        {
            string msg = "";
            foreach (var rider in riders)
            {
                switch (rider.Code)
                {
                    case "ADD1":
                        //S5125
                        S5125 s5125 = new S5125(RiderManager.RiderLoad(ProposalNo, rider.Code, Role), rider.Code);
                        s5125.Execute();
                        msg = s5125.GetMessage();
                        if (msg.Trim() != "")
                        {
                            //log error
                            throw new Exception("S5125 "+Role+" detail: " + msg);
                        }
                        s5125.Next();
                        s5125.WaitingToNextScreen();
                        break;

                    case "DSR1":
                    case "OPW1":
                        //SR516
                        SR516 sr516 = new SR516(RiderManager.RiderLoad(ProposalNo, rider.Code, Role), rider.Code);
                        sr516.Execute();
                        msg = sr516.GetMessage();
                        if (msg.Trim() != "")
                        {
                            //log error
                            throw new Exception("SR516 " + Role + " detail: " + msg);
                        }
                        sr516.Next();
                        sr516.WaitingToNextScreen();
                        break;
                    case "TLR1":
                        //S5123
                        S5123 s5123 = new S5123(RiderManager.RiderLoad(ProposalNo, rider.Code, Role), rider.Code);
                        s5123.Execute();
                        msg = s5123.GetMessage();
                        if (msg.Trim() != "")
                        {
                            //log error
                            throw new Exception("TLR1 " + Role + " detail: " + msg);
                        }
                        s5123.Next();
                        s5123.WaitingToNextScreen();
                        break;                    
                }
                /*
                if (rider.Code == "ADD1")
                {
                    //S5125
                    S5125 s5125 = new S5125(RiderManager.RiderLoad(ProposalNo, rider.Code, LifeNo), rider.Code);
                    s5125.Execute();
                    msg = s5125.GetMessage();
                    if (msg.Trim() != "")
                    {
                        //log error
                        return;
                    }
                    s5125.Next();
                    s5125.WaitingToNextScreen();
                }
                if (rider.Code == "OPW1")
                {
                    //SR516
                    SR516 sr516 = new SR516(RiderManager.RiderLoad(ProposalNo, rider.Code, LifeNo), rider.Code);
                    sr516.Execute();
                    msg = sr516.GetMessage();
                    if (msg.Trim() != "")
                    {
                        //log error
                        return;
                    }
                    sr516.Next();
                    sr516.WaitingToNextScreen();
                }
                if (rider.Code == "TLR1")
                {
                    //S5123
                    S5123 s5125 = new S5123(RiderManager.RiderLoad(ProposalNo, rider.Code, LifeNo), rider.Code);
                    s5125.Execute();
                    msg = s5125.GetMessage();
                    if (msg.Trim() != "")
                    {
                        //log error
                        return;
                    }
                    s5125.Next();
                    s5125.WaitingToNextScreen();
                }
                if (rider.Code == "DSR1")
                {
                    //SR516
                    SR516 sr516 = new SR516(RiderManager.RiderLoad(ProposalNo, rider.Code, LifeNo), rider.Code);
                    sr516.Execute();
                    msg = sr516.GetMessage();
                    if (msg.Trim() != "")
                    {
                        //log error
                        return;
                    }
                    sr516.Next();
                    sr516.WaitingToNextScreen();
                }
                 * */
            }
        }
    }
}
