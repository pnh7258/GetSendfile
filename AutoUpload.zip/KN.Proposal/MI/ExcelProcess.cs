﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using KN.DataAcess;

namespace KN.Proposals.MI
{
    public static class ExcelProcess
    {
        static string[] sheets = new string[] { "S2465_LAInfo", "SV51L_ATS", "S2067_ReceiptInfo", "S2610_ReceiptInfo" };
        static string[] tables = new string[] { "S2465", "SV51L", "S2067", "S2610" };

        public static void UpLoad(string filename)
        {
            try
            {
                PruDBHelp db;
                for (int i = 0; i < sheets.Length;i++ )
                {
                    db = new PruDBHelp(filename);
                    var dt = db.ExecuteDataTable("select * from [" + sheets[i] + "$]", CommandType.Text);
                    if (dt == null) continue;
                    if (dt.Rows.Count == 0) continue;
                    Table_Import(tables[i], dt);
                }
            }
            catch { throw; }
        }

        public static void Table_Import(string table, DataTable tabledata)
        {
            PruDBHelp db = new PruDBHelp();
            db.ExecuteNonQuery("delete from " + "DATA_" + table, CommandType.Text);

            StringBuilder sqlColumns = new StringBuilder(1024);
            StringBuilder sqlValues = new StringBuilder(1024);
            string columname = "";
            for (int i = 0; i < tabledata.Columns.Count; i++)
            {
                columname = FormatParameter(tabledata.Columns[i].ColumnName);
                sqlColumns.AppendFormat("[{0}]{1}", columname, i < tabledata.Columns.Count - 1 ? ", " : String.Empty);
                sqlValues.AppendFormat("{0}{1}", "@"+columname, i < tabledata.Columns.Count - 1 ? ", " : String.Empty);
            }

            string sql = String.Format("INSERT INTO {0} ({1}) VALUES ({2})", "DATA_"+table, sqlColumns.ToString(), sqlValues.ToString());

            foreach (DataRow dr in tabledata.Rows)
            {
                db = new PruDBHelp();
                string values = "";
                for (int i = 0; i < tabledata.Columns.Count; i++)
                {
                    columname = FormatParameter(tabledata.Columns[i].ColumnName);
                    values = dr[i].ToString().Trim();// (dr[i] == null || dr[i] == DBNull.Value ? DBNull.Value : (tabledata.Columns[i].DataType == typeof(DateTime) ? ((DateTime)dr[i]).Date : dr[i]))
                    db.AddParameter("@" + columname, values);                                               
                }
                db.ExecuteNonQuery(sql,CommandType.Text);
            }            
        }        

        public static string FormatParameter(string name)
        {
            return name.Replace(" ", "").Replace("(", "").Replace(")", "").Replace("#", "").Replace(".", "").Replace("@", "").Replace("%", "").Replace("/", "");
        }
    }
}    
    


