﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KN.Screens;
using KN.BusinessLogic;

namespace KN.Proposals.MI
{
    public class Main:Proposal
    {
        
        public Main(string ExcelProposal)
        {
            try
            {
                
            }
            catch
            {
                throw;
            }
        }
        
        public override void Fire()
        {
            try
            {

                
            }
            catch
            {
                throw;
            }
            
        }
    }
}
