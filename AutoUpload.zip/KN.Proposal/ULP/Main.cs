﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KN.Screens;
using KN.BusinessLogic;

namespace KN.Proposals.ULP
{
    public class Main:Proposal
    {
        private S5004 s5004;
        private S5007 s5007;
        private S5005 s5005;
        private S5006 s5006;
        //private S5123 s5123;
        private S6326 s6326;
        private S5417 s5417;
        private S5002 s5002;       

        private Product product;
        private BeneficiaryCollection ben;
        private Client despatch ;
        private Basicplan basic;
        public Main(string ExcelProposal)
        {
            try
            {
                this.ProposalNo = ExcelProposal;

                ben = BeneficiaryManager.BeneficiaryLoad(this.ProposalNo);
                product = ProductManager.ProductLoad(this.ProposalNo);
                despatch = ClientManager.DespatchLoad(this.ProposalNo);
                basic = BasicplanManager.BasicplanLoad(this.ProposalNo, "ULR1");

                if (ben != null && ben.Count > 0)
                {
                    if (product != null)
                    {
                        product.Beneficiaries = "X";
                    }
                }

                if (despatch != null)
                {
                    if (product != null)
                    {
                        product.DespatchAddress = "X";
                    }
                }


                this.s5002 = new S5002("UR1");
                this.s5004 = new S5004(product);
                this.s5007 = new S5007(AgentManager.AgentLoad(this.ProposalNo));
                this.s5005 = new S5005(LifeAssureManager.LifeAssureLoad(this.ProposalNo, "LA1"));

                this.s5006 = new S5006(RiderManager.RiderLoad(this.ProposalNo, "LA1"));

                this.s6326 = new S6326(basic);
                this.s5417 = new S5417(basic);
            }
            catch
            {
                throw;
            }
        }
        
        public override void Fire()
        {
            try
            {

                string msg = "";

                try
                {
                    msg = s5002.GetScreenCode();
                    while (msg == "S5002")
                    {
                        s5002.Execute();
                        s5002.Enter();
                        msg = s5002.GetScreenCode();
                    }
                }
                catch
                { 

                }
                s5002.WaitingToNextScreen();

                s5004.Execute();
                msg = s5004.GetMessage();
                if (msg.Trim() != "")
                {
                    throw new Exception("S5002 detail: " + msg);
                }
                s5004.Next();
                //s5004.WaitingToNextScreen();

                if (product.DespatchAddress.ToUpper() == "X")
                {
                    S6225 s6225 = new S6225(despatch.ClientID);
                    s6225.Execute();
                    msg = s6225.GetMessage();

                    if (msg.Trim() != "")
                    {
                        //log error
                        throw new Exception("S6225 detail: " + msg);
                    }
                    s6225.Next();
                    s6225.WaitingToNextScreen();
                }

                s5007.Execute();
                msg = s5007.GetMessage();

                if (msg.Trim() != "")
                {
                    //log error
                    throw new Exception("S5007 detail: " + msg);
                }
                s5007.Next();
                s5007.WaitingToNextScreen();

                if (product.Beneficiaries.ToUpper() == "X")
                {
                    S5010 s5010 = new S5010(ben);
                    s5010.Execute();
                    msg = s5010.GetMessage();

                    if (msg.Trim() != "")
                    {
                        //log error
                        throw new Exception("S5010 detail: " + msg);
                    }
                    s5010.Next();
                    s5010.WaitingToNextScreen();
                }


                //return to screen S5004
                msg = s5004.GetMessage();

                if (msg.Trim() != "")
                {
                    //log error
                    throw new Exception("S5004 detail: " + msg);                    
                }
                s5004.Next();
                s5004.WaitingToNextScreen();
                //Life 1
                s5005.Execute();
                //System.Threading.Thread.Sleep(2000);
                msg = s5005.GetMessage();
                if (msg.Trim() != "")
                {
                    //log error
                    throw new Exception("S5005 detail: " + msg);
                }
                s5005.Next();
                s5005.WaitingToNextScreen();

                //rider select
                s5006.Execute();
                //msg = s5006.GetMessage();
                //if (msg.Trim() != "")
                //{
                //    //log error
                //    return;
                //}
                s5006.Next();
                s5006.WaitingToNextScreen();

                //basicplan
                s6326.Execute();
                msg = s6326.GetMessage();
                if (msg.Trim() != "")
                {
                    //log error
                    throw new Exception("S6326 detail: " + msg);
                }
                s6326.Next();
                s6326.WaitingToNextScreen();

                //Fund
                s5417.Execute();
                msg = s5417.GetMessage();
                if (msg.Trim() != "")
                {
                    //log error
                    throw new Exception("S5417 detail: " + msg);
                }
                s5417.Next();
                s5417.WaitingToNextScreen();

                //Rider Detail
                var riders = RiderManager.RiderLoad(this.ProposalNo,"LA1");
                FireRider(riders, "LA1");

                //If Proposal have Life 2
                S5003 s5003;
                var life2 = LifeAssureManager.LifeAssureLoad(ProposalNo, "LA2");
                if (life2 != null)
                {
                    s5003 = new S5003();
                    s5003.Execute();
                    s5003.Next();
                    s5003.WaitingToNextScreen();

                    //Life 2
                    this.s5005 = new S5005(life2);
                    s5005.Execute();
                    msg = s5005.GetMessage();
                    if (msg.Trim() != "")
                    {
                        //log error
                        throw new Exception("S5005 (Life 2) detail: " + msg);
                    }
                    s5005.Next();
                    s5005.WaitingToNextScreen();

                    //Select Rider
                    var rider2 = RiderManager.RiderLoad(this.ProposalNo, "LA2");
                    this.s5006 = new S5006(rider2);
                    s5006.Execute();
                    //msg = s5006.GetMessage();
                    //if (msg.Trim() != "")
                    //{
                    //    //log error
                    //    return;
                    //}
                    s5006.Next();
                    s5006.WaitingToNextScreen();
                    //rider detail
                    //riders = RiderManager.ReadRiderFromExcel("", "02");
                    FireRider(rider2, "LA2");

                }
                s5003 = new S5003();
                string policy="";
                policy = s5003.GetValues(new KN.Systems.Point(3,20),8);
                s5003.Enter();
                BasicplanManager.UpdatePolicy(this.ProposalNo, policy);
            }
            catch
            {
                throw;
            }
            
        }
    }
}
