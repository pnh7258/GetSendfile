﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using KN.BusinessLogic;
using KN.Systems;
namespace KN.Screens
{
    public class S5417 :Screen
    {
        public override Point NamePos
        {
            get
            {
                return new Point(1, 72);// 72;
            }
        }

        public override Point MessagePos
        {
            get
            {
                return new Point(24, 2);// 23 * 80 + 2;
            }
        }


        public S5417(Basicplan basic)
            : base("S5417", "Premium Direction")
        {
            SetValues(basic);
        }

        public override void SetValues(object obj)
        {
            Basicplan basic = (Basicplan)obj;
            screenconfig.items["FundSplitPlan"].itemconfig.values = basic.FundSplitPlan;
            screenconfig.items["PremAmnt"].itemconfig.values = basic.PremAmnt;
            int i = 1;
            foreach (var fund in basic.Funds)
            {
                screenconfig.items["FundCode_"+i.ToString()].itemconfig.values = fund.FundCode;
                screenconfig.items["FundAmount_" + i.ToString()].itemconfig.values = fund.Amount;
                i++;
            }
        }           

        public override void Execute()
        {
            this.F5();
            this.Waiting();
            this.F5();
            base.Execute();
        }
       
    }
}
