﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using KN.BusinessLogic;
using KN.Systems;
namespace KN.Screens
{
    public class S2472 :Screen
    {
        public override Point NamePos
        {
            get
            {
                return new Point(8, 60);// 2 * 80 + 71;
            }
        }       

        public S2472()
            : base("S2472", "Add Alternate Adress")
        {
           
        }

        public S2472(DATA_S2610_ACTION_C client)
            : base("S2472", "Add Alternate Adress")
        {            
            SetValues(client);
        }

        public override void SetValues(object obj)
        {
            var client = (DATA_S2610_ACTION_C)obj; 

            //screenconfig.items["LocationCode"].itemconfig.values = client.DA_Location;
            //screenconfig.items["Street1"].itemconfig.values = client.DA_Street;
            screenconfig.items["Street2"].itemconfig.values = "";
            screenconfig.items["Street3"].itemconfig.values = "";
            screenconfig.items["Street4"].itemconfig.values = "";
            screenconfig.items["CountryCode"].itemconfig.values = "";
            screenconfig.items["Bus_Res"].itemconfig.values = "R";
            //screenconfig.items["Telephone1"].itemconfig.values = client.DA_PhoneM;
            //screenconfig.items["Telephone2"].itemconfig.values = client.DA_PhoneC;
            //screenconfig.items["Telephone3"].itemconfig.values = client.DA_PhoneH;
        }       

        public override void Execute()
        {
            base.Execute();
        }
       
    }
}
