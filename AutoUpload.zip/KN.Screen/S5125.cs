﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using KN.BusinessLogic;
using KN.Systems;
namespace KN.Screens
{
    public class S5125 :Screen
    {
        public override Point NamePos
        {
            get
            {
                return new Point(1, 72);// 72;
            }
        }

        public override Point MessagePos
        {
            get
            {
                return new Point(24, 2);// 23 * 80 + 2;
            }
        }


        public S5125(Rider rider, string RiderCode)
            : base("S5125", "Rider")
        {
            SetValues(rider, RiderCode);
        }

        public override void SetValues(object obj, string RiderCode)
        {
            Rider rider = (Rider)obj;
            switch (RiderCode)
            {
                case "ADD1":
                    screenconfig.items["Benefit_Amount"].itemconfig.values = rider.Benefit_Amount;
                    screenconfig.items["Risk_Cess_Age_Term"].itemconfig.values = rider.Risk_Cess_Age_Term;
                    screenconfig.items["Prem_Cess_Age_Term"].itemconfig.values = rider.Prem_Cess_Age_Term;
                    screenconfig.items["Bene_Cess_Age_Term"].itemconfig.values = rider.Bene_Cess_Age_Term;
                    screenconfig.items["Mortality_Class"].itemconfig.values = rider.Mortality_Class;
                    screenconfig.items["Special_Terms"].itemconfig.values = rider.Special_Terms;
                    break;

                default:
                    break;

            }
            
        }           

        public override void Execute()
        {
            base.Execute();
        }
       
    }
}
