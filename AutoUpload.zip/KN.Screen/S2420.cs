﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using KN.BusinessLogic;
using KN.Systems;
namespace KN.Screens
{
    public class S2420 :Screen
    {
        public override Point NamePos
        {
            get
            {
                return new Point(1, 70);// 72;
            }
        }

        public override Point MessagePos
        {
            get
            {
                return new Point(24, 2);// 23 * 80 + 2;
            }
        }

        ClientCollection clientCollection = null;
        public S2420(ClientCollection client)
            : base("S2420", "Establish Client Relationships")
        {
            clientCollection = client;
            SetValues(client);
        }

        public override void SetValues(object obj)
        {
            ClientCollection clients = (ClientCollection)obj;
            int icount=0;
            foreach (var client in clients)
            {
                icount++;
                this.screenconfig.items["ClientNo_" + icount.ToString()].itemconfig.values = client.ClientID;
                this.screenconfig.items["RelationShip_" + icount.ToString()].itemconfig.values = client.RelationShip;                
            }
        }

        public void ReSetValues(object obj, int index)
        {
            ClientCollection clients = (ClientCollection)obj;
            int icount = 0;
            foreach (var client in clients)
            {
                icount++;
                if (icount < index)
                {
                    this.screenconfig.items["ClientNo_" + icount.ToString()].itemconfig.values = "";
                    this.screenconfig.items["RelationShip_" + icount.ToString()].itemconfig.values = "";
                }
                else
                {
                    this.screenconfig.items["ClientNo_" + icount.ToString()].itemconfig.values = client.ClientID;
                    this.screenconfig.items["RelationShip_" + icount.ToString()].itemconfig.values = client.RelationShip;
                }
            }
        }  

        public override void Execute()
        {
            //base.Execute();
            //Waiting();
            //string temp_value = "";
            ////Check
            //int icount = 0;
            //foreach (var item in screenconfig.items)
            //{
            //    temp_value = "";                
            //    temp_value = GetValues(item.Value.itemconfig.name);

            //    if (temp_value.Trim() == "")
            //    {
            //        continue;
            //    }
            //    icount++;
            //}

            //ClientCollection clients = clientCollection;
            //icount = icount / 2;
            //foreach (var client in clients)            
            //{
            //    icount++;
            //    if (icount <= 10)
            //    {
            //        this.screenconfig.items["ClientNo_" + icount.ToString()].itemconfig.values = client.ClientID;
            //        this.screenconfig.items["RelationShip_" + icount.ToString()].itemconfig.values = client.RelationShip;
            //    }
            //}

            base.Execute();
        }
       
    }
}
