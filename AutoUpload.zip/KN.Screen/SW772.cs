﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using KN.BusinessLogic;
using KN.Systems;
namespace KN.Screens
{
    public class SW772 : Screen
    {
        public override Point NamePos
        {
            get { return new Point(1, 72); }
        }

        public override Point MessagePos
        {
            get { return new Point(24, 2); }
        }

        public SW772()
            : base("SW772", "Questionnaire")
        {

        }

        public SW772(DATA_Questionaire_Collection questions, DATA_Questionaire_Collection ans_8)
            : base("SW772", "Questionnaire")
        {
            SetValues(questions, ans_8);
        }

        public void SetValues(DATA_Questionaire_Collection questions, DATA_Questionaire_Collection ans_8)
        {
            foreach (var question in questions)
            {
                if (question.Question.StartsWith("Question_0008") == false)
                    screenconfig.items[question.Question].itemconfig.values = question.Answer;
            }

            if (ans_8.Count != 0)
            {
                screenconfig.items["Question_0008_1_Sel"].itemconfig.values = "Y";
                screenconfig.items["Question_0008_1_Ans_1"].itemconfig.values = "Y";
                screenconfig.items["Question_0008_1_Ans_2"].itemconfig.values = ans_8;
            }

            screenconfig.items["PageDown1"].itemconfig.values = "X";
            screenconfig.items["PageDown2"].itemconfig.values = "X";
            screenconfig.items["PageDown3"].itemconfig.values = "X";
            screenconfig.items["PageDown4"].itemconfig.values = "X";
            screenconfig.items["PageDown5"].itemconfig.values = "X";
            screenconfig.items["PageDown6"].itemconfig.values = "X";
        }

        public override void Execute()
        {
            Waiting();
            Type mytype = null;
            KN.Systems.Screen subscreen = null;
            foreach (var item in screenconfig.items)
            {
                try
                {
                    if (item.Value.itemconfig.values == null)
                    {
                        continue;
                    }
                    System.Threading.Thread.Sleep(200);
                    Waiting();
                    EhllapiWrapper.SetCursorPos(item.Value.itemconfig.point.cursor);
                    Waiting();

                    switch (item.Value.itemconfig.action.id)
                    {
                        case -1:
                            continue;
                        case 0:
                            EhllapiWrapper.SendStr("@F");
                            EhllapiWrapper.SendStr(item.Value.itemconfig.values.ToString());
                            break;
                        case 1:
                            //EhllapiWrapper.SendStr(item.Value.itemconfig.action.value);
                            //EhllapiWrapper.SendStr(item.Value.itemconfig.values.ToString());
                            //break;

                            EhllapiWrapper.SendStr(item.Value.itemconfig.action.value);

                            if (item.Value.itemconfig.name.StartsWith("Question_0008_1_Ans")==true)
                            {
                                string screencode="";
                                EhllapiWrapper.ReadScreen(new Point(5, 58).cursor, 5, out screencode);
                                if (screencode != "SW777")
                                {
                                    EhllapiWrapper.SendStr(item.Value.itemconfig.action.value);
                                }
                            }

                            if ((mytype = Type.GetType(item.Value.itemconfig.typename, false, true)) == null)
                            {
                                System.Reflection.Assembly assembly = System.Reflection.Assembly.LoadFrom(AppSetting.FOLDER_ROOT + @"\KN.Screen.dll");
                                foreach (System.Type type in assembly.GetTypes())
                                    if (type.IsClass && type.FullName.CompareTo(item.Value.itemconfig.typename) == 0)
                                        mytype = type;
                            }

                            subscreen = (KN.Systems.Screen)Activator.CreateInstance(mytype, new object[] { item.Value.itemconfig.values });
                            subscreen.Waiting();
                            subscreen.Execute();
                            Next();
                            subscreen.Waiting();
                            if (subscreen.GetScreenCode() == subscreen.screenconfig.code)
                            {
                                throw new Exception(subscreen.GetMessage());
                            }
                            break;
                        case 2:
                            EhllapiWrapper.SendStr(item.Value.itemconfig.action.value);

                            if ((mytype = Type.GetType(item.Value.itemconfig.typename, false, true)) == null)
                            {
                                System.Reflection.Assembly assembly = System.Reflection.Assembly.LoadFrom(AppSetting.FOLDER_ROOT + @"\KN.Screen.dll");
                                foreach (System.Type type in assembly.GetTypes())
                                    if (type.IsClass && type.FullName.CompareTo(item.Value.itemconfig.typename) == 0)
                                        mytype = type;
                            }

                            subscreen = (KN.Systems.Screen)Activator.CreateInstance(mytype, new string[] { item.Value.itemconfig.values.ToString() });
                            subscreen.Waiting();
                            subscreen.Execute();
                            Next();
                            break;
                        case 3:
                            EhllapiWrapper.SendStr(item.Value.itemconfig.action.value);
                            break;
                        case 4:
                            EhllapiWrapper.SendStr("@F");
                            EhllapiWrapper.SendStr(item.Value.itemconfig.values.ToString());
                            EhllapiWrapper.SendStr(item.Value.itemconfig.action.value);
                            break;
                        case 5:
                            EhllapiWrapper.SendStr("@E");
                            EhllapiWrapper.SendStr("@4");
                            if ((mytype = Type.GetType(item.Value.itemconfig.typename, false, true)) == null)
                            {
                                System.Reflection.Assembly assembly = System.Reflection.Assembly.LoadFrom(AppSetting.FOLDER_ROOT + @"\KN.Screen.dll");
                                foreach (System.Type type in assembly.GetTypes())
                                    if (type.IsClass && type.FullName.CompareTo(item.Value.itemconfig.typename) == 0)
                                        mytype = type;
                            }

                            subscreen = (KN.Systems.Screen)Activator.CreateInstance(mytype, new string[] { item.Value.itemconfig.values.ToString() });
                            subscreen.Waiting();
                            subscreen.Execute();
                            Next();
                            break;
                    }
                    //EhllapiWrapper.SendStr(item.Value.itemconfig.values.ToString());
                }
                catch
                {
                    throw new Exception(item.Key);
                }
            }
        }

    }
}
