﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using KN.BusinessLogic;
using KN.Systems;
namespace KN.Screens
{
    public class S5005 :Screen
    {
        public override Point NamePos
        {
            get
            {
                return new Point(1, 72);// 72;
            }
        }

        public override Point MessagePos
        {
            get
            {
                return new Point(24, 2);// 23 * 80 + 2;
            }
        }


        public S5005(LifeAssure LA)
            : base("S5005", "Lives Assured")
        {
            SetValues(LA);
        }

        public override void SetValues(object obj)
        {
            LifeAssure LA = (LifeAssure)obj;
            //this.screenconfig.items["ContrastNumber"].itemconfig.values = LA.ContrastNumber;
            //this.screenconfig.items["LifeNo"].itemconfig.values = LA.LifeNo;
            this.screenconfig.items["Life"].itemconfig.values = LA.Life;
            this.screenconfig.items["Sex"].itemconfig.values = LA.Sex;
            this.screenconfig.items["DateOfBirth"].itemconfig.values = LA.DateOfBirth;
            this.screenconfig.items["MedicalEvidence"].itemconfig.values = LA.MedicalEvidence;
            this.screenconfig.items["Smoking"].itemconfig.values = LA.Smoking;
            this.screenconfig.items["PursuitCode1"].itemconfig.values = LA.PursuitCode1;
            this.screenconfig.items["PursuitCode2"].itemconfig.values = LA.PursuitCode2;
            this.screenconfig.items["Height"].itemconfig.values = LA.Height;
            this.screenconfig.items["Weight"].itemconfig.values = LA.Weight;
            
        }       

        public override void Execute()
        {
            base.Execute();
        }
       
    }
}
