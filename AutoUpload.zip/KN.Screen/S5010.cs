﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using KN.BusinessLogic;
using KN.Systems;
namespace KN.Screens
{
    public class S5010 :Screen
    {
        public override Point NamePos
        {
            get
            {
                return new Point(1, 72);// 72;
            }
        }

        public override Point MessagePos
        {
            get
            {
                return new Point(24, 2);// 23 * 80 + 2;
            }
        }


        public S5010(BeneficiaryCollection bens)
            : base("S5010", "Contrast Commission Split")
        {
            SetValues(bens);
        }

        public override void SetValues(object obj)
        {
            BeneficiaryCollection bens = (BeneficiaryCollection)obj;
            int icount=0;
            foreach (var ben in bens)
            {
                icount++;
                this.screenconfig.items["Relation_" + icount.ToString()].itemconfig.values = ben.Relation;
                this.screenconfig.items["N_" + icount.ToString()].itemconfig.values = ben.N;
                this.screenconfig.items["ShareCode_" + icount.ToString()].itemconfig.values = ben.ShareCode;
                this.screenconfig.items["Beneficiary_" + icount.ToString()].itemconfig.values = ben.ClientNo;
                this.screenconfig.items["EffectiveFrom_" + icount.ToString()].itemconfig.values = ben.EffectiveFrom;
            }

        }       

        public override void Execute()
        {
            base.Execute();
        }
       
    }
}
