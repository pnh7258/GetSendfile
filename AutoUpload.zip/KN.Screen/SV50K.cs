﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KN.Systems;
using KN.BusinessLogic;

namespace KN.Screens
{
    public class SV50K : Screen
    {
        public override Point NamePos
        {
            get
            {
                return new Point(1, 72);// 2 * 80 + 71;
            }
        }
        public override Point MessagePos
        {
            get
            {
                return new Point(24, 2);// 23 * 80 + 2;
            }
        }
        public string Action
        {
            get;
            set;
        }

        public SV50K()
            : base("SV50K", "Advance Premium Receipt")
        {

        }

        public SV50K(object obj)
            : base("SV50K", "Advance Premium Receipt")
        {
            SetValues(obj);
        }

        public override void SetValues(object obj)
        {
            var data_SV50K = (DATA_SV50K)obj;
            //screenconfig.items["Bank_Code"].itemconfig.values = data_SV50K.Bank_Code;
            //screenconfig.items["Tax_Invoice"].itemconfig.values = data_SV50K.Tax_Invoice;
            //screenconfig.items["Contract_Number"].itemconfig.values = data_SV50K.Contract_Number;
            //screenconfig.items["Action"].itemconfig.values = data_SV50K.Action;
            screenconfig.items["OR1_Number"].itemconfig.values = data_SV50K.OR1_Number;
            screenconfig.items["Collected_Agent_Collector"].itemconfig.values = data_SV50K.Collected_Agent_Collector;
            screenconfig.items["OR2_Number"].itemconfig.values = data_SV50K.OR2_Number;
            screenconfig.items["Payment_Type"].itemconfig.values = data_SV50K.Payment_Type;
            screenconfig.items["Received_From"].itemconfig.values = data_SV50K.Received_From;
            screenconfig.items["Amount"].itemconfig.values = data_SV50K.Amount;
            screenconfig.items["TR_NO"].itemconfig.values = data_SV50K.TR_NO;
            screenconfig.items["Receipt_Date"].itemconfig.values = data_SV50K.Receipt_Date;
            screenconfig.items["GL_Amount"].itemconfig.values = data_SV50K.GL_Amount;
            screenconfig.items["BSB_Code"].itemconfig.values = data_SV50K.BSB_Code;
            screenconfig.items["Cheque_No"].itemconfig.values = data_SV50K.Cheque_No;
            screenconfig.items["Cheque_Date"].itemconfig.values = data_SV50K.Cheque_Date;
            screenconfig.items["InterID"].itemconfig.values = data_SV50K.InterID;
            screenconfig.items["SubCode1"].itemconfig.values = data_SV50K.SubCode1;
            screenconfig.items["SubType1"].itemconfig.values = data_SV50K.SubType1;
            screenconfig.items["Contract_Number1"].itemconfig.values = data_SV50K.Contract_Number1;
            screenconfig.items["Desc1"].itemconfig.values = data_SV50K.Desc1;
            screenconfig.items["SubAmount1"].itemconfig.values = data_SV50K.SubAmount1;
            screenconfig.items["SubCode2"].itemconfig.values = data_SV50K.SubCode2;
            screenconfig.items["SubType2"].itemconfig.values = data_SV50K.SubType2;
            screenconfig.items["Contract_Number2"].itemconfig.values = data_SV50K.Contract_Number2;
            screenconfig.items["Desc2"].itemconfig.values = data_SV50K.Desc2;
            screenconfig.items["SubAmount2"].itemconfig.values = data_SV50K.SubAmount2;
            screenconfig.items["SubCode3"].itemconfig.values = data_SV50K.SubCode3;
            screenconfig.items["SubType3"].itemconfig.values = data_SV50K.SubType3;
            screenconfig.items["Contract_Number3"].itemconfig.values = data_SV50K.Contract_Number3;
            screenconfig.items["Desc3"].itemconfig.values = data_SV50K.Desc3;
            screenconfig.items["SubAmount3"].itemconfig.values = data_SV50K.SubAmount3;
            //screenconfig.items["SubCode4"].itemconfig.values = data_SV50K.SubCode4;
            //screenconfig.items["SubType4"].itemconfig.values = data_SV50K.SubType4;
            //screenconfig.items["Contract_Number4"].itemconfig.values = data_SV50K.Contract_Number4;
            //screenconfig.items["Desc4"].itemconfig.values = data_SV50K.Desc4;
            //screenconfig.items["SubAmount4"].itemconfig.values = data_SV50K.SubAmount4;
            //screenconfig.items["PTD_ADV"].itemconfig.values = data_SV50K.PTD_ADV;
            //screenconfig.items["InsPrem"].itemconfig.values = data_SV50K.InsPrem;
            //screenconfig.items["Sum_Temp"].itemconfig.values = data_SV50K.Sum_Temp;
        }
        public override void Execute()
        {
            base.Execute();
        }

    }
}
