﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KN.Systems;
using KN.BusinessLogic;

namespace KN.Screens
{
    public class S0018:Screen
    {
        public S0018()
            : base("S0018", "Receipts")
        {            
            
        }        

        public override Point  NamePos
        {
	        get 
	        {
                return new Point(1, 72);
	        }
        }       
    }
}
