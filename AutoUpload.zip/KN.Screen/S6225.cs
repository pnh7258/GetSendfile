﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using KN.BusinessLogic;
using KN.Systems;
namespace KN.Screens
{
    public class S6225 :Screen
    {
        public override Point NamePos
        {
            get
            {
                return new Point(13, 56);// 72;
            }
        }

        public override Point MessagePos
        {
            get
            {
                return new Point(24, 2);// 23 * 80 + 2;
            }
        }


        public S6225(string ClientNo)
            : base("S6225", "Despatch Address")
        {
            SetValues(ClientNo);
        }

        public override void SetValues(object ClientNo)
        {
            this.screenconfig.items["Client_No"].itemconfig.values = ClientNo.ToString();
        }       

        public override void Execute()
        {
            base.Execute();
        }
       
    }
}
