﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace KN.Screens
{
    public class MsgBox
    {
        public static void ShowMessageInfo(string text, string caption = "Auto Upload")
        {
            MessageBox.Show(text, caption, MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        public static void ShowMessageWarning(string text, string caption = "Auto Upload")
        {
            MessageBox.Show(text, caption, MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        public static void ShowMessageError(string text, string caption = "Auto Upload")
        {
            MessageBox.Show(text, caption, MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        public static DialogResult ShowMessageQuestion(string text, string caption = "Auto Upload")
        {
            return MessageBox.Show(text, caption, MessageBoxButtons.OK, MessageBoxIcon.Question);
        }
    }
}
