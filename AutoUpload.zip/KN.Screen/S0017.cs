﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KN.Systems;
using KN.BusinessLogic;

namespace KN.Screens
{
    public class S0017:Screen
    {
        public S0017(string branchcode)
            : base("S0017", "Clients & Groups")
        {            
            SetValues(branchcode);
        }

        public override void SetValues(object obj)
        {
            screenconfig.items["BranchCode"].itemconfig.values = obj;            
        }

        public override Point  NamePos
        {
	        get 
	        {
                return new Point(1, 72);
	        }
        }       
    }
}
