﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using KN.BusinessLogic;
using KN.Systems;
namespace KN.Screens
{
    public class S5002 :Screen
    {
        public override Point NamePos
        {
            get
            {
                return new Point(1, 72);// 72;
            }
        }

        public override Point MessagePos
        {
            get
            {
                return new Point(24, 2);// 23 * 80 + 2;
            }
        }


        public S5002(string ContractType)
            : base("S5002", "New Contract Proposal Submenu")
        {
            SetValues(ContractType);
        }

        public S5002(string ContractNumber, string LifeAssured, string ActionType)
            : base("S5002", "New Contract Proposal Submenu")
        {
            screenconfig.items["ContractNumber"].itemconfig.values = ContractNumber;
            screenconfig.items["LifeAssured"].itemconfig.values = LifeAssured;
            screenconfig.items["Action"].itemconfig.values = ActionType;
        }

        public override void SetValues(object ContractType)
        {
            screenconfig.items["ContractNumber"].itemconfig.values = "          ";
            screenconfig.items["ContractType"].itemconfig.values = ContractType;
        }           

        public override void Execute()
        {
            base.Execute();
        }
       
    }
}
