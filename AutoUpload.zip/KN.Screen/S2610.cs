﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KN.Systems;
using KN.BusinessLogic;

namespace KN.Screens
{
    public class S2610:Screen
    {
        public override Point NamePos
        {
            get
            {
                return new Point(1, 72);// 2 * 80 + 71;
            }
        }
        public override Point MessagePos
        {
            get
            {
                return new Point(24, 2);// 23 * 80 + 2;
            }
        }
        public string Action
        {
            get;
            set;
        }

        public S2610()
            : base("S2610", "Cash not Banked")
        {
           
        }

        public S2610(object obj)
            : base("S2610", "Cash not Banked")
        {            
            SetValues(obj);
        }

        public override void SetValues(object obj)
        {
            var data_S2610 = (DATA_S2610)obj;
            screenconfig.items["OR_No_1"].itemconfig.values = data_S2610.OR_No_1;
            screenconfig.items["OR_No_2"].itemconfig.values = data_S2610.OR_No_2;
            screenconfig.items["OR_No_3"].itemconfig.values = data_S2610.OR_No_3;
            screenconfig.items["OR_No_4"].itemconfig.values = data_S2610.OR_No_4;
            screenconfig.items["CollectedAgentCollector"].itemconfig.values = data_S2610.CollectedAgentCollector;
            screenconfig.items["TransID"].itemconfig.values = data_S2610.TransID;
            screenconfig.items["PaymType"].itemconfig.values = data_S2610.PaymType;
            screenconfig.items["RS"].itemconfig.values = data_S2610.RS;
            screenconfig.items["BankCode"].itemconfig.values = data_S2610.BankCode;
            screenconfig.items["TranDate"].itemconfig.values = data_S2610.TranDate;
            screenconfig.items["SBR"].itemconfig.values = data_S2610.SBR;
            screenconfig.items["ReceivedFr"].itemconfig.values = data_S2610.ReceivedFr;
            screenconfig.items["ClientCode"].itemconfig.values = data_S2610.ClientCode;
            screenconfig.items["Amount"].itemconfig.values = data_S2610.Amount;
            screenconfig.items["GLAmount"].itemconfig.values = data_S2610.GLAmount;
            screenconfig.items["TRNo"].itemconfig.values = data_S2610.TRNo;
            screenconfig.items["RcptDte"].itemconfig.values = data_S2610.RcptDte;
            screenconfig.items["PropNo"].itemconfig.values = data_S2610.PropNo;
            screenconfig.items["Bank"].itemconfig.values = data_S2610.Bank;
            screenconfig.items["BSBCode"].itemconfig.values = data_S2610.BSBCode;
            screenconfig.items["Branch"].itemconfig.values = data_S2610.Branch;
            screenconfig.items["CheNo"].itemconfig.values = data_S2610.CheNo;
            screenconfig.items["Date"].itemconfig.values = data_S2610.Date;
            screenconfig.items["Account"].itemconfig.values = data_S2610.Account;
            screenconfig.items["InterfaceID"].itemconfig.values = data_S2610.InterfaceID;
            screenconfig.items["EffDte"].itemconfig.values = data_S2610.EffDte;
            screenconfig.items["MainAgent"].itemconfig.values = data_S2610.MainAgent;
            screenconfig.items["SubCode1"].itemconfig.values = data_S2610.SubCode1;
            screenconfig.items["SubType1"].itemconfig.values = data_S2610.SubType1;
            screenconfig.items["Desc1"].itemconfig.values = data_S2610.Desc1;
            screenconfig.items["SubAmount1"].itemconfig.values = data_S2610.SubAmount1;
          
        }
        public override void Execute()
        {
            base.Execute();
        }

    }
}
