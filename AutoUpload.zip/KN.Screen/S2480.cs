﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KN.Systems;
namespace KN.Screens
{
    public class S2480:Screen
    {
        public override Point NamePos
        {
            get
            {
                return new Point(1, 73);// 2 * 80 + 71;
            }
        }
        public override Point MessagePos
        {
            get
            {
                return new Point(24, 2);// 23 * 80 + 2;
            }
        }
        public string Action
        {
            get;
            set;
        }

        public S2480()
            : base("S2480", "Client Maintenance Submenu")
        {
           
        }

        public S2480(string ID)
            : base("S2480", "Client Maintenance Submenu")
        {
            //ItemColection item = new ItemColection();
            //LoadConfig("S2465");
            SetValues(ID);
        }

        public override void SetValues(object obj)
        {
            var ID = (string)obj;
            //items["ClientID"].values = client.ClientID;
            screenconfig.items["ID"].itemconfig.values = ID;
            screenconfig.items["Action"].itemconfig.values = this.Action;            
        }
        public override void Execute()
        {
            base.Execute();
        }

    }
}
