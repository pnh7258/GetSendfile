﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using KN.BusinessLogic;
using KN.Systems;
namespace KN.Screens
{
    public class S5004 :Screen
    {
        public override Point NamePos
        {
            get
            {
                return new Point(1, 72);// 72;
            }
        }

        public override Point MessagePos
        {
            get
            {
                return new Point(24, 2);// 23 * 80 + 2;
            }
        }


        public S5004(Product product)
            : base("S5004", "Product")
        {
            //ItemColection item = new ItemColection();
            //LoadConfig("S2465");
            SetValues(product);
        }

        public override void SetValues(object obj)
        {
            Product product = (Product)obj;
            screenconfig.items["ContactOwner"].itemconfig.values = product.ContactOwner;
            screenconfig.items["ProspectNumber"].itemconfig.values = product.ProspectNumber;
            screenconfig.items["IncomeRage"].itemconfig.values = product.IncomeRage;
            screenconfig.items["Amount"].itemconfig.values = product.Amount;
            screenconfig.items["RiskComDate"].itemconfig.values = product.RiskComDate;
            screenconfig.items["PropDate"].itemconfig.values = product.PropDate;
            screenconfig.items["BillingFrequency"].itemconfig.values = product.BillingFrequency;
            screenconfig.items["PropRcvDate"].itemconfig.values = product.PropRcvDate;
            screenconfig.items["MethodPayment"].itemconfig.values = product.MethodPayment;
            screenconfig.items["UWDecDate"].itemconfig.values = product.UWDecDate;
            screenconfig.items["FirstBillingDate"].itemconfig.values = product.FirstBillingDate;
            screenconfig.items["NoOfPolicy"].itemconfig.values = product.NoOfPolicy;
            screenconfig.items["ContrastCurrency"].itemconfig.values = product.ContrastCurrency;
            screenconfig.items["BillCurrency"].itemconfig.values = product.BillCurrency;
            screenconfig.items["NonFFTOpt"].itemconfig.values = product.NonFFTOpt;
            screenconfig.items["ContrastRegister"].itemconfig.values = product.ContrastRegister;
            screenconfig.items["CrossRefType"].itemconfig.values = product.CrossRefType;
            screenconfig.items["Number"].itemconfig.values = product.Number;
            screenconfig.items["SourceOfBussiness"].itemconfig.values = product.SourceOfBussiness;
            screenconfig.items["TempRcptNo"].itemconfig.values = product.TempRcptNo;
            screenconfig.items["DupRefNo"].itemconfig.values = product.DupRefNo;
            screenconfig.items["TemporaryReceiptDate"].itemconfig.values = product.TemporaryReceiptDate;
            screenconfig.items["ServicingBranch"].itemconfig.values = product.ServicingBranch;
            screenconfig.items["Agency"].itemconfig.values = product.Agency;
            screenconfig.items["Campaign"].itemconfig.values = product.Campaign;
            screenconfig.items["JointOwner"].itemconfig.values = product.JointOwner;
            screenconfig.items["Assignee"].itemconfig.values = product.Assignee;
            screenconfig.items["Applycash"].itemconfig.values = product.Applycash;
            screenconfig.items["DespatchAddress"].itemconfig.values = product.DespatchAddress;
            screenconfig.items["Payor"].itemconfig.values = product.Payor;
            screenconfig.items["RevApplyCash"].itemconfig.values = product.RevApplyCash;
            screenconfig.items["DirectDebit"].itemconfig.values = product.DirectDebit;
            screenconfig.items["FollowUps"].itemconfig.values = product.FollowUps;
            screenconfig.items["Commission"].itemconfig.values = product.Commission;
            screenconfig.items["GroupDetails"].itemconfig.values = product.GroupDetails;
            screenconfig.items["Beneficiaries"].itemconfig.values = product.Beneficiaries;
            screenconfig.items["ReducingTerm"].itemconfig.values = product.ReducingTerm;

        }       

        public override void Execute()
        {
            base.Execute();
        }
       
    }
}
