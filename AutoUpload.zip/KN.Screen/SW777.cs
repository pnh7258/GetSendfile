﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using KN.BusinessLogic;
using KN.Systems;
namespace KN.Screens
{
    public class SW777 :Screen
    {
        public override Point NamePos
        {
            get { return new Point(6, 58); }
        }

        public override Point MessagePos
        {
            get { return new Point(22, 5); }
        }
        public SW777()
            : base("SW777", "Questionnaire")
        {
           
        }

        public SW777(DATA_Questionaire_Collection questions)
            : base("SW777", "Questionnaire")
        {
            SetValues(questions);
        }

        public override void SetValues(object obj)
        {
            var questions = (DATA_Questionaire_Collection)obj;
            foreach (var question in questions)
            {
                screenconfig.items[question.Question].itemconfig.values = question.Answer;
            }            
        } 
    }
}
