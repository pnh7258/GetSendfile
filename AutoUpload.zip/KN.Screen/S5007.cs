﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using KN.BusinessLogic;
using KN.Systems;
namespace KN.Screens
{
    public class S5007 :Screen
    {
        public override Point NamePos
        {
            get
            {
                return new Point(1, 72);// 72;
            }
        }

        public override Point MessagePos
        {
            get
            {
                return new Point(24, 2);// 23 * 80 + 2;
            }
        }


        public S5007(AgentCollection agents)
            : base("S5007", "Contrast Commission Split")
        {
            SetValues(agents);
        }

        public override void SetValues(object obj)
        {
            AgentCollection agents = (AgentCollection)obj;
            int icount=0;
            foreach (var agent in agents)
            {
                icount++;
                this.screenconfig.items["AgentCode_" + icount.ToString()].itemconfig.values = agent.AgentCode;
                this.screenconfig.items["Commission_" + icount.ToString()].itemconfig.values = agent.Commission;
                this.screenconfig.items["BonusPoints_" + icount.ToString()].itemconfig.values = agent.BonusPoints;
            }

        }       

        public override void Execute()
        {
            base.Execute();
        }
       
    }
}
