﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using KN.BusinessLogic;
using KN.Systems;
namespace KN.Screens
{
    public class S5003 :Screen
    {
        public override Point NamePos
        {
            get
            {
                return new Point(1, 71);// 72;
            }
        }

        public override Point MessagePos
        {
            get
            {
                return new Point(24, 2);// 23 * 80 + 2;
            }
        }


        public S5003()
            : base("S5003", "Work With Proposal")
        {
            SetValues(null);
        }

        public override void SetValues(object obj)
        {
            this.screenconfig.items["Act_1"].itemconfig.values = "2";
        }       

        public override void Execute()
        {
            base.Execute();
        }
       
    }
}
