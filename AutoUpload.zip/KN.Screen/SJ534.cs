﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using KN.BusinessLogic;
using KN.Systems;
namespace KN.Screens
{
    public class SJ534 :Screen
    {                      
        public SJ534()
            : base("SJ534", "Data Entry/Update Proposal Records")
        {
           
        }

        public SJ534(string obj)
            : base("SJ534", "Data Entry/Update Proposal Records")
        {
            SetValues(obj);
        }

        public override void SetValues(object obj)
        {
            var ApplicationNumber = (string)obj;
            screenconfig.items["Action"].itemconfig.values = "E";
            screenconfig.items["ApplicationNumber"].itemconfig.values = ApplicationNumber;            
        }       

        public override void Execute()
        {
            base.Execute();
        }
       
    }
}
