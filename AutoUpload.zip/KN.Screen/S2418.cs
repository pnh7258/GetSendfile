﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KN.Systems;
namespace KN.Screens
{
    public class S2418:Screen
    {
        public override Point NamePos
        {
            get
            {
                return new Point(1, 71);// 2 * 80 + 71;
            }
        }
        public override Point MessagePos
        {
            get
            {
                return new Point(24, 2);// 23 * 80 + 2;
            }
        }
        public string Action
        {
            get;
            set;
        }

        public S2418()
            : base("S2418", "Client Relationships")
        {
           
        }

        public S2418(string ClientNo)
            : base("S2418", "Client Relationships")
        {
            //ItemColection item = new ItemColection();
            //LoadConfig("S2465");
            SetValues(ClientNo);
        }

        public override void SetValues(object obj)
        {
            var ClientNo = (string)obj;
            //items["ClientID"].values = client.ClientID;
            screenconfig.items["MasterKey"].itemconfig.values = ClientNo;
            screenconfig.items["Action"].itemconfig.values = this.Action;            
        }
        public override void Execute()
        {
            base.Execute();
        }

    }
}
