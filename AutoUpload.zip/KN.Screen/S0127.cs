﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KN.Systems;
using KN.BusinessLogic;

namespace KN.Screens
{
    class S0127:Screen
    {
        public S0127(string salutation)
            : base("S0127", "Client Maintain - Personal")
        {
            //ItemColection item = new ItemColection();
            //LoadConfig("S2465");
            SetValues(salutation);
        }

        public override Point  NamePos
        {
	        get 
	        {
                return new Point(3, 61);// 2 * 80 + 61;
	        }
        } 
        

        public override void SetValues(object obj)
        {
            //var salutation = (Salutation)obj;
            //items["ClientID"].values = client.ClientID;
            screenconfig.items["Select"].itemconfig.values = "X"; 
        }       

        public override void Execute()
        {
            base.Execute();
        }
    }
}
