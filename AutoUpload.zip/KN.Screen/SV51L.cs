﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using KN.BusinessLogic;
using KN.Systems;
namespace KN.Screens
{
    public class SV51L :Screen
    {
        
        public SV51L()
            : base("SV51L", "Application Received at CS")
        {
           
        }

        public SV51L(DATA_SV51L sv51l)
            : base("SV51L", "Application Received at CS")
        {
            SetValues(sv51l);
        }

        public override void SetValues(object obj)
        {
            var sv51l = (DATA_SV51L)obj;

            screenconfig.items["ReceivedDate"].itemconfig.values = sv51l.ReceivedDate;
            screenconfig.items["ApplicationNumber"].itemconfig.values = sv51l.ApplicationNumber;
            screenconfig.items["BillingFrequency"].itemconfig.values = sv51l.BillingFrequency;
            screenconfig.items["ContractType"].itemconfig.values = sv51l.ContractType;
            //screenconfig.items["Add_Y_N"].itemconfig.values = sv51l.Add_Y_N;
        }       

        public override void Execute()
        {
            base.Execute();
        }
       
    }
}
