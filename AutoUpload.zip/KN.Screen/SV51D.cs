﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KN.Systems;
using KN.BusinessLogic;

namespace KN.Screens
{
    public class SV15U :Screen
    {
        public override Point NamePos
        {
            get
            {
                return new Point(1, 72);// 2 * 80 + 71;
            }
        }
        public override Point MessagePos
        {
            get
            {
                return new Point(24, 2);// 23 * 80 + 2;
            }
        }
        public string Action
        {
            get;
            set;
        }

        public SV15U ()
            : base("SV15U ", "New Suspense Receipt")
        {
           
        }

        public SV15U (object obj)
            : base("SV15U ", "New Suspense Receipt")
        {            
            SetValues(obj);
        }

        public override void SetValues(object obj)
        {
            var data_SV51D = (DATA_SV51D)obj;
            //screenconfig.items["Action"].itemconfig.values = data_SV51D.Action;
            screenconfig.items["Amount"].itemconfig.values = data_SV51D.Amount;
            //screenconfig.items["Bank_Code"].itemconfig.values = data_SV51D.Bank_Code;
            screenconfig.items["BSB_Code"].itemconfig.values = data_SV51D.BSB_Code;
            screenconfig.items["Cheque_Date"].itemconfig.values = data_SV51D.Cheque_Date;
            screenconfig.items["Cheque_No"].itemconfig.values = data_SV51D.Cheque_No;
            screenconfig.items["Collected_Agent_Collector"].itemconfig.values = data_SV51D.Collected_Agent_Collector;
            //screenconfig.items["Contract_Number"].itemconfig.values = data_SV51D.Contract_Number;
            screenconfig.items["Contract_Number1"].itemconfig.values = data_SV51D.Contract_Number1;
            screenconfig.items["Contract_Number2"].itemconfig.values = data_SV51D.Contract_Number2;
            //screenconfig.items["Contract_Number3"].itemconfig.values = data_SV51D.Contract_Number3;
            screenconfig.items["Desc1"].itemconfig.values = data_SV51D.Desc1;
            screenconfig.items["Desc2"].itemconfig.values = data_SV51D.Desc2;
            //screenconfig.items["Desc3"].itemconfig.values = data_SV51D.Desc3;
            screenconfig.items["GASubType"].itemconfig.values = data_SV51D.GASubType;
            screenconfig.items["GL_Amount"].itemconfig.values = data_SV51D.GL_Amount;
            //screenconfig.items["InsPrem"].itemconfig.values = data_SV51D.InsPrem;
            screenconfig.items["InterID"].itemconfig.values = data_SV51D.InterID;
            screenconfig.items["OR1_Number"].itemconfig.values = data_SV51D.OR1_Number;
            screenconfig.items["OR2_Number"].itemconfig.values = data_SV51D.OR2_Number;
            screenconfig.items["Payment_Type"].itemconfig.values = data_SV51D.Payment_Type;
            //screenconfig.items["PTD_ADV"].itemconfig.values = data_SV51D.PTD_ADV;
            screenconfig.items["Receipt_Date"].itemconfig.values = data_SV51D.Receipt_Date;
            screenconfig.items["Received_From"].itemconfig.values = data_SV51D.Received_From;
            screenconfig.items["SubAmount1"].itemconfig.values = data_SV51D.SubAmount1;
            screenconfig.items["SubAmount2"].itemconfig.values = data_SV51D.SubAmount2;
            //screenconfig.items["SubAmount3"].itemconfig.values = data_SV51D.SubAmount3;
            screenconfig.items["SubCode1"].itemconfig.values = data_SV51D.SubCode1;
            screenconfig.items["SubCode2"].itemconfig.values = data_SV51D.SubCode2;
            //screenconfig.items["SubCode3"].itemconfig.values = data_SV51D.SubCode3;
            screenconfig.items["SubType1"].itemconfig.values = data_SV51D.SubType1;
            screenconfig.items["SubType2"].itemconfig.values = data_SV51D.SubType2;
            //screenconfig.items["SubType3"].itemconfig.values = data_SV51D.SubType3;
            //screenconfig.items["Tax_Invoice"].itemconfig.values = data_SV51D.Tax_Invoice;
            screenconfig.items["TR_NO"].itemconfig.values = data_SV51D.TR_NO;
        }
        public override void Execute()
        {
            base.Execute();
        }

    }
}
