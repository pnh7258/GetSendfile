﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KN.Systems;
using KN.BusinessLogic;

namespace KN.Screens
{
    public class SVRST : Screen
    {
        public override Point NamePos
        {
            get
            {
                return new Point(1, 72);// 2 * 80 + 71;
            }
        }
        public override Point MessagePos
        {
            get
            {
                return new Point(24, 2);// 23 * 80 + 2;
            }
        }
        public string Action
        {
            get;
            set;
        }

        public SVRST()
            : base("SVRST", "Magnum")
        {

        }

        public SVRST(object obj)
            : base("SVRST", "Magnum")
        {
            SetValues(obj);
        }

        public override void SetValues(object obj)
        {
            screenconfig.items["Question_Item"].itemconfig.values = obj;
        }
        public override void Execute()
        {
            base.Execute();
        }

    }
}
