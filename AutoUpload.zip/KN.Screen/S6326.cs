﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using KN.BusinessLogic;
using KN.Systems;
namespace KN.Screens
{
    public class S6326 :Screen
    {
        public override Point NamePos
        {
            get
            {
                return new Point(1, 72);// 72;
            }
        }

        public override Point MessagePos
        {
            get
            {
                return new Point(24, 2);// 23 * 80 + 2;
            }
        }


        public S6326(Basicplan basic)
            : base("S6326", "UL Regular Premium - Series 1")
        {
            SetValues(basic);
        }

        public override void SetValues(object obj)
        {
            Basicplan basic = (Basicplan)obj;
            screenconfig.items["SumAssured"].itemconfig.values = basic.SumAssured;
            screenconfig.items["MaturityAge_Term"].itemconfig.values = basic.MaturityAge_Term;
            screenconfig.items["PremiumCessAge_Term"].itemconfig.values = basic.PremiumCessAge_Term;
            screenconfig.items["ReserveUnits"].itemconfig.values = basic.ReserveUnits;
            screenconfig.items["ReserveUnitsDate"].itemconfig.values = basic.ReserveUnitsDate;
            screenconfig.items["MortalityClass"].itemconfig.values = basic.MortalityClass;
            screenconfig.items["JointLife"].itemconfig.values = basic.JointLife;
            screenconfig.items["SpecialTerms"].itemconfig.values = basic.SpecialTerms;
            screenconfig.items["RiskProfile"].itemconfig.values = basic.RiskProfile;
        }           

        public override void Execute()
        {
            base.Execute();
        }
       
    }
}
