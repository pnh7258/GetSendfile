﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using KN.BusinessLogic;
using KN.Systems;
namespace KN.Screens
{
    public class SJ566 :Screen
    {                      
        public SJ566()
            : base("SJ566", "Bulk Data Entry")
        {
           
        }

        public SJ566(string obj)
            : base("SJ566", "Bulk Data Entry")
        {
            SetValues(obj);
        }

        public override void SetValues(object obj)
        {
            var action = (string)obj;
            screenconfig.items["Action"].itemconfig.values = action;                  
        }       

        public override void Execute()
        {
            base.Execute();
        }
       
    }
}
