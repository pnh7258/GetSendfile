﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using KN.BusinessLogic;
using KN.Systems;
namespace KN.Screens
{
    public class S5006 :Screen
    {
        public override Point NamePos
        {
            get
            {
                return new Point(1, 71);// 72;
            }
        }

        public override Point MessagePos
        {
            get
            {
                return new Point(24, 2);// 23 * 80 + 2;
            }
        }


        public S5006(RiderCollection riders)
            : base("S5006", "Select Cover Required")
        {
            SetValues(riders);
        }

        public override void SetValues(object obj)
        {
            riders = (RiderCollection)obj;        
        }

        RiderCollection riders;
        public override void Execute()
        {
            try
            {
                this.Waiting();

                List<string> temp_riders = new List<string>();

                foreach (var item in this.screenconfig.items)
                {
                    string temp_rider = this.GetValues(item.Value.itemconfig.name);

                    if (temp_rider == null) continue;
                    if (temp_rider.Trim() == "") continue;
                    if (temp_rider.Trim().Length < 4) continue;

                    temp_riders.Add(temp_rider.Trim());
                }

                foreach (var rider in riders)
                {   
                    int index = temp_riders.FindIndex(x => x.StartsWith(rider.Code)==true) + 1;
                    if (rider.Role == "LA1") index++;
                    this.screenconfig.items["RiderSelect_" + index.ToString()].itemconfig.values = "X";
                }
            }
            catch
            {
                throw;
            }
            base.Execute();
        }
       
    }
}
