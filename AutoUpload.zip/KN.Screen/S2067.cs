﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KN.Systems;
using KN.BusinessLogic;

namespace KN.Screens
{
    public class S2067:Screen
    {
        public override Point NamePos
        {
            get
            {
                return new Point(1, 72);// 2 * 80 + 71;
            }
        }
        public override Point MessagePos
        {
            get
            {
                return new Point(24, 2);// 23 * 80 + 2;
            }
        }
        public string Action
        {
            get;
            set;
        }

        public S2067()
            : base("S2067", "Cash Receipt Submenu")
        {
           
        }

        public S2067(object obj)
            : base("S2067", "Cash Receipt Submenu")
        {            
            SetValues(obj);
        }

        public override void SetValues(object obj)
        {
            var data_S2067 = (DATA_S2067)obj;
            screenconfig.items["Action"].itemconfig.values = data_S2067.Action;
            screenconfig.items["BankCode"].itemconfig.values = data_S2067.BankCode;
            screenconfig.items["ChequeNumber"].itemconfig.values = data_S2067.ChequeNumber;
            screenconfig.items["ContractNumber"].itemconfig.values = data_S2067.ContractNumber;
            screenconfig.items["ReceiptNumber"].itemconfig.values = data_S2067.ReceiptNumber;
            screenconfig.items["TaxNumber"].itemconfig.values = data_S2067.TaxNumber;

        }

        public override string GetMessage()
        {
            Enter();
            string message = "";
            //UInt32 status = EhllapiWrapper.Wait();
            //System.Threading.Thread.Sleep(500);
            Waiting();
            EhllapiWrapper.ReadScreen(MessagePos.cursor, 70, out message);
            message = message.Trim();

            if (message.Length > 10)
                return message;
            else
                return "";
        }

        public override string GetMessage2()
        {
           
            string message = "";          
            Waiting();
            EhllapiWrapper.ReadScreen(MessagePos.cursor, 70, out message);
            message = message.Trim();
            if (message.Length > 10)
                return message;
            else
                return "";
        }

        public override void Execute()
        {
            base.Execute();
        }

    }
}
