﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using KN.BusinessLogic;
using KN.Systems;
namespace KN.Screens
{
    public class S2465 :Screen
    {
        public override Point NamePos
        {
            get
            {
                return new Point(3, 71);// 2 * 80 + 71;
            }
        }

        public override Point MessagePos
        {
            get
            {
                return new Point(22, 4);
            }
        } 
        //public Item ClientID { get; set; }
        //public Item SrvBranch { get; set; }
        //public Item Inception { get; set; }
        //public Item SurName { get; set; }
        //public Item GivName { get; set; }
        //public Item RefName { get; set; }
        //public Item Location { get; set; }
        //public Item Salutation { get; set; }
        //public Item Sex { get; set; }
        //public Item Married { get; set; }
        //public Item Street { get; set; }
        //public Item Ward { get; set; }
        //public Item District { get; set; }
        //public Item City { get; set; }
        //public Item Country { get; set; }
        //public Item BusOrRes { get; set; }
        //public Item ID { get; set; }
        //public Item MobliePhone { get; set; }
        //public Item WorkPhone { get; set; }
        //public Item HomePhone { get; set; }
        //public Item NameFormat { get; set; }
        //public Item Nationality { get; set; }
        //public Item CompDoctor { get; set; }
        //public Item Employment { get; set; }
        //public Item Occupation { get; set; }
        //public Item Language { get; set; }
        //public Item Category { get; set; }
        //public Item BirthDay { get; set; }
        //public Item BirthPlace { get; set; }
        //public Item SoE { get; set; }
        //public Item DocumentNo { get; set; }
        //public Item DeathDate { get; set; }
        //public Item VIP { get; set; }
        //public Item Mailing { get; set; }
        //public Item DirectMail { get; set; }
        //public Item CustomerInfoUpdate { get; set; }
        //public Item SalaryHist { get; set; }
        //public Item SSRetention { get; set; }
        //public Item Additional { get; set; }
        //public Item FUp { get; set; }
        //public Item CheckDuplicate { get; set; }

        public S2465()
            : base("S2465", "Client Maintain - Personal")
        {
           
        }

        public S2465(Client client)
            : base("S2465", "Client Maintain - Personal")
        {
            //ItemColection item = new ItemColection();
            //LoadConfig("S2465");
            SetValues(client);
        }

        public S2465(DATA_S2610_ACTION_C client)
            : base("S2465", "Client Maintain - Personal")
        {
            //ItemColection item = new ItemColection();
            //LoadConfig("S2465");
            SetValues(client);
        }

        public S2465(DATA_ACTION_D client)
            : base("S2465", "Client Maintain - Personal")
        {
            //ItemColection item = new ItemColection();
            //LoadConfig("S2465");
            SetValues(client);
        }

        public override void SetValues(object obj)
        {
            var client = (Client)obj;
            //items["ClientID"].values = client.ClientID;
            screenconfig.items["SrvBranch"].itemconfig.values = client.SrvBranch;
            screenconfig.items["Inception"].itemconfig.values = client.Inception;
            screenconfig.items["SurName"].itemconfig.values = client.SurName;
            screenconfig.items["GivName"].itemconfig.values = client.GivName;
            screenconfig.items["RefName"].itemconfig.values = client.RefName;
            screenconfig.items["Location"].itemconfig.values = client.Location;
            screenconfig.items["Salutation"].itemconfig.values = client.Salutation;
            screenconfig.items["Sex"].itemconfig.values = client.Sex;
            screenconfig.items["Married"].itemconfig.values = client.Married;
            screenconfig.items["Street"].itemconfig.values = client.Street;
            screenconfig.items["Ward"].itemconfig.values = client.Ward;
            screenconfig.items["District"].itemconfig.values = client.District;
            screenconfig.items["City"].itemconfig.values = client.City;
            screenconfig.items["Country"].itemconfig.values = client.Country;
            screenconfig.items["BusOrRes"].itemconfig.values = client.BusOrRes;
            screenconfig.items["ID"].itemconfig.values = client.ID;
            screenconfig.items["MobliePhone"].itemconfig.values = client.MobliePhone;
            screenconfig.items["WorkPhone"].itemconfig.values = client.WorkPhone;
            screenconfig.items["HomePhone"].itemconfig.values = client.HomePhone;
            screenconfig.items["NameFormat"].itemconfig.values = client.NameFormat;
            screenconfig.items["Nationality"].itemconfig.values = client.Nationality;
            screenconfig.items["CompDoctor"].itemconfig.values = client.CompDoctor;
            screenconfig.items["Employment"].itemconfig.values = client.Employment;
            screenconfig.items["Occupation"].itemconfig.values = client.Occupation;
            screenconfig.items["Language"].itemconfig.values = client.Language;
            screenconfig.items["Category"].itemconfig.values = client.Category;
            screenconfig.items["BirthDay"].itemconfig.values = client.BirthDay;
            screenconfig.items["BirthPlace"].itemconfig.values = client.BirthPlace;
            screenconfig.items["SoE"].itemconfig.values = client.SoE;
            screenconfig.items["DocumentNo"].itemconfig.values = client.DocumentNo;
            screenconfig.items["DeathDate"].itemconfig.values = client.DeathDate;
            screenconfig.items["VIP"].itemconfig.values = client.VIP;
            screenconfig.items["Mailing"].itemconfig.values = client.Mailing;
            screenconfig.items["DirectMail"].itemconfig.values = client.DirectMail;
            screenconfig.items["CustomerInfoUpdate"].itemconfig.values = client.CustomerInfoUpdate;
            screenconfig.items["SalaryHist"].itemconfig.values = client.SalaryHist;
            screenconfig.items["SSRetention"].itemconfig.values = client.SSRetention;
            screenconfig.items["Additional"].itemconfig.values = client.Additional;
            screenconfig.items["FUp"].itemconfig.values = client.FUp;
            screenconfig.items["CheckDuplicate"].itemconfig.values = client.CheckDuplicate;

        }

        public void SetValues(DATA_S2610_ACTION_C client2)
        {
            //screenconfig.items["Action"].itemconfig.values = client2.Action;
            //screenconfig.items["Amount"].itemconfig.values = client2.Amount;
            //screenconfig.items["Bank_Code"].itemconfig.values = client2.Bank_Code;
            //screenconfig.items["Billing_Frequency"].itemconfig.values = client2.Billing_Frequency;
            screenconfig.items["BirthDay"].itemconfig.values = client2.BirthDate;
            //screenconfig.items["BSB_Code"].itemconfig.values = client2.BSB_Code;
            //screenconfig.items["Cheque_Date"].itemconfig.values = client2.Cheque_Date;
            //screenconfig.items["Cheque_No"].itemconfig.values = client2.Cheque_No;
            screenconfig.items["Client"].itemconfig.values = client2.Client_Code;
            //screenconfig.items["TaxIDNumber"].itemconfig.values = client2.CLIENT_TAX_CODE;
            //screenconfig.items["Collected_Agent_Collector"].itemconfig.values = client2.Collected_Agent_Collector;
            //screenconfig.items["Contract_Number"].itemconfig.values = client2.Contract_Number;
            //screenconfig.items["Contract_Number1"].itemconfig.values = client2.Contract_Number1;
            //screenconfig.items["Contract_Number2"].itemconfig.values = client2.Contract_Number2;
            //screenconfig.items["Contract_Number3"].itemconfig.values = client2.Contract_Number3;
            //screenconfig.items["Contract_Type"].itemconfig.values = client2.Contract_Type;
            //screenconfig.items["Desc1"].itemconfig.values = client2.Desc1;
            //screenconfig.items["Desc2"].itemconfig.values = client2.Desc2;
            //screenconfig.items["Desc3"].itemconfig.values = client2.Desc3;
            //screenconfig.items["GL_Amount"].itemconfig.values = client2.GL_Amount;
            screenconfig.items["GivName"].itemconfig.values = client2.Gurname;
            screenconfig.items["ID"].itemconfig.values = client2.ID;
            //screenconfig.items["InsPrem"].itemconfig.values = client2.InsPrem;
            //screenconfig.items["InterID"].itemconfig.values = client2.InterID;
            screenconfig.items["Location"].itemconfig.values = client2.Location;
            //screenconfig.items["Main_Agt"].itemconfig.values = client2.Main_Agt;
            screenconfig.items["Married"].itemconfig.values = client2.Married;
            screenconfig.items["Occupation"].itemconfig.values = client2.Occupation;
            //screenconfig.items["OR_Number"].itemconfig.values = client2.OR_Number;
            //screenconfig.items["Payment_Type"].itemconfig.values = client2.Payment_Type;
            screenconfig.items["PhoneC"].itemconfig.values = client2.PhoneC;
            screenconfig.items["PhoneH"].itemconfig.values = client2.PhoneH;
            screenconfig.items["PhoneM"].itemconfig.values = client2.PhoneM;
            //screenconfig.items["PropNo"].itemconfig.values = client2.Prop_No;
            //screenconfig.items["PTD_ADV"].itemconfig.values = client2.PTD_ADV;
            //screenconfig.items["Receipt_Date"].itemconfig.values = client2.Receipt_Date;
            //screenconfig.items["Received_From"].itemconfig.values = client2.Received_From;
            screenconfig.items["RefName"].itemconfig.values = client2.RName;
            screenconfig.items["Salutation"].itemconfig.values = client2.Salutation;
            screenconfig.items["Sex"].itemconfig.values = client2.Sex;
            screenconfig.items["SoE"].itemconfig.values = client2.SoE;
            screenconfig.items["Street"].itemconfig.values = client2.Street;
            //screenconfig.items["SubAmount1"].itemconfig.values = client2.SubAmount1;
            //screenconfig.items["SubAmount2"].itemconfig.values = client2.SubAmount2;
            //screenconfig.items["SubAmount3"].itemconfig.values = client2.SubAmount3;
            //screenconfig.items["SubCode1"].itemconfig.values = client2.SubCode1;
            //screenconfig.items["SubCode2"].itemconfig.values = client2.SubCode2;
            //screenconfig.items["SubCode3"].itemconfig.values = client2.SubCode3;
            //screenconfig.items["SubType1"].itemconfig.values = client2.SubType1;
            //screenconfig.items["SubType2"].itemconfig.values = client2.SubType2;
            //screenconfig.items["SubType3"].itemconfig.values = client2.SubType3;
            screenconfig.items["SurName"].itemconfig.values = client2.Surname;
            //screenconfig.items["Tax_Invoice"].itemconfig.values = client2.Tax_Invoice;
            //screenconfig.items["TR_NO"].itemconfig.values = client2.TR_NO;
            screenconfig.items["Additional"].itemconfig.values = "X";
            screenconfig.items["CheckDuplicate"].itemconfig.values = " ";
            screenconfig.items["Category"].itemconfig.values = client2.Category;

            screenconfig.items["Country"].itemconfig.values = client2.Country;
            screenconfig.items["UStax"].itemconfig.values = client2.UStax;
            screenconfig.items["BirthCountry"].itemconfig.values = client2.BirthCountry;
            screenconfig.items["MobileCode"].itemconfig.values = client2.MobileCode;
            screenconfig.items["CompCode"].itemconfig.values = client2.CompCode;
            screenconfig.items["HomeCode"].itemconfig.values = client2.HomeCode;
            screenconfig.items["Nationality"].itemconfig.values = client2.Nationality;
            screenconfig.items["FatcaInf"].itemconfig.values = " ";
        }

        public void SetValues(DATA_ACTION_D client2)
        {
            screenconfig.items["BirthDay"].itemconfig.values = client2.BirthDate;
            screenconfig.items["GivName"].itemconfig.values = client2.Gurname;
            screenconfig.items["ID"].itemconfig.values = client2.ID;
            screenconfig.items["Location"].itemconfig.values = client2.Location;
            screenconfig.items["Married"].itemconfig.values = client2.Married;
            screenconfig.items["Occupation"].itemconfig.values = client2.Occupation;
            screenconfig.items["PhoneC"].itemconfig.values = client2.PhoneC;
            screenconfig.items["PhoneH"].itemconfig.values = client2.PhoneH;
            screenconfig.items["PhoneM"].itemconfig.values = client2.PhoneM;
            screenconfig.items["RefName"].itemconfig.values = client2.RName;
            screenconfig.items["Salutation"].itemconfig.values = client2.Salutation;
            screenconfig.items["Sex"].itemconfig.values = client2.Sex;
            screenconfig.items["SoE"].itemconfig.values = client2.SoE;
            screenconfig.items["Street"].itemconfig.values = client2.Street;            
            screenconfig.items["SurName"].itemconfig.values = client2.Surname;
            screenconfig.items["Additional"].itemconfig.values = "X";
            screenconfig.items["CheckDuplicate"].itemconfig.values = " ";
            screenconfig.items["Category"].itemconfig.values = client2.Category;

            screenconfig.items["Country"].itemconfig.values = client2.Country;
            screenconfig.items["UStax"].itemconfig.values = client2.UStax;
            screenconfig.items["BirthCountry"].itemconfig.values = client2.BirthCountry;
            screenconfig.items["MobileCode"].itemconfig.values = client2.MobileCode;
            screenconfig.items["CompCode"].itemconfig.values = client2.CompCode;
            screenconfig.items["HomeCode"].itemconfig.values = client2.HomeCode;
            screenconfig.items["Nationality"].itemconfig.values = client2.Nationality;
            screenconfig.items["FatcaInf"].itemconfig.values = " ";
        }
        public override void Execute()
        {
            Waiting();

            foreach (var item in screenconfig.items)
            {
                if (item.Value.itemconfig.values == null && item.Value.itemconfig.action.id != 2)
                {
                    continue;
                }
                EhllapiWrapper.SetCursorPos(item.Value.itemconfig.point.cursor);
                //EhllapiWrapper.SendStr("@F");
                //EhllapiWrapper.SendStr(item.Value.itemconfig.values.ToString());               

                //System.Threading.Thread.Sleep(500);
                switch (item.Value.itemconfig.action.id)
                {
                    case -1:
                        continue;
                    case 0:
                        break;
                    case 1:
                        //EhllapiWrapper.SetCursorPos(item.Value.itemconfig.point.cursor);
                        //EhllapiWrapper.SendStr("@F");
                        //EhllapiWrapper.SendStr(item.Value.itemconfig.values.ToString());
                        EhllapiWrapper.SendStr(item.Value.itemconfig.action.value);
                        continue;
                    case 2:
                        EhllapiWrapper.SendStr(item.Value.itemconfig.action.value);
                        Type mytype = null;

                        if ((mytype = Type.GetType(item.Value.itemconfig.typename, false, true)) == null)
                        {
                            System.Reflection.Assembly assembly = System.Reflection.Assembly.LoadFrom(AppSetting.FOLDER_ROOT + @"\KN.Screen.dll");
                            foreach (System.Type type in assembly.GetTypes())
                                if (type.IsClass && type.FullName.CompareTo(item.Value.itemconfig.typename) == 0)
                                    mytype = type;
                        }

                        KN.Systems.Screen subscreen = (KN.Systems.Screen)Activator.CreateInstance(mytype, new string[] { "X" });
                        subscreen.Waiting();
                        subscreen.Execute();
                        Next();
                        break;
                    case 4:
                        EhllapiWrapper.SendStr("@F");
                        EhllapiWrapper.SendStr(item.Value.itemconfig.values.ToString());
                        EhllapiWrapper.SendStr(item.Value.itemconfig.action.value);
                        continue; 
                }
                Waiting();
                EhllapiWrapper.SetCursorPos(item.Value.itemconfig.point.cursor);
                EhllapiWrapper.SendStr("@F");
                EhllapiWrapper.SendStr(item.Value.itemconfig.values.ToString());

                //delay
                //System.Threading.Thread.Sleep(500);
            }
        }
       
    }
}
