﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KN.Systems;

namespace KN.Screens
{
    public class SV210 : Screen
    {
        public override Point NamePos
        {
            get
            {
                return new Point(5, 74);
            }
        }
        public override Point MessagePos
        {
            get
            {
                return new Point(22, 4);
            }
        }
        public string Action
        {
            get;
            set;
        }

        public SV210()
            : base("SV210", "Check Duplicate")
        {

        }

        public SV210(object obj)
            : base("SV210", "Check Duplicate")
        {
            SetValues(obj);
        }

        
        public override void Execute()
        {
            base.Execute();
        }
    }
}
