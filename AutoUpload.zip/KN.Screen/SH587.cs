﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using KN.BusinessLogic;
using KN.Systems;
namespace KN.Screens
{
    public class SH587 :Screen
    {
        public SH587()
            : base("SH587", "Remark")
        {
           
        }

        public SH587(string obj)
            : base("SH587", "Remark")
        {
            SetValues(obj);
        }

        public override void SetValues(object obj)
        {
            var Remarks = (string)obj;
            screenconfig.items["Action"].itemconfig.values = "A";
            screenconfig.items["Remarks"].itemconfig.values = Remarks;            
        }       

        public override void Execute()
        {
            base.Execute();
        }
       
    }
}
