﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KN.Systems;
using KN.BusinessLogic;

namespace KN.Screens
{
    public class SV51B : Screen
    {
        public override Point NamePos
        {
            get
            {
                return new Point(1, 72);// 2 * 80 + 71;
            }
        }
        public override Point MessagePos
        {
            get
            {
                return new Point(24, 2);// 23 * 80 + 2;
            }
        }
        public string Action
        {
            get;
            set;
        }

        public SV51B()
            : base("SV51B", "Loan repayment Receipt")
        {

        }

        public SV51B(object obj)
            : base("SV51B", "Loan repayment Receipt")
        {
            SetValues(obj);
        }

        public override void SetValues(object obj)
        {
            var data_SV51B = (DATA_SV51B)obj;
            screenconfig.items["Amount"].itemconfig.values = data_SV51B.Amount;
            screenconfig.items["BSB_Code"].itemconfig.values = data_SV51B.BSB_Code;
            screenconfig.items["Cheque_Date"].itemconfig.values = data_SV51B.Cheque_Date;
            screenconfig.items["Cheque_No"].itemconfig.values = data_SV51B.Cheque_No;
            screenconfig.items["Collected_Agent_Collector"].itemconfig.values = data_SV51B.Collected_Agent_Collector;
            screenconfig.items["Desc1"].itemconfig.values = data_SV51B.Desc1;
            screenconfig.items["Desc2"].itemconfig.values = data_SV51B.Desc2;
            screenconfig.items["Desc3"].itemconfig.values = data_SV51B.Desc3;
            screenconfig.items["InterID"].itemconfig.values = data_SV51B.InterID;
            screenconfig.items["OR_Date"].itemconfig.values = data_SV51B.Receipt_Date;
            screenconfig.items["OR1_Number"].itemconfig.values = data_SV51B.OR1_Number;
            screenconfig.items["OR2_Number"].itemconfig.values = data_SV51B.OR2_Number;
            screenconfig.items["Payment_Type"].itemconfig.values = data_SV51B.Payment_Type;
            screenconfig.items["Received_From"].itemconfig.values = data_SV51B.Received_From;
            // LHT added
            screenconfig.items["SubCode2"].itemconfig.values = data_SV51B.SubCode2;
            screenconfig.items["SubCode3"].itemconfig.values = data_SV51B.SubCode3;
            screenconfig.items["SubType2"].itemconfig.values = data_SV51B.SubType2;
            screenconfig.items["SubType3"].itemconfig.values = data_SV51B.SubType3;
            // ---------

            screenconfig.items["SubAmount2"].itemconfig.values = data_SV51B.SubAmount2;
            screenconfig.items["SubAmount3"].itemconfig.values = data_SV51B.SubAmount3;
            screenconfig.items["TR_NO"].itemconfig.values = data_SV51B.TR_NO;

            //screenconfig.items["Tax_Invoice"].itemconfig.values = data_SV51B.Tax_Invoice;
            //screenconfig.items["SubCode1"].itemconfig.values = data_SV51B.SubCode1;
            //screenconfig.items["SubType1"].itemconfig.values = data_SV51B.SubType1;

            // LHT closed
            //screenconfig.items["SacsCode1"].itemconfig.values = data_SV51B.SacsCode1;
            //screenconfig.items["SacsType1"].itemconfig.values = data_SV51B.SacsType1;
            //screenconfig.items["SacsCode2"].itemconfig.values = data_SV51B.SacsCode2;
            //screenconfig.items["SacsType2"].itemconfig.values = data_SV51B.SacsType2;
            //screenconfig.items["SacsCode3"].itemconfig.values = data_SV51B.SacsCode3;
            //screenconfig.items["SacsType3"].itemconfig.values = data_SV51B.SacsType3;
            // ----------
        }
        public override void Execute()
        {
            base.Execute();
        }

    }
}
