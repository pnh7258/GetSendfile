﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using KN.BusinessLogic;
using KN.Systems;
namespace KN.Screens
{
    public class SR208 :Screen
    {
        public override Point NamePos
        {
            get
            {
                return new Point(8, 70);// 72;
            }
        }

        public override Point MessagePos
        {
            get
            {
                return new Point(24, 2);// 23 * 80 + 2;
            }
        }


        public SR208(Client client)
            : base("SR208", "Client Additional Info")
        {
            SetValues(client);
        }

        public SR208(DATA_S2610_ACTION_C client2)
            : base("SR208", "Client Additional Info")
        {
            SetValues(client2);
        }

        public SR208(DATA_ACTION_D client2)
            : base("SR208", "Client Additional Info")
        {
            SetValues(client2);
        }

        public override void SetValues(object obj)
        {
            Client client = (Client)obj;
            this.screenconfig.items["InternetAddress"].itemconfig.values = client.InternetAddress.Replace("@","@@");
            this.screenconfig.items["TaxIDNumber"].itemconfig.values = client.TaxIDNumber;
        }

        public void SetValues(DATA_S2610_ACTION_C client2)
        {
            this.screenconfig.items["InternetAddress"].itemconfig.values = client2.InternetAddress.Replace("@", "@@");
            this.screenconfig.items["TaxIDNumber"].itemconfig.values = client2.CLIENT_TAX_CODE;
        }

        public void SetValues(DATA_ACTION_D client2)
        {
            this.screenconfig.items["InternetAddress"].itemconfig.values = client2.InternetAddress.Replace("@", "@@");
            this.screenconfig.items["TaxIDNumber"].itemconfig.values = client2.CLIENT_TAX_CODE;
        }

        public override void Execute()
        {
            base.Execute();
        }
       
    }
}
