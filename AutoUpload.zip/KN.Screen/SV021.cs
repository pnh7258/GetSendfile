﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KN.Systems;
using KN.BusinessLogic;

namespace KN.Screens
{
    public class SV021:Screen
    {
        public SV021(object obj)
            : base("SV021", "")
        {
            SetValues(obj);
        }

        public override void SetValues(object obj)
        {
            DATA_SV021 data_sv021 = (DATA_SV021)obj;

            //screenconfig.items["PayerID"].itemconfig.values = data_sv021.PayerID;
            //screenconfig.items["PayerName"].itemconfig.values = data_sv021.PayerName;
            //screenconfig.items["PayerDOB"].itemconfig.values = data_sv021.PayerDOB;
            //screenconfig.items["Country"].itemconfig.values = data_sv021.Country;
            //screenconfig.items["Nationality"].itemconfig.values = data_sv021.Nationality;
            //screenconfig.items["Payer_Relationship"].itemconfig.values = data_sv021.Payer_Relationship; 
        }

        public override Point  NamePos
        {
	        get 
	        {
                return new Point(1, 72);
	        }
        }       
    }
}
