﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using KN.DataAcess;

namespace KN.BusinessLogic
{
    public class ErrorLogReceiptManager
    {
        private static ErrorLogReceipt GetObjectFromReader(IDataReader dataReader)
        {
            try
            {
                ErrorLogReceipt obj = new ErrorLogReceipt();
                obj.Tax_Invoice = KNDataHelper.GetString(dataReader, "Tax_Invoice");
                obj.Contract_Number = KNDataHelper.GetString(dataReader, "Contract_Number");                
                obj.Receipt_No = KNDataHelper.GetString(dataReader, "Receipt_No");
                obj.BranchCode = KNDataHelper.GetString(dataReader, "BranchCode");
                obj.Description = KNDataHelper.GetString(dataReader, "Description");
                return obj;
            }
            catch
            {
                throw;
            }
        }

        public static ErrorLogReceiptCollection AllErrorLogLoad()
        {
            var result = new ErrorLogReceiptCollection();
            PruDBHelp db = new PruDBHelp();
            try
            {
                using (IDataReader dataReader = db.ExecuteReader("select * from LogReceipt", CommandType.Text))
                {
                    while (dataReader.Read())
                    {
                        result.Add(GetObjectFromReader(dataReader));
                    }
                }
                return result;
            }
            catch
            {
                throw;
            }
        }

        public static DataTable AllErrorLogLoad2()
        {
            PruDBHelp db = new PruDBHelp();
            DataTable dt = db.ExecuteDataTable(@"select * from LogReceipt", CommandType.Text);

            return dt;            
        }

        public static void ErrorLogInsert(string Tax_Invoice, string Contract_Number, string Receipt_No, string BranchCode, string Description)
        {
            var result = new ErrorLogReceiptCollection();
            PruDBHelp db = new PruDBHelp();
            //if (CheckExist(Tax_Invoice, Contract_Number) == false)
            //{
                db.AddParameter("@Tax_Invoice", Tax_Invoice);
                db.AddParameter("@Contract_Number", Contract_Number);
                db.AddParameter("@Receipt_No", Receipt_No);
                db.AddParameter("@BranchCode", BranchCode);
                db.AddParameter("@Description", Description);
                db.ExecuteNonQuery("insert into LogReceipt(Tax_Invoice, Contract_Number, Receipt_No, BranchCode, Description) values (@Tax_Invoice, @Contract_Number, @Receipt_No, @BranchCode, @Description)", CommandType.Text);
            //}
            //else
            //{
            //    db.AddParameter("@Description", Description);
            //    db.AddParameter("@Tax_Invoice", Tax_Invoice);
            //    db.AddParameter("@Contract_Number", Contract_Number);
            //    db.ExecuteNonQuery("UPDATE LogReceipt SET Description = Description + '|' +  @Description WHERE Tax_Invoice=@Tax_Invoice and Contract_Number=@Contract_Number", CommandType.Text);
            //}
        }

        public static bool CheckExist(string Tax_Invoice, string Contract_Number)
        {
            bool result = false;
            PruDBHelp db = new PruDBHelp();
            db.AddParameter("@Tax_Invoice", Tax_Invoice);
            db.AddParameter("@Contract_Number", Contract_Number);            
           
            DataTable dt = db.ExecuteDataTable(@"SELECT count(*)                                            
                                                 FROM LogReceipt where Tax_Invoice=@Tax_Invoice and Contract_Number=@Contract_Number", CommandType.Text);

            int count = Common.CommonHelper.ToInt(dt.Rows[0][0].ToString());
            if (count > 0) result = true;
            return result;
        }

        public static void ErrorLogClear()
        {
            PruDBHelp db = new PruDBHelp();

            db.ExecuteNonQuery("Delete from LogReceipt", CommandType.Text);
        }
    }
}
