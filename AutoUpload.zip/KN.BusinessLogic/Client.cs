﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KN.BusinessLogic
{
    public class Client
    {
        public string ProposalNo { get; set; }
        public string ID { get; set; }
        public string ClientID { get; set; }
        public string SrvBranch { get; set; }
        public string Inception { get; set; }
        public string SurName { get; set; }
        public string GivName { get; set; }
        public string RefName { get; set; }
        public string Location { get; set; }
        public string Salutation { get; set; }
        public string Sex { get; set; }
        public string Married { get; set; }
        public string Street { get; set; }
        public string Ward { get; set; }
        public string District { get; set; }
        public string City { get; set; }
        public string Country { get; set; }
        public string BusOrRes { get; set; }
        
        public string MobliePhone { get; set; }
        public string WorkPhone { get; set; }
        public string HomePhone { get; set; }
        public string NameFormat { get; set; }
        public string Nationality { get; set; }
        public string CompDoctor { get; set; }
        public string Employment { get; set; }
        public string Occupation { get; set; }
        public string Language { get; set; }
        public string Category { get; set; }
        public string BirthDay { get; set; }
        public string BirthPlace { get; set; }
        public string SoE { get; set; }
        public string DocumentNo { get; set; }
        public string DeathDate { get; set; }
        public string VIP { get; set; }
        public string Mailing { get; set; } 
        public string DirectMail { get; set; }
        public string CustomerInfoUpdate { get; set; }
        public string SalaryHist { get; set; }
        public string SSRetention { get; set; }
        public string Additional { get; set; }
        public string FUp { get; set; }
        public string CheckDuplicate { get; set; }
        public string Role { get; set; }
        public string RelationShip { get; set; }
       
        public string InternetAddress { get; set; }
        public string TaxIDNumber { get; set; } 

    }
}
