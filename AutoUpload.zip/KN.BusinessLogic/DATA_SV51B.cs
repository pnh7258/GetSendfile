﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace KN.BusinessLogic
{
    public class DATA_SV51B
    {
        public string Action { get; set; }
        public string Amount { get; set; }
        public string Bank_Code { get; set; }
        public string BSB_Code { get; set; }
        public string Cheque_Date { get; set; }
        public string Cheque_No { get; set; }
        public string Collected_Agent_Collector { get; set; }
        public string Contract_Number { get; set; }
        public string Contract_Number1 { get; set; }
        public string Contract_Number2 { get; set; }
        public string Contract_Number3 { get; set; }
        public string Desc1 { get; set; }
        public string Desc2 { get; set; }
        public string Desc3 { get; set; }
        public string GL_Amount { get; set; }
        public string InsPrem { get; set; }
        public string InterID { get; set; }
        public string OR1_Number { get; set; }
        public string OR2_Number { get; set; }
        public string Payment_Type { get; set; }
        public string PTD_ADV { get; set; }
        public string Receipt_Date { get; set; }
        public string Received_From { get; set; }
        public string SubAmount1 { get; set; }
        public string SubAmount2 { get; set; }
        public string SubAmount3 { get; set; }
        public string SubCode1 { get; set; }
        public string SubCode2 { get; set; }
        public string SubCode3 { get; set; }
        public string SubType1 { get; set; }
        public string SubType2 { get; set; }
        public string SubType3 { get; set; }
        public string Tax_Invoice { get; set; }
        public string TR_NO { get; set; }
        public string SacsCode1 { get; set; }
        public string SacsType1 { get; set; }
        public string SacsCode2 { get; set; }
        public string SacsType2 { get; set; }
        public string SacsCode3 { get; set; }
        public string SacsType3 { get; set; }
        public string BranchCode { get; set; }
        public string AlertMsg { get; set; } 
        
        public DATA_SV51B(DataRow row)
        {
            Action = row["Action"].ToString();
            Amount = row["Amount"].ToString().PadLeft(23);
            Bank_Code = row["Bank_Code"].ToString();
            BSB_Code = row["BSB_Code"].ToString();
            Cheque_Date = row["Cheque_Date"].ToString();
            Cheque_No = row["Cheque_No"].ToString();
            Collected_Agent_Collector = row["Collected_Agent_Collector"].ToString();
            Contract_Number = row["Contract_Number"].ToString();
            Contract_Number1 = row["Contract_Number1"].ToString().PadRight(15);
            Contract_Number2 = row["Contract_Number2"].ToString().PadRight(15);
            Contract_Number3 = row["Contract_Number3"].ToString().PadRight(15);
            Desc1 = row["Desc1"].ToString().PadRight(30);
            Desc2 = row["Desc2"].ToString().PadRight(30);
            Desc3 = row["Desc3"].ToString().PadRight(30);
            GL_Amount = row["GL_Amount"].ToString().PadLeft(23);
            InsPrem = row["InsPrem"].ToString();
            InterID = row["InterID"].ToString();
            OR1_Number = row["OR1_Number"].ToString();
            OR2_Number = row["OR2_Number"].ToString();
            Payment_Type = row["Payment_Type"].ToString();
            PTD_ADV = row["PTD_ADV"].ToString();
            //Receipt_Date = (OR1_Number.Contains("GA") || OR1_Number.Contains("CS")) ? null : row["Receipt_Date"].ToString(); //null: get value on screen
            Receipt_Date = row["Receipt_Date"].ToString(); //null: get value on screen
            Received_From = row["Received_From"].ToString();
            SubAmount1 = row["SubAmount1"].ToString().PadLeft(23);
            SubAmount2 = row["SubAmount2"].ToString().PadLeft(23);
            SubAmount3 = row["SubAmount3"].ToString().PadLeft(23);
            SubCode1 = row["SubCode1"].ToString();
            SubCode2 = row["SubCode2"].ToString();
            SubCode3 = row["SubCode3"].ToString();
            SubType1 = row["SubType1"].ToString();
            SubType2 = row["SubType2"].ToString();
            SubType3 = row["SubType3"].ToString();
            Tax_Invoice = row["Tax_Invoice"].ToString();
            TR_NO = row["TR_NO"].ToString();
            BranchCode = row["BranchCode"].ToString();
            AlertMsg = row["AlertMsg"].ToString();
        }
    }
}
