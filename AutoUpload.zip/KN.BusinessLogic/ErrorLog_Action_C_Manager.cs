﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using KN.DataAcess;
namespace KN.BusinessLogic
{
    public static class ErrorLog_Action_C_Manager
    {
        private static ErrorLog_Action_C GetObjectFromReader(IDataReader dataReader)
        {
            try
            {
                ErrorLog_Action_C obj = new ErrorLog_Action_C();
                obj.ClientID = KNDataHelper.GetString(dataReader, "ClientID");
                obj.ReceiptID = KNDataHelper.GetString(dataReader, "ReceiptID");
                obj.ProposalNo = KNDataHelper.GetString(dataReader, "ProposalNo");
                obj.TR_No = KNDataHelper.GetString(dataReader, "TR_No");
                obj.ClientNo = KNDataHelper.GetString(dataReader, "ClientNo");
                obj.Surname = KNDataHelper.GetString(dataReader, "Surname");
                obj.Gurname = KNDataHelper.GetString(dataReader, "Gurname");
                obj.ID = KNDataHelper.GetString(dataReader, "ID");
                obj.BirthDate = KNDataHelper.GetString(dataReader, "BirthDate");
                obj.ReceiptNo = KNDataHelper.GetString(dataReader, "ReceiptNo");
                obj.Description = KNDataHelper.GetString(dataReader, "Description");
                obj.BranchCode = KNDataHelper.GetString(dataReader, "BranchCode");
                ////country | ustax | birthcountry | mobilecode | compcode | homecode
                obj.Country = KNDataHelper.GetString(dataReader, "Country");
                obj.UStax = KNDataHelper.GetString(dataReader, "UStax");
                obj.BirthCountry = KNDataHelper.GetString(dataReader, "BirthCountry");
                obj.MobileCode = KNDataHelper.GetString(dataReader, "MobileCode");
                obj.CompCode = KNDataHelper.GetString(dataReader, "CompCode");
                obj.HomeCode = KNDataHelper.GetString(dataReader, "HomeCode");
                obj.Nationality = KNDataHelper.GetString(dataReader, "Nationality");
                return obj;
            }
            catch
            {
                throw;
            }
        }

        public static ErrorLog_Action_C_Collection AllErrorLogLoad()
        {
            var result = new ErrorLog_Action_C_Collection();
            PruDBHelp db = new PruDBHelp();
            try
            {
                using (IDataReader dataReader = db.ExecuteReader("select ClientID, ReceiptID, ProposalNo, TR_No, ClientNo, Surname, Gurname, ID, BirthDate, ReceiptNo, BranchCode, Description, Country, UStax, BirthCountry, MobileCode, CompCode, HomeCode, Nationality from Logs_Action_C", CommandType.Text))
                {
                    while (dataReader.Read())
                    {
                        result.Add(GetObjectFromReader(dataReader));
                    }
                }
                return result;
            }
            catch
            {                
                throw;
            }
        }

        public static DataTable AllErrorLogLoad2()
        {
            PruDBHelp db = new PruDBHelp();
            DataTable dt = db.ExecuteDataTable(@"select ProposalNo, TR_No, ClientNo, Surname, Gurname, ID, BirthDate, ReceiptNo, BranchCode, Country, UStax, BirthCountry, MobileCode, CompCode, HomeCode, Nationality, Description from Logs_Action_C", CommandType.Text);

            return dt;
        }
        
        public static void ErrorLogInsert(DATA_S2610_ACTION_C client, string ReceiptNo, string Description)
        {           
            PruDBHelp db = new PruDBHelp();
            if (CheckExist(client) == false)
            {
                db.AddParameter("@ClientID", client.ClientID);
                db.AddParameter("@ReceiptID", client.ReceiptID);
                db.AddParameter("@ProposalNo", client.Prop_No);
                db.AddParameter("@TR_No", client.TR_NO);
                db.AddParameter("@ClientNo", client.Client_Code);
                db.AddParameter("@Surname", client.Surname);
                db.AddParameter("@Gurname", client.Gurname);
                db.AddParameter("@ID", client.ID);
                db.AddParameter("@BirthDate", client.BirthDate);
                db.AddParameter("@ReceiptNo", ReceiptNo);
                db.AddParameter("@Description", Description);
                db.AddParameter("@BranchCode", client.BranchCode);

                db.AddParameter("@Country", client.Country);
                db.AddParameter("@UStax", client.UStax);
                db.AddParameter("@BirthCountry", client.BirthCountry);
                db.AddParameter("@MobileCode", client.MobileCode);
                db.AddParameter("@CompCode", client.CompCode);
                db.AddParameter("@HomeCode", client.HomeCode);
                db.AddParameter("@Nationality", client.Nationality);

                db.ExecuteNonQuery("insert into Logs_Action_C(ClientID, ReceiptID, ProposalNo, TR_No, ClientNo, Surname, Gurname, ID, BirthDate, ReceiptNo, Description, BranchCode, Country, UStax, BirthCountry, MobileCode, CompCode, HomeCode, Nationality) values (@ClientID, @ReceiptID, @ProposalNo, @TR_No, @ClientNo, @Surname, @Gurname, @ID, @BirthDate, @ReceiptNo, @Description,@BranchCode, @Country, @UStax, @BirthCountry, @MobileCode, @CompCode, @HomeCode, @Nationality)", CommandType.Text);        
            }
            else
            {
                db.AddParameter("@ReceiptNo", ReceiptNo);
                db.AddParameter("@Description", Description);
                db.AddParameter("@ClientID", client.ClientID);
                db.AddParameter("@ReceiptID", client.ReceiptID);
                db.ExecuteNonQuery("UPDATE Logs_Action_C SET ReceiptNo=@ReceiptNo, Description = Description + '|' +  @Description WHERE ClientID=@ClientID and ReceiptID=@ReceiptID", CommandType.Text);
            }
        }

        public static bool CheckExist(DATA_S2610_ACTION_C value)
        {
            bool result = false;
            PruDBHelp db = new PruDBHelp();
            db.AddParameter("@ClientID", value.ClientID);
            db.AddParameter("@ReceiptID", value.ReceiptID);
            DataTable dt = db.ExecuteDataTable(@"SELECT count(*)                                            
                                                 FROM Logs_Action_C where ClientID=@ClientID and ReceiptID=@ReceiptID", CommandType.Text);

            int count = Common.CommonHelper.ToInt(dt.Rows[0][0].ToString());
            if (count > 0) result = true;
            return result;
        }

        public static void ErrorLogClear()
        {
            PruDBHelp db = new PruDBHelp();

            db.ExecuteNonQuery("delete from Logs_Action_C", CommandType.Text);
        }

        public static DataTable GetDataForGANET()
        {
            PruDBHelp db = new PruDBHelp();
            DataTable dt = db.ExecuteDataTable(@"SELECT [ClientID], [ReceiptID], [ClientNo], [ReceiptNo],[Description]                                        
                                                 FROM Logs_Action_C", CommandType.Text);

            return dt;
        }
    }
}
