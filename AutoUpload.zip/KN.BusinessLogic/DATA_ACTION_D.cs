﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace KN.BusinessLogic
{
    public class DATA_ACTION_D
    {
        public string Surname { get; set; }
        public string Gurname { get; set; }
        public string RName { get; set; }
        public string Location { get; set; }
        public string Salutation { get; set; }
        public string Sex { get; set; }
        public string Married { get; set; }
        public string Street { get; set; }
        public string ID { get; set; }
        public string PhoneM { get; set; }
        public string PhoneC { get; set; }
        public string PhoneH { get; set; }
        public string Occupation { get; set; }
        public string BirthDate { get; set; }
        public string SoE { get; set; }
        public string CLIENT_TAX_CODE { get; set; }
        public string InternetAddress { get; set; }
        public string Category { get; set; }
        public string ClientID { get; set; }

        public string Country { get; set; }
        public string UStax { get; set; }
        public string BirthCountry { get; set; }
        public string MobileCode { get; set; }
        public string CompCode { get; set; }
        public string HomeCode { get; set; }
        public string Nationality { get; set; }

        public DATA_ACTION_D()
        {
        }

        public DATA_ACTION_D(DataRow row)
        {
            Surname = row["Surname"].ToString();
            Gurname = row["Gurname"].ToString();
            RName = row["RName"].ToString();
            Location = row["Location"].ToString();
            Salutation = row["Salutation"].ToString();
            Sex = row["Sex"].ToString();
            Married = row["Married"].ToString();
            Street = row["Street"].ToString().Replace('|', ',');
            ID = row["ID"].ToString();
            PhoneM = row["PhoneM"].ToString();
            PhoneC = row["PhoneC"].ToString();
            PhoneH = row["PhoneH"].ToString();
            Occupation = row["Occupation"].ToString();
            BirthDate = row["BirthDate"].ToString();
            SoE = row["SoE"].ToString();
            Category = row["Category"].ToString();
            InternetAddress = row["InternetAddress"].ToString();
            CLIENT_TAX_CODE = row["CLIENT_TAX_CODE"].ToString();
            ClientID = row["ClientID"].ToString();

            Country = row["Country"].ToString();
            UStax = row["UStax"].ToString();
            BirthCountry = row["BirthCountry"].ToString();
            MobileCode = row["MobileCode"].ToString();
            CompCode = row["CompCode"].ToString();
            HomeCode = row["HomeCode"].ToString();
            Nationality = row["Nationality"].ToString();
        }
    }
}
