﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KN.BusinessLogic
{
    public class Beneficiary
    {       
        public string PoposalNo { get; set; }
        public string Relation { get; set; }        
        public string ShareCode { get; set; }    
        public string ClientNo { get; set; }  
        public string EffectiveFrom { get; set; }
        public string Role { get; set; }
        public string N { get; set; }
    }
}
