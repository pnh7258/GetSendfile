﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace KN.BusinessLogic
{
    public class DATA_SV021
    {
        public string PayerID { get; set; }
        public string PayerName { get; set; }
        public string PayerDOB { get; set; }
        public string Country { get; set; }
        public string Nationality { get; set; }
        public string Payer_Relationship { get; set; }

        //public DATA_SV021(DATA_SV51D data_sv51d)
        //{
        //    this.PayerID = data_sv51d.PayerID;
        //    this.PayerName = data_sv51d.PayerName;
        //    this.PayerDOB = data_sv51d.PayerDOB;
        //    this.Country = data_sv51d.Country;
        //    this.Nationality = data_sv51d.Nationality;
        //    this.Payer_Relationship = data_sv51d.Payer_Relationship;
        //}

        //public DATA_SV021(DATA_SV51B data_sv51b)
        //{
        //    this.PayerID = data_sv51b.PayerID;
        //    this.PayerName = data_sv51b.PayerName;
        //    this.PayerDOB = data_sv51b.PayerDOB;
        //    this.Country = data_sv51b.Country;
        //    this.Nationality = data_sv51b.Nationality;
        //    this.Payer_Relationship = data_sv51b.Payer_Relationship;
        //}

        //public DATA_SV021(DATA_SV50K data_sv50k)
        //{
        //    this.PayerID = data_sv50k.PayerID;
        //    this.PayerName = data_sv50k.PayerName;
        //    this.PayerDOB = data_sv50k.PayerDOB;
        //    this.Country = data_sv50k.Country;
        //    this.Nationality = data_sv50k.Nationality;
        //    this.Payer_Relationship = data_sv50k.Payer_Relationship;
        //}

        public DATA_SV021(string PayerID, string PayerName, string PayerDOB, string Country, string Nationality, string Payer_Relationship)
        {
            this.PayerID = PayerID;
            this.PayerName = "";
            this.PayerDOB = "";
            this.Country = "";
            this.Nationality = "";
            this.Payer_Relationship = "";
        }
    }
}
