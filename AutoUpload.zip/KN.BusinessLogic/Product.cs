﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KN.BusinessLogic
{
    public class Product
    {
        public string PoposalNo { get; set; }
        public string ContactOwner { get; set; }
        public string ProspectNumber { get; set; }
        public string IncomeRage { get; set; }
        public string Amount { get; set; }
        public string RiskComDate { get; set; }
        public string PropDate { get; set; }
        public string BillingFrequency { get; set; }
        public string PropRcvDate { get; set; }
        public string MethodPayment { get; set; }
        public string UWDecDate { get; set; }
        public string FirstBillingDate { get; set; }
        public string NoOfPolicy { get; set; }
        public string ContrastCurrency { get; set; }
        public string BillCurrency { get; set; }
        public string NonFFTOpt { get; set; }
        public string ContrastRegister { get; set; }
        public string CrossRefType { get; set; }
        public string Number { get; set; }
        public string SourceOfBussiness { get; set; }
        public string DupRefNo { get; set; }
        public string TempRcptNo { get; set; }
        public string TemporaryReceiptDate { get; set; }
        public string ServicingBranch { get; set; }
        public string Agency { get; set; }
        public string Campaign { get; set; }
        public string JointOwner { get; set; }
        public string Assignee { get; set; }
        public string Applycash { get; set; }
        public string DespatchAddress { get; set; }
        public string Payor { get; set; }
        public string RevApplyCash { get; set; }
        public string DirectDebit { get; set; }
        public string FollowUps { get; set; }
        public string Commission { get; set; }
        public string GroupDetails { get; set; }
        public string Beneficiaries { get; set; }
        public string ReducingTerm { get; set; }
        public string Role { get; set; }
        public string PropRvcDate { get; set; } 

    }
}
