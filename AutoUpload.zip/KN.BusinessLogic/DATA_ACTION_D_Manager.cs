﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using KN.DataAcess;
using KN.Systems;

namespace KN.BusinessLogic
{
    public class DATA_ACTION_D_Manager
    {
        private static string sTableData = "DATA_ACTION_D";
        private static string sTableError = "ERROR_ACTION_D";
        private static string sTableSuccess = "SUCCESS_ACTION_D";
        private static string sTableLog = "LOGS_ACTION_D";

        public static DATA_ACTION_D_Collection GetAllClients()
        {
            var result = new DATA_ACTION_D_Collection();

            PruDBHelp db = new PruDBHelp();
            DataTable dt = db.ExecuteDataTable("SELECT * FROM " + sTableData, CommandType.Text);

            foreach (DataRow row in dt.Rows)
                result.Add(new DATA_ACTION_D(row));

            return result;
        }

        public static DataTable GetAllClients2()
        {
            PruDBHelp db = new PruDBHelp();
            DataTable dt = db.ExecuteDataTable("SELECT * FROM " + sTableData, CommandType.Text);
               
            return dt;
        }

        public static void UploadClients(string csvFilePath)
        {
            var dt = ExcelProcess.ReadCSV(csvFilePath, true);
            ExcelProcess.Table_Import("ACTION_D", dt);
        }

        public static void ClientUpdate(string ID, string Client_Code)
        {           
            PruDBHelp db = new PruDBHelp();
            try
            {
                db.AddParameter("@Client_Code", Client_Code);
                db.AddParameter("@ID", ID);
                db.ExecuteNonQuery("update DATA_S2465_2 set Client_Code=@Client_Code where ID=@ID", CommandType.Text);
            }
            catch
            {
                throw;
            }
        }
        

        public static void InsertError(DATA_ACTION_D value, string message)
        {
            PruDBHelp db = new PruDBHelp();
            db.AddParameter("@Surname", value.Surname);
            db.AddParameter("@Gurname", value.Gurname);
            db.AddParameter("@RName", value.RName);
            db.AddParameter("@Location", value.Location);
            db.AddParameter("@Salutation", value.Salutation);
            db.AddParameter("@Sex", value.Sex);
            db.AddParameter("@Married", value.Married);
            db.AddParameter("@Street", value.Street);
            db.AddParameter("@ID", value.ID);
            db.AddParameter("@PhoneM", value.PhoneM);
            db.AddParameter("@PhoneC", value.PhoneC);
            db.AddParameter("@PhoneH", value.PhoneH);
            db.AddParameter("@Occupation", value.Occupation);
            db.AddParameter("@BirthDate", value.BirthDate);
            db.AddParameter("@SoE", value.SoE); 
            db.AddParameter("@Category", value.Category);
            db.AddParameter("@InternetAddress", value.InternetAddress);
            db.AddParameter("@CLIENT_TAX_CODE", value.CLIENT_TAX_CODE);
            db.AddParameter("@ClientID", value.ClientID);
            db.AddParameter("@message", message);

            db.AddParameter("@Country", value.Country);
            db.AddParameter("@UStax", value.UStax);
            db.AddParameter("@BirthCountry", value.BirthCountry);
            db.AddParameter("@MobileCode", value.MobileCode);
            db.AddParameter("@CompCode", value.CompCode);
            db.AddParameter("@HomeCode", value.HomeCode);
            db.AddParameter("@Nationality", value.Nationality);
            try
            {
                string SQL = "";
                //if (CheckExist(value) == false)
                //{
                    SQL = "INSERT INTO " + sTableError + " ([Surname], [Gurname], [RName], [Location], [Salutation], [Sex], [Married], [Street], [ID], [PhoneM], [PhoneC], [PhoneH], [Occupation], [BirthDate], [SoE], [Category], [InternetAddress], [CLIENT_TAX_CODE], [ClientID], [message], Country, UStax, BirthCountry, MobileCode, CompCode, HomeCode, Nationality) VALUES (@Surname, @Gurname, @RName, @Location, @Salutation, @Sex, @Married, @Street, @ID, @PhoneM, @PhoneC, @PhoneH, @Occupation, @BirthDate, @SoE, @Category, @InternetAddress, @CLIENT_TAX_CODE, @ClientID, @message, @Country, @UStax, @BirthCountry, @MobileCode, @CompCode, @HomeCode, @Nationality)";
                //}
                //else
                //{
                //    db.ClearParameter();
                //    db.AddParameter("@message", message);
                //    db.AddParameter("@ID", value.ID);
                //    SQL = "UPDATE " + sTableError + " SET message = message + '|' +  @message WHERE ClientID=@ClientID";
                //}
                db.ExecuteNonQuery(SQL, CommandType.Text);
            }
            catch
            {
                throw;
            }
        }

        public static void InsertSuccess(DATA_ACTION_D value)
        {
            PruDBHelp db = new PruDBHelp();
            db.AddParameter("@Surname", value.Surname);
            db.AddParameter("@Gurname", value.Gurname);
            db.AddParameter("@RName", value.RName);
            db.AddParameter("@Location", value.Location);
            db.AddParameter("@Salutation", value.Salutation);
            db.AddParameter("@Sex", value.Sex);
            db.AddParameter("@Married", value.Married);
            db.AddParameter("@Street", value.Street);
            db.AddParameter("@ID", value.ID);
            db.AddParameter("@PhoneM", value.PhoneM);
            db.AddParameter("@PhoneC", value.PhoneC);
            db.AddParameter("@PhoneH", value.PhoneH);
            db.AddParameter("@Occupation", value.Occupation);
            db.AddParameter("@BirthDate", value.BirthDate);
            db.AddParameter("@SoE", value.SoE);
            db.AddParameter("@Category", value.Category);
            db.AddParameter("@InternetAddress", value.InternetAddress);
            db.AddParameter("@CLIENT_TAX_CODE", value.CLIENT_TAX_CODE);

            db.AddParameter("@Country", value.Country);
            db.AddParameter("@UStax", value.UStax);
            db.AddParameter("@BirthCountry", value.BirthCountry);
            db.AddParameter("@MobileCode", value.MobileCode);
            db.AddParameter("@CompCode", value.CompCode);
            db.AddParameter("@HomeCode", value.HomeCode);
            db.AddParameter("@Nationality", value.Nationality);
            try
            {
                //string SQL = "INSERT INTO " + sTableSuccess + " ([Surname], [Gurname], [RName], [Location], [Salutation], [Sex], [Married], [Street], [ID], [PhoneM], [PhoneC], [PhoneH], [Occupation], [BirthDate], [SoE], [Billing_Frequency], [Contract_Type], [Bank_Code], [Tax_Invoice], [Contract_Number], [Action], [OR_Number], [Collected_Agent_Collector], [Payment_Type], [Received_From], [Client_Code], [Amount], [TR_NO], [Receipt_Date], [GL_Amount], [BSB_Code], [Cheque_No], [Cheque_Date], [InterID], [Prop_No], [Main_Agt], [SubCode1], [SubType1], [Contract_Number1], [Desc1], [SubAmount1], [SubCode2], [SubType2], [Contract_Number2], [Desc2], [SubAmount2], [SubCode3], [SubType3], [Contract_Number3], [Desc3], [SubAmount3], [PTD_ADV], [InsPrem], [CLIENT_TAX_CODE]) VALUES (@Surname, @Gurname, @RName, @Location, @Salutation, @Sex, @Married, @Street, @ID, @PhoneM, @PhoneC, @PhoneH, @Occupation, @BirthDate, @SoE, @Billing_Frequency, @Contract_Type, @Bank_Code, @Tax_Invoice, @Contract_Number, @Action, @OR_Number, @Collected_Agent_Collector, @Payment_Type, @Received_From, @Client_Code, @Amount, @TR_NO, @Receipt_Date, @GL_Amount, @BSB_Code, @Cheque_No, @Cheque_Date, @InterID, @Prop_No, @Main_Agt, @SubCode1, @SubType1, @Contract_Number1, @Desc1, @SubAmount1, @SubCode2, @SubType2, @Contract_Number2, @Desc2, @SubAmount2, @SubCode3, @SubType3, @Contract_Number3, @Desc3, @SubAmount3, @PTD_ADV, @InsPrem, @CLIENT_TAX_CODE)";              
                string SQL = "INSERT INTO " + sTableSuccess + " ([Surname], [Gurname], [RName], [Location], [Salutation], [Sex], [Married], [Street], [ID], [PhoneM], [PhoneC], [PhoneH], [Occupation], [BirthDate], [SoE], [Category], [InternetAddress], [CLIENT_TAX_CODE], Country, UStax, BirthCountry, MobileCode, CompCode, HomeCode, Nationality) VALUES (@Surname, @Gurname, @RName, @Location, @Salutation, @Sex, @Married, @Street, @ID, @PhoneM, @PhoneC, @PhoneH, @Occupation, @BirthDate, @SoE, @Category, @InternetAddress, @CLIENT_TAX_CODE, @Country, @UStax, @BirthCountry, @MobileCode, @CompCode, @HomeCode, @Nationality)";
                db.ExecuteNonQuery(SQL, CommandType.Text);
            }
            catch
            {
                throw;
            }
        }

        public static bool CheckExist(DATA_ACTION_D value)
        {
            bool result = false;
            PruDBHelp db = new PruDBHelp();
            db.AddParameter("@ClientID", value.ClientID);
            DataTable dt = db.ExecuteDataTable(@"SELECT count(*)                                            
                                                 FROM " + sTableError + " where ClientID=@ClientID", CommandType.Text);

            int count = Common.CommonHelper.ToInt(dt.Rows[0][0].ToString());
            if (count > 0) result = true;
            return result;
        }

        public static DATA_ACTION_D_Collection GetFailClients2()
        {
            var result = new DATA_ACTION_D_Collection();

            PruDBHelp db = new PruDBHelp();
            DataTable dt = db.ExecuteDataTable("SELECT * FROM " + sTableError, CommandType.Text);

            foreach (DataRow row in dt.Rows)
                result.Add(new DATA_ACTION_D(row));

            return result;
        }

        public static DATA_ACTION_D_Collection GetSuccessClients2()
        {
            var result = new DATA_ACTION_D_Collection();

            PruDBHelp db = new PruDBHelp();
            DataTable dt = db.ExecuteDataTable(@"SELECT *
                                                 FROM " + sTableSuccess, CommandType.Text);

            foreach (DataRow row in dt.Rows)
                result.Add(new DATA_ACTION_D(row));

            return result;
        }

        public static DataTable GetSuccessClients()
        {
            PruDBHelp db = new PruDBHelp();
            DataTable dt = db.ExecuteDataTable(@"SELECT *
                                                 FROM " + sTableSuccess, CommandType.Text);

            return dt;
        }

        public static DataTable GetFailClients()
        {
            PruDBHelp db = new PruDBHelp();
            DataTable dt = db.ExecuteDataTable(@"SELECT [message], [Surname], [Gurname], [RName], [Location], [Salutation], [Sex], [Married], [Street], [ID], [PhoneM], [PhoneC], [PhoneH], [Occupation], [BirthDate], [SoE], [Category], [InternetAddress], [CLIENT_TAX_CODE], [ClientID] , Country, UStax, BirthCountry, MobileCode, CompCode, HomeCode, Nationality
                                                 FROM " + sTableError, CommandType.Text);

            return dt;
        }

        public static DataTable GetFailClientsEx()
        {
            PruDBHelp db = new PruDBHelp();
            DataTable dt = db.ExecuteDataTable(@"SELECT [message], " + sTableError + @".*
                                                 FROM " + sTableError, CommandType.Text);

            return dt;
        }

        public static DataTable GetLogClients()
        {
            PruDBHelp db = new PruDBHelp();
            DataTable dt = db.ExecuteDataTable(@"SELECT message,
                                                        Surname,
                                                        Gurname,
                                                        RName,
                                                        Location,
                                                        Salutation,
                                                        Sex,
                                                        Married,
                                                        Street,
                                                        ID,
                                                        PhoneM,
                                                        PhoneC,
                                                        PhoneH,
                                                        Occupation,
                                                        BirthDate,
                                                        SoE,
                                                        Category,
                                                        InternetAddress,
                                                        CLIENT_TAX_CODE,
                                                        ClientID,
                                                        ClientNo,                                                        
                                                        country,
                                                        ustax,
                                                        birthcountry,
                                                        mobilecode,
                                                        compcode,
                                                        homecode,
                                                        nationality

                                                 FROM " + sTableLog, CommandType.Text);

            return dt;
        }

        public static void ClearSuccessClients()
        {
            PruDBHelp db = new PruDBHelp();
            db.ExecuteNonQuery("delete from " + sTableSuccess, CommandType.Text);
        }

        public static void ClearFailClients()
        {
            PruDBHelp db = new PruDBHelp();
            db.ExecuteNonQuery("delete from " + sTableError, CommandType.Text);
        }

        public static void ClearLogs()
        {
            PruDBHelp db = new PruDBHelp();
            db.ExecuteNonQuery("delete from " + sTableLog, CommandType.Text);
        }
        public static void ErrorLogInsert(DATA_ACTION_D value, string ClientNo, string message)
        {
            PruDBHelp db = new PruDBHelp();
            if (CheckExist(value) == false)
            {                
                db.AddParameter("@Surname", value.Surname);
                db.AddParameter("@Gurname", value.Gurname);
                db.AddParameter("@RName", value.RName);
                db.AddParameter("@Location", value.Location);
                db.AddParameter("@Salutation", value.Salutation);
                db.AddParameter("@Sex", value.Sex);
                db.AddParameter("@Married", value.Married);
                db.AddParameter("@Street", value.Street);
                db.AddParameter("@ID", value.ID);
                db.AddParameter("@PhoneM", value.PhoneM);
                db.AddParameter("@PhoneC", value.PhoneC);
                db.AddParameter("@PhoneH", value.PhoneH);
                db.AddParameter("@Occupation", value.Occupation);
                db.AddParameter("@BirthDate", value.BirthDate);
                db.AddParameter("@SoE", value.SoE);
                db.AddParameter("@Category", value.Category);
                db.AddParameter("@InternetAddress", value.InternetAddress);
                db.AddParameter("@CLIENT_TAX_CODE", value.CLIENT_TAX_CODE);
                db.AddParameter("@ClientID", value.ClientID);
                db.AddParameter("@ClientNo", ClientNo);
                db.AddParameter("@message", message);

                db.AddParameter("@Country", value.Country);
                db.AddParameter("@UStax", value.UStax);
                db.AddParameter("@BirthCountry", value.BirthCountry);
                db.AddParameter("@MobileCode", value.MobileCode);
                db.AddParameter("@CompCode", value.CompCode);
                db.AddParameter("@HomeCode", value.HomeCode);
                db.AddParameter("@Nationality", value.Nationality);
                try
                {
                    string SQL = "INSERT INTO " + sTableLog + " ([Surname], [Gurname], [RName], [Location], [Salutation], [Sex], [Married], [Street], [ID], [PhoneM], [PhoneC], [PhoneH], [Occupation], [BirthDate], [SoE], [Category], [InternetAddress], [CLIENT_TAX_CODE], [ClientID], [ClientNo], [message], Country, UStax, BirthCountry, MobileCode, CompCode, HomeCode, Nationality) VALUES (@Surname, @Gurname, @RName, @Location, @Salutation, @Sex, @Married, @Street, @ID, @PhoneM, @PhoneC, @PhoneH, @Occupation, @BirthDate, @SoE, @Category, @InternetAddress, @CLIENT_TAX_CODE, @ClientID, @ClientNo, @message, @Country, @UStax, @BirthCountry, @MobileCode, @CompCode, @HomeCode, @Nationality)";
                    db.ExecuteNonQuery(SQL, CommandType.Text);
                }
                catch
                {
                    throw;
                }
            }
            else
            {                
                db.AddParameter("@ClientNo", ClientNo);
                db.AddParameter("@message", message);
                db.AddParameter("@ID", value.ID);
                db.ExecuteNonQuery("UPDATE " + sTableLog + " SET ClientNo=@ClientNo, message = message + '|' +  @message WHERE ID=@ID", CommandType.Text);
            }
        }
        
        public static DataTable GetDataForGANET()
        {
            PruDBHelp db = new PruDBHelp();
            DataTable dt = db.ExecuteDataTable(@"SELECT [ClientID], [ClientNo], [message]                                        
                                                 FROM Logs_Action_D", CommandType.Text);

            return dt;
        }
    }
}
