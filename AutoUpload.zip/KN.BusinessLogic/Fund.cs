﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KN.BusinessLogic
{
    public class Fund
    {
        public string PoposalNo { get; set; }
        public string FundCode {get;set;}
        public string Amount { get; set; }
        public string Price { get; set; }
        public string FundSplitPlan { get; set; }
        

        public Fund(string FundCode, string Amount, string Price)
        {
            this.FundCode = FundCode;
            this.Amount = Amount;
            this.Price = Price;
        }
        public Fund()
        {
            
        }
    }
}
