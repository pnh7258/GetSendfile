﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KN.BusinessLogic
{
    public class DATA_S2067
    {

        public string ID { get; set; }
        public string BankCode { get; set; }
        public string ReceiptNumber { get; set; }
        public string TaxNumber { get; set; }
        public string ChequeNumber { get; set; }
        public string ContractNumber { get; set; }
        public string Action { get; set; }

        public DATA_S2067()
        { 
        }

        public DATA_S2067(DATA_S2610_ACTION_C client2)
        {
            this.BankCode = client2.Bank_Code;
            this.ChequeNumber = client2.Cheque_No;
            this.TaxNumber = client2.Tax_Invoice;
            this.ContractNumber = client2.Contract_Number;
        }

        public DATA_S2067(DATA_S2610_ACTION_A data)
        {
            this.BankCode = data.Bank_Code;
            this.ChequeNumber = data.Cheque_No;
            this.TaxNumber = data.Tax_Invoice;
            this.ContractNumber = data.Contract_Number;
            this.Action = data.Action;
        }

        public DATA_S2067(DATA_SV51D data)
        {
            this.BankCode = data.Bank_Code;
            this.ChequeNumber = data.Cheque_No;
            this.TaxNumber = data.Tax_Invoice;
            this.ContractNumber = data.Contract_Number;
            this.Action = data.Action;
        }

        public DATA_S2067(DATA_SV51B data)
        {
            this.BankCode = data.Bank_Code;
            this.ChequeNumber = data.Cheque_No;
            this.TaxNumber = data.Tax_Invoice;
            this.ContractNumber = data.Contract_Number;
            this.Action = data.Action;
        }

        public DATA_S2067(DATA_SV50K data)
        {
            this.BankCode = data.Bank_Code;
            this.ChequeNumber = data.Cheque_No;
            this.TaxNumber = data.Tax_Invoice;
            this.ContractNumber = data.Contract_Number;
            this.Action = data.Action;
        }
    }
}
