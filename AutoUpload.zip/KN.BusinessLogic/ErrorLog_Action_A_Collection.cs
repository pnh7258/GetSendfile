﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KN.BusinessLogic
{
    public class ErrorLog_Action_A_Collection : List<ErrorLog_Action_A>
    {
    }
}
