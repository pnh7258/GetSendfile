﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using KN.DataAcess;
namespace KN.BusinessLogic
{
    public class BasicplanManager
    {
        private static Basicplan GetObjectFromReader(IDataReader dataReader)
        {
            try
            {
                Basicplan obj = new Basicplan();
                //  DATA_Products
                //	PolicyNo	ClientNo	Lifeno	Coverage	Riderno	Rider	TotalPremium	RiskProfile	

                obj.ProposalNo = KNDataHelper.GetString(dataReader, "PoposalNo");
                obj.SumAssured = KNDataHelper.GetString(dataReader, "SumassuredBenefitAmount");
                obj.MaturityAge_Term = KNDataHelper.GetString(dataReader, "MaturityTermRiskCessTerm");
                obj.MortalityClass = KNDataHelper.GetString(dataReader, "MortalityClass");
                obj.Coverage = KNDataHelper.GetString(dataReader, "Coverage");
                obj.RiskProfile = KNDataHelper.GetString(dataReader, "RiskProfile");
                obj.Role = KNDataHelper.GetString(dataReader, "Role");
                
                obj.PremiumCessAge_Term = "";
                obj.ReserveUnits = "";
                obj.ReserveUnitsDate = "";                
                obj.JointLife = "";
                obj.SpecialTerms = "";
                obj.FundSplitPlan = "";
                obj.PremAmnt = "";                

                return obj;
            }
            catch
            {
                throw;
            }
        }

        public static Basicplan BasicplanLoad(string PoposalNo, string ProductCode)
        {
            PruDBHelp db = new PruDBHelp();
            try
            {
                db.AddParameter("@PoposalNo", PoposalNo);
                db.AddParameter("@ProductCode", ProductCode);

                using (IDataReader dataReader = db.ExecuteReader("select * from DATA_Products where PoposalNo = @PoposalNo and Rider=@ProductCode and Role='LA1'", CommandType.Text))
                {
                    while (dataReader.Read())
                    {
                        return GetObjectFromReader(dataReader);
                    }
                }
                return null;
            }
            catch
            {
                throw;
            }
        }

        public static void UpdatePolicy(string ProposalNo, string PolicyNo)
        {
            var result = new ClientCollection();
            PruDBHelp db = new PruDBHelp();
            try
            {
                db.AddParameter("@PolicyNo", PolicyNo);
                db.AddParameter("@PoposalNo", ProposalNo);

                db.ExecuteNonQuery("update DATA_Products set PolicyNo=@PolicyNo where PoposalNo=@PoposalNo", CommandType.Text);
            }
            catch
            {
                throw;
            }
        }

        public static void UpdateError(string PoposalNo)
        {
            PruDBHelp db = new PruDBHelp();
            try
            {
                string SQL = "insert into ERROR_Products ";
                SQL += "select * from DATA_Products ";
                SQL += "where PoposalNo=@PoposalNo ";
                db.AddParameter("@PoposalNo", PoposalNo);
                db.ExecuteNonQuery(SQL, CommandType.Text);
            }
            catch
            {
                throw;
            }
        }

        public static Basicplan LoadBasicPlanByExcelProposal(int Proposal)
        {
            var result = new Basicplan();
            result.SumAssured = "1000000000";
            result.MaturityAge_Term = "10";
            result.PremiumCessAge_Term = "10";
            result.ReserveUnits = "Y";
            result.ReserveUnitsDate = "10/10/2011";
            result.MortalityClass = "C";
            result.JointLife = "";
            result.SpecialTerms = "";

            return result;
        }

        public static Basicplan ReadBasicPlanFromExcel(string file)
        {
            var result = new Basicplan();
            result.SumAssured = "1000000000";
            result.MaturityAge_Term = "10";
            result.PremiumCessAge_Term = "10";
            result.ReserveUnits = "Y";
            result.ReserveUnitsDate ="10/10/2011";
            result.MortalityClass ="C";
            result.JointLife = "";
            result.SpecialTerms = "";
            
            return result;
        }
    }
}
