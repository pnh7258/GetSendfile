﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using KN.DataAcess;
namespace KN.BusinessLogic
{
    public class DATA_S2067Manager
    {
        private static DATA_S2067 GetObjectFromReader(IDataReader dataReader)
        {
            try
            {                
                DATA_S2067 obj = new DATA_S2067();
                obj.ID = KNDataHelper.GetString(dataReader, "ID");
                obj.Action = KNDataHelper.GetString(dataReader, "Action");
                obj.BankCode = KNDataHelper.GetString(dataReader, "BankCode");
                obj.ChequeNumber = KNDataHelper.GetString(dataReader, "ChequeNumber");
                obj.ContractNumber = KNDataHelper.GetString(dataReader, "ContractNumber");
                obj.ReceiptNumber = KNDataHelper.GetString(dataReader, "ReceiptNumber");
                obj.ChequeNumber = KNDataHelper.GetString(dataReader, "ChequeNumber");
                obj.TaxNumber = KNDataHelper.GetString(dataReader, "TaxNumber");
                
                return obj;
            }
            catch
            {
                throw;
            }
        }

        public static DATA_S2067 DATA_S2067Load(string ID)
        {
            PruDBHelp db = new PruDBHelp();
            try
            {
                db.AddParameter("@ID", ID);

                using (IDataReader dataReader = db.ExecuteReader("select * from DATA_S2067 where ID = @ID", CommandType.Text))
                {
                    while (dataReader.Read())
                    {
                        return GetObjectFromReader(dataReader);
                    }
                }
                return null;
            }
            catch
            {
                throw;
            }
        }
              

        public static DATA_S2067Collection AllDATA_S2067Load()
        {
            var result = new DATA_S2067Collection();
            PruDBHelp db = new PruDBHelp();
            try
            {                
                using (IDataReader dataReader = db.ExecuteReader("select * from DATA_S2067", CommandType.Text))
                {
                    while (dataReader.Read())
                    {
                        result.Add(GetObjectFromReader(dataReader));
                    }
                }
                return result;
            }
            catch
            {                
                throw;
            }
        }
             

        public static void UpdateError(string ID)
        {            
            PruDBHelp db = new PruDBHelp();
            try
            {
                string SQL = "insert into ERROR_S2067 ";
                SQL += "select * from DATA_S2067 ";
                SQL += "where ID=@ID ";
                db.AddParameter("@ID",ID);
                db.ExecuteNonQuery(SQL, CommandType.Text);        
            }
            catch
            {
                throw;
            }
        }

        public static void DATA_S2067UpdateForCS()
        {            
            PruDBHelp db = new PruDBHelp();
            try
            {
                db.ExecuteNonQuery("update DATA_S2067 set [Action]='A'", CommandType.Text);        
            }
            catch
            {
                throw;
            }
        }
    }
}
