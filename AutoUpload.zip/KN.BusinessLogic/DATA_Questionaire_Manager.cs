﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using KN.DataAcess;
using KN.Systems;

namespace KN.BusinessLogic
{
    public class DATA_Questionaire_Manager
    {
        private static string sTableData = "DATA_Questionaire";
        private static string sViewTableData = "vDATA_Questionaire";
        private static string sTableError = "Error_Questionaire";
        private static string sTableSuccess = "SUCCESS_Questionaire";
        private static string sTableLog = "Logs_Questionaire";


        public static DATA_Questionaire_Collection GetAllQuestionaires()
        {
            var result = new DATA_Questionaire_Collection();

            PruDBHelp db = new PruDBHelp();
            DataTable dt = db.ExecuteDataTable("SELECT * FROM " + sViewTableData, CommandType.Text);

            foreach (DataRow row in dt.Rows)
                result.Add(new DATA_Questionaire(row));

            return result;
        }

        public static DATA_Questionaire_Collection GetAllQuestionaires(string ContractNumber, string LifeAssured)
        {
            var result = new DATA_Questionaire_Collection();

            PruDBHelp db = new PruDBHelp();
            db.AddParameter("@ContractNumber", ContractNumber);
            db.AddParameter("@LifeAssured", LifeAssured);
            DataTable dt = db.ExecuteDataTable("SELECT * FROM " + sViewTableData + " WHERE ContractNumber=@ContractNumber and LifeAssured=@LifeAssured", CommandType.Text);

            foreach (DataRow row in dt.Rows)
                result.Add(new DATA_Questionaire(row));

            return result;
        }

        public static DATA_Questionaire_Collection GetAllQuestionaires(string ContractNumber, string LifeAssured, string QuestionNum)
        {
            var result = new DATA_Questionaire_Collection();

            PruDBHelp db = new PruDBHelp();
            db.AddParameter("@ContractNumber", ContractNumber);
            db.AddParameter("@LifeAssured", LifeAssured);
            db.AddParameter("@QuestionNum", QuestionNum);
            DataTable dt = db.ExecuteDataTable("SELECT * FROM " + sViewTableData + " WHERE ContractNumber=@ContractNumber and LifeAssured=@LifeAssured and Question like @QuestionNum", CommandType.Text);

            foreach (DataRow row in dt.Rows)
                result.Add(new DATA_Questionaire(row));

            return result;
        }

        public static DataTable GetAllQuestionairesMaster()
        {            
            PruDBHelp db = new PruDBHelp();
            DataTable dt = db.ExecuteDataTable("SELECT distinct [ContractNumber], [LifeAssured] FROM " + sTableData, CommandType.Text);

            return dt;
        }

        public static void UploadQuestionaire(string csvFilePath)
        {
            var dt = ExcelProcess.ReadCSV(csvFilePath, true);
            ExcelProcess.Table_Import("Questionaire", dt);
        }

        public static void InsertLog(DATA_Questionaire value, string message)
        {
            PruDBHelp db = new PruDBHelp();
            db.AddParameter("@ContractNumber", value.ContractNumber);
            db.AddParameter("@LifeAssured", value.LifeAssured);
            db.AddParameter("@Question", value.Question);
            db.AddParameter("@Answer", value.Answer);
            db.AddParameter("@message", message);
            try
            {
                string SQL = "";
                //if (CheckExist(value) == false)
                //{
                    SQL = "INSERT INTO " + sTableLog + " ([ContractNumber], [LifeAssured], [Question], [Answer], [message]) VALUES (@ContractNumber,  @LifeAssured, @Question, @Answer, @message)";
                //}
                //else
                //{
                //    db.ClearParameter();
                //    db.AddParameter("@message", message);

                //    // --- add other
                //    db.AddParameter("@ContractNumber", value.ContractNumber);
                //    db.AddParameter("@LifeAssured", value.LifeAssured);

                //    SQL = "UPDATE " + sTableLog + " SET message = message + '|' +  @message WHERE ContractNumber=@ContractNumber and LifeAssured=@LifeAssured";
                //}
                db.ExecuteNonQuery(SQL, CommandType.Text);
            }
            catch
            {
                throw;
            }
        }

        public static void InsertSuccess(string ContractNumber, string LifeAssured, string Message)
        {
            PruDBHelp db = new PruDBHelp();
            db.AddParameter("@ContractNumber", ContractNumber);
            db.AddParameter("@LifeAssured", LifeAssured);
            //db.AddParameter("@Message", Message);           
            
            try
            {
                String SQL = "INSERT INTO " + sTableSuccess + " ([ContractNumber], [LifeAssured]) VALUES (@ContractNumber, @LifeAssured)";
                db.ExecuteNonQuery(SQL, CommandType.Text);
            }
            catch
            {
                throw;
            }
        }

        public static void InsertError(string ContractNumber, string LifeAssured, string Message)
        {
            PruDBHelp db = new PruDBHelp();
            db.AddParameter("@ContractNumber", ContractNumber);
            db.AddParameter("@LifeAssured", LifeAssured);
            //db.AddParameter("@Message", Message);           

            try
            {
                String SQL = "INSERT INTO " + sTableError + " ([ContractNumber], [LifeAssured]) VALUES (@ContractNumber, @LifeAssured)";
                db.ExecuteNonQuery(SQL, CommandType.Text);
            }
            catch
            {
                throw;
            }
        }
        public static DATA_Questionaire_Collection GetFailReceipts2()
        {
            var result = new DATA_Questionaire_Collection();

            PruDBHelp db = new PruDBHelp();
            DataTable dt = db.ExecuteDataTable("SELECT * FROM " + sTableError, CommandType.Text);

            foreach (DataRow row in dt.Rows)
                result.Add(new DATA_Questionaire(row));

            return result;
        }

        public static DATA_Questionaire_Collection GetSuccessQuestionaire2()
        {
            var result = new DATA_Questionaire_Collection();

            PruDBHelp db = new PruDBHelp();
            DataTable dt = db.ExecuteDataTable("SELECT * FROM " + sTableSuccess, CommandType.Text);

            foreach (DataRow row in dt.Rows)
                result.Add(new DATA_Questionaire(row));

            return result;
        }

        public static DataTable GetSuccessQuestionaire()
        {
            PruDBHelp db = new PruDBHelp();
            DataTable dt = db.ExecuteDataTable("SELECT [ContractNumber], [LifeAssured] FROM " + sTableSuccess, CommandType.Text);

            return dt;
        }

        public static int CountSuccessQuestionaire()
        {
            try
            {
                PruDBHelp db = new PruDBHelp();
                DataTable dt = db.ExecuteDataTable("SELECT distinct [ContractNumber] FROM " + sTableSuccess, CommandType.Text);

                return dt.Rows.Count;
            }
            catch { return 0; }
        }
        public static DataTable GetFailQuestionaire()
        {
            PruDBHelp db = new PruDBHelp();
            DataTable dt = db.ExecuteDataTable("SELECT [ContractNumber], [LifeAssured] FROM " + sTableError, CommandType.Text);

            return dt;
        }

        public static int CountFailQuestionaire()
        {
            try
            {
                PruDBHelp db = new PruDBHelp();
                DataTable dt = db.ExecuteDataTable("SELECT distinct [ContractNumber] FROM " + sTableError, CommandType.Text);

                return dt.Rows.Count;
            }
            catch
            {
                return 0;
            }
        }

        public static DataTable GetLogQuestionaire()
        {
            PruDBHelp db = new PruDBHelp();
            DataTable dt = db.ExecuteDataTable("SELECT * FROM " + sTableLog, CommandType.Text);

            return dt;
        }

        public static DataTable GetFailQuestionaireEx()
        {
            PruDBHelp db = new PruDBHelp();
            DataTable dt = db.ExecuteDataTable(@"SELECT [ContractNumber], [LifeAssured], [Question], [Answer], [message]
                                                 FROM " + sTableError, CommandType.Text);

            return dt;
        }

        public static bool CheckExist(DATA_Questionaire value)
        {
            bool result = false;
            PruDBHelp db = new PruDBHelp();
            db.AddParameter("@ContractNumber", value.ContractNumber);
            db.AddParameter("@LifeAssured", value.LifeAssured);
            db.AddParameter("@Question", value.Question);    
            DataTable dt = db.ExecuteDataTable(@"SELECT count(*)                                            
                                                 FROM " + sTableLog + " where ContractNumber=@ContractNumber and LifeAssured=@LifeAssured and Question=@Question", CommandType.Text);

            int count = Common.CommonHelper.ToInt(dt.Rows[0][0].ToString());
            if (count > 0) result = true;
            return result;
        }

        public static void ClearSuccessQuestionaire()
        {
            PruDBHelp db = new PruDBHelp();
            db.ExecuteNonQuery("delete from " + sTableSuccess, CommandType.Text);
        }
        public static void ClearQuestionaireLogs() {
            PruDBHelp db = new PruDBHelp();
            db.ExecuteNonQuery("delete from " + sTableLog, CommandType.Text);
        }
        public static void ClearFailQuestionaire()
        {
            PruDBHelp db = new PruDBHelp();
            db.ExecuteNonQuery("delete from " + sTableError, CommandType.Text);
        }
    }
}
