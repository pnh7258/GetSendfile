﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using KN.DataAcess;
namespace KN.BusinessLogic
{
    public static class LifeAssureManager
    {
        private static LifeAssure GetObjectFromReader(IDataReader dataReader)
        {
            try
            {
                //DATA_S5005
                //No.	PoposalNo				
               
                LifeAssure obj = new LifeAssure();
                obj.PoposalNo = KNDataHelper.GetString(dataReader, "PoposalNo");
                obj.ContrastNumber = KNDataHelper.GetString(dataReader, "PolicyNo");
                obj.LifeNo = KNDataHelper.GetString(dataReader, "Lifeno");
                obj.Life=KNDataHelper.GetString(dataReader, "ClientNo");
                obj.Height = KNDataHelper.GetString(dataReader, "Height");
                obj.Weight = KNDataHelper.GetString(dataReader, "Weight");
                obj.Smoking=KNDataHelper.GetString(dataReader, "Smoking");
                obj.Role = KNDataHelper.GetString(dataReader, "Role");

                obj.PursuitCode1 = "";
                obj.PursuitCode2 = "";
                obj.Sex = "";
                obj.DateOfBirth = "";
                obj.MedicalEvidence = "";
                

                return obj;
            }
            catch
            {
                throw;
            }
        }

        public static LifeAssure LifeAssureLoad(string PoposalNo, string Role)
        {
            PruDBHelp db = new PruDBHelp();
            try
            {
                db.AddParameter("@PoposalNo", PoposalNo);
                db.AddParameter("@Role", Role);

                using (IDataReader dataReader = db.ExecuteReader("select * from DATA_S5005 where PoposalNo = @PoposalNo and Role=@Role", CommandType.Text))
                {
                    while (dataReader.Read())
                    {
                        return GetObjectFromReader(dataReader);
                    }
                }
                return null;
            }
            catch
            {
                throw;
            }
        }
        public static LifeAssureCollection AllLifeAssureLoad()
        {
            var result = new LifeAssureCollection();
            PruDBHelp db = new PruDBHelp();
            try
            {                
                using (IDataReader dataReader = db.ExecuteReader("select * from DATA_S5005", CommandType.Text))
                {
                    while (dataReader.Read())
                    {
                        result.Add(GetObjectFromReader(dataReader));
                    }
                }
                return result;
            }
            catch
            {
                throw;
            }
        }
        public static LifeAssureCollection LifeAssureLoad(string PoposalNo)
        {
            var result = new LifeAssureCollection();
            PruDBHelp db = new PruDBHelp();
            try
            {
                db.AddParameter("@PoposalNo", PoposalNo);

                using (IDataReader dataReader = db.ExecuteReader("select * from DATA_S5005 where PoposalNo = @PoposalNo", CommandType.Text))
                {
                    while (dataReader.Read())
                    {
                        result.Add(GetObjectFromReader(dataReader));
                    }
                }
                return result;
            }
            catch
            {
                throw;
            }
        }

        public static void UpdateError(string PoposalNo)
        {
            PruDBHelp db = new PruDBHelp();
            try
            {
                string SQL = "insert into ERROR_S5005 ";
                SQL += "select * from DATA_S5005 ";
                SQL += "where PoposalNo=@PoposalNo ";
                db.AddParameter("@PoposalNo", PoposalNo);
                db.ExecuteNonQuery(SQL, CommandType.Text);
            }
            catch
            {
                throw;
            }
        }
    }
}
