﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KN.BusinessLogic
{
    public class Rider
    {
        public string ProposalNo { get; set; }
        public string LifeNo { get; set; }
        public string ClientNo { get; set; }
        public string Code { get; set; }
        public string Role { get; set; }        
        public string Benefit_Amount { get; set; }
        public string Risk_Cess_Age_Term { get; set; }
        public string Prem_Cess_Age_Term { get; set; }
        public string Bene_Cess_Age_Term { get; set; }
        public string Mortality_Class { get; set; }
        public string Special_Terms { get; set; }
        public string Option { get; set; }
        public string Coverage { get; set; }                 
    }
}
