﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KN.BusinessLogic
{
    public class DATA_SV51LCollection : List<DATA_SV51L>
    {
    }
}
