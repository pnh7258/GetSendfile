﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using KN.DataAcess;
using KN.Systems;

namespace KN.BusinessLogic
{
    public class DATA_SV51D_Manager
    {
        private static string sTableData = "DATA_SV51D";
        private static string sTableError = "ERROR_SV51D";
        private static string sTableSuccess = "SUCCESS_SV51D";

        public static DATA_SV51D_Collection GetAllReceipts()
        {
            var result = new DATA_SV51D_Collection();

            PruDBHelp db = new PruDBHelp();
            DataTable dt = db.ExecuteDataTable("SELECT * FROM " + sTableData, CommandType.Text);

            foreach (DataRow row in dt.Rows)
                result.Add(new DATA_SV51D(row));

            return result;
        }

        public static DataTable GetAllReceipts2()
        {
            PruDBHelp db = new PruDBHelp();
            DataTable dt = db.ExecuteDataTable("SELECT * FROM " + sTableData, CommandType.Text);

            return dt;

        }

        public static void UploadReceipts(string csvFilePath)
        {
            var dt = ExcelProcess.ReadCSV(csvFilePath, true);
            ExcelProcess.Table_Import(sTableData.Replace("DATA_", ""), dt);
        }

        public static void InsertError(DATA_SV51D value, string message)
        {
            PruDBHelp db = new PruDBHelp();
            db.AddParameter("@Bank_Code", value.Bank_Code);
            db.AddParameter("@Tax_Invoice", value.Tax_Invoice);
            db.AddParameter("@Contract_Number", value.Contract_Number);
            db.AddParameter("@Action", value.Action);
            db.AddParameter("@OR1_Number", value.OR1_Number);
            db.AddParameter("@Collected_Agent_Collector", value.Collected_Agent_Collector);
            db.AddParameter("@OR2_Number", value.OR2_Number);
            db.AddParameter("@Payment_Type", value.Payment_Type);
            db.AddParameter("@Received_From", value.Received_From);
            db.AddParameter("@Amount", value.Amount);
            db.AddParameter("@TR_NO", value.TR_NO);
            db.AddParameter("@Receipt_Date", value.Receipt_Date == null ? "" : value.Receipt_Date);
            db.AddParameter("@GL_Amount", value.GL_Amount);
            db.AddParameter("@BSB_Code", value.BSB_Code);
            db.AddParameter("@Cheque_No", value.Cheque_No);
            db.AddParameter("@Cheque_Date", value.Cheque_Date);
            db.AddParameter("@InterID", value.InterID);
            db.AddParameter("@SubCode1", value.SubCode1);
            db.AddParameter("@SubType1", value.SubType1);
            db.AddParameter("@Contract_Number1", value.Contract_Number1);
            db.AddParameter("@GASubType", value.GASubType);
            db.AddParameter("@Desc1", value.Desc1);
            db.AddParameter("@SubAmount1", value.SubAmount1);
            db.AddParameter("@SubCode2", value.SubCode2);
            db.AddParameter("@SubType2", value.SubType2);
            db.AddParameter("@Contract_Number2", value.Contract_Number2);
            db.AddParameter("@Desc2", value.Desc2);
            db.AddParameter("@SubAmount2", value.SubAmount2);
            db.AddParameter("@SubCode3", value.SubCode3);
            db.AddParameter("@SubType3", value.SubType3);
            db.AddParameter("@Contract_Number3", value.Contract_Number3);
            db.AddParameter("@Desc3", value.Desc3);
            db.AddParameter("@SubAmount3", value.SubAmount3);
            db.AddParameter("@PTD_ADV", value.PTD_ADV);
            db.AddParameter("@InsPrem", value.InsPrem);
            db.AddParameter("@BranchCode", value.BranchCode);
            db.AddParameter("@AlertMsg", value.BranchCode);
            db.AddParameter("@message", message);

            try
            {                
                string SQL = "";
                if (CheckExist(value) == false)
                {
                    SQL = "INSERT INTO " + sTableError + " ([Bank_Code], [Tax_Invoice], [Contract_Number], [Action], [OR1_Number], [Collected_Agent_Collector], [OR2_Number], [Payment_Type], [Received_From], [Amount], [TR_NO], [Receipt_Date], [GL_Amount], [BSB_Code], [Cheque_No], [Cheque_Date], [InterID], [SubCode1], [SubType1], [Contract_Number1], [GASubType], [Desc1], [SubAmount1], [SubCode2], [SubType2], [Contract_Number2], [Desc2], [SubAmount2], [SubCode3], [SubType3], [Contract_Number3], [Desc3], [SubAmount3], [PTD_ADV], [InsPrem], [BranchCode], [AlertMsg], [message]) VALUES (@Bank_Code, @Tax_Invoice, @Contract_Number, @Action, @OR1_Number, @Collected_Agent_Collector, @OR2_Number, @Payment_Type, @Received_From, @Amount, @TR_NO, @Receipt_Date, @GL_Amount, @BSB_Code, @Cheque_No, @Cheque_Date, @InterID, @SubCode1, @SubType1, @Contract_Number1, @GASubType, @Desc1, @SubAmount1, @SubCode2, @SubType2, @Contract_Number2, @Desc2, @SubAmount2, @SubCode3, @SubType3, @Contract_Number3, @Desc3, @SubAmount3, @PTD_ADV, @InsPrem, @BranchCode, @AlertMsg, @message)";
                }
                else
                {
                    db.ClearParameter();
                    db.AddParameter("@message", message);
                    db.AddParameter("@Tax_Invoice", value.Tax_Invoice);

                    SQL = "UPDATE " + sTableError + " SET message = message + '|' +  @message WHERE Tax_Invoice=@Tax_Invoice";
                }  
                db.ExecuteNonQuery(SQL, CommandType.Text);
            }
            catch
            {
                throw;
            }
        }

        public static void InsertSuccess(DATA_SV51D value)
        {
            PruDBHelp db = new PruDBHelp();
            db.AddParameter("@Bank_Code", value.Bank_Code);
            db.AddParameter("@Tax_Invoice", value.Tax_Invoice);
            db.AddParameter("@Contract_Number", value.Contract_Number);
            db.AddParameter("@Action", value.Action);
            db.AddParameter("@OR1_Number", value.OR1_Number);
            db.AddParameter("@Collected_Agent_Collector", value.Collected_Agent_Collector);
            db.AddParameter("@OR2_Number", value.OR2_Number);
            db.AddParameter("@Payment_Type", value.Payment_Type);
            db.AddParameter("@Received_From", value.Received_From);
            db.AddParameter("@Amount", value.Amount);
            db.AddParameter("@TR_NO", value.TR_NO);
            db.AddParameter("@Receipt_Date", value.Receipt_Date == null ? "" : value.Receipt_Date);
            db.AddParameter("@GL_Amount", value.GL_Amount);
            db.AddParameter("@BSB_Code", value.BSB_Code);
            db.AddParameter("@Cheque_No", value.Cheque_No);
            db.AddParameter("@Cheque_Date", value.Cheque_Date);
            db.AddParameter("@InterID", value.InterID);
            db.AddParameter("@SubCode1", value.SubCode1);
            db.AddParameter("@SubType1", value.SubType1);
            db.AddParameter("@Contract_Number1", value.Contract_Number1);
            db.AddParameter("@GASubType", value.GASubType);
            db.AddParameter("@Desc1", value.Desc1);
            db.AddParameter("@SubAmount1", value.SubAmount1);
            db.AddParameter("@SubCode2", value.SubCode2);
            db.AddParameter("@SubType2", value.SubType2);
            db.AddParameter("@Contract_Number2", value.Contract_Number2);
            db.AddParameter("@Desc2", value.Desc2);
            db.AddParameter("@SubAmount2", value.SubAmount2);
            db.AddParameter("@SubCode3", value.SubCode3);
            db.AddParameter("@SubType3", value.SubType3);
            db.AddParameter("@Contract_Number3", value.Contract_Number3);
            db.AddParameter("@Desc3", value.Desc3);
            db.AddParameter("@SubAmount3", value.SubAmount3);
            db.AddParameter("@PTD_ADV", value.PTD_ADV);
            db.AddParameter("@InsPrem", value.InsPrem);
            db.AddParameter("@BranchCode", value.BranchCode);
            db.AddParameter("@AlertMsg", value.BranchCode);
            
            try
            {
                string SQL = "INSERT INTO " + sTableSuccess + " ([Bank_Code], [Tax_Invoice], [Contract_Number], [Action], [OR1_Number], [Collected_Agent_Collector], [OR2_Number], [Payment_Type], [Received_From], [Amount], [TR_NO], [Receipt_Date], [GL_Amount], [BSB_Code], [Cheque_No], [Cheque_Date], [InterID], [SubCode1], [SubType1], [Contract_Number1], [GASubType], [Desc1], [SubAmount1], [SubCode2], [SubType2], [Contract_Number2], [Desc2], [SubAmount2], [SubCode3], [SubType3], [Contract_Number3], [Desc3], [SubAmount3], [PTD_ADV], [InsPrem], [BranchCode], [AlertMsg]) VALUES (@Bank_Code, @Tax_Invoice, @Contract_Number, @Action, @OR1_Number, @Collected_Agent_Collector, @OR2_Number, @Payment_Type, @Received_From, @Amount, @TR_NO, @Receipt_Date, @GL_Amount, @BSB_Code, @Cheque_No, @Cheque_Date, @InterID, @SubCode1, @SubType1, @Contract_Number1, @GASubType, @Desc1, @SubAmount1, @SubCode2, @SubType2, @Contract_Number2, @Desc2, @SubAmount2, @SubCode3, @SubType3, @Contract_Number3, @Desc3, @SubAmount3, @PTD_ADV, @InsPrem, @BranchCode, @AlertMsg)";  
                db.ExecuteNonQuery(SQL, CommandType.Text);
            }
            catch
            {
                throw;
            }
        }

        public static DATA_SV51D_Collection GetFailReceipts2()
        {
            var result = new DATA_SV51D_Collection();

            PruDBHelp db = new PruDBHelp();
            DataTable dt = db.ExecuteDataTable("SELECT * FROM " + sTableError, CommandType.Text);

            foreach (DataRow row in dt.Rows)
                result.Add(new DATA_SV51D(row));

            return result;
        }

        public static DATA_SV51D_Collection GetSuccessReceipts2()
        {
            var result = new DATA_SV51D_Collection();

            PruDBHelp db = new PruDBHelp();
            DataTable dt = db.ExecuteDataTable("SELECT * FROM " + sTableSuccess, CommandType.Text);

            foreach (DataRow row in dt.Rows)
                result.Add(new DATA_SV51D(row));

            return result;
        }

        public static DataTable GetSuccessReceipts()
        {
            PruDBHelp db = new PruDBHelp();
            DataTable dt = db.ExecuteDataTable(@"SELECT [Bank_Code], [Tax_Invoice], [Contract_Number], [Action], [OR1_Number], [Collected_Agent_Collector], [OR2_Number], [Payment_Type], [Received_From], [Amount], [TR_NO], [Receipt_Date], [GL_Amount], [BSB_Code], [Cheque_No], [Cheque_Date], [InterID], [SubCode1], [SubType1], [Contract_Number1], [GASubType], [Desc1], [SubAmount1], [SubCode2], [SubType2], [Contract_Number2], [Desc2], [SubAmount2], [SubCode3], [SubType3], [Contract_Number3], [Desc3], [SubAmount3], [PTD_ADV], [InsPrem], [BranchCode], [AlertMsg]                                                
                                                FROM " + sTableSuccess, CommandType.Text);

            return dt;
        }

        public static DataTable GetFailReceipts()
        {
            PruDBHelp db = new PruDBHelp();
            DataTable dt = db.ExecuteDataTable(@"SELECT [message], [Bank_Code], [Tax_Invoice], [Contract_Number], [Action], [OR1_Number], [Collected_Agent_Collector], [OR2_Number], [Payment_Type], [Received_From], [Amount], [TR_NO], [Receipt_Date], [GL_Amount], [BSB_Code], [Cheque_No], [Cheque_Date], [InterID], [SubCode1], [SubType1], [Contract_Number1], [GASubType], [Desc1], [SubAmount1], [SubCode2], [SubType2], [Contract_Number2], [Desc2], [SubAmount2], [SubCode3], [SubType3], [Contract_Number3], [Desc3], [SubAmount3], [PTD_ADV], [InsPrem], [BranchCode], [AlertMsg]
                                                FROM " + sTableError, CommandType.Text);

            return dt;
        }

        public static DataTable GetFailReceiptsEx()
        {
            PruDBHelp db = new PruDBHelp();
            DataTable dt = db.ExecuteDataTable(@"SELECT [Bank_Code], [Tax_Invoice], [Contract_Number], [Action], [OR1_Number], [Collected_Agent_Collector], [OR2_Number], [Payment_Type], [Received_From], [Amount], [TR_NO], [Receipt_Date], [GL_Amount], [BSB_Code], [Cheque_No], [Cheque_Date], [InterID], [SubCode1], [SubType1], [Contract_Number1], [GASubType], [Desc1], [SubAmount1], [SubCode2], [SubType2], [Contract_Number2], [Desc2], [SubAmount2], [SubCode3], [SubType3], [Contract_Number3], [Desc3], [SubAmount3], [PTD_ADV], [InsPrem], [BranchCode], [AlertMsg]                                               
                                                FROM " + sTableError, CommandType.Text);

            return dt;
        }

        public static void ClearSuccessReceipts()
        {
            PruDBHelp db = new PruDBHelp();
            db.ExecuteNonQuery("delete from " + sTableSuccess, CommandType.Text);
        }

        public static void ClearFailReceipts()
        {
            PruDBHelp db = new PruDBHelp();
            db.ExecuteNonQuery("delete from " + sTableError, CommandType.Text);
        }

        public static bool CheckExist(DATA_SV51D value)
        {
            bool result = false;
            PruDBHelp db = new PruDBHelp();
            db.AddParameter("@Tax_Invoice", value.Tax_Invoice);
            //db.AddParameter("@Prop_No", value.Prop_No);
            DataTable dt = db.ExecuteDataTable(@"SELECT count(*)                                            
                                                 FROM " + sTableError + " where Tax_Invoice=@Tax_Invoice", CommandType.Text);

            int count = Common.CommonHelper.ToInt(dt.Rows[0][0].ToString());
            if (count > 0) result = true;
            return result;
        }
    }
}
