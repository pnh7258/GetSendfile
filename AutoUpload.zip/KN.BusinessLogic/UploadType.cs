﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KN.BusinessLogic
{
    public class UploadType
    {
        public int ID { get; set; }
        public string Description { get; set; }
        public bool IsUse { get; set; }

        public UploadType()
        {
        }

        public UploadType(int iID, string sDescription, bool bIsUse)
        {
            ID = iID;
            Description = sDescription;
            IsUse = bIsUse;
        }
    }
}
