﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KN.BusinessLogic
{
    public class Agent
    {

        public string PoposalNo { get; set; }
        public string AgentCode { get; set; }
        public string Commission { get; set; }
        public string BonusPoints { get; set; }
        public Agent()
        {
            this.AgentCode = "";
            this.BonusPoints = "";
            this.Commission = "";
        }
    }
}
