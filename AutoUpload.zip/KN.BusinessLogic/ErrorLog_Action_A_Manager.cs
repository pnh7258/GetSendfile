﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using KN.DataAcess;
namespace KN.BusinessLogic
{
    public static class ErrorLog_Action_A_Manager
    {
        private static ErrorLog_Action_A GetObjectFromReader(IDataReader dataReader)
        {
            try
            {
                ErrorLog_Action_A obj = new ErrorLog_Action_A();
                obj.ProposalNo = KNDataHelper.GetString(dataReader, "ProposalNo");
                obj.ClientNo = KNDataHelper.GetString(dataReader, "ClientNo");                
                obj.ReceiptNo = KNDataHelper.GetString(dataReader, "ReceiptNo");
                obj.Description = KNDataHelper.GetString(dataReader, "Description");
                obj.BranchCode = KNDataHelper.GetString(dataReader, "BranchCode");
                
                return obj;
            }
            catch
            {
                throw;
            }
        }

        public static ErrorLog_Action_A_Collection AllErrorLogLoad()
        {
            var result = new ErrorLog_Action_A_Collection();
            PruDBHelp db = new PruDBHelp();
            try
            {
                using (IDataReader dataReader = db.ExecuteReader("select * from Logs_Action_A", CommandType.Text))
                {
                    while (dataReader.Read())
                    {
                        result.Add(GetObjectFromReader(dataReader));
                    }
                }
                return result;
            }
            catch
            {                
                throw;
            }
        }

        public static DataTable AllErrorLogLoad2()
        {
            PruDBHelp db = new PruDBHelp();
            DataTable dt = db.ExecuteDataTable(@"select * from Logs_Action_A", CommandType.Text);

            return dt;
        }

        public static void ErrorLogInsert(string ProposalNo, string ClientNo, string ReceiptNo, string ClientID, string ReceiptID, string BranchCode, string Description)
        {
            var result = new ErrorLog_Action_A_Collection();
            PruDBHelp db = new PruDBHelp();

            //if (CheckExist(ClientID, ReceiptID) == false)
            //{
                db.AddParameter("@ProposalNo", ProposalNo);
                db.AddParameter("@ClientNo", ClientNo);
                db.AddParameter("@ReceiptNo", ReceiptNo);
                db.AddParameter("@ClientID", ClientID);
                db.AddParameter("@ReceiptID", ReceiptID);
                db.AddParameter("@BranchCode", BranchCode);                
                db.AddParameter("@Description", Description);
                db.ExecuteNonQuery("insert into Logs_Action_A(ProposalNo, ClientNo, ReceiptNo, ClientID, ReceiptID, BranchCode, Description) values (@ProposalNo, @ClientNo, @ReceiptNo, @ClientID, @ReceiptID, @BranchCode, @Description)", CommandType.Text);
            //}
            //else
            //{
            //    db.AddParameter("@Description", Description);
            //    db.AddParameter("@ClientID", ClientID);
            //    db.AddParameter("@ReceiptID", ReceiptID);
            //    db.ExecuteNonQuery("UPDATE Logs_Action_A SET Description = Description + '|' +  @Description WHERE ClientID=@ClientID and ReceiptID=@ReceiptID", CommandType.Text);
            //}

        }

        public static bool CheckExist(string ClientID, string ReceiptID)
        {
            bool result = false;
            PruDBHelp db = new PruDBHelp();
            db.AddParameter("@ClientID", ClientID);
            db.AddParameter("@ReceiptID", ReceiptID);
            DataTable dt = db.ExecuteDataTable(@"SELECT count(*)                                            
                                                 FROM Logs_Action_A where ClientID=@ClientID and ReceiptID=@ReceiptID", CommandType.Text);

            int count = Common.CommonHelper.ToInt(dt.Rows[0][0].ToString());
            if (count > 0) result = true;
            return result;
        }

        public static void ErrorLogClear()
        {
            PruDBHelp db = new PruDBHelp();

            db.ExecuteNonQuery("delete from Logs_Action_A", CommandType.Text);
        }

        public static DataTable GetDataForGANET()
        {
            PruDBHelp db = new PruDBHelp();
            DataTable dt = db.ExecuteDataTable(@"SELECT [ClientID], [ReceiptID], [ClientNo], [ReceiptNo], [Description]                                        
                                                 FROM Logs_Action_A", CommandType.Text);

            return dt;
        }
    }
}
