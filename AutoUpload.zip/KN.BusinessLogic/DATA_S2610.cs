﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KN.BusinessLogic
{
    public class DATA_S2610
    {
        public string OR_No_1 { get; set; }
        public string OR_No_2 { get; set; }
        public string OR_No_3 { get; set; }
        public string OR_No_4 { get; set; }
        public string CollectedAgentCollector { get; set; }
        public string TransID { get; set; }
        public string PaymType { get; set; }
        public string RS { get; set; }
        public string BankCode { get; set; }
        public string TranDate { get; set; }
        public string SBR { get; set; }
        public string ReceivedFr { get; set; }
        public string ClientCode { get; set; }
        public string Amount { get; set; }
        public string GLAmount { get; set; }
        public string TRNo { get; set; }
        public string RcptDte { get; set; }
        public string PropNo { get; set; }
        public string Bank { get; set; }
        public string BSBCode { get; set; }
        public string Branch { get; set; }
        public string CheNo { get; set; }
        public string Date { get; set; }
        public string Account { get; set; }
        public string InterfaceID { get; set; }
        public string EffDte { get; set; }
        public string MainAgent { get; set; }

        public string SubCode1 { get; set; }
        public string SubType1 { get; set; }
        public string Desc1 { get; set; }
        public string SubAmount1 { get; set; }

        public DATA_S2610()
        {
        }

        public DATA_S2610(DATA_S2610_ACTION_C client2)
        {
            OR_No_1 = client2.OR_Number;
            //OR_No_2 = client2. ;
            //OR_No_3 = client2. ;
            //OR_No_4 = client2. ;
            CollectedAgentCollector = client2.Collected_Agent_Collector;
            //TransID = client2. ;
            PaymType = client2.Payment_Type;
            //RS = client2. ;
            BankCode = client2.Bank_Code;
            //TranDate = client2. ;
            //SBR = client2. ;
            ReceivedFr = client2.Received_From + client2.Client_Code;
            ClientCode = client2.Client_Code;
            Amount = client2.Amount;
            GLAmount = client2.GL_Amount;
            TRNo = client2.TR_NO;
            RcptDte = client2.Receipt_Date;
            PropNo = client2.Prop_No;
            //Bank = client2. ;
            BSBCode = client2.BSB_Code;
            //Branch = client2. ;
            CheNo = client2.Cheque_No;
            Date = client2.Cheque_Date;
            //Account = client2. ;
            InterfaceID = client2.InterID;
            //EffDte = client2. ;
            MainAgent = client2.Main_Agt;

            SubCode1 = client2.SubCode1;
            SubType1 = client2.SubType1;
            Desc1 = client2.Desc1;
            SubAmount1 = client2.SubAmount1;
        }

        public DATA_S2610(DATA_S2610_ACTION_A data)
        {
            OR_No_1 = data.OR_Number;
            //OR_No_2 = data. ;
            //OR_No_3 = data. ;
            //OR_No_4 = data. ;
            CollectedAgentCollector = data.Collected_Agent_Collector;
            //TransID = data. ;
            PaymType = data.Payment_Type;
            //RS = data. ;
            BankCode = data.Bank_Code;
            //TranDate = data. ;
            //SBR = data. ;
            ReceivedFr = data.Received_From + data.Client_Code;
            //ClientCode = data.Client_Code;
            Amount = data.Amount;
            GLAmount = data.GL_Amount;
            TRNo = data.TR_NO;
            //RcptDte = OR_No_1.Contains("GA") ? null : data.Receipt_Date; //null: get value on screen
            RcptDte = data.Receipt_Date;
            PropNo = data.Prop_No;
            //Bank = data. ;
            BSBCode = data.BSB_Code;
            //Branch = data. ;
            CheNo = data.Cheque_No;
            Date = data.Cheque_Date;
            //Account = data. ;
            InterfaceID = data.InterID;
            //EffDte = data. ;
            MainAgent = data.Main_Agt;

            SubCode1 = data.SubCode1;
            SubType1 = data.SubType1;
            Desc1 = data.Desc1;
            SubAmount1 = data.SubAmount1;
        }
    }
}
