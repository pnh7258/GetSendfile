﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KN.BusinessLogic
{
    public class Basicplan
    {
        public string ProposalNo { get; set; }
        public string SumAssured { get; set; }
        public string MaturityAge_Term { get; set; }
        public string PremiumCessAge_Term { get; set; }
        public string ReserveUnits { get; set; }
        public string ReserveUnitsDate { get; set; }
        public string MortalityClass { get; set; }
        public string JointLife { get; set; }
        public string SpecialTerms { get; set; }
        public string Coverage { get; set; } 
        public string FundSplitPlan { get; set; }
        public string PremAmnt { get; set; }
        public string Role { get; set; }
        public string RiskProfile { get; set; } 
        public FundCollection Funds
        {
            get { return FundManager.FundLoad(ProposalNo); }
        }
    }
}
