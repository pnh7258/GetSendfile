﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using KN.DataAcess;

namespace KN.BusinessLogic
{
    public static class ProductManager
    {
        private static Product GetObjectFromReader(IDataReader dataReader)
        {
            try
            {
                //DATA_S5004

                Product obj = new Product();
                obj.PoposalNo = KNDataHelper.GetString(dataReader, "PoposalNo");
                obj.ContactOwner = KNDataHelper.GetString(dataReader, "ContractOwner");
                obj.ProspectNumber = KNDataHelper.GetString(dataReader, "ProspectNumber");
                obj.IncomeRage = KNDataHelper.GetString(dataReader, "IncomeRange");
                obj.Amount = KNDataHelper.GetString(dataReader, "Amount");
                obj.RiskComDate = KNDataHelper.GetString(dataReader, "RiskCommDate");
                obj.PropDate = KNDataHelper.GetString(dataReader, "PropDate");
                obj.BillingFrequency = KNDataHelper.GetString(dataReader, "BillingFrequency");
                obj.MethodPayment = KNDataHelper.GetString(dataReader, "MethodofPayment");
                obj.TemporaryReceiptDate = KNDataHelper.GetString(dataReader, "TemporaryReceiptDate");
                obj.Agency = KNDataHelper.GetString(dataReader, "Agency");
                obj.DespatchAddress = KNDataHelper.GetString(dataReader, "DespatchAddress");
                obj.Number = KNDataHelper.GetString(dataReader, "PoposalNo");
                obj.TempRcptNo = KNDataHelper.GetString(dataReader, "TempRcptNo");                
                obj.PropRvcDate = KNDataHelper.GetString(dataReader, "PropRvcDate");
                obj.Role = "";
                obj.UWDecDate = "";
                obj.FirstBillingDate = "";
                obj.NoOfPolicy = "";
                obj.ContrastCurrency = "";
                obj.BillCurrency = "";
                obj.NonFFTOpt = "";
                obj.ContrastRegister = "";
                obj.CrossRefType = "";
                obj.SourceOfBussiness = "";
                obj.DupRefNo = "";                
                obj.ServicingBranch = "";
                obj.Campaign = "";
                obj.JointOwner = "";
                obj.Assignee = "";
                obj.Applycash = "";
                obj.Payor = "";
                obj.RevApplyCash = "";
                obj.DirectDebit = "";
                obj.FollowUps = "";
                obj.Commission = "";
                obj.GroupDetails = "";
                obj.Beneficiaries = "";
                obj.ReducingTerm = "";

                return obj;
            }
            catch
            {
                throw;
            }
        }

        public static Product ProductLoad(string PoposalNo)
        {
            PruDBHelp db = new PruDBHelp();
            try
            {
                db.AddParameter("@PoposalNo", PoposalNo);
                
                using (IDataReader dataReader = db.ExecuteReader("select * from DATA_S5004 where PoposalNo = @PoposalNo", CommandType.Text))
                {
                    while (dataReader.Read())
                    {
                        return GetObjectFromReader(dataReader);
                    }
                }
                return null;
            }
            catch
            {
                throw;
            }
        }

        public static void ProductDelete(string PoposalNo)
        {
            PruDBHelp db = new PruDBHelp();
            try
            {
                db.AddParameter("@PoposalNo", PoposalNo);
                db.ExecuteNonQuery("delete from DATA_S5004 where PoposalNo=@PoposalNo", CommandType.Text);                
            }
            catch
            {
                throw;
            }
        }
               

        public static ProductCollection AllProductLoad()
        {
            PruDBHelp db = new PruDBHelp();
            var result = new ProductCollection();
            try
            {                
                using (IDataReader dataReader = db.ExecuteReader("select * from DATA_S5004", CommandType.Text))
                {
                    while (dataReader.Read())
                    {
                        result.Add( GetObjectFromReader(dataReader));
                    }
                }
                return result;
            }
            catch
            {
                throw;                
            }
        }

        public static void UpdateError(string PoposalNo)
        {
            PruDBHelp db = new PruDBHelp();
            try
            {
                string SQL = "insert into ERROR_S5004 ";
                SQL += "select * from DATA_S5004 ";
                SQL += "where PoposalNo=@PoposalNo ";
                db.AddParameter("@PoposalNo", PoposalNo);
                db.ExecuteNonQuery(SQL, CommandType.Text);
            }
            catch
            {
                throw;
            }
        }
    }
}
