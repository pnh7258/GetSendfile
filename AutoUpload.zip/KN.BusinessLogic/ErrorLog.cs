﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KN.BusinessLogic
{
    public class ErrorLog
    {

        public string ProposalNo { get; set; }
        public string ScreenCode { get; set; }
        public string Description { get; set; }        
    }
}
