﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using KN.DataAcess;
namespace KN.BusinessLogic
{
    public class DATA_S2610Manager
    {
        private static DATA_S2610 GetObjectFromReader(IDataReader dataReader)
        {
            try
            {
                //ID												SubCode1	SubType1	Desc1	SubAmount1

                DATA_S2610 obj = new DATA_S2610();
                //CS 010 300 111
                string ORNUM = KNDataHelper.GetString(dataReader, "OR_Number");
                obj.OR_No_1 = ORNUM.Substring(0, 2);
                obj.OR_No_2 = ORNUM.Substring(2, 3);
                obj.OR_No_3 = ORNUM.Substring(5, 3);
                obj.OR_No_4 = ORNUM.Substring(8, 3);
                obj.CollectedAgentCollector = KNDataHelper.GetString(dataReader, "CollectedAgentCollector");
                obj.PaymType = KNDataHelper.GetString(dataReader, "PaymentType");
                obj.ReceivedFr = KNDataHelper.GetString(dataReader, "ReceivedFrom");
                obj.ClientCode = KNDataHelper.GetString(dataReader, "ClientCode");
                obj.Amount = KNDataHelper.GetString(dataReader, "Amount");
                obj.TRNo = KNDataHelper.GetString(dataReader, "TRNO");
                obj.RcptDte = KNDataHelper.GetString(dataReader, "ReceiptDate");
                obj.GLAmount = KNDataHelper.GetString(dataReader, "GLAmount");
                obj.PropNo = KNDataHelper.GetString(dataReader, "PropNo");
                obj.MainAgent = KNDataHelper.GetString(dataReader, "MainAgt");
                obj.SubCode1 = KNDataHelper.GetString(dataReader, "SubCode1");
                obj.SubType1 = KNDataHelper.GetString(dataReader, "SubType1");
                obj.Desc1 = KNDataHelper.GetString(dataReader, "Desc1");
                obj.SubAmount1 = KNDataHelper.GetString(dataReader, "SubAmount1");


                obj.TransID = "";                
                obj.RS = "";
                obj.BankCode = "";
                obj.TranDate = "";
                obj.SBR = "";
                obj.Bank = "";
                obj.BSBCode = "";
                obj.Branch = "";
                obj.CheNo = "";
                obj.Date = "";
                obj.Account = "";
                obj.InterfaceID = "";
                obj.EffDte = "";
                

                
                return obj;
            }
            catch
            {
                throw;
            }
        }

        public static DATA_S2610 DATA_S2610Load(string ID)
        {
            PruDBHelp db = new PruDBHelp();
            try
            {
                db.AddParameter("@ID", ID);

                using (IDataReader dataReader = db.ExecuteReader("select * from DATA_S2610 where ID = @ID", CommandType.Text))
                {
                    while (dataReader.Read())
                    {
                        return GetObjectFromReader(dataReader);
                    }
                }
                return null;
            }
            catch
            {
                throw;
            }
        }

        public static void ClientUpdate(string ID, string ClientCode)
        {
            var result = new ClientCollection();
            PruDBHelp db = new PruDBHelp();
            try
            {
                db.AddParameter("@ClientCode", ClientCode);
                db.AddParameter("@ID", ID);
                db.ExecuteNonQuery("update DATA_S2610 set ClientCode=@ClientCode where ID=@ID", CommandType.Text);
            }
            catch
            {
                throw;
            }
        }

        public static DATA_S2610Collection AllDATA_S2610Load()
        {
            var result = new DATA_S2610Collection();
            PruDBHelp db = new PruDBHelp();
            try
            {                
                using (IDataReader dataReader = db.ExecuteReader("select * from DATA_S2610", CommandType.Text))
                {
                    while (dataReader.Read())
                    {
                        result.Add(GetObjectFromReader(dataReader));
                    }
                }
                return result;
            }
            catch
            {                
                throw;
            }
        }

        public static void DATA_S2610UpdateForCS()
        {           
            PruDBHelp db = new PruDBHelp();
            try
            {
                db.ExecuteNonQuery("update DATA_S2610 set ReceivedFrom='CN', PaymentType='1', SubCode1='SC', SubType1='I', Desc1='Phi BH tam thu HS', SubAmount1= Amount, GLAmount=Amount", CommandType.Text);
            }
            catch
            {
                throw;
            }
        }

        public static void UpdateError(string ID)
        {
            PruDBHelp db = new PruDBHelp();
            try
            {
                string SQL = "insert into ERROR_S2610 ";
                SQL += "select * from DATA_S2610 ";
                SQL += "where ID=@ID ";
                db.AddParameter("@ID", ID);
                db.ExecuteNonQuery(SQL, CommandType.Text);
            }
            catch
            {
                throw;
            }
        }
    }
}
