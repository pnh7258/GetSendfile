﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KN.BusinessLogic
{
    public class LifeMenu
    {

        public int X { get; set; }
        public int Y { get; set; }
        public int Leng { get; set; }
        public string MenuName { get; set; }        
    }
}
