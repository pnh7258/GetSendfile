﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using KN.DataAcess;
namespace KN.BusinessLogic
{
    public class AgentManager
    {
        private static Agent GetObjectFromReader(IDataReader dataReader)
        {
            try
            {
                //DATA_S5007
                //No.	PoposalNo	PolicyNo	Agency	Commission	Bonuspoints
                Agent obj = new Agent();
                obj.PoposalNo = KNDataHelper.GetString(dataReader, "PoposalNo");
                obj.AgentCode = KNDataHelper.GetString(dataReader, "Agency");
                obj.Commission = KNDataHelper.GetString(dataReader, "Commission");
                obj.BonusPoints = KNDataHelper.GetString(dataReader, "BonusPoints");                
                return obj;
            }
            catch
            {
                throw;
            }
        }

        public static Agent AgentLoad(string PoposalNo, string AgentCode)
        {
            PruDBHelp db = new PruDBHelp();
            try
            {
                db.AddParameter("@PoposalNo", PoposalNo);
                db.AddParameter("@Agency", AgentCode);

                using (IDataReader dataReader = db.ExecuteReader("select * from DATA_S5007 where PoposalNo = @PoposalNo and Agency=@AgentCode", CommandType.Text))
                {
                    while (dataReader.Read())
                    {
                        return GetObjectFromReader(dataReader);
                    }
                }
                return null;
            }
            catch
            {
                throw;
            }
        }

        public static AgentCollection AgentLoad(string PoposalNo)
        {
            var result = new AgentCollection();
            PruDBHelp db = new PruDBHelp();
            try
            {
                db.AddParameter("@PoposalNo", PoposalNo);                

                using (IDataReader dataReader = db.ExecuteReader("select * from DATA_S5007 where PoposalNo = @PoposalNo", CommandType.Text))
                {
                    while (dataReader.Read())
                    {
                        result.Add( GetObjectFromReader(dataReader));
                    }
                }
                return result;
            }
            catch
            {                
                throw;
            }
        }

        public static AgentCollection AllAgentLoad()
        {
            var result = new AgentCollection();
            PruDBHelp db = new PruDBHelp();
            try
            {                
                using (IDataReader dataReader = db.ExecuteReader("select * from DATA_S5007", CommandType.Text))
                {
                    while (dataReader.Read())
                    {
                        result.Add(GetObjectFromReader(dataReader));
                    }
                }
                return result;
            }
            catch
            {                
                throw;
            }
        }

        public static void UpdateError(string PoposalNo)
        {
            PruDBHelp db = new PruDBHelp();
            try
            {
                string SQL = "insert into ERROR_S5007 ";
                SQL += "select * from DATA_S5007 ";
                SQL += "where PoposalNo=@PoposalNo ";
                db.AddParameter("@PoposalNo", PoposalNo);
                db.ExecuteNonQuery(SQL, CommandType.Text);
            }
            catch
            {
                throw;
            }
        }

        public static AgentCollection ReadAgentFromExcel(string file)
        {
            var result =new AgentCollection();
            var agent1 = new KN.BusinessLogic.Agent();
            agent1.AgentCode = "60000001";
            agent1.Commission = "100";
            agent1.BonusPoints = "100";

            result.Add(agent1);

            var agent2 = new KN.BusinessLogic.Agent();
            agent2.AgentCode = "60020209";
            agent2.Commission = "50";
            agent2.BonusPoints = "50";

            //result.Add(agent2);

            for (int i = 0; i < 8; i++ )
            {
                result.Add(new Agent());
            }
            return result;
        }
    }
}
