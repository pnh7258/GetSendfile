﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using KN.DataAcess;
using KN.Systems;

namespace KN.BusinessLogic
{
    public class DATA_S2610_ACTION_C_Manager
    {
        private static string sTableData = "DATA_S2465_2";
        private static string sTableError = "ERROR_S2465_2";
        private static string sTableSuccess = "SUCCESS_S2465_2";

        public static DATA_S2610_ACTION_C_Collection GetAllClients()
        {
            var result = new DATA_S2610_ACTION_C_Collection();

            PruDBHelp db = new PruDBHelp();
            DataTable dt = db.ExecuteDataTable("SELECT * FROM DATA_S2465_2", CommandType.Text);

            foreach (DataRow row in dt.Rows)
                result.Add(new DATA_S2610_ACTION_C(row));

            return result;
        }

        public static DataTable GetAllClients2()
        {
            PruDBHelp db = new PruDBHelp();
            DataTable dt = db.ExecuteDataTable("SELECT * FROM DATA_S2465_2", CommandType.Text);
               
            return dt;
        }

        public static void UploadClients(string csvFilePath)
        {
            var dt = ExcelProcess.ReadCSV(csvFilePath, true);
            ExcelProcess.Table_Import("S2465_2", dt);
        }

        public static void ClientUpdate(string ID, string Client_Code)
        {           
            PruDBHelp db = new PruDBHelp();
            try
            {
                db.AddParameter("@Client_Code", Client_Code);
                db.AddParameter("@ID", ID);
                db.ExecuteNonQuery("update DATA_S2465_2 set Client_Code=@Client_Code where ID=@ID", CommandType.Text);
            }
            catch
            {
                throw;
            }
        }

        //public static void UpdateError(string PoposalNo)
        //{
        //    PruDBHelp db = new PruDBHelp();
        //    try
        //    {
        //        string SQL = "insert into ERROR_S2465_2 ";
        //        SQL += "select * from DATA_S2465_2 ";
        //        SQL += "where Prop_No='" + PoposalNo + "'";
        //        db.ExecuteNonQuery(SQL, CommandType.Text);
        //    }
        //    catch
        //    {
        //        throw;
        //    }
        //}

        public static void InsertError(DATA_S2610_ACTION_C value, string message)
        {
            PruDBHelp db = new PruDBHelp();
            db.AddParameter("@Surname", value.Surname);
            db.AddParameter("@Gurname", value.Gurname);
            db.AddParameter("@RName", value.RName);
            db.AddParameter("@Location", value.Location);
            db.AddParameter("@Salutation", value.Salutation);
            db.AddParameter("@Sex", value.Sex);
            db.AddParameter("@Married", value.Married);
            db.AddParameter("@Street", value.Street);
            db.AddParameter("@ID", value.ID);
            db.AddParameter("@PhoneM", value.PhoneM);
            db.AddParameter("@PhoneC", value.PhoneC);
            db.AddParameter("@PhoneH", value.PhoneH);
            db.AddParameter("@Occupation", value.Occupation);
            db.AddParameter("@BirthDate", value.BirthDate);
            db.AddParameter("@SoE", value.SoE);
            db.AddParameter("@Billing_Frequency", value.Billing_Frequency);
            db.AddParameter("@Contract_Type", value.Contract_Type);
            db.AddParameter("@Bank_Code", value.Bank_Code);
            db.AddParameter("@Tax_Invoice", value.Tax_Invoice);
            db.AddParameter("@Contract_Number", value.Contract_Number);
            db.AddParameter("@Action", value.Action);
            db.AddParameter("@OR_Number", value.OR_Number);
            db.AddParameter("@Collected_Agent_Collector", value.Collected_Agent_Collector);
            db.AddParameter("@Payment_Type", value.Payment_Type);
            db.AddParameter("@Received_From", value.Received_From);
            db.AddParameter("@Client_Code", value.Client_Code);
            db.AddParameter("@Amount", value.Amount);
            db.AddParameter("@TR_NO", value.TR_NO);
            db.AddParameter("@Receipt_Date", value.Receipt_Date == null ? "" : value.Receipt_Date);
            db.AddParameter("@GL_Amount", value.GL_Amount);
            db.AddParameter("@BSB_Code", value.BSB_Code);
            db.AddParameter("@Cheque_No", value.Cheque_No);
            db.AddParameter("@Cheque_Date", value.Cheque_Date);
            db.AddParameter("@InterID", value.InterID);
            db.AddParameter("@Prop_No", value.Prop_No);
            db.AddParameter("@Main_Agt", value.Main_Agt);
            db.AddParameter("@SubCode1", value.SubCode1);
            db.AddParameter("@SubType1", value.SubType1);
            db.AddParameter("@Contract_Number1", value.Contract_Number1);
            db.AddParameter("@Desc1", value.Desc1);
            db.AddParameter("@SubAmount1", value.SubAmount1);
            db.AddParameter("@SubCode2", value.SubCode2);
            db.AddParameter("@SubType2", value.SubType2);
            db.AddParameter("@Contract_Number2", value.Contract_Number2);
            db.AddParameter("@Desc2", value.Desc2);
            db.AddParameter("@SubAmount2", value.SubAmount2);
            db.AddParameter("@SubCode3", value.SubCode3);
            db.AddParameter("@SubType3", value.SubType3);
            db.AddParameter("@Contract_Number3", value.Contract_Number3);
            db.AddParameter("@Desc3", value.Desc3);
            db.AddParameter("@SubAmount3", value.SubAmount3);
            db.AddParameter("@PTD_ADV", value.PTD_ADV);
            db.AddParameter("@InsPrem", value.InsPrem);
            db.AddParameter("@CLIENT_TAX_CODE", value.CLIENT_TAX_CODE);
            db.AddParameter("@ClientID", value.ClientID);
            db.AddParameter("@ReceiptID", value.ReceiptID);
            db.AddParameter("@BranchCode", value.BranchCode);
            db.AddParameter("@message", message);

            try
            {
                string SQL = "";
                //if (CheckExist(value) == false)
                //{
                    SQL = "INSERT INTO " + sTableError + " ([Surname], [Gurname], [RName], [Location], [Salutation], [Sex], [Married], [Street], [ID], [PhoneM], [PhoneC], [PhoneH], [Occupation], [BirthDate], [SoE], [Billing_Frequency], [Contract_Type], [Bank_Code], [Tax_Invoice], [Contract_Number], [Action], [OR_Number], [Collected_Agent_Collector], [Payment_Type], [Received_From], [Client_Code], [Amount], [TR_NO], [Receipt_Date], [GL_Amount], [BSB_Code], [Cheque_No], [Cheque_Date], [InterID], [Prop_No], [Main_Agt], [SubCode1], [SubType1], [Contract_Number1], [Desc1], [SubAmount1], [SubCode2], [SubType2], [Contract_Number2], [Desc2], [SubAmount2], [SubCode3], [SubType3], [Contract_Number3], [Desc3], [SubAmount3], [PTD_ADV], [InsPrem], [CLIENT_TAX_CODE], [ClientID], [ReceiptID], [BranchCode], [message]) VALUES (@Surname, @Gurname, @RName, @Location, @Salutation, @Sex, @Married, @Street, @ID, @PhoneM, @PhoneC, @PhoneH, @Occupation, @BirthDate, @SoE, @Billing_Frequency, @Contract_Type, @Bank_Code, @Tax_Invoice, @Contract_Number, @Action, @OR_Number, @Collected_Agent_Collector, @Payment_Type, @Received_From, @Client_Code, @Amount, @TR_NO, @Receipt_Date, @GL_Amount, @BSB_Code, @Cheque_No, @Cheque_Date, @InterID, @Prop_No, @Main_Agt, @SubCode1, @SubType1, @Contract_Number1, @Desc1, @SubAmount1, @SubCode2, @SubType2, @Contract_Number2, @Desc2, @SubAmount2, @SubCode3, @SubType3, @Contract_Number3, @Desc3, @SubAmount3, @PTD_ADV, @InsPrem, @CLIENT_TAX_CODE, @ClientID, @ReceiptID, @BranchCode, @message)";
                //}
                //else
                //{
                //    db.ClearParameter();
                //    db.AddParameter("@message", message);
                //    db.AddParameter("@Tax_Invoice", value.Tax_Invoice);
                //    SQL = "UPDATE " + sTableError + " SET message = message + '|' +  @message WHERE Tax_Invoice=@Tax_Invoice";
                //}
                db.ExecuteNonQuery(SQL, CommandType.Text);
            }
            catch
            {
                throw;
            }
        }

        public static void InsertSuccess(DATA_S2610_ACTION_C value)
        {
            PruDBHelp db = new PruDBHelp();
            db.AddParameter("@Surname", value.Surname);
            db.AddParameter("@Gurname", value.Gurname);
            db.AddParameter("@RName", value.RName);
            db.AddParameter("@Location", value.Location);
            db.AddParameter("@Salutation", value.Salutation);
            db.AddParameter("@Sex", value.Sex);
            db.AddParameter("@Married", value.Married);
            db.AddParameter("@Street", value.Street);
            db.AddParameter("@ID", value.ID);
            db.AddParameter("@PhoneM", value.PhoneM);
            db.AddParameter("@PhoneC", value.PhoneC);
            db.AddParameter("@PhoneH", value.PhoneH);
            db.AddParameter("@Occupation", value.Occupation);
            db.AddParameter("@BirthDate", value.BirthDate);
            db.AddParameter("@SoE", value.SoE);
            db.AddParameter("@Billing_Frequency", value.Billing_Frequency);
            db.AddParameter("@Contract_Type", value.Contract_Type);
            db.AddParameter("@Bank_Code", value.Bank_Code);
            db.AddParameter("@Tax_Invoice", value.Tax_Invoice);
            db.AddParameter("@Contract_Number", value.Contract_Number);
            db.AddParameter("@Action", value.Action);
            db.AddParameter("@OR_Number", value.OR_Number);
            db.AddParameter("@Collected_Agent_Collector", value.Collected_Agent_Collector);
            db.AddParameter("@Payment_Type", value.Payment_Type);
            db.AddParameter("@Received_From", value.Received_From);
            db.AddParameter("@Client_Code", value.Client_Code);
            db.AddParameter("@Amount", value.Amount);
            db.AddParameter("@TR_NO", value.TR_NO);
            db.AddParameter("@Receipt_Date", value.Receipt_Date);
            db.AddParameter("@GL_Amount", value.GL_Amount);
            db.AddParameter("@BSB_Code", value.BSB_Code);
            db.AddParameter("@Cheque_No", value.Cheque_No);
            db.AddParameter("@Cheque_Date", value.Cheque_Date);
            db.AddParameter("@InterID", value.InterID);
            db.AddParameter("@Prop_No", value.Prop_No);
            db.AddParameter("@Main_Agt", value.Main_Agt);
            db.AddParameter("@SubCode1", value.SubCode1);
            db.AddParameter("@SubType1", value.SubType1);
            db.AddParameter("@Contract_Number1", value.Contract_Number1);
            db.AddParameter("@Desc1", value.Desc1);
            db.AddParameter("@SubAmount1", value.SubAmount1);
            db.AddParameter("@SubCode2", value.SubCode2);
            db.AddParameter("@SubType2", value.SubType2);
            db.AddParameter("@Contract_Number2", value.Contract_Number2);
            db.AddParameter("@Desc2", value.Desc2);
            db.AddParameter("@SubAmount2", value.SubAmount2);
            db.AddParameter("@SubCode3", value.SubCode3);
            db.AddParameter("@SubType3", value.SubType3);
            db.AddParameter("@Contract_Number3", value.Contract_Number3);
            db.AddParameter("@Desc3", value.Desc3);
            db.AddParameter("@SubAmount3", value.SubAmount3);
            db.AddParameter("@PTD_ADV", value.PTD_ADV);
            db.AddParameter("@InsPrem", value.InsPrem);
            db.AddParameter("@CLIENT_TAX_CODE", value.CLIENT_TAX_CODE);
            db.AddParameter("@ClientID", value.ClientID);            
            db.AddParameter("@ReceiptID", value.ReceiptID);
            db.AddParameter("@BranchCode", value.BranchCode);

            db.AddParameter("@Country", value.Country);
            db.AddParameter("@UStax", value.UStax);
            db.AddParameter("@BirthCountry", value.BirthCountry);
            db.AddParameter("@MobileCode", value.MobileCode);
            db.AddParameter("@CompCode", value.CompCode);
            db.AddParameter("@HomeCode", value.HomeCode);
            db.AddParameter("@Nationality", value.Nationality);
            try
            {
                string SQL = "INSERT INTO " + sTableSuccess + " ([Surname], [Gurname], [RName], [Location], [Salutation], [Sex], [Married], [Street], [ID], [PhoneM], [PhoneC], [PhoneH], [Occupation], [BirthDate], [SoE], [Billing_Frequency], [Contract_Type], [Bank_Code], [Tax_Invoice], [Contract_Number], [Action], [OR_Number], [Collected_Agent_Collector], [Payment_Type], [Received_From], [Client_Code], [Amount], [TR_NO], [Receipt_Date], [GL_Amount], [BSB_Code], [Cheque_No], [Cheque_Date], [InterID], [Prop_No], [Main_Agt], [SubCode1], [SubType1], [Contract_Number1], [Desc1], [SubAmount1], [SubCode2], [SubType2], [Contract_Number2], [Desc2], [SubAmount2], [SubCode3], [SubType3], [Contract_Number3], [Desc3], [SubAmount3], [PTD_ADV], [InsPrem], [CLIENT_TAX_CODE], [ClientID], [ReceiptID], [BranchCode], Country, UStax, BirthCountry, MobileCode, CompCode, HomeCode, Nationality) VALUES (@Surname, @Gurname, @RName, @Location, @Salutation, @Sex, @Married, @Street, @ID, @PhoneM, @PhoneC, @PhoneH, @Occupation, @BirthDate, @SoE, @Billing_Frequency, @Contract_Type, @Bank_Code, @Tax_Invoice, @Contract_Number, @Action, @OR_Number, @Collected_Agent_Collector, @Payment_Type, @Received_From, @Client_Code, @Amount, @TR_NO, @Receipt_Date, @GL_Amount, @BSB_Code, @Cheque_No, @Cheque_Date, @InterID, @Prop_No, @Main_Agt, @SubCode1, @SubType1, @Contract_Number1, @Desc1, @SubAmount1, @SubCode2, @SubType2, @Contract_Number2, @Desc2, @SubAmount2, @SubCode3, @SubType3, @Contract_Number3, @Desc3, @SubAmount3, @PTD_ADV, @InsPrem, @CLIENT_TAX_CODE, @ClientID, @ReceiptID, @BranchCode, @Country, @UStax, @BirthCountry, @MobileCode, @CompCode, @HomeCode, @Nationality)";              
                db.ExecuteNonQuery(SQL, CommandType.Text);
            }
            catch
            {
                throw;
            }
        }

        public static DATA_S2610_ACTION_C_Collection GetFailClients2()
        {
            var result = new DATA_S2610_ACTION_C_Collection();

            PruDBHelp db = new PruDBHelp();
            DataTable dt = db.ExecuteDataTable("SELECT * FROM ERROR_S2465_2", CommandType.Text);

            foreach (DataRow row in dt.Rows)
                result.Add(new DATA_S2610_ACTION_C(row));

            return result;
        }

        public static DATA_S2610_ACTION_C_Collection GetSuccessClients2()
        {
            var result = new DATA_S2610_ACTION_C_Collection();

            PruDBHelp db = new PruDBHelp();
            DataTable dt = db.ExecuteDataTable("SELECT * FROM SUCCESS_S2465_2", CommandType.Text);

            foreach (DataRow row in dt.Rows)
                result.Add(new DATA_S2610_ACTION_C(row));

            return result;
        }

        public static DataTable GetSuccessClients()
        {
            PruDBHelp db = new PruDBHelp();
            DataTable dt = db.ExecuteDataTable(@"SELECT [Surname], [Gurname], [RName], [Location], [Salutation], [Sex], [Married], [Street], [ID], [PhoneM], [PhoneC], [PhoneH], [Occupation], [BirthDate], [SoE], [Billing_Frequency], [Contract_Type], [Bank_Code], [Tax_Invoice], [Contract_Number], [Action], [OR_Number], [Collected_Agent_Collector], [Payment_Type], [Received_From], [Client_Code], [Amount], [TR_NO], [Receipt_Date], [GL_Amount], [BSB_Code], [Cheque_No], [Cheque_Date], [InterID], [Prop_No], [Main_Agt], [SubCode1], [SubType1], [Contract_Number1], [Desc1], [SubAmount1], [SubCode2], [SubType2], [Contract_Number2], [Desc2], [SubAmount2], [SubCode3], [SubType3], [Contract_Number3], [Desc3], [SubAmount3], [PTD_ADV], [InsPrem], [CLIENT_TAX_CODE], [ClientID], [ReceiptID] ,[BranchCode], Country, UStax, BirthCountry, MobileCode, CompCode, HomeCode, Nationality                                                   
                                                 FROM " + sTableSuccess, CommandType.Text);

            return dt;
        }

        public static DataTable GetFailClients()
        {
            PruDBHelp db = new PruDBHelp();
            DataTable dt = db.ExecuteDataTable(@"SELECT [message], [Surname], [Gurname], [RName], [Location], [Salutation], [Sex], [Married], [Street], [ID], [PhoneM], [PhoneC], [PhoneH], [Occupation], [BirthDate], [SoE], [Billing_Frequency], [Contract_Type], [Bank_Code], [Tax_Invoice], [Contract_Number], [Action], [OR_Number], [Collected_Agent_Collector], [Payment_Type], [Received_From], [Client_Code], [Amount], [TR_NO], [Receipt_Date], [GL_Amount], [BSB_Code], [Cheque_No], [Cheque_Date], [InterID], [Prop_No], [Main_Agt], [SubCode1], [SubType1], [Contract_Number1], [Desc1], [SubAmount1], [SubCode2], [SubType2], [Contract_Number2], [Desc2], [SubAmount2], [SubCode3], [SubType3], [Contract_Number3], [Desc3], [SubAmount3], [PTD_ADV], [InsPrem], [CLIENT_TAX_CODE], [BranchCode], Country, UStax, BirthCountry, MobileCode, CompCode, HomeCode, Nationality                                                
                                                 FROM " + sTableError, CommandType.Text);

            return dt;
        }

        public static DataTable GetFailClientsEx()
        {
            PruDBHelp db = new PruDBHelp();
            DataTable dt = db.ExecuteDataTable(@"SELECT [message], [Bank_Code], [Tax_Invoice], [Contract_Number], [Action], [OR_Number], [Collected_Agent_Collector], [Payment_Type], [Received_From], [Client_Code], [Amount], [TR_NO], [Receipt_Date], [GL_Amount], [BSB_Code], [Cheque_No], [Cheque_Date], [InterID], [Prop_No], [Main_Agt], [SubCode1], [SubType1], [Contract_Number1], [Desc1], [SubAmount1], [SubCode2], [SubType2], [Contract_Number2], [Desc2], [SubAmount2], [SubCode3], [SubType3], [Contract_Number3], [Desc3], [SubAmount3], [PTD_ADV], [InsPrem], [CLIENT_TAX_CODE], [ClientID], [ReceiptID], [BranchCode]
                                                 FROM " + sTableError, CommandType.Text);

            return dt;
        }

        public static bool CheckExist(DATA_S2610_ACTION_C value)
        {
            bool result = false;
            PruDBHelp db = new PruDBHelp();
            db.AddParameter("@Tax_Invoice", value.Tax_Invoice);            
            DataTable dt = db.ExecuteDataTable(@"SELECT count(*)                                            
                                                 FROM " + sTableError + " where Tax_Invoice=@Tax_Invoice", CommandType.Text);

            int count = Common.CommonHelper.ToInt(dt.Rows[0][0].ToString());
            if (count > 0) result = true;
            return result;
        }

        public static void ClearSuccessClients()
        {
            PruDBHelp db = new PruDBHelp();
            db.ExecuteNonQuery("delete from " + sTableSuccess, CommandType.Text);
        }

        public static void ClearFailClients()
        {
            PruDBHelp db = new PruDBHelp();
            db.ExecuteNonQuery("delete from " + sTableError, CommandType.Text);
        }

       
    }
}
