﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KN.BusinessLogic
{
    public class DATA_SV51L
    {

        public string ReceivedDate { get; set; }
        public string ApplicationNumber { get; set; }
        public string BillingFrequency { get; set; }
        public string ContractType { get; set; }
        public string Add_Y_N { get; set; }

        public DATA_SV51L()
        { 
        }

        public DATA_SV51L(DATA_S2610_ACTION_C client2)
        {
            ReceivedDate = client2.Receipt_Date;
            ApplicationNumber = client2.Prop_No;
            BillingFrequency = client2.Billing_Frequency;
            ContractType = client2.Contract_Type;
        }
    }
}
