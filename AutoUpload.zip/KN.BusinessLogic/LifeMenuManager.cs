﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using KN.DataAcess;
namespace KN.BusinessLogic
{
    public class LifeMenuManager
    {
        private static LifeMenu GetObjectFromReader(IDataReader dataReader)
        {
            try
            {
                
                LifeMenu obj = new LifeMenu();
                obj.X = KNDataHelper.GetInt(dataReader, "X");
                obj.Y = KNDataHelper.GetInt(dataReader, "Y");
                obj.Leng = KNDataHelper.GetInt(dataReader, "Leng");
                obj.MenuName = KNDataHelper.GetString(dataReader, "MenuName");                
                return obj;
            }
            catch
            {
                throw;
            }
        }

        //public static LifeMenu LifeMenuLoad(string LifeMenuname)
        //{
        //    PruDBHelp db = new PruDBHelp();
        //    try
        //    {
        //        db.AddParameter("@LifeMenuName", LifeMenuname);

        //        using (IDataReader dataReader = db.ExecuteReader("select * from LifeMenu where LifeMenuName = @LifeMenuName", CommandType.Text))
        //        {
        //            while (dataReader.Read())
        //            {
        //                return GetObjectFromReader(dataReader);
        //            }
        //        }
        //        return null;
        //    }
        //    catch
        //    {
        //        throw;
        //    }
        //}

        public static LifeMenuCollection MenuLoad(string MenuName)
        {
            var result = new LifeMenuCollection();
            PruDBHelp db = new PruDBHelp();
            try
            {
                db.AddParameter("@MenuName", MenuName);

                using (IDataReader dataReader = db.ExecuteReader("select * from Menu where MenuName = @MenuName", CommandType.Text))
                {
                    while (dataReader.Read())
                    {
                        result.Add( GetObjectFromReader(dataReader));
                    }
                }
                return result;
            }
            catch
            {                
                throw;
            }
        }

        public static LifeMenuCollection AllMenuLoad()
        {
            var result = new LifeMenuCollection();
            PruDBHelp db = new PruDBHelp();
            try
            {                
                using (IDataReader dataReader = db.ExecuteReader("select * from Menu", CommandType.Text))
                {
                    while (dataReader.Read())
                    {
                        result.Add(GetObjectFromReader(dataReader));
                    }
                }
                return result;
            }
            catch
            {                
                throw;
            }
        }

        
    }
}
