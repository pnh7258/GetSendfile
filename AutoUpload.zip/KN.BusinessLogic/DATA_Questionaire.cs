﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace KN.BusinessLogic
{
    public class DATA_Questionaire
    {
        public string ContractNumber { get; set; }
        public string LifeAssured { get; set; }
        public string Question { get; set; }
        public string Answer { get; set; }
        

        public DATA_Questionaire()
        { 
        }

        public DATA_Questionaire(string ContractNumber, string LifeAssured, string Question)
        {
            this.ContractNumber = ContractNumber;
            this.LifeAssured = LifeAssured;
            this.Question = Question;
            this.Answer = "";
        }

        public DATA_Questionaire(DataRow row)
        {
            ContractNumber = row["ContractNumber"].ToString();
            LifeAssured = row["LifeAssured"].ToString();
            Question = row["Question"].ToString();
            Answer = row["Answer"].ToString();
        }
    }
}
