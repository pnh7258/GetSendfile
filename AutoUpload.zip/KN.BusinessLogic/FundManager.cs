﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using KN.DataAcess;
namespace KN.BusinessLogic
{
    public static class FundManager
    {
        private static Fund GetObjectFromReader(IDataReader dataReader)
        {
            try
            {
                //DATA_S5417
                //No.

                Fund obj = new Fund();
                obj.PoposalNo = KNDataHelper.GetString(dataReader, "PoposalNo");
                obj.FundCode=KNDataHelper.GetString(dataReader, "Fund");
                obj.Amount=KNDataHelper.GetString(dataReader, "Amount");
                obj.Price=KNDataHelper.GetString(dataReader, "Price");
                obj.FundSplitPlan = KNDataHelper.GetString(dataReader, "FundSplitPlan");
                return obj;
            }
            catch
            {
                throw;
            }
        }

        public static Fund FundLoad(string PoposalNo, string FundCode)
        {
            PruDBHelp db = new PruDBHelp();
            try
            {
                db.AddParameter("@PoposalNo", PoposalNo);
                db.AddParameter("@Fund", FundCode);

                using (IDataReader dataReader = db.ExecuteReader("select * from DATA_S5417 where PoposalNo = @PoposalNo and Fund=@FundCode", CommandType.Text))
                {
                    while (dataReader.Read())
                    {
                        return GetObjectFromReader(dataReader);
                    }
                }
                return null;
            }
            catch
            {
                throw;
            }
        }

        public static FundCollection FundLoad(string PoposalNo)
        {
            var result = new FundCollection();
            PruDBHelp db = new PruDBHelp();
            try
            {
                db.AddParameter("@PoposalNo", PoposalNo);

                using (IDataReader dataReader = db.ExecuteReader("select * from DATA_S5417 where PoposalNo = @PoposalNo", CommandType.Text))
                {
                    while (dataReader.Read())
                    {
                        result.Add(GetObjectFromReader(dataReader));
                    }
                }
                return result;
            }
            catch
            {                
                throw;
            }
        }

        public static FundCollection AllFundLoad()
        {
            var result = new FundCollection();
            PruDBHelp db = new PruDBHelp();
            try
            {               
                using (IDataReader dataReader = db.ExecuteReader("select * from DATA_S5417", CommandType.Text))
                {
                    while (dataReader.Read())
                    {
                        result.Add(GetObjectFromReader(dataReader));
                    }
                }
                return result;
            }
            catch
            {                
                throw;
            }
        }

        public static void UpdateError(string PoposalNo)
        {
            PruDBHelp db = new PruDBHelp();
            try
            {
                string SQL = "insert into ERROR_S5417 ";
                SQL += "select * from DATA_S5417 ";
                SQL += "where PoposalNo=@PoposalNo ";
                db.AddParameter("@PoposalNo", PoposalNo);
                db.ExecuteNonQuery(SQL, CommandType.Text);
            }
            catch
            {
                throw;
            }
        }

        public static FundCollection LoadFundByExcelProposal(int Proposal)
        {
            FundCollection result = new FundCollection();

            result.Add(new Fund("UEQ1", "10", ""));
            result.Add(new Fund("UGR1", "10", ""));
            result.Add(new Fund("UBL1", "10", ""));
            result.Add(new Fund("USB1", "10", ""));
            result.Add(new Fund("UFI1", "10", ""));
            result.Add(new Fund("UPS1", "50", ""));

            return result;
        }

        public static FundCollection ReadFundFromExcel(string file)
        {
            FundCollection result = new FundCollection();

            result.Add(new Fund("UEQ1", "10", ""));
            result.Add(new Fund("UGR1", "10", ""));
            result.Add(new Fund("UBL1", "10", ""));
            result.Add(new Fund("USB1", "10", ""));
            result.Add(new Fund("UFI1", "10", ""));
            result.Add(new Fund("UPS1", "50", ""));

            return result;
        }

    }
}
