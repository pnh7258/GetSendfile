﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using KN.DataAcess;
namespace KN.BusinessLogic
{
    public static class ErrorLogManager
    {
        private static ErrorLog GetObjectFromReader(IDataReader dataReader)
        {
            try
            {
                ErrorLog obj = new ErrorLog();
                obj.ProposalNo = KNDataHelper.GetString(dataReader, "ProposalNo");
                obj.ScreenCode = KNDataHelper.GetString(dataReader, "ScreenCode");
                obj.Description = KNDataHelper.GetString(dataReader, "Description");
                return obj;
            }
            catch
            {
                throw;
            }
        }

        
        public static ErrorLogCollection AllErrorLogLoad()
        {
            var result = new ErrorLogCollection();
            PruDBHelp db = new PruDBHelp();
            try
            {
                using (IDataReader dataReader = db.ExecuteReader("select * from Logs order by ProposalNo", CommandType.Text))
                {
                    while (dataReader.Read())
                    {
                        result.Add(GetObjectFromReader(dataReader));
                    }
                }
                return result;
            }
            catch
            {                
                throw;
            }
        }

        public static void ErrorLogInsert(string ProposalNo, string Description)
        {
            var result = new ErrorLogCollection();
            PruDBHelp db = new PruDBHelp();
            db.AddParameter("@ProposalNo", ProposalNo);
            db.AddParameter("@Description", Description);
            db.ExecuteNonQuery("insert into Logs(ProposalNo, Description) values (@ProposalNo, @Description)", CommandType.Text);
        }

        public static void ErrorLogClear()
        {
            PruDBHelp db = new PruDBHelp();
            
            db.ExecuteNonQuery("Delete from Logs", CommandType.Text);
        }
    }
}
