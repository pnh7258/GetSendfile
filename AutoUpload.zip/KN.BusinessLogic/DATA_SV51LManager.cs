﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using KN.DataAcess;
namespace KN.BusinessLogic
{
    public class DATA_SV51LManager
    {
        private static DATA_SV51L GetObjectFromReader(IDataReader dataReader)
        {
            try
            {                
                DATA_SV51L obj = new  DATA_SV51L();
                
                obj.ApplicationNumber = KNDataHelper.GetString(dataReader, "ApplicationNo");
                obj.BillingFrequency = KNDataHelper.GetString(dataReader, "BillingFrequency");
                obj.ContractType = KNDataHelper.GetString(dataReader, "ContractType");
                obj.Add_Y_N = KNDataHelper.GetString(dataReader, "Add_Y_N");
                obj.ReceivedDate = "";
                
                return obj;
            }
            catch
            {
                throw;
            }
        }

        public static DATA_SV51L DATA_SV51LLoad(string ApplicationNo)
        {
            PruDBHelp db = new PruDBHelp();
            try
            {
                db.AddParameter("@ApplicationNo", ApplicationNo);

                using (IDataReader dataReader = db.ExecuteReader("select * from  DATA_SV51L where ApplicationNo = @ApplicationNo", CommandType.Text))
                {
                    while (dataReader.Read())
                    {
                        return GetObjectFromReader(dataReader);
                    }
                }
                return null;
            }
            catch
            {
                throw;
            }
        }
              

        public static  DATA_SV51LCollection AllDATA_SV51LLoad()
        {
            var result = new  DATA_SV51LCollection();
            PruDBHelp db = new PruDBHelp();
            try
            {                
                using (IDataReader dataReader = db.ExecuteReader("select * from  DATA_SV51L", CommandType.Text))
                {
                    while (dataReader.Read())
                    {
                        result.Add(GetObjectFromReader(dataReader));
                    }
                }
                return result;
            }
            catch
            {                
                throw;
            }
        }

        public static void UpdateError(string ApplicationNo)
        {
            PruDBHelp db = new PruDBHelp();
            try
            {
                string SQL = "insert into ERROR_SV51L ";
                SQL += "select * from DATA_SV51L ";
                SQL += "where ApplicationNo=@ApplicationNo ";
                db.AddParameter("@ApplicationNo", ApplicationNo);
                db.ExecuteNonQuery(SQL, CommandType.Text);
            }
            catch
            {
                throw;
            }
        }
    }
}
