﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KN.BusinessLogic
{
    public class ErrorLog_Action_A
    {
        public string ProposalNo { get; set; }
        public string ClientNo { get; set; }        
        public string ReceiptNo { get; set; }
        public string Description { get; set; }
        public string BranchCode { get; set; }
    }
}
