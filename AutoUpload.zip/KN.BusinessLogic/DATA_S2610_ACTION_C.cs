﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace KN.BusinessLogic
{
    public class DATA_S2610_ACTION_C
    {
        public string Surname { get; set; }
        public string Gurname { get; set; }
        public string RName { get; set; }
        public string Location { get; set; }
        public string Salutation { get; set; }
        public string Sex { get; set; }
        public string Married { get; set; }
        public string Street { get; set; }
        public string ID { get; set; }
        public string PhoneM { get; set; }
        public string PhoneC { get; set; }
        public string PhoneH { get; set; }
        public string Occupation { get; set; }
        public string BirthDate { get; set; }
        public string SoE = "ID";
        public string Billing_Frequency { get; set; }
        public string Contract_Type { get; set; }
        public string Bank_Code { get; set; }
        public string Tax_Invoice { get; set; }
        public string Contract_Number { get; set; }
        public string Action { get; set; }
        public string OR_Number { get; set; }
        public string Collected_Agent_Collector { get; set; }
        public string Payment_Type { get; set; }
        public string Received_From { get; set; }
        public string Client_Code { get; set; }
        public string Amount { get; set; }
        public string TR_NO { get; set; }
        public string Receipt_Date { get; set; }
        public string GL_Amount { get; set; }
        public string BSB_Code { get; set; }
        public string Cheque_No { get; set; }
        public string Cheque_Date { get; set; }
        public string InterID { get; set; }
        public string Prop_No { get; set; }
        public string Main_Agt { get; set; }
        public string SubCode1 { get; set; }
        public string SubType1 { get; set; }
        public string Contract_Number1 { get; set; }
        public string Desc1 { get; set; }
        public string SubAmount1 { get; set; }
        public string SubCode2 { get; set; }
        public string SubType2 { get; set; }
        public string Contract_Number2 { get; set; }
        public string Desc2 { get; set; }
        public string SubAmount2 { get; set; }
        public string SubCode3 { get; set; }
        public string SubType3 { get; set; }
        public string Contract_Number3 { get; set; }
        public string Desc3 { get; set; }
        public string SubAmount3 { get; set; }
        public string PTD_ADV { get; set; }
        public string InsPrem { get; set; }
        public string CLIENT_TAX_CODE { get; set; }
        public bool NeedToKeyReceipt { get; set; }

        public string InternetAddress{ get; set; }  
        public string Category{ get; set; }
        public string ClientID { get; set; }
        public string ReceiptID { get; set; }
        public string BranchCode { get; set; }

        public string Country { get; set; }
        public string UStax { get; set; }
        public string BirthCountry { get; set; }
        public string MobileCode { get; set; }
        public string CompCode { get; set; }
        public string HomeCode { get; set; }
        public string Nationality { get; set; }
        //public bool IsDespatchAddress
        //{
        //    get
        //    {
        //        if (DA_Location == "" && DA_PhoneM == "" && DA_PhoneC == "" && DA_PhoneH == "")
        //            return false;
        //        else
        //            return true;
        //    }
        //}
       
        //public string DA_Location { get; set; }
        //public string DA_Street { get; set; }
        //public string DA_PhoneM { get; set; }
        //public string DA_PhoneC { get; set; }
        //public string DA_PhoneH { get; set; }

        public DATA_S2610_ACTION_C()
        {
        }

        public DATA_S2610_ACTION_C(DataRow row)
        {
            Surname = row["Surname"].ToString();
            Gurname = row["Gurname"].ToString();
            RName = row["RName"].ToString();
            Location = row["Location"].ToString();
            Salutation = row["Salutation"].ToString();
            Sex = row["Sex"].ToString();
            Married = row["Married"].ToString();
            Street = row["Street"].ToString().Replace('|', ',');
            ID = row["ID"].ToString();
            PhoneM = row["PhoneM"].ToString();
            PhoneC = row["PhoneC"].ToString();
            PhoneH = row["PhoneH"].ToString();
            Occupation = row["Occupation"].ToString();
            BirthDate = row["BirthDate"].ToString();
            //SoE = row["SoE"].ToString();
            Billing_Frequency = row["Billing_Frequency"].ToString();
            Contract_Type = row["Contract_Type"].ToString();
            Bank_Code = row["Bank_Code"].ToString();
            Tax_Invoice = row["Tax_Invoice"].ToString();
            Contract_Number = row["Contract_Number"].ToString();
            Action = row["Action"].ToString();
            OR_Number = row["OR_Number"].ToString();
            Collected_Agent_Collector = row["Collected_Agent_Collector"].ToString();
            Payment_Type = row["Payment_Type"].ToString();
            Received_From = row["Received_From"].ToString();
            Client_Code = row["Client_Code"].ToString();
            Amount = row["Amount"].ToString();
            TR_NO = row["TR_NO"].ToString();
            Receipt_Date = row["Receipt_Date"].ToString();
            //Receipt_Date = (OR_Number.Contains("GA") || OR_Number.Contains("CS")) ? null : row["Receipt_Date"].ToString();
            GL_Amount = row["GL_Amount"].ToString();
            BSB_Code = row["BSB_Code"].ToString();
            Cheque_No = row["Cheque_No"].ToString();
            Cheque_Date = row["Cheque_Date"].ToString();
            InterID = row["InterID"].ToString();
            Prop_No = row["Prop_No"].ToString();
            Main_Agt = row["Main_Agt"].ToString();
            SubCode1 = row["SubCode1"].ToString();
            SubType1 = row["SubType1"].ToString();
            Contract_Number1 = row["Contract_Number1"].ToString();
            Desc1 = row["Desc1"].ToString();
            SubAmount1 = row["SubAmount1"].ToString();
            SubCode2 = row["SubCode2"].ToString();
            SubType2 = row["SubType2"].ToString();
            Contract_Number2 = row["Contract_Number2"].ToString();
            Desc2 = row["Desc2"].ToString();
            SubAmount2 = row["SubAmount2"].ToString();
            SubCode3 = row["SubCode3"].ToString();
            SubType3 = row["SubType3"].ToString();
            Contract_Number3 = row["Contract_Number3"].ToString();
            Desc3 = row["Desc3"].ToString();
            SubAmount3 = row["SubAmount3"].ToString();
            PTD_ADV = row["PTD_ADV"].ToString();
            InsPrem = row["InsPrem"].ToString();
            CLIENT_TAX_CODE = row["CLIENT_TAX_CODE"].ToString();
            InternetAddress = row["InternetAddress"].ToString();
            Category = row["Category"].ToString();
            ClientID = row["ClientID"].ToString();
            ReceiptID = row["ReceiptID"].ToString();

            //DA_Location = row["DA_Location"].ToString();
            //DA_Street = row["DA_Street"].ToString();
            //DA_PhoneM = row["DA_PhoneM"].ToString();
            //DA_PhoneC = row["DA_PhoneC"].ToString();
            //DA_PhoneH = row["DA_PhoneH"].ToString();
            BranchCode = row["BranchCode"].ToString();

            Country = row["Country"].ToString();
            UStax = row["UStax"].ToString();
            BirthCountry = row["BirthCountry"].ToString();
            MobileCode = row["MobileCode"].ToString();
            CompCode = row["CompCode"].ToString();
            HomeCode = row["HomeCode"].ToString();
            Nationality = row["Nationality"].ToString();
            NeedToKeyReceipt = false;
        }
    }
}
