﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KN.BusinessLogic
{
    public class DATA_ACTION_D_Collection : List<DATA_ACTION_D>
    {
    }
}
