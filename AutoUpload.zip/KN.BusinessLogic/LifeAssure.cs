﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KN.BusinessLogic
{
    public class LifeAssure
    {
        public string PoposalNo { get; set; }
        public string ContrastNumber {get;set;}
        public string LifeNo { get; set; }
        public string Life { get; set; }
        public string Sex { get; set; }
        public string DateOfBirth { get; set; }
        public string MedicalEvidence { get; set; }
        public string Smoking { get; set; }
        public string PursuitCode1 { get; set; }
        public string PursuitCode2 { get; set; }
        public string Height { get; set; }
        public string Weight { get; set; }
        public string Role { get; set; } 
    }
}
