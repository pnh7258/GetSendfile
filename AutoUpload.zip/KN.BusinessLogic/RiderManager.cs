﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using KN.DataAcess;

namespace KN.BusinessLogic
{
    public static class RiderManager
    {
        private static Rider GetObjectFromReader(IDataReader dataReader)
        {
            try
            {
                //  DATA_Products
                //	PolicyNo	ClientNo		Riderno			TotalPremium		

                Rider obj = new Rider();
                obj.ProposalNo = KNDataHelper.GetString(dataReader, "PoposalNo");
                obj.Role = KNDataHelper.GetString(dataReader, "Role");
                obj.LifeNo = KNDataHelper.GetString(dataReader, "LifeNo");
                obj.ClientNo = KNDataHelper.GetString(dataReader, "ClientNo");
                obj.Code = KNDataHelper.GetString(dataReader, "Rider");                
                obj.Benefit_Amount = KNDataHelper.GetString(dataReader, "SumassuredBenefitAmount");
                obj.Risk_Cess_Age_Term = KNDataHelper.GetString(dataReader, "MaturityTermRiskCessTerm");
                obj.Coverage = KNDataHelper.GetString(dataReader, "Coverage");
                obj.Mortality_Class = KNDataHelper.GetString(dataReader, "MortalityClass");
                obj.Special_Terms = "";
                obj.Prem_Cess_Age_Term="";
                obj.Bene_Cess_Age_Term="";
                obj.Option="";
                //obj.Name = "";

                return obj;
            }
            catch
            {
                throw;
            }
        }

        public static Rider RiderLoad(string PoposalNo, string ProductCode, string Role)
        {
            PruDBHelp db = new PruDBHelp();
            try
            {
                db.AddParameter("@PoposalNo", PoposalNo);
                db.AddParameter("@Rider", ProductCode);
                db.AddParameter("@Role", Role);
                using (IDataReader dataReader = db.ExecuteReader("select * from DATA_Products where PoposalNo = @PoposalNo and Rider=@ProductCode and Role=@Role order by Lifeno, Riderno", CommandType.Text))
                {
                    while (dataReader.Read())
                    {
                        return GetObjectFromReader(dataReader);
                    }
                }
                return null;
            }
            catch
            {
                throw;
            }
        }

        public static RiderCollection RiderLoad(string PoposalNo, string Role)
        {
            var result = new RiderCollection();
            PruDBHelp db = new PruDBHelp();
            try
            {
                db.AddParameter("@PoposalNo", PoposalNo);
                db.AddParameter("@Role", Role);

                using (IDataReader dataReader = db.ExecuteReader("select * from DATA_Products where PoposalNo = @PoposalNo and Role=@Role order by Lifeno, Riderno", CommandType.Text))
                {
                    while (dataReader.Read())
                    {
                        result.Add(GetObjectFromReader(dataReader));
                    }
                }
                return result;
            }
            catch
            {
                throw;
            }
        }
        public static RiderCollection AllRiderLoad()
        {
            var result = new RiderCollection();
            PruDBHelp db = new PruDBHelp();
            try
            {
                using (IDataReader dataReader = db.ExecuteReader("select * from DATA_Products order by Lifeno, Riderno", CommandType.Text))
                {
                    while (dataReader.Read())
                    {
                        result.Add(GetObjectFromReader(dataReader));
                    }
                }
                return result;
            }
            catch
            {
                throw;
            }
        }

        public static void UpdateError(string PoposalNo)
        {
            PruDBHelp db = new PruDBHelp();
            try
            {
                string SQL = "insert into ERROR_Products ";
                SQL += "select * from DATA_Products ";
                SQL += "where PoposalNo=@PoposalNo ";
                db.AddParameter("@PoposalNo", PoposalNo);
                db.ExecuteNonQuery(SQL, CommandType.Text);
            }
            catch
            {
                throw;
            }
        }
    }
}
