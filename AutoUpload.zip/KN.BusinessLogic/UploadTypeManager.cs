﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using KN.DataAcess;

namespace KN.BusinessLogic
{
    public class UploadTypeManager
    {
        public static UploadTypeCollection GetAllUploadType()
        {
            UploadTypeCollection result = new UploadTypeCollection();

            PruDBHelp db = new PruDBHelp();
            DataTable dt = db.ExecuteDataTable("SELECT * FROM UploadType WHERE IsUse=Yes", CommandType.Text);

            foreach (DataRow row in dt.Rows)
            {
                int iID = int.Parse(row["ID"].ToString());
                string sDescription = row["Description"].ToString();
                bool bIsUse = Convert.ToBoolean(row["IsUse"]);

                result.Add(new UploadType(iID, sDescription, bIsUse));
            }

            return result;
        }
    }
}
