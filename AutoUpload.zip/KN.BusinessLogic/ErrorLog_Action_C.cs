﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KN.BusinessLogic
{
    public class ErrorLog_Action_C
    {
        public string ClientID { get; set; }
        public string ReceiptID { get; set; }
        public string ProposalNo { get; set; }
        public string TR_No { get; set; }
        public string ClientNo { get; set; }
        public string Surname { get; set; }
        public string Gurname { get; set; }
        public string ID { get; set; }
        public string BirthDate { get; set; }
        public string ReceiptNo { get; set; }
        public string BranchCode { get; set; }
        //country | ustax | birthcountry | mobilecode | compcode | homecode
        public string Country { get; set; }
        public string UStax { get; set; }
        public string BirthCountry { get; set; }
        public string MobileCode { get; set; }
        public string CompCode { get; set; }
        public string HomeCode { get; set; }
        public string Nationality { get; set; }
        public string Description { get; set; }        
    }
}
