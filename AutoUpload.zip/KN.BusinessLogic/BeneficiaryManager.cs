﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using KN.DataAcess;
namespace KN.BusinessLogic
{
    public class BeneficiaryManager
    {
        private static Beneficiary GetObjectFromReader(IDataReader dataReader)
        {
            try
            {
                //DATA_S5010
                
                Beneficiary obj = new Beneficiary();                
                obj.PoposalNo = KNDataHelper.GetString(dataReader, "PoposalNo");
                obj.Relation = KNDataHelper.GetString(dataReader, "Relation");                
                obj.ShareCode = KNDataHelper.GetString(dataReader, "ShareCode");
                obj.ClientNo = KNDataHelper.GetString(dataReader, "Beneficiary");
                obj.EffectiveFrom = KNDataHelper.GetString(dataReader, "EffectiveFrom");
                obj.Role = KNDataHelper.GetString(dataReader, "Role");
                obj.N = "";

                return obj;
            }
            catch
            {
                throw;
            }
        }
               

        public static BeneficiaryCollection BeneficiaryLoad(string PoposalNo)
        {
            var result = new BeneficiaryCollection();
            PruDBHelp db = new PruDBHelp();
            try
            {
                db.AddParameter("@PoposalNo", PoposalNo);

                using (IDataReader dataReader = db.ExecuteReader("select * from DATA_S5010 where PoposalNo = @PoposalNo", CommandType.Text))
                {
                    while (dataReader.Read())
                    {
                        result.Add( GetObjectFromReader(dataReader));
                    }
                }
                return result;
            }
            catch
            {                
                throw;
            }
        }

        public static void UpdateError(string PoposalNo)
        {
            PruDBHelp db = new PruDBHelp();
            try
            {
                string SQL = "insert into ERROR_S5010 ";
                SQL += "select * from DATA_S5010 ";
                SQL += "where PoposalNo=@PoposalNo ";
                db.AddParameter("@PoposalNo", PoposalNo);
                db.ExecuteNonQuery(SQL, CommandType.Text);
            }
            catch
            {
                throw;
            }
        }

        public static BeneficiaryCollection AllBeneficiaryLoad()
        {
            var result = new BeneficiaryCollection();
            PruDBHelp db = new PruDBHelp();
            try
            {                
                using (IDataReader dataReader = db.ExecuteReader("select * from DATA_S5010", CommandType.Text))
                {
                    while (dataReader.Read())
                    {
                        result.Add(GetObjectFromReader(dataReader));
                    }
                }
                return result;
            }
            catch
            {                
                throw;
            }
        }

        public static BeneficiaryCollection ReadBeneficiaryFromExcel(string file)
        {
            var result =new BeneficiaryCollection();
            
            return result;
        }
    }
}
