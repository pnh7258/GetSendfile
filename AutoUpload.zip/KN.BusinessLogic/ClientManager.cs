﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using KN.DataAcess;

namespace KN.BusinessLogic
{
    public static class ClientManager
    {
        private static Client GetObjectFromReader(IDataReader dataReader)
        {
            try
            {
                //DATA_S2465
                //No.	Role
                
                Client obj = new Client();
                obj.ProposalNo = KNDataHelper.GetString(dataReader, "ProposalNo");
                obj.ClientID = KNDataHelper.GetString(dataReader, "ClientNo");
                obj.SurName = KNDataHelper.GetString(dataReader, "Surname");
                obj.GivName = KNDataHelper.GetString(dataReader, "GivenName");
                obj.RefName = KNDataHelper.GetString(dataReader, "PrefName");
                obj.Location = KNDataHelper.GetString(dataReader, "ZIPCode");
                obj.Salutation = KNDataHelper.GetString(dataReader, "Salutation");
                obj.Sex = KNDataHelper.GetString(dataReader, "Sex");
                obj.Married = KNDataHelper.GetString(dataReader, "Married");
                obj.Street = KNDataHelper.GetString(dataReader, "Street");
                obj.ID = KNDataHelper.GetString(dataReader, "ID");
                obj.MobliePhone = KNDataHelper.GetString(dataReader, "TelM");
                obj.WorkPhone = KNDataHelper.GetString(dataReader, "TelC");
                obj.HomePhone = KNDataHelper.GetString(dataReader, "TelH");
                obj.Occupation = KNDataHelper.GetString(dataReader, "Occupation");
                obj.BirthDay = KNDataHelper.GetString(dataReader, "BirthDate");
                obj.SoE = KNDataHelper.GetString(dataReader, "SoE");
                obj.CheckDuplicate = " ";
                obj.Role = KNDataHelper.GetString(dataReader, "Role");
                obj.RelationShip = KNDataHelper.GetString(dataReader, "RelationShip");
                obj.Category = KNDataHelper.GetString(dataReader, "Category");
                obj.InternetAddress = KNDataHelper.GetString(dataReader, "InternetAddress");
                obj.TaxIDNumber = KNDataHelper.GetString(dataReader, "TaxIDNumber");
                obj.Additional = "X";

                obj.SrvBranch = "";
                obj.Inception = "";
                obj.Ward = "";
                obj.District = "";
                obj.City = "";
                obj.Country = "";
                obj.BusOrRes = "";
                obj.NameFormat = "";
                obj.Nationality = "";
                obj.CompDoctor = "";
                obj.Employment = "";
                obj.Language = "";                
                obj.BirthPlace = "";
                obj.DocumentNo = "";
                obj.DeathDate = "";
                obj.VIP = "";
                obj.Mailing = "";
                obj.DirectMail = "";
                obj.CustomerInfoUpdate = "";
                obj.SalaryHist = "";
                obj.SSRetention = "";
                
                obj.FUp = "";

                return obj;
            }
            catch
            {
                throw;
            }
        }

        public static void UpdateError(string PoposalNo)
        {
            PruDBHelp db = new PruDBHelp();
            try
            {
                string SQL = "insert into ERROR_S2465 ";
                SQL += "select * from DATA_S2465 ";
                SQL += "where PoposalNo=@PoposalNo ";
                db.AddParameter("@PoposalNo", PoposalNo);
                db.ExecuteNonQuery(SQL, CommandType.Text);
            }
            catch
            {
                throw;
            }
        }

        public static Client ClientLoad(string ProposalNo, string ID)
        {
            PruDBHelp db = new PruDBHelp();
            try
            {
                db.AddParameter("@PoposalNo", ProposalNo);
                db.AddParameter("@ID", ID);

                using (IDataReader dataReader = db.ExecuteReader("select * from DATA_S2465 where ProposalNo = @ProposalNo and ID=@ID", CommandType.Text))
                {
                    while (dataReader.Read())
                    {
                        return GetObjectFromReader(dataReader);
                    }
                }
                return null;
            }
            catch
            {
                throw;
            }
        }

        public static Client DespatchLoad(string ProposalNo)
        {
            PruDBHelp db = new PruDBHelp();
            try
            {
                db.AddParameter("@PoposalNo", ProposalNo);               

                using (IDataReader dataReader = db.ExecuteReader("select * from DATA_S2465 where ProposalNo = @ProposalNo and Role='DES'", CommandType.Text))
                {
                    while (dataReader.Read())
                    {
                        return GetObjectFromReader(dataReader);
                    }
                }
                return null;
            }
            catch
            {
                throw;
            }
        }
        public static Client POLoad(string ProposalNo)
        {
            PruDBHelp db = new PruDBHelp();
            try
            {
                db.AddParameter("@PoposalNo", ProposalNo);

                using (IDataReader dataReader = db.ExecuteReader("select * from DATA_S2465 where ProposalNo = @ProposalNo and Role='PO'", CommandType.Text))
                {
                    while (dataReader.Read())
                    {
                        return GetObjectFromReader(dataReader);
                    }
                }
                return null;
            }
            catch
            {
                throw;
            }
        }
        public static ClientCollection ClientLoad(string ProposalNo)
        {
            var result = new ClientCollection();
            PruDBHelp db = new PruDBHelp();
            try
            {
                db.AddParameter("@ProposalNo", ProposalNo);

                using (IDataReader dataReader = db.ExecuteReader("select * from DATA_S2465 where ProposalNo = @ProposalNo", CommandType.Text))
                {
                    while (dataReader.Read())
                    {
                        result.Add(GetObjectFromReader(dataReader));
                    }
                }
                return result;
            }
            catch
            {               
                throw;
            }
        }
        public static ClientCollection ClientRelationLoad(string ProposalNo)
        {
            var result = new ClientCollection();
            PruDBHelp db = new PruDBHelp();
            try
            {
                db.AddParameter("@ProposalNo", ProposalNo);

                using (IDataReader dataReader = db.ExecuteReader("select * from DATA_S2465 where ProposalNo = @ProposalNo and Role <> 'PO' and RelationShip <> ''", CommandType.Text))
                {
                    while (dataReader.Read())
                    {
                        result.Add(GetObjectFromReader(dataReader));
                    }
                }
                return result;
            }
            catch
            {
                throw;
            }
        }
        public static List<string> ProposalNoLoad()
        {
            var result = new List<string>();
            PruDBHelp db = new PruDBHelp();
            try
            {

                using (IDataReader dataReader = db.ExecuteReader("select distinct ProposalNo from DATA_S2465", CommandType.Text))
                {
                    while (dataReader.Read())
                    {
                        result.Add(KNDataHelper.GetString(dataReader, "ProposalNo"));
                    }
                }
                return result;
            }
            catch
            {                
                throw;
            }
        }

        public static void ClientUpdate(string ID, string ClientNo)
        {
            var result = new ClientCollection();
            PruDBHelp db = new PruDBHelp();
            try
            {                
                db.AddParameter("@ClientNo", ClientNo);
                db.AddParameter("@ID", ID);
                db.ExecuteNonQuery("update DATA_S2465 set ClientNo=@ClientNo where ID=@ID",CommandType.Text);
            }
            catch
            {                
                throw;
            }
        }

        public static void DespatchUpdate(string ProposalNo, string ClientNo)
        {
            var result = new ClientCollection();
            PruDBHelp db = new PruDBHelp();
            try
            {                
                db.AddParameter("@ClientNo", ClientNo);
                db.AddParameter("@ProposalNo", ProposalNo);

                db.ExecuteNonQuery("update DATA_S2465 set ClientNo=@ClientNo where ProposalNo=@ProposalNo and Role = 'DES'", CommandType.Text);
            }
            catch
            {
                throw;
            }
        }

        public static ClientCollection AllClientLoad()
        {
            var result = new ClientCollection();
            PruDBHelp db = new PruDBHelp();
            try
            { 
                using (IDataReader dataReader = db.ExecuteReader("select * from DATA_S2465", CommandType.Text))
                {
                    while (dataReader.Read())
                    {
                        result.Add(GetObjectFromReader(dataReader));
                    }
                }
                return result;
            }
            catch
            {
                throw;
            }
        }

        public static ClientCollection AllClientLoadExceptDES()
        {
            var result = new ClientCollection();
            PruDBHelp db = new PruDBHelp();
            try
            {
                using (IDataReader dataReader = db.ExecuteReader("select * from DATA_S2465 where Role <> 'DES'", CommandType.Text))
                {
                    while (dataReader.Read())
                    {
                        result.Add(GetObjectFromReader(dataReader));
                    }
                }
                return result;
            }
            catch
            {
                throw;
            }
        }
        public static Client LoadClientByExcelProposal(int Proposal)
        {
            var client = new KN.BusinessLogic.Client();
            client.SrvBranch = "";
            client.Inception = "";
            client.SurName = "KHANG";
            client.GivName = "LE BA";
            client.RefName = "LE BA TRONG KHANG";
            client.Location = "080808";
            client.Salutation = "";
            client.Sex = "F";
            client.Married = "";
            client.Street = "";
            client.Ward = "";
            client.District = "";
            client.City = "";
            client.Country = "";
            client.BusOrRes = "";
            client.ID = "";
            client.MobliePhone = "";
            client.WorkPhone = "";
            client.HomePhone = "";
            client.NameFormat = "";
            client.Nationality = "";
            client.CompDoctor = "";
            client.Employment = "";
            client.Occupation = "";
            client.Language = "";
            client.Category = "";
            client.BirthDay = "";
            client.BirthPlace = "";
            client.SoE = "";
            client.DocumentNo = "";
            client.DeathDate = "";
            client.VIP = "";
            client.Mailing = "";
            client.DirectMail = "";
            client.CustomerInfoUpdate = "";
            client.SalaryHist = "";
            client.SSRetention = "";
            client.Additional = "";
            client.FUp = "";
            client.CheckDuplicate = "";
            return client;
        }

        public static Client ReadClientFromExcel(string file)
        {
            var client = new KN.BusinessLogic.Client();
            client.SrvBranch = "";
            client.Inception = "";
            client.SurName = "KHANG";
            client.GivName = "LE BA";
            client.RefName = "LE BA TRONG KHANG";
            client.Location = "080808";
            client.Salutation = "";
            client.Sex = "F";
            client.Married = "";
            client.Street = "";
            client.Ward = "";
            client.District = "";
            client.City = "";
            client.Country = "";
            client.BusOrRes = "";
            client.ID = "";
            client.MobliePhone = "";
            client.WorkPhone = "";
            client.HomePhone = "";
            client.NameFormat = "";
            client.Nationality = "";
            client.CompDoctor = "";
            client.Employment = "";
            client.Occupation = "";
            client.Language = "";
            client.Category = "";
            client.BirthDay = "";
            client.BirthPlace = "";
            client.SoE = "";
            client.DocumentNo = "";
            client.DeathDate = "";
            client.VIP = "";
            client.Mailing = "";
            client.DirectMail = "";
            client.CustomerInfoUpdate = "";
            client.SalaryHist = "";
            client.SSRetention = "";
            client.Additional = "";
            client.FUp = "";
            client.CheckDuplicate = "";
            return client;
        }

    }
}
