﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace KN.BusinessLogic
{
    public class DATA_S2610_ACTION_A
    {
        public string Bank_Code { get; set; }
        public string Tax_Invoice { get; set; }
        public string Contract_Number { get; set; }
        public string Action { get; set; }
        public string OR_Number { get; set; }
        public string Collected_Agent_Collector { get; set; }
        public string Payment_Type { get; set; }
        public string Received_From { get; set; }
        public string Client_Code { get; set; }
        public string Amount { get; set; }
        public string TR_NO { get; set; }
        public string Receipt_Date { get; set; }
        public string GL_Amount { get; set; }
        public string BSB_Code { get; set; }
        public string Cheque_No { get; set; }
        public string Cheque_Date { get; set; }
        public string InterID { get; set; }
        public string Prop_No { get; set; }
        public string Main_Agt { get; set; }
        public string SubCode1 { get; set; }
        public string SubType1 { get; set; }
        public string Contract_Number1 { get; set; }
        public string Desc1 { get; set; }
        public string SubAmount1 { get; set; }
        public string SubCode2 { get; set; }
        public string SubType2 { get; set; }
        public string Contract_Number2 { get; set; }
        public string Desc2 { get; set; }
        public string SubAmount2 { get; set; }
        public string SubCode3 { get; set; }
        public string SubType3 { get; set; }
        public string Contract_Number3 { get; set; }
        public string Desc3 { get; set; }
        public string SubAmount3 { get; set; }
        public string PTD_ADV { get; set; }
        public string InsPrem { get; set; }
        public string CLIENT_TAX_CODE { get; set; }
        public string ClientID { get; set; }
        public string ReceiptID { get; set; }
        public string BranchCode { get; set; }

        public DATA_S2610_ACTION_A()
        { 
        }

        public DATA_S2610_ACTION_A(DataRow row)
        {
            Bank_Code = row["Bank_Code"].ToString();
            Tax_Invoice = row["Tax_Invoice"].ToString();
            Contract_Number = row["Contract_Number"].ToString();
            Action = row["Action"].ToString();
            OR_Number = row["OR_Number"].ToString();
            Collected_Agent_Collector = row["Collected_Agent_Collector"].ToString();
            Payment_Type = row["Payment_Type"].ToString();
            Received_From = row["Received_From"].ToString();
            Client_Code = row["Client_Code"].ToString();
            Amount = row["Amount"].ToString();
            TR_NO = row["TR_NO"].ToString();
            Receipt_Date = row["Receipt_Date"].ToString();
            GL_Amount = row["GL_Amount"].ToString();
            BSB_Code = row["BSB_Code"].ToString();
            Cheque_No = row["Cheque_No"].ToString();
            Cheque_Date = row["Cheque_Date"].ToString();
            InterID = row["InterID"].ToString();
            Prop_No = row["Prop_No"].ToString();
            Main_Agt = row["Main_Agt"].ToString();
            SubCode1 = row["SubCode1"].ToString();
            SubType1 = row["SubType1"].ToString();
            Contract_Number1 = row["Contract_Number1"].ToString();
            Desc1 = row["Desc1"].ToString();
            SubAmount1 = row["SubAmount1"].ToString();
            SubCode2 = row["SubCode2"].ToString();
            SubType2 = row["SubType2"].ToString();
            Contract_Number2 = row["Contract_Number2"].ToString();
            Desc2 = row["Desc2"].ToString();
            SubAmount2 = row["SubAmount2"].ToString();
            SubCode3 = row["SubCode3"].ToString();
            SubType3 = row["SubType3"].ToString();
            Contract_Number3 = row["Contract_Number3"].ToString();
            Desc3 = row["Desc3"].ToString();
            SubAmount3 = row["SubAmount3"].ToString();
            PTD_ADV = row["PTD_ADV"].ToString();
            InsPrem = row["InsPrem"].ToString();
            CLIENT_TAX_CODE = row["CLIENT_TAX_CODE"].ToString();
            ClientID = row["ClientID"].ToString();
            ReceiptID = row["ReceiptID"].ToString();
            BranchCode = row["BranchCode"].ToString();
        }
    }
}
