﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KN.BusinessLogic
{
    public class DATA_S2610_ACTION_C_Collection: List<DATA_S2610_ACTION_C>
    {
    }
}
