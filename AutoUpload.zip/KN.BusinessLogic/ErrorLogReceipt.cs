﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KN.BusinessLogic
{
    public class ErrorLogReceipt
    {
        public string Tax_Invoice { get; set; }
        public string Contract_Number { get; set; }        
        public string Receipt_No { get; set; }
        public string BranchCode { get; set; }
        public string Description { get; set; }
    }
}
