﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Prudential.CmPritingService.Engine;

namespace KN.SmallAdvancePolicy
{
    [Serializable]
    public class Policy
    {
        /*
        00000862
        00000643
        00000721
        00001102
        00000803
        00001242
        00001123
        00001303
        00002302
        00001061
        00001323
        00001081*/
        //public string ContractNo { get; set; }
        //public string OR1_1 { get; set; }
        //public string OR1_2 { get; set; }
        //public string OR1_3 { get; set; }
        //public string OR1_4 { get; set; }
        //public string Ag_Col { get; set; }
        //public string OR2_1 { get; set; }
        //public string OR2_2 { get; set; }
        //public string OR2_3 { get; set; }
        //public string OR2_4 { get; set; }
        //public string Rs { get; set; }
        //public string TranID { get; set; }
        //public string PTyp { get; set; }
        //public string Tax { get; set; }
        //public string BankCode { get; set; }
        //public string RecDte { get; set; }
        //public string SBr { get; set; }
        //public string ReceivedFr { get; set; }
        //public string Amount { get; set; }
        //public string Currency { get; set; }
        //public string TR_No { get; set; }
        //public string BSB_Code { get; set; }
        //public string ChequeNo { get; set; }
        //public string ChequeDate { get; set; }
        //public string InterfaceID { get; set; }
        //public string GL_Amt { get; set; }
        //public string TRC { get; set; }
        //public string RcptDte { get; set; }

        //Property for action X
        public string Bank_Code { get; set; }
        public string Tax_Invoice { get; set; }
        public string Contract_Number { get; set; }
        public string Action { get; set; }
        public string OR1_Number { get; set; }
        public string Collected_Agent_Collector { get; set; }
        public string OR2_Number { get; set; }
        public string Payment_Type { get; set; }
        public string Received_From { get; set; }
        public string Amount { get; set; }
        public string TR_NO { get; set; }
        public string Receipt_Date{ get; set; }
        public string GL_Amount { get; set; }
        public string BSB_Code { get; set; }
        public string Cheque_No { get; set; }
        public string Cheque_Date { get; set; }
        public string InterID { get; set; }
        public string SubCode1 { get; set; }
        public string SubType1 { get; set; }
        public string Contract_Number1 { get; set; }
        public string GASubType { get; set; }
        public string Desc1 { get; set; }
        public string SubAmount1 { get; set; }
        public string SubCode2 { get; set; }
        public string SubType2 { get; set; }
        public string Contract_Number2 { get; set; }
        public string Desc2 { get; set; }
        public string SubAmount2 { get; set; }
        public string SubCode3 { get; set; }
        public string SubType3 { get; set; }
        public string Contract_Number3 { get; set; }
        public string Desc3 { get; set; }
        public string SubAmount3 { get; set; }
        public string PTD_ADV { get; set; }
        public string InsPrem { get; set; }
        public string branchcode { get; set; }
        public string AlertMsg { get; set; }
        
    }
}
