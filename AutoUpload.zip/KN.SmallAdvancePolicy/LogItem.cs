﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KN.SmallAdvancePolicy
{
    [Serializable]
    public class LogItem
    {
        public string ReceiptNo { get; set; }
        public bool status { get; set; }
        public string TranDate { get; set; }
        public string ErrorMessage { get; set; }
    }
}
