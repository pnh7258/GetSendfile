﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KN.BusinessLogic.Proposal.Command;
using System.Reflection;
using System.IO;
using NVelocity.App;
using Commons.Collections;
using NVelocity;
using NVelocity.Context;
using NVelocity.Runtime;
using KN.BusinessLogic.Proposal.Compiliing;
using KN.BusinessLogic.Proposal;


namespace KN.SmallAdvancePolicy
{
    public class CommandScript
    {
        public List<ScreenBlock> GetScript(Policy policy)
        {
            string script = Template(policy);
            List<ScreenBlock> result = Compile(script);

            return result;
        }

        public string Template(Policy policy)
        {
            string ScriptFilename = @"Policy.prus";

            Uri baseUri = new Uri(Assembly.GetExecutingAssembly().CodeBase);
            string path = Path.GetDirectoryName(baseUri.LocalPath);
            path = Path.Combine(path, "Scripts");

            VelocityEngine velocity = new VelocityEngine();
            ExtendedProperties props = new ExtendedProperties();
            props.AddProperty(RuntimeConstants.FILE_RESOURCE_LOADER_PATH, path);
            velocity.Init(props);

            Template template = velocity.GetTemplate(ScriptFilename, "utf-8");
            VelocityContext context = new VelocityContext();
            context.Put("policy", policy);

            StringWriter writer = new StringWriter();
            template.Merge(context, writer);

            return writer.GetStringBuilder().ToString();
        }

        private List<ScreenBlock> Compile(string script)
        {
            List<ScreenBlock> result = new List<ScreenBlock>();
            ScreenBlockBuilder block = new ScreenBlockBuilder();

            string[] lines = script.Split(new char[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (string line in lines)
            {
                ICommand command = ParseLine(line);
                if (command == null)
                {
                    continue;
                }

                if (command is BeginScreenCommand)
                {
                    block.Begin((BeginScreenCommand)command);
                }
                else if (command is EndScreenCommand)
                {
                    block.End((EndScreenCommand)command);
                }
                else
                {
                    block.Add(command);
                }

                if (!block.Complete)
                {
                    continue;
                }

                result.Add(block.ToScreenBlock());
                block.Clear();
            }
            return result;
        }

        private ICommand ParseLine(string line)
        {
            line = line.Trim();
            if (line.Length == 0)
            {
                return null;
            }

            var command = ParseCommand(line);
            switch (command.Name)
            {
                case "BeginScreen":
                    return BeginScreenCommand.Make(command.Parameters);
                case "ClearError":
                    return new ClearErrorCommand();
                case "ClearTextbox":
                    return new ClearTextboxCommand();
                case "Check":
                    return CheckCommand.Make(command.Parameters);
                case "Input":
                    return InputCommand.Make(command.Parameters);
                case "Label":
                    return new LabelCommand(command.Parameters[0]);
                case "Enter":
                    return new EnterCommand();
                case "F5":
                    return new F5Command();
                case "Goto":
                    return GotoCommand.Make(command.Parameters);
                case "GotoIf":
                    return GotoIfCommand.Make(command.Parameters);
                case "ReadError":
                    return new ReadErrorCommand();
                case "ReadText":
                    return ReadTextCommand.Make(command.Parameters);
                case "EndScreen":
                    return EndScreenCommand.Make(command.Parameters);
                case "Exit":
                    return ExitCommand.Make(command.Parameters);
                case "ExitIf":
                    return ExitIfCommand.Make(command.Parameters);
                case "ExitIfn":
                    return ExitIfnCommand.Make(command.Parameters);
                case "EnterMenu":
                    return EnterMenuCommand.Make(command.Parameters);
                case "SelectRider":
                    return SelectRiderCommand.Make(command.Parameters);
                case "SelectLa":
                    return SelectLaCommand.Make(command.Parameters);
                case "SelectProposalItems":
                    return SelectProposalItemsCommand.Make(command.Parameters);
                case "Tag":
                    return TagCommand.Make(command.Parameters);
                case "Untag":
                    return UntagCommand.Make(command.Parameters);
                case "Validate":
                    string value = command.Parameters.Length > 0 ? command.Parameters[0] : null;
                    return new ValidateCommand(value);
                case "Wait":
                    return new WaitCommand();
                default:
                    return null;
            }
        }

        private CommandData ParseCommand(string line)
        {
            CommandData command = new CommandData();

            string paramsInString;
            int seperator = line.IndexOf(' ');

            command.Name = (seperator > 0) ? line.Substring(0, seperator) : line;
            paramsInString = (seperator > 0) ? line.Substring(seperator) : "";

            string[] @params = new string[] { };
            if (paramsInString.Length > 0)
            {
                @params = paramsInString.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                for (int i = 0; i < @params.Length; i++)
                {
                    @params[i] = @params[i].Trim().Trim('"');
                }
            }

            command.Parameters = @params;
            return command;
        }

    }
}
