﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using KN.BusinessLogic.Proposal;
using KN.Systems;
using log4net;
using log4net.Config;

namespace Prudential.AutoUpload
{
    static class Program
    {
        private static ILog log = LogManager.GetLogger(typeof(Program));

        public static string version ="ver. 2016/01/20";

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            XmlConfigurator.Configure();

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            Application.ThreadException += new System.Threading.ThreadExceptionEventHandler(Application_ThreadException);
            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
            AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(CurrentDomain_UnhandledException);

            Application.ApplicationExit += new EventHandler(Application_ApplicationExit);
            Application.ThreadExit += new EventHandler(Application_ThreadExit);

            UploadApp.RunSlow = Properties.Settings.Default.RunSlowly;
            UploadApp.StopIfError = Properties.Settings.Default.StopIfError;

            var frmProposal = new frmProposal();
            var frmMain = new frmMain();

            frmProposal.FrmMain = frmMain;
            frmMain.FrmProposal = frmProposal;

            Application.Run(frmMain);
        }

        static void Application_ApplicationExit(object sender, EventArgs e)
        {
            log.Debug("Application exit");
            EhllapiWrapper.Disconnect();
        }
        static void Application_ThreadExit(object sender, EventArgs e)
        {
            log.Debug("Thread exit");
            EhllapiWrapper.Disconnect();
        }

        static void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            log.Debug(e.ExceptionObject);
            EhllapiWrapper.Disconnect();
        }
        static void Application_ThreadException(object sender, System.Threading.ThreadExceptionEventArgs e)
        {
            log.Debug(e.Exception);
            EhllapiWrapper.Disconnect();
        }
    }
}
