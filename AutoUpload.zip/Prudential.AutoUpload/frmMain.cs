﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using KN.BusinessLogic;
using KN.Screens;
using KN.Systems;
using KN.SmallAdvancePolicy;
using KN.BusinessLogic.Proposal.Command;
using System.Globalization;
using System.Threading;

namespace Prudential.AutoUpload
{
    // 1.Phí hồ sơ & mã khách hàng (PO)--- C
    // 2.Phí hồ sơ mới (SCI)-------------- A
    // 3.Phí khác (LPS)------------------- N
    // 4.Phí hoàn trả (APL/OPL)----------- L
    // 5.Phí định kỳ (LNVP) -------------- J
    // 6.Mã khách hàng (LA & BEN)--------- D
    // 7.Câu hỏi sức khỏe----------------- N-Questionairy
    // 8.Giảm phí (LPN)----------------- X

    public partial class frmMain : Form
    {
        frmProposal frmProp;
        
        public frmProposal FrmProposal
        {
            get { return frmProp; }
            set { frmProp = value; }
        }

        protected override void Dispose(bool disposing) {
            if (disposing) {
                if (components != null) {
                    components.Dispose();
                }

                
            }

            base.Dispose(disposing);
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmProp.FrmMain = this;
            frmProp.Location = this.Location;
            frmProp.Show();
            this.Hide();
        }
        private void newVersionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmProp.FrmMain = this;
            frmProp.Location = this.Location;
            frmProp.Show();
            this.Hide();
        }

        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            this.Text = "Prudential Auto Upload - Key-in Action - " + Program.version;
            Display();
        }

        private void btnBrowser_Click(object sender, EventArgs e)
        {           
            try
            {
                int iUploadTypeId = ((UploadType)cbbUploadType.SelectedItem).ID;                               
                
                DATA_S2610_ACTION_A_Manager.ClearSuccessReceipts();
                DATA_S2610_ACTION_C_Manager.ClearSuccessClients();
                DATA_SV51B_Manager.ClearSuccessReceipts();
                DATA_SV50K_Manager.ClearSuccessReceipts();
                DATA_SV51D_Manager.ClearSuccessReceipts();
               
                DATA_S2610_ACTION_A_Manager.ClearFailReceipts();
                DATA_S2610_ACTION_C_Manager.ClearFailClients();
                DATA_SV51B_Manager.ClearFailReceipts();
                DATA_SV50K_Manager.ClearFailReceipts();
                DATA_SV51D_Manager.ClearFailReceipts(); 
                
                ErrorLog_Action_C_Manager.ErrorLogClear();
                ErrorLogReceiptManager.ErrorLogClear();
                ErrorLog_Action_A_Manager.ErrorLogClear();

                DATA_ACTION_D_Manager.ClearLogs();
                DATA_ACTION_D_Manager.ClearSuccessClients();
                DATA_ACTION_D_Manager.ClearFailClients();

                DATA_Questionaire_Manager.ClearQuestionaireLogs();
                DATA_Questionaire_Manager.ClearSuccessQuestionaire();
                DATA_Questionaire_Manager.ClearFailQuestionaire();

                openFileDialog1.FileName = string.Empty;
                openFileDialog1.Filter = "CSV Files (*.csv)|*.csv|All Files (*.*)|*.*";
                openFileDialog1.ShowDialog();
                textBox1.Text = openFileDialog1.FileName;
                FileInfo file = new FileInfo(openFileDialog1.FileName);

                if (file.Exists == false)
                {
                    textBox1.Text = "Invalid file path. Please try again";
                    MsgBox.ShowMessageError("Invalid file path. Please try again");
                    return;
                }

                if (!file.Extension.ToUpper().Contains("CSV"))
                    ExcelProcess.UpLoad(textBox1.Text);
                else
                {
                    switch (iUploadTypeId)
                    {
                        case 1: //Action C
                            DATA_S2610_ACTION_C_Manager.UploadClients(textBox1.Text); //hcmnhvu, 2012-07-05
                            break;                       

                        case 2: //Action A
                            DATA_S2610_ACTION_A_Manager.UploadReceipts(textBox1.Text); //hcmnhvu, 2012-08-29
                            break;

                        case 3: //Action N
                            DATA_SV51D_Manager.UploadReceipts(textBox1.Text); //hcmnhvu, 2012-08-30
                            break;

                        case 4: //Action L
                            DATA_SV51B_Manager.UploadReceipts(textBox1.Text); //hcmnhvu, 2012-08-31
                            break;

                        case 5: //Action J
                            DATA_SV50K_Manager.UploadReceipts(textBox1.Text); //hcmnhvu, 2012-09-01
                            break;

                        case 6: //Action D
                            DATA_ACTION_D_Manager.UploadClients(textBox1.Text); //hcmnhvu, 2012-07-05
                            break;

                        case 7: //Action N - Questionaire
                            DATA_Questionaire_Manager.UploadQuestionaire(textBox1.Text); //hcmnvxthinh, 2013-17-07
                            break;
                        case 8:
                           
                            break;
                        case 9: //Action R - Receipt
                            DATA_SV51D_Manager.UploadReceipts(textBox1.Text);
                            break;

                    }

                    Display();
                }
            }
            catch (Exception ex)
            {
                MsgBox.ShowMessageError("Upload has a issue. Please try again. Error: " + ex.Message);
            }
        }

        private void Display()
        {
            
            //load UploadType
            if (cbbUploadType.Items.Count == 0)
            {
                cbbUploadType.DataSource = UploadTypeManager.GetAllUploadType();
                cbbUploadType.DisplayMember = "Description";
                cbbUploadType.ValueMember = "ID";
                cbbUploadType.SelectedIndex = 0;
            }
            else
            {
                int iUploadTypeId = ((UploadType)cbbUploadType.SelectedItem).ID;

                switch (iUploadTypeId)
                {
                    case 1: //Action C
                        grdInfo.DataSource = DATA_S2610_ACTION_C_Manager.GetAllClients2();
                        //grdInfo.Columns["NeedToKeyReceipt"].Visible = false;
                        //Result
                        grdSuccess.DataSource = DATA_S2610_ACTION_C_Manager.GetSuccessClients();
                        grdFail.DataSource = DATA_S2610_ACTION_C_Manager.GetFailClients();                        
                        break;

                    case 2: //Action A
                        grdInfo.DataSource = DATA_S2610_ACTION_A_Manager.GetAllReceipts2();
                        //Result
                        grdSuccess.DataSource = DATA_S2610_ACTION_A_Manager.GetSuccessReceipts();
                        grdFail.DataSource = DATA_S2610_ACTION_A_Manager.GetFailReceipts();
                        break;

                    case 3: //Action N
                        grdInfo.DataSource = DATA_SV51D_Manager.GetAllReceipts2();
                        //Result
                        grdSuccess.DataSource = DATA_SV51D_Manager.GetSuccessReceipts();
                        grdFail.DataSource = DATA_SV51D_Manager.GetFailReceipts();
                        break;

                    case 4: //Action L
                        grdInfo.DataSource = DATA_SV51B_Manager.GetAllReceipts2();
                        //Result
                        grdSuccess.DataSource = DATA_SV51B_Manager.GetSuccessReceipts();
                        grdFail.DataSource = DATA_SV51B_Manager.GetFailReceipts();
                        break;

                    case 5: //Action J
                        grdInfo.DataSource = DATA_SV50K_Manager.GetAllReceipts2();
                        //Result
                        grdSuccess.DataSource = DATA_SV50K_Manager.GetSuccessReceipts();
                        grdFail.DataSource = DATA_SV50K_Manager.GetFailReceipts();
                        break;

                    case 6: //Action D
                        grdInfo.DataSource = DATA_ACTION_D_Manager.GetAllClients2();                        
                        grdSuccess.DataSource = DATA_ACTION_D_Manager.GetSuccessClients();
                        grdFail.DataSource = DATA_ACTION_D_Manager.GetFailClients();
                        break;

                    case 7: //Action N - Questionary
                        grdInfo.DataSource = DATA_Questionaire_Manager.GetAllQuestionaires();
                        grdSuccess.DataSource = DATA_Questionaire_Manager.GetSuccessQuestionaire();
                        grdFail.DataSource = DATA_Questionaire_Manager.GetFailQuestionaire();
                        break;
                    case 8:
                        IList<Prudential.AutoUpload.Classes.Models.RcptDisc2LA> RcptDisc2LAs = new List<Classes.Models.RcptDisc2LA>();
                        Classes.Controllers.RcptDisc2LA objRcptDisc2LA = new Classes.Controllers.RcptDisc2LA();
                        RcptDisc2LAs = objRcptDisc2LA.Process(textBox1.Text);
                        grdInfo.DataSource = RcptDisc2LAs;
                        break;
                    case 9: //Action N
                        grdInfo.DataSource = DATA_SV51D_Manager.GetAllReceipts2();
                        //Result
                        grdSuccess.DataSource = DATA_SV51D_Manager.GetSuccessReceipts();
                        grdFail.DataSource = DATA_SV51D_Manager.GetFailReceipts();
                        break;

                }
            }
        }

        private bool Navigator(string action)
        {
            switch (action)
            {
                case "C":
                    //Clients & Groups
                    var screen = new KN.Systems.Screen();
                    KN.Systems.Point p = GetMenuPosition2(screen, "Application Tracking Sys");
                    if (p != null)
                    {
                        screen.SetValues(p, "@E");

                        p = GetMenuPosition2(screen, "Client Maintenance");//Client Maintenance

                        if (p != null)
                        {
                            screen.SetValues(p, "@E");
                            return true;
                        }
                    }

                    return false;                                      

                case "A":

                    break;
            }

            return true;
 
        }

        private void btnUpload_Click(object sender, EventArgs e)
        {
            int iUploadTypeId = ((UploadType)cbbUploadType.SelectedItem).ID;

            //cmdClearLog_Click(sender, e); //clear log
            ClearDataLog();

            this.Connect();
            S2480 s2480;
            S2465 s2465;
            S0017 s0017;
            S0018 s0018;
            string ClientNo = "";
            string msg = "";

            #region Return system menu

            #endregion

            switch (iUploadTypeId)
            {
                    
                #region Action C
                    case 1:

                    string sTransID = "";
                    string ID = "";
                    KN.Systems.Screen screen;
                    KN.Systems.Point p;

                    try
                    {
                        s2480 = new S2480("");
                        string current_screen = s2480.GetScreenCode();
                        if (current_screen != "S2480")
                        {
                            MsgBox.ShowMessageWarning("You don't stand at S2480. Please navigate to LAS screen to S2480 -  Client Maintenance Submenu.");
                            return;
                        }

                        var clients = DATA_S2610_ACTION_C_Manager.GetAllClients();                                             

                        foreach (var client in clients)
                        {
                            try
                            {
                                ClientNo = "";
                                ID = client.ID;
                                s2480 = new S2480(ID);
                                s2480.Action = "D";
                                s2480.SetValues(ID);
                                s2480.Execute();

                                msg = s2480.GetMessage().Trim();
                                if (msg.StartsWith("Client Not On File")) //Khong ton tai
                                {
                                    s2480.Action = "A";
                                    s2480.SetValues(ID);
                                    s2480.Execute();
                                    s2480.Enter();
                                    s2480.WaitingToNextScreen();
                                }

                                s2465 = new S2465(client);

                                if (s2480.Action == "A")
                                {
                                    s2465.Execute();

                                    ClientNo = s2465.GetValues("Client").Trim();

                                    s2465.Next();

                                    msg = s2465.GetMessage2().Trim();

                                    if (msg.Trim() != "")
                                    {
                                        ErrorLog_Action_C_Manager.ErrorLogInsert(client, String.Empty, "Key client fail, Error: " + msg);
                                        DATA_S2610_ACTION_C_Manager.InsertError(client, "Key client fail, Error: " + msg);
                                        s2465.F3();
                                        continue;
                                    }
                                    else
                                    {
                                        //Tax ID Number
                                        SR208 sr208 = new SR208(client);
                                        sr208.Execute();
                                        sr208.Enter();

                                        //Check Duplicate
                                        SV210 sv210 = new SV210();
                                        sv210.Waiting(10);

                                        msg = sv210.GetValues(new KN.Systems.Point(22, 4), 19);
                                        if (msg.Contains("No Duplicate Client") == false)// Dulpicate
                                        {                                            
                                            ErrorLog_Action_C_Manager.ErrorLogInsert(client, String.Empty, "Key client fail, Error: Duplicate Client");
                                            DATA_S2610_ACTION_C_Manager.InsertError(client, "Key client fail, Error: Duplicate Client");
                                            s2465.F3();
                                            continue;
                                        }
                                        
                                        s2465.Enter();
                                        s2465.Execute("CheckDuplicate");
                                        s2465.Enter();

                                        //Write log
                                        msg = s2480.GetMessage2().Trim();

                                        if (msg.Trim() == string.Empty)
                                            msg = s2480.GetMessage().Trim();

                                        if (msg.Contains("created"))
                                        {
                                            client.Client_Code = ClientNo; //Update client No.
                                            //20130726
                                            ErrorLog_Action_C_Manager.ErrorLogInsert(client, String.Empty, "Client created.");
                                        }                                      
                                    }
                                }
                                else
                                {
                                    ClientNo = s2465.GetValues("Client").Trim();
                                    client.Client_Code = ClientNo;
                                    ErrorLog_Action_C_Manager.ErrorLogInsert(client, String.Empty, "Key client fail, Error: ID already exist.");
                                    DATA_S2610_ACTION_C_Manager.InsertError(client, "Key client fail, Error: ID already exist.");
                                    s2465.F3();
                                }

                                //Next
                                s2480.WaitingToNextScreen();

                                DATA_S2610_ACTION_C_Manager.ClientUpdate(ID, ClientNo);

                            }
                            catch (Exception ex)
                            {
                                DATA_S2610_ACTION_C_Manager.InsertError(client, ex.Message.Substring(0, 200));
                                this.F3("S2465");
                                continue;
                            }
                        }                        
                        
                        ExcelProcess.PreProcess();
                        Display();

                        /* Bulk data */
                        
                        //back to S0018
                        s2480.F3();
                        s2480.Waiting();

                        //back to S0017
                        screen = new KN.Systems.Screen();
                        screen.F3();
                        screen.Waiting();
                        //go to "Application Tracking Sys"
                        p = GetMenuPosition2(screen, "Application Tracking Sys");
                        if (p != null)
                        {
                            screen.Enter(p); //screen.SetValues(p, "@E");

                            p = GetMenuPosition2(screen, "Bulk Data Entry");

                            if (p != null)
                            {
                                screen.Enter(p); //screen.SetValues(p, "@E"); //Action A -> SJ566
                            }
                        }

                        foreach (var client in clients)
                        {
                            try
                            {
                                SJ566 sj566 = new SJ566();
                                sj566.Enter();

                                DATA_SV51L data_sv51L = new DATA_SV51L(client);
                                SV51L sv51L = new SV51L(data_sv51L);
                                //System.Threading.Thread.Sleep(5000);
                                sv51L.Execute();
                                //System.Threading.Thread.Sleep(5000);
                                sv51L.F5(); 
                                //System.Threading.Thread.Sleep(5000);
                                sv51L.Enter();
                                //System.Threading.Thread.Sleep(5000);
                                try
                                {
                                    msg = sj566.GetMessage2().Trim();
                                }
                                catch
                                {
                                    msg = sv51L.GetMessage2().Trim();
                                }

                                if (msg.Contains("Enter cnt.type or blank")) //fail
                                    sv51L.Enter();

                                try
                                {
                                    msg = sj566.GetMessage2().Trim();
                                }
                                catch
                                {
                                    msg = sv51L.GetMessage2().Trim();
                                }

                                if (msg.Contains("processed")) //fail, SV51L
                                {
                                    client.NeedToKeyReceipt = true;
                                }
                                else
                                {
                                    sv51L.F3();
                                    screen.Waiting();
                                    continue;
                                }
                            }
                            catch (Exception ex)
                            {
                                this.F3("SV51L");
                                screen.Waiting();
                                DATA_S2610_ACTION_C_Manager.InsertError(client, ex.Message);                                
                                continue;
                            }
                        }

                        //Key receipt

                        /* Lay so client vua tao de qua man hinh receipt key vao */
                        screen = new KN.Systems.Screen(); //SJ566
                        screen.F3(); //back to S0018
                        screen.Waiting();
                        screen.F3(); //back to S0017
                        //go to "Receivables and Payables"
                        screen.Waiting();

                        foreach (var client in clients)
                        {
                            try
                            {
                                if (!client.NeedToKeyReceipt)
                                {
                                    ErrorLog_Action_C_Manager.ErrorLogInsert(client, String.Empty, "Key receipt fail, Error: Bulk data fail");
                                    DATA_S2610_ACTION_C_Manager.InsertError(client, "Key receipt fail, Error: Bulk data fail");
                                    continue;
                                }

                                screen = new KN.Systems.Screen();

                                s0017 = new S0017(client.BranchCode);
                                s0018 = new S0018();

                                if (s0017.IsCurrentScreen() == false)
                                {
                                    MessageBox.Show("Error at receipt: " + client.Tax_Invoice + ". Please navigate to LAS screen to S0017 to continue upload");                                                              
                                }                                
                                s0017.Execute();//Key BranchCode

                                p = GetMenuPosition2(screen, "Receivables and Payables");

                                if (p != null)
                                {
                                    s0017.Enter(p);//Enter

                                    if (s0018.IsCurrentScreen() == false)
                                    {
                                        MessageBox.Show("Error at receipt: " + client.Tax_Invoice + ". Please navigate to LAS screen to S0018 to continue upload");                                       
                                    }
                                    p = GetMenuPosition2(s0018, "Receipts");
                                    if (p != null)
                                    {
                                        //System.Threading.Thread.Sleep(500);
                                        s0018.Enter(p); //S2067
                                    }
                                }

                                //-------------S2067--------------------
                                DATA_S2067 data_s2067 = new DATA_S2067(client);
                                data_s2067.Action = "A";

                                S2067 s2067 = new S2067(data_s2067);
                                if (s2067.IsCurrentScreen() == false)
                                {
                                    MessageBox.Show("Error at receipt: " + client.Tax_Invoice + ". Please navigate to LAS screen to S2067 to continue upload");

                                }
                                s2067.Execute();
                                s2067.Enter2();
                                if (s2067.IsCurrentScreen() == true)
                                {
                                    try
                                    {
                                        msg = s2067.GetMessage2().Trim();

                                        if (!string.IsNullOrEmpty(msg))
                                        {
                                            ErrorLog_Action_C_Manager.ErrorLogInsert(client, String.Empty, "Tax Number " + data_s2067.TaxNumber + " already exists");
                                            DATA_S2610_ACTION_C_Manager.InsertError(client, "Tax Number " + data_s2067.TaxNumber + " already exists");
                                            s2067.F3();//S0018
                                            s2067.F3();//S0017
                                            continue;
                                        }

                                    }
                                    catch { }
                                }

                                //---------------S2610-------------
                                DATA_S2610 data_s2610 = new DATA_S2610(client);
                                S2610 s2610 = new S2610(data_s2610);
                                s2610.Execute();
                                sTransID = s2610.GetValues(new KN.Systems.Point(3, 16), 8);
                                s2610.F5();
                                s2610.Enter();

                                if (s2067.IsCurrentScreen() == true)
                                {
                                    ErrorLog_Action_C_Manager.ErrorLogInsert(client, sTransID, "Key receipt successfully");
                                    DATA_S2610_ACTION_C_Manager.InsertSuccess(client);
                                    s2067.F3();//S0018
                                    s2067.F3();//S0017
                                    continue;
                                }

                                if (s2610.IsCurrentScreen() == true)
                                {
                                    msg = s2610.GetMessage2().Trim();
                                    ErrorLog_Action_C_Manager.ErrorLogInsert(client, String.Empty, "Key receipt fail. Error: " + msg);
                                    DATA_S2610_ACTION_C_Manager.InsertError(client, "Key receipt fail. Error: " + msg);
                                    s2610.F3();//S2067
                                    s2610.F3();//S0018
                                    s2610.F3();//S0017
                                    continue;
                                }   
                            }
                            catch (Exception ex)
                            {
                                ErrorLog_Action_C_Manager.ErrorLogInsert(client, String.Empty, "Key receipt fail. Error: " + ex.Message);                                
                                DATA_S2610_ACTION_C_Manager.InsertError(client, "Key receipt fail. Error: " + ex.Message);
                                MessageBox.Show("Error at receipt: " + client.Tax_Invoice + ". Please navigate to LAS screen to S0017 to continue upload");
                                continue;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    finally
                    {
                        grdLogs.DataSource = ErrorLog_Action_C_Manager.AllErrorLogLoad2();
                    }

                    break;
               
                #endregion Action C

                #region Action A

                case 2:

                    try
                    {
                        S2067 s2067_A = new S2067();
                        s0017 = new S0017("");
                        string current_screen = s0017.GetScreenCode();
                        if (current_screen != "S0017")
                        {
                            MsgBox.ShowMessageWarning("You don't stand at S0017. Please navigate to LAS screen to S0017.");
                            return;
                        }                        

                        var receipts = DATA_S2610_ACTION_A_Manager.GetAllReceipts();

                        foreach (var receipt in receipts)
                        {
                            string sTransID_A = string.Empty;
                            string msg_A = string.Empty;

                            try
                            {
                                s0017 = new S0017(receipt.BranchCode);
                                s0018 = new S0018();

                                if (s0017.IsCurrentScreen() == false)
                                {
                                    MessageBox.Show("Error at receipt: " + receipt.Tax_Invoice + ". Please navigate to LAS screen to S0017 to continue upload.");
                                }
                                s0017.Execute();

                                p = GetMenuPosition2(s0017, "Receivables and Payables");

                                if (p != null)
                                {
                                    s0017.Enter(p);//Enter

                                    if (s0018.IsCurrentScreen() == false)
                                    {
                                        MessageBox.Show("Error at receipt: " + receipt.Tax_Invoice + ". Please navigate to LAS screen to S0018 to continue upload.");
                                    }
                                    p = GetMenuPosition2(s0018, "Receipts");
                                    if (p != null)
                                    {
                                        s0018.Enter(p); //S2067
                                    }
                                }

                                //S2067
                                DATA_S2067 data_s2067 = new DATA_S2067(receipt);
                                s2067_A = new S2067(data_s2067);

                                if (s2067_A.IsCurrentScreen() == false)
                                {
                                    MessageBox.Show("Error at receipt: " + receipt.Tax_Invoice + ". Please navigate to LAS screen to S2067 to continue upload.");
                                }
                                s2067_A.Execute();
                                s2067_A.Enter2();

                                if (s2067_A.IsCurrentScreen() == true)
                                {
                                    try
                                    {
                                        msg_A = s2067_A.GetMessage2().Trim();

                                        if (!string.IsNullOrEmpty(msg_A))
                                        {
                                            ErrorLog_Action_A_Manager.ErrorLogInsert(receipt.Prop_No, receipt.Client_Code, string.Empty, receipt.ClientID, receipt.ReceiptID, receipt.BranchCode, "Tax Number " + data_s2067.TaxNumber + " already exists");
                                            DATA_S2610_ACTION_A_Manager.InsertError(receipt, "Tax Number " + data_s2067.TaxNumber + " already exists");
                                            s2067_A.F3();//S0018
                                            s2067_A.F3();//S0017
                                            continue;
                                        }

                                    }
                                    catch{}
                                }
                                                               
                                //S2610
                                DATA_S2610 data_s2610 = new DATA_S2610(receipt);
                                S2610 s2610 = new S2610(data_s2610);
                                if (s2610.IsCurrentScreen() == false)
                                {
                                    MessageBox.Show("Error at receipt: " + receipt.Tax_Invoice + ". Please navigate to LAS screen to S2610 to continue upload.");
                                }

                                s2610.Execute();
                                sTransID_A = s2610.GetValues("TransID");
                                s2610.F5();
                                s2610.Enter();

                                if (s2067_A.IsCurrentScreen() == true)
                                {
                                    s2067_A.F3();//S0018
                                    s2067_A.F3();//S0017
                                    ErrorLog_Action_A_Manager.ErrorLogInsert(receipt.Prop_No, receipt.Client_Code, sTransID_A, receipt.ClientID, receipt.ReceiptID, receipt.BranchCode, "Key receipt successfully");
                                    DATA_S2610_ACTION_A_Manager.InsertSuccess(receipt);
                                    continue;
                                }
                                 
                                if (s2610.IsCurrentScreen() == true)
                                {
                                    msg_A = s2610.GetMessage2().Trim();
                                    ErrorLog_Action_A_Manager.ErrorLogInsert(receipt.Prop_No, receipt.Client_Code, sTransID_A, receipt.ClientID, receipt.ReceiptID, receipt.BranchCode, "Key receipt fail. Error: " + msg_A);
                                    DATA_S2610_ACTION_A_Manager.InsertError(receipt, "Key receipt fail. Error: " + msg_A); s2610.F3();//S2067
                                    s2610.F3();//S0018
                                    s2610.F3();//S0017
                                    continue;
                                }                               
                            }
                            catch (Exception ex)
                            {
                                ErrorLog_Action_A_Manager.ErrorLogInsert(receipt.Prop_No, receipt.Client_Code, string.Empty, receipt.ClientID, receipt.ReceiptID,receipt.BranchCode,"Key receipt fail. Error: " + ex.Message);
                                DATA_S2610_ACTION_A_Manager.InsertError(receipt, "Key receipt fail. Error: " + ex.Message);
                                MessageBox.Show("Error at receipt: " + receipt.Tax_Invoice + ". Please navigate to LAS screen to S0017 to continue upload.");
                                continue;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        ErrorLog_Action_A_Manager.ErrorLogInsert(string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, "Key receipt error: " + ex.Message);
                    }
                    finally
                    {
                        grdLogs.DataSource = ErrorLog_Action_A_Manager.AllErrorLogLoad2();
                    }

                    break;

                #endregion

                #region Action N

                case 3:

                    try
                    {                       

                        S2067 s2067_N = new S2067();
                        s0017 = new S0017("");
                        string current_screen = s0017.GetScreenCode();
                        if (current_screen != "S0017")
                        {
                            MsgBox.ShowMessageWarning("You don't stand at S0017. Please navigate to LAS screen to S0017.");
                            return;
                        }

                        var receipts = DATA_SV51D_Manager.GetAllReceipts();

                        foreach (var receipt in receipts)
                        {
                            string sTransID_N = string.Empty;
                            string sShowHRC = string.Empty;
                            string msg_N = string.Empty;

                            try
                            {
                                screen = new KN.Systems.Screen();

                                s0017 = new S0017(receipt.BranchCode);
                                s0018 = new S0018();

                                if (s0017.IsCurrentScreen() == false)
                                {
                                    MessageBox.Show("Error at receipt: " + receipt.Tax_Invoice + ". Please navigate to LAS screen to S0017 to continue upload");
                                }
                                s0017.Execute();//Branch Code

                                p = GetMenuPosition2(s0017, "Receivables and Payables");

                                if (p != null)
                                {
                                    s0017.Enter(p);//Enter

                                    if (s0018.IsCurrentScreen() == false)
                                    {
                                        MessageBox.Show("Error at receipt: " + receipt.Tax_Invoice + ". Please navigate to LAS screen to S0018 to continue upload");
                                    }
                                    p = GetMenuPosition2(s0018, "Receipts");
                                    if (p != null)
                                    {
                                        //System.Threading.Thread.Sleep(500);
                                        s0018.Enter(p); //S2067
                                    }
                                }
                                //-----------S2067--------------------

                                DATA_S2067 data_s2067 = new DATA_S2067(receipt);
                                s2067_N = new S2067(data_s2067);
                                if (s2067_N.IsCurrentScreen() == false)
                                {
                                    MessageBox.Show("Error at receipt: " + receipt.Tax_Invoice + ". Please navigate to LAS screen to S2067 to continue upload");
                                }
                                s2067_N.Execute();
                                s2067_N.Enter2();

                                if (s2067_N.IsCurrentScreen() == true)
                                {
                                    try
                                    {
                                        msg_N = s2067_N.GetMessage2().Trim();

                                        if (!string.IsNullOrEmpty(msg_N))
                                        {
                                            ErrorLogReceiptManager.ErrorLogInsert(receipt.Tax_Invoice, receipt.Contract_Number, string.Empty, receipt.BranchCode, "Key receipt fail, Error: " + msg_N);
                                            DATA_SV51D_Manager.InsertError(receipt, "Key receipt fail, Error: " + msg_N);
                                            s2067_N.F3();//S0018
                                            s2067_N.F3();//S0017
                                            continue;
                                        }
                                    }
                                    catch
                                    {
                                    }
                                }

                                //SV51D
                                SV51D sv51D = new SV51D(receipt);
                                if (sv51D.IsCurrentScreen() == false)
                                {
                                    MessageBox.Show("Error at receipt: " + receipt.Tax_Invoice + ". Please navigate to LAS screen to SV51D to continue upload");
                                }

                                //try
                                //{
                                //    msg_N = sv51D.GetMessage2().Trim();
                                //}
                                //catch
                                //{
                                //}

                                //if (!string.IsNullOrEmpty(msg_N) && msg_N.ToLower().Trim().StartsWith(">>> hd luu y dac biet") == false)
                                //{
                                //    ErrorLogReceiptManager.ErrorLogInsert(receipt.Tax_Invoice, receipt.Contract_Number, string.Empty, receipt.BranchCode, "Key receipt fail, Error: " + msg_N);
                                //    DATA_SV51D_Manager.InsertError(receipt, "Key receipt fail, Error: " + msg_N);
                                   
                                //    s2067_N.F3();//S2067
                                //    s2067_N.F3();//S0018
                                //    s2067_N.F3();//S0017
                                //    continue;
                                //}
                                //sv51D.Waiting();


                                sShowHRC = sv51D.GetValues(new KN.Systems.Point(15, 10), 3);
                                if (sShowHRC == "HRC") // New BS Check HRC(Y/N)
                                    sv51D.SetValues(new KN.Systems.Point(15, 20), "Y");

                                sv51D.Execute();
                                sTransID_N = sv51D.GetValues(new KN.Systems.Point(3, 15), 8);
                                sv51D.F5();

                                if (
                                    //sv51D.GetValues(new KN.Systems.Point(14, 33), 15).StartsWith("Over 50mil VND") == true ||
                                    sv51D.GetValues(new KN.Systems.Point(14, 33), 15).StartsWith("Over 150mil VND") == true)
                                {
                                    sv51D.SetValues(new KN.Systems.Point(14, 56), "Y");
                                }

                                sv51D.Enter();

                                #region PNH => CMT
                                //// LHT added
                                //if (sv51D.screenconfig.items["OR1_Number"].itemconfig.values.ToString().Substring(0, 2).Equals("GA") || sv51D.screenconfig.items["OR1_Number"].itemconfig.values.ToString().Substring(0, 2).Equals("CS"))
                                //{
                                //    DATA_SV021 data_sv021 = new DATA_SV021("", "", "", "", "", "");
                                //    SV021 sv021 = new SV021(data_sv021);
                                //    sv021.Enter();
                                //    sv021.Wait(10);
                                //    sv51D.Enter();
                                //}
                                //// ---------
                                #endregion

                                if (s2067_N.IsCurrentScreen() == true)
                                {
                                    ErrorLogReceiptManager.ErrorLogInsert(receipt.Tax_Invoice, receipt.Contract_Number, sTransID_N, receipt.BranchCode, "Key receipt successfully");
                                    DATA_SV51D_Manager.InsertSuccess(receipt);
                                    s2067_N.F3();//S0018
                                    s2067_N.F3();//S0017                                    
                                    continue;
                                }

                                if (sv51D.IsCurrentScreen() == true)
                                {
                                    msg_N = sv51D.GetMessage2().Trim();
                                    ErrorLogReceiptManager.ErrorLogInsert(receipt.Tax_Invoice, receipt.Contract_Number, string.Empty, receipt.BranchCode, "Key receipt fail. Error: " + msg_N);
                                    DATA_SV51D_Manager.InsertError(receipt, "Key receipt fail. Error: " + msg_N);
                                    sv51D.F3();//S2067
                                    s2067_N.F3();//S0018
                                    s2067_N.F3();//S0017
                                    continue;
                                }
                                
                            }
                            catch (Exception ex)
                            {
                                ErrorLogReceiptManager.ErrorLogInsert(receipt.Tax_Invoice, receipt.Contract_Number, string.Empty, receipt.BranchCode, "Key receipt fail. Error: " + ex.Message);
                                DATA_SV51D_Manager.InsertError(receipt, "Key receipt fail. Error: " + ex.Message);                              
                                MessageBox.Show("Error at receipt: " + receipt.Tax_Invoice + ". Please navigate to LAS screen to S0017 to continue upload");
                                continue;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        ErrorLogReceiptManager.ErrorLogInsert(string.Empty, string.Empty, string.Empty, string.Empty, "Key receipt error: " + ex.Message);
                    }
                    finally
                    {
                        grdLogs.DataSource = ErrorLogReceiptManager.AllErrorLogLoad2();
                    }

                    break;

                #endregion

                #region Action L

                case 4:

                    try
                    {                        

                        S2067 s2067_L = new S2067();
                        s0017 = new S0017("");
                        string current_screen = s0017.GetScreenCode();
                        if (current_screen != "S0017")
                        {
                            MsgBox.ShowMessageWarning("You don't stand at S0017. Please navigate to LAS screen to S0017.");
                            return;
                        }

                        var receipts = DATA_SV51B_Manager.GetAllReceipts();

                        foreach (var receipt in receipts)
                        {
                            string sTransID_L = string.Empty;
                            string msg_L = string.Empty;
                            try
                            {                                
                                s0017 = new S0017(receipt.BranchCode);
                                s0018 = new S0018();

                                if (s0017.IsCurrentScreen() == false)
                                {
                                    MessageBox.Show("Error at receipt: " + receipt.Tax_Invoice + ". Please navigate to LAS screen to S0017 to continue upload.");
                                }
                                s0017.Execute();//Branch Code

                                p = GetMenuPosition2(s0017, "Receivables and Payables");

                                if (p != null)
                                {
                                    s0017.Enter(p);//Enter

                                    if (s0018.IsCurrentScreen() == false)
                                    {
                                        MessageBox.Show("Error at receipt: " + receipt.Tax_Invoice + ". Please navigate to LAS screen to S0018 to continue upload.");
                                    }
                                    p = GetMenuPosition2(s0018, "Receipts");
                                    if (p != null)
                                    {
                                        //System.Threading.Thread.Sleep(500);
                                        s0018.Enter(p); //S2067
                                    }
                                }

                                //---------------------S2067-----------------
                                if (s2067_L.IsCurrentScreen() == false)
                                {
                                    MessageBox.Show("Error at receipt: " + receipt.Tax_Invoice + ". Please navigate to LAS screen to S2067 to continue upload.");
                                }
                                DATA_S2067 data_s2067 = new DATA_S2067(receipt);
                                s2067_L = new S2067(data_s2067);
                                s2067_L.Execute();// Key in TaxCode 
                                s2067_L.Enter2();

                                if (s2067_L.IsCurrentScreen() == true)
                                {
                                    try
                                    {
                                        msg_L = s2067_L.GetMessage2().Trim();

                                        if (!string.IsNullOrEmpty(msg_L))
                                        {
                                            ErrorLogReceiptManager.ErrorLogInsert(receipt.Tax_Invoice, receipt.Contract_Number, string.Empty, receipt.BranchCode, "Key receipt fail, Error: " + msg_L);
                                            DATA_SV51B_Manager.InsertError(receipt, "Key receipt fail, Error: " + msg_L);
                                            s2067_L.F3();//S0018
                                            s2067_L.F3();//S0017
                                            continue;
                                        }
                                    }
                                    catch
                                    {
                                    }
                                }

                                //------------SV51B----------------------
                                SV51B sv51B = new SV51B(receipt);
                                if (sv51B.IsCurrentScreen() == false)
                                {
                                    MessageBox.Show("Error at receipt: " + receipt.Tax_Invoice + ". Please navigate to LAS screen to SV51B to continue upload.");
                                }
                                
                                sv51B.Execute();

                                sTransID_L = sv51B.GetValues(new KN.Systems.Point(3, 16), 8);
                                sv51B.F5();
                                if (
                                    //sv51B.GetValues(new KN.Systems.Point(13, 28), 15).StartsWith("Over 50mil VND") == true ||
                                    sv51B.GetValues(new KN.Systems.Point(13, 28), 15).StartsWith("Over 150mil VND") == true)
                                {
                                    sv51B.SetValues(new KN.Systems.Point(13, 51), "Y");
                                }
                                sv51B.Enter();

                                #region PNH => CMT
                                //// LHT added
                                //if (sv51B.screenconfig.items["OR1_Number"].itemconfig.values.ToString().Substring(0, 2).Equals("GA") || sv51B.screenconfig.items["OR1_Number"].itemconfig.values.ToString().Substring(0, 2).Equals("CS"))
                                //{
                                //    DATA_SV021 data_sv021 = new DATA_SV021("", "", "", "", "", "");
                                //    SV021 sv021 = new SV021(data_sv021);
                                //    sv021.Enter();
                                //    sv021.Wait(10);
                                //    sv51B.Enter();
                                //}
                                //// ---------
                                #endregion

                                if (s2067_L.IsCurrentScreen() == true)
                                {
                                    ErrorLogReceiptManager.ErrorLogInsert(receipt.Tax_Invoice, receipt.Contract_Number, sTransID_L, receipt.BranchCode, "Key receipt successfully");
                                    DATA_SV51B_Manager.InsertSuccess(receipt);
                                    s2067_L.F3();//S0018
                                    s2067_L.F3();//S0017
                                    continue;
                                }

                                if (sv51B.IsCurrentScreen() == true)
                                {
                                    msg_L = sv51B.GetMessage2().Trim();
                                    ErrorLogReceiptManager.ErrorLogInsert(receipt.Tax_Invoice, receipt.Contract_Number, string.Empty, receipt.BranchCode, "Key receipt fail. Error: " + msg_L);
                                    DATA_SV51B_Manager.InsertError(receipt, "Key receipt fail. Error: " + msg_L);
                                    sv51B.F3();//S2067
                                    s2067_L.F3();//S0018
                                    s2067_L.F3();//S0017
                                    continue;
                                }
                            }
                            catch (Exception ex)
                            {
                                ErrorLogReceiptManager.ErrorLogInsert(receipt.Tax_Invoice, receipt.Contract_Number, string.Empty, receipt.BranchCode, "Key receipt fail. Error: " + ex.Message);
                                DATA_SV51B_Manager.InsertError(receipt, "Key receipt fail. Error: " + ex.Message);
                                MessageBox.Show("Error at receipt: " + receipt.Tax_Invoice + ". Please navigate to LAS screen to S0017 to continue upload.");
                                continue;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        ErrorLogReceiptManager.ErrorLogInsert(string.Empty, string.Empty, string.Empty,string.Empty, "Key receipt error: " + ex.Message);
                    }
                    finally
                    {
                        grdLogs.DataSource = ErrorLogReceiptManager.AllErrorLogLoad2();
                    }

                    break;

                #endregion

                #region Action J

                case 5:

                    try
                    {
                        S2067 s2067_J = new S2067();
                        s0017 = new S0017("");
                        
                        string current_screen = s0017.GetScreenCode();
                        if (current_screen != "S0017")
                        {
                            MsgBox.ShowMessageWarning("You don't stand at S0017. Please navigate to LAS screen to S0017.");
                            return;
                        }

                        var receipts = DATA_SV50K_Manager.GetAllReceipts();

                        foreach (var receipt in receipts)
                        {
                            string sTransID_J = "";
                            string msg_J = "";

                            try
                            {
                                screen = new KN.Systems.Screen();
                                                                
                                s0017 = new S0017(receipt.BranchCode);
                                s0018 = new S0018();

                                if (s0017.IsCurrentScreen() == false)
                                {
                                    MessageBox.Show("Error at receipt: " + receipt.Tax_Invoice + ". Please navigate to LAS screen to S0017 to continue upload");                                                              
                                }                                
                                s0017.Execute();

                                p = GetMenuPosition2(screen, "Receivables and Payables");

                                if (p != null)
                                {
                                    s0017.Enter(p);//Enter

                                    if (s0018.IsCurrentScreen() == false)
                                    {                                       
                                        MessageBox.Show("Error at receipt: " + receipt.Tax_Invoice + ". Please navigate to LAS screen to S0018 to continue upload");                                       
                                    }
                                    p = GetMenuPosition2(s0018, "Receipts");
                                    if (p != null)
                                    {
                                        //System.Threading.Thread.Sleep(500);
                                        s0018.Enter(p); //S2067
                                    }
                                }
                                //------------------S2067---------------
                                DATA_S2067 data_s2067 = new DATA_S2067(receipt);
                                s2067_J = new S2067(data_s2067);

                                if (s2067_J.IsCurrentScreen() == false)
                                {
                                    MessageBox.Show("Error at receipt: " + receipt.Tax_Invoice + ". Please navigate to LAS screen to S2067 to continue upload");
                                                   
                                }
                                s2067_J.Execute();// Key in TaxCode 
                                s2067_J.Enter2();

                                if (s2067_J.IsCurrentScreen() == true)
                                {
                                    try
                                    {
                                        msg_J = s2067_J.GetMessage2().Trim();

                                        if (!string.IsNullOrEmpty(msg_J))
                                        {
                                            ErrorLogReceiptManager.ErrorLogInsert(receipt.Tax_Invoice, receipt.Contract_Number, string.Empty, receipt.BranchCode, "Key receipt fail, Error: " + msg_J);
                                            DATA_SV50K_Manager.InsertError(receipt, "Key receipt fail, Error at s2067: " + msg_J);                                            
                                            s2067_J.F3();//S0018
                                            s2067_J.F3();//S0017
                                            continue;
                                        }

                                    }
                                    catch{}
                                }

                                //-----------SV50K---------------------------
                                SV50K sv50K = new SV50K(receipt);

                                if (sv50K.IsCurrentScreen() == false)
                                {
                                    MessageBox.Show("Error at receipt: " + receipt.Tax_Invoice + ". Please navigate to LAS screen to SV50K to continue upload");
                                }

                                //try
                                //{
                                //    msg_J = sv50K.GetMessage2().Trim();
                                //}
                                //catch
                                //{
                                //}

                                //if (!string.IsNullOrEmpty(msg_J) && msg_J.ToLower().Trim().StartsWith(">>> hd luu y dac biet") == false)
                                //{
                                //    ErrorLogReceiptManager.ErrorLogInsert(receipt.Tax_Invoice, receipt.Contract_Number, string.Empty, receipt.BranchCode, "Key receipt fail, Error: " + msg_J);
                                //    DATA_SV50K_Manager.InsertError(receipt, "Key receipt fail, Error at s2067: " + msg_J);
                                //    s2067_J.F3();//S2067 
                                //    s2067_J.F3();//S0018
                                //    s2067_J.F3();//S0017
                                //    continue;
                                //}

                                //sv50K.Waiting();
                                sv50K.Execute();
                                //System.Threading.Thread.Sleep(1000);
                                sTransID_J = sv50K.GetValues(new KN.Systems.Point(3, 15), 8);

                                string PTD_ADV = sv50K.GetValues("PTD_ADV");

                                Thread.CurrentThread.CurrentCulture = new CultureInfo("vi-VN");
                                if (DateTime.Parse(PTD_ADV) != DateTime.Parse(receipt.PTD_ADV) && sv50K.GetScreenCode() == "SV50K")
                                {
                                    ErrorLogReceiptManager.ErrorLogInsert(receipt.Tax_Invoice, receipt.Contract_Number, string.Empty, receipt.BranchCode, "Key receipt fail. Error: PTD_ADV is incorrect.");
                                    DATA_SV50K_Manager.InsertError(receipt, "Key receipt fail. Error: PTD_ADV is incorrect.");
                                    sv50K.F3();//S2067
                                    s2067_J.F3();//S0018
                                    s2067_J.F3();//S0017
                                    continue;
                                }
                                //System.Threading.Thread.Sleep(1000);
                                sv50K.F5();
                                if (//sv50K.GetValues(new KN.Systems.Point(13, 33), 15).StartsWith("Over 50 mil VND") == true || 
                                    sv50K.GetValues(new KN.Systems.Point(13, 33), 15).StartsWith("Over 150mil VND") == true)
                                {
                                    sv50K.SetValues(new KN.Systems.Point(13, 57), "Y");
                                }
                                sv50K.Enter();

                                #region PNH Cmt
                                //// LHT added
                                //if (sv50K.screenconfig.items["OR1_Number"].itemconfig.values.ToString().Substring(0, 2).Equals("GA") || sv50K.screenconfig.items["OR1_Number"].itemconfig.values.ToString().Substring(0, 2).Equals("CS"))
                                //{
                                //    DATA_SV021 data_sv021 = new DATA_SV021("", "", "", "", "", "");
                                //    SV021 sv021 = new SV021(data_sv021);
                                //    sv021.Enter();
                                //    sv021.Wait(10);
                                //    sv50K.Enter();
                                //}
                                //// ---------
                                #endregion

                                if (s2067_J.IsCurrentScreen() == true)
                                {                                   
                                    ErrorLogReceiptManager.ErrorLogInsert(receipt.Tax_Invoice, receipt.Contract_Number, sTransID_J, receipt.BranchCode, "Key receipt successfully");
                                    DATA_SV50K_Manager.InsertSuccess(receipt);
                                    s2067_J.F3();//S0018
                                    s2067_J.F3();//S0017
                                    continue;
                                }

                                if (sv50K.IsCurrentScreen() == true)
                                {
                                    msg_J = sv50K.GetMessage2().Trim();
                                    ErrorLogReceiptManager.ErrorLogInsert(receipt.Tax_Invoice, receipt.Contract_Number, string.Empty, receipt.BranchCode, "Key receipt fail. Error: " + msg_J);
                                    DATA_SV50K_Manager.InsertError(receipt, "Key receipt fail. Error not processed: " + msg_J);
                                    sv50K.F3();//S2067
                                    sv50K.F3();//S0018
                                    sv50K.F3();//S0017
                                    continue;
                                }
                            }
                            catch (Exception ex)
                            {
                                ErrorLogReceiptManager.ErrorLogInsert(receipt.Tax_Invoice, receipt.Contract_Number, string.Empty, receipt.BranchCode, "Key receipt fail. Error: " + ex.Message);
                                DATA_SV50K_Manager.InsertError(receipt, "Key receipt fail, Error ex: " + ex.Message);                              
                                MessageBox.Show("Error at receipt: " + receipt.Tax_Invoice + ". Please navigate to LAS screen to S0017 to continue upload");
                                continue;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        ErrorLogReceiptManager.ErrorLogInsert(string.Empty, string.Empty, string.Empty, string.Empty, "Key receipt error: " + ex.Message);
                    }
                    finally
                    {
                        grdLogs.DataSource = ErrorLogReceiptManager.AllErrorLogLoad2();
                    }

                    break;

                #endregion

                #region Action D
                case 6:
                    s2480 = new S2480("");
                    string current_scr = s2480.GetScreenCode();
                    if (current_scr != "S2480")
                    {
                        MsgBox.ShowMessageWarning("You don't stand at S2480. Please navigate to LAS screen to S2480 -  Client Maintenance Submenu.");
                        return;
                    }

                    var client_actionds = DATA_ACTION_D_Manager.GetAllClients();
                    ClientNo = "";
                    msg = "";                    

                    foreach (var client in client_actionds)
                    {
                        try
                        {
                            try
                            {
                                //----------------S2480-----------
                                ClientNo = "";
                                ID = client.ID;
                                s2480 = new S2480(ID);
                                s2480.Action = "D";
                                s2480.SetValues(ID);
                                if (s2480.IsCurrentScreen() == false)
                                {
                                    MessageBox.Show("Error at client: " + client.ID + ". Please navigate to LAS screen to S2480 to continue upload.");
                                }
                                s2480.Execute();

                                msg = s2480.GetMessage().Trim();
                                if (msg.Contains("Client Not On File")) //Khong ton tai
                                {
                                    s2480.Action = "A";
                                    s2480.SetValues(ID);
                                    s2480.Execute();
                                    s2480.Enter();
                                    s2480.WaitingToNextScreen();
                                }
                            }
                            catch
                            {
                                continue;
                            }

                            //----------------S2465-----------
                            s2465 = new S2465(client);

                            if (s2480.Action == "A")
                            {
                                ClientNo = s2465.GetValues("Client").Trim();

                                s2465.Execute();

                                if (s2465.GetMessage2() != "")
                                {
                                    DATA_ACTION_D_Manager.ErrorLogInsert(client, String.Empty, "Key client fail, Error: " + msg);
                                    DATA_ACTION_D_Manager.InsertError(client, "Key client fail, Error: " + msg);
                                    s2465.F3();
                                    continue;
                                }

                                // LHT added -------------------------------
                                if (client.Country.Equals("VN"))
                                    s2465.Next();

                                //Tax ID Number
                                SR208 sr208 = new SR208(client);
                                sr208.Execute();
                                sr208.Enter();

                                // Check Duplicate
                                SV210 sv210 = new SV210();
                                sv210.Waiting(10);

                                msg = sv210.GetValues(new KN.Systems.Point(22, 4), 19);
                                if (msg.Contains("No Duplicate Client") == false)// Dulpicate
                                {
                                    DATA_ACTION_D_Manager.ErrorLogInsert(client, String.Empty, "Key client fail, Error: Duplicate Client");
                                    DATA_ACTION_D_Manager.InsertError(client, "Key client fail, Error: Duplicate Client");
                                    s2465.F3();
                                    continue;
                                }

                                s2465.Enter();
                                s2465.Execute("CheckDuplicate");
                                s2465.Enter();

                                //Write log
                                System.Threading.Thread.Sleep(300);
                                if (s2465.IsCurrentScreen() == true)
                                {
                                    s2465.F3();
                                    continue;
                                }

                                DATA_ACTION_D_Manager.ErrorLogInsert(client, ClientNo, "Key client Successful.");
                                DATA_ACTION_D_Manager.InsertSuccess(client);
                            }
                            else
                            {
                                ClientNo = s2465.GetValues("Client").Trim();
                                DATA_ACTION_D_Manager.ErrorLogInsert(client, ClientNo, "Key client fail, Error: ID already exist.");
                                DATA_ACTION_D_Manager.InsertError(client, "Key client fail, Error: ID already exist.");
                                if (s2465.IsCurrentScreen() == true)
                                {
                                    s2465.F3();
                                }                                
                            }                            
                        }
                        catch (Exception ex)
                        {
                            DATA_ACTION_D_Manager.InsertError(client, ex.Message.Substring(0, Math.Min(ex.Message.Length ,200)));
                            MessageBox.Show("Error at client: " + client.ID + ". Please navigate to LAS screen to S0017 to continue upload.");
                            continue;
                        }
                    }
                    break;
                #endregion

                #region Action N-Questionairy
                case 7:                   

                    try
                    {
                        DataTable master = DATA_Questionaire_Manager.GetAllQuestionairesMaster();

                        string message = "";
                        for (int i = 0; i < master.Rows.Count; i++)
                        {
                            try
                            {
                                message = "";
                                var s5002 = new S5002(master.Rows[i]["ContractNumber"].ToString(), master.Rows[i]["LifeAssured"].ToString(), "N");
                                string current_screen = s5002.GetScreenCode();
                                if (current_screen != "S5002")
                                {
                                    MsgBox.ShowMessageWarning("You don't stand at S5002. Please navigate LAS screen to S5002 - New Contract Proposal Submenu.");
                                    return;
                                }

                                s5002.Execute();
                                s5002.Enter();
                                s5002.WaitingToNextScreen();
                                message = s5002.GetMessage2();
                                if (message.StartsWith("Contract already in use") == true)
                                {
                                    continue;
                                }
                                DATA_Questionaire_Collection questions = DATA_Questionaire_Manager.GetAllQuestionaires(master.Rows[i]["ContractNumber"].ToString(), master.Rows[i]["LifeAssured"].ToString());
                                DATA_Questionaire_Collection ans_8 = DATA_Questionaire_Manager.GetAllQuestionaires(master.Rows[i]["ContractNumber"].ToString(), master.Rows[i]["LifeAssured"].ToString(), "Question_0008_1_Ans_%");

                                SW772 sw772 = new SW772(questions, ans_8);
                                sw772.Execute();
                                EhllapiWrapper.SendStr("@E");
                                message = s5002.GetMessage2();
                                if (message.StartsWith("Field must be entered") == true)
                                {
                                    DATA_Questionaire_Manager.InsertLog(new DATA_Questionaire(master.Rows[i]["ContractNumber"].ToString(), master.Rows[i]["LifeAssured"].ToString(), "Unknown"), "Error: Field must be entered");
                                    DATA_Questionaire_Manager.InsertError(master.Rows[i]["ContractNumber"].ToString(), master.Rows[i]["LifeAssured"].ToString(), "Error: Field must be entered");
                                    this.F3("SW772"); 
                                    continue;
                                }

                                System.Threading.Thread.Sleep(500);
                                EhllapiWrapper.SendStr("@E");
                                EhllapiWrapper.SendStr("Y");
                                EhllapiWrapper.SendStr("@E");

                                sw772.Waiting();
                                if (sw772.GetScreenCode() == sw772.screenconfig.code)
                                {
                                    DATA_Questionaire_Manager.InsertLog(new DATA_Questionaire(master.Rows[i]["ContractNumber"].ToString(), master.Rows[i]["LifeAssured"].ToString(), "Unknown"), sw772.GetMessage());
                                    DATA_Questionaire_Manager.InsertError(master.Rows[i]["ContractNumber"].ToString(), master.Rows[i]["LifeAssured"].ToString(), "Error.");
                                    this.F3("SW772");
                                    continue;
                                }
                                DATA_Questionaire_Manager.InsertSuccess(master.Rows[i]["ContractNumber"].ToString(), master.Rows[i]["LifeAssured"].ToString(), "Key-in successfully.");

                            }catch(Exception ex)
                            {
                                DATA_Questionaire_Manager.InsertLog(new DATA_Questionaire(master.Rows[i]["ContractNumber"].ToString(), master.Rows[i]["LifeAssured"].ToString(), ex.Message.Substring(0,21)) , "Error.");
                                DATA_Questionaire_Manager.InsertError(master.Rows[i]["ContractNumber"].ToString(), master.Rows[i]["LifeAssured"].ToString(), "Error.");
                                
                                this.F3("SW772"); 
                                continue;
                            }

                        }
                    }
                    catch
                    {
                                             
                    }
                    break;
                #endregion

                #region Action X - Small Advance Policy
                case 8:
                    IList<Prudential.AutoUpload.Classes.Models.RcptDisc2LA> RcptDisc2LAs = new List<Classes.Models.RcptDisc2LA>();
                    IList<Policy> Policies = new List<Policy>();
                    Classes.Controllers.RcptDisc2LA objRcptDisc2LA = new Classes.Controllers.RcptDisc2LA();
                    LogItem logInfo = null;

                    RcptDisc2LAs = (IList<Prudential.AutoUpload.Classes.Models.RcptDisc2LA>)grdInfo.DataSource; //objRcptDisc2LA.Process(textBox1.Text);
                    foreach (Classes.Models.RcptDisc2LA item in RcptDisc2LAs)
                    {
                        Policy pol = new Policy();
                        pol.Bank_Code = item.Bank_Code;
                        pol.Contract_Number = item.Contract_Number;
                        pol.Tax_Invoice = item.Tax_Invoice;
                        pol.Action = item.Action;
                        pol.OR1_Number = item.OR1_Number;
                        pol.Collected_Agent_Collector = item.Collected_Agent_Collector;
                        pol.OR2_Number = item.OR2_Number;
                        pol.Payment_Type = item.Payment_Type;
                        pol.Received_From = item.Received_From;
                        pol.Amount = item.Amount;
                        pol.TR_NO = item.TR_NO;

                        if (item.OR1_Number.StartsWith("GA") || item.OR1_Number.StartsWith("CS"))
                            pol.Receipt_Date = "";
                        else
                            pol.Receipt_Date = item.Receipt_Date;
                        pol.GL_Amount = item.GL_Amount;
                        pol.BSB_Code = item.BSB_Code;
                        pol.Cheque_No = item.Cheque_No;
                        pol.Cheque_Date = item.Cheque_Date;
                        pol.InterID = item.InterID;
                        pol.SubCode1 = item.SubCode1;
                        pol.SubType1 = item.SubType1;
                        pol.Contract_Number1 = item.Contract_Number1;
                        pol.GASubType = item.GASubType;
                        pol.Desc1 = item.Desc1;
                        pol.SubAmount1 = item.SubAmount1;
                        pol.SubCode2 = item.SubCode2;
                        pol.SubType2 = item.SubType2;
                        pol.Contract_Number2 = item.Contract_Number2;
                        pol.Desc2 = item.Desc2;
                        pol.SubAmount2 = item.SubAmount2;
                        pol.SubCode3 = item.SubCode3;
                        pol.SubType3 = item.SubType3;
                        pol.Contract_Number3 = item.Contract_Number3;
                        pol.Desc3 = item.Desc3;
                        pol.SubAmount3 = item.SubAmount3;
                        pol.PTD_ADV = item.PTD_ADV;
                        pol.InsPrem = item.InsPrem;
                        pol.branchcode = item.branchcode;
                        pol.AlertMsg = item.AlertMsg;

                        logInfo = ImportPolicy(pol);

                        //Add data for grdInfo
                        Policies.Add(pol);
                        //Add data for grdSuccessful & grdFail

                        item.ReceiptNo = logInfo.ReceiptNo;
                        item.ErrorMessage = logInfo.ErrorMessage;
                        item.status = logInfo.status;
                        item.TranDate = logInfo.TranDate;

                        System.Threading.Thread.Sleep(1000);
                    }
                    //grdInfo.DataSource = Policies;

                    //grdFail.DataSource = RcptDisc2LAs.Where(f=>!f.status).ToList();
                    grdFail.DataSource = (from item in RcptDisc2LAs
                                          where item.status == false
                                          select new {
                                              item.ErrorMessage,
                                              item.Bank_Code,
                                              item.Tax_Invoice,
                                              item.Contract_Number,
                                              item.Action,
                                              item.OR1_Number,
                                              item.Collected_Agent_Collector,
                                              item.OR2_Number,
                                              item.Payment_Type,
                                              item.Received_From,
                                              item.Amount,
                                              item.TR_NO,
                                              item.Receipt_Date,
                                              item.GL_Amount,
                                              item.BSB_Code,
                                              item.Cheque_No,
                                              item.Cheque_Date,
                                              item.InterID,
                                              item.SubCode1,
                                              item.SubType1,
                                              item.Contract_Number1,
                                              item.GASubType,
                                              item.Desc1,
                                              item.SubAmount1,
                                              item.SubCode2,
                                              item.SubType2,
                                              item.Contract_Number2,
                                              item.Desc2,
                                              item.SubAmount2,
                                              item.SubCode3,
                                              item.SubType3,
                                              item.Contract_Number3,
                                              item.Desc3,
                                              item.SubAmount3,
                                              item.PTD_ADV,
                                              item.InsPrem,
                                              item.branchcode,
                                              item.AlertMsg,
                                              item.ReceiptNo,
                                              item.status,
                                              item.TranDate
                                          }).ToList();

                    //grdSuccess.DataSource = RcptDisc2LAs.Where(f => f.status).ToList();
                    grdSuccess.DataSource = (from item in RcptDisc2LAs
                                             where item.status == true
                                             select new {
                                                 item.ErrorMessage,
                                                 item.Bank_Code,
                                                 item.Tax_Invoice,
                                                 item.Contract_Number,
                                                 item.Action,
                                                 item.OR1_Number,
                                                 item.Collected_Agent_Collector,
                                                 item.OR2_Number,
                                                 item.Payment_Type,
                                                 item.Received_From,
                                                 item.Amount,
                                                 item.TR_NO,
                                                 item.Receipt_Date,
                                                 item.GL_Amount,
                                                 item.BSB_Code,
                                                 item.Cheque_No,
                                                 item.Cheque_Date,
                                                 item.InterID,
                                                 item.SubCode1,
                                                 item.SubType1,
                                                 item.Contract_Number1,
                                                 item.GASubType,
                                                 item.Desc1,
                                                 item.SubAmount1,
                                                 item.SubCode2,
                                                 item.SubType2,
                                                 item.Contract_Number2,
                                                 item.Desc2,
                                                 item.SubAmount2,
                                                 item.SubCode3,
                                                 item.SubType3,
                                                 item.Contract_Number3,
                                                 item.Desc3,
                                                 item.SubAmount3,
                                                 item.PTD_ADV,
                                                 item.InsPrem,
                                                 item.branchcode,
                                                 item.AlertMsg,
                                                 item.ReceiptNo,
                                                 item.status,
                                                 item.TranDate
                                             }).ToList();

                    grdLogs.DataSource = (from item in RcptDisc2LAs
                                          select new { 
                                            item.Tax_Invoice, 
                                            item.Contract_Number,
                                            item.ReceiptNo,
                                            item.branchcode,
                                            item.ErrorMessage
                                          }).ToList();
                    break;
                #endregion

                #region Action R
                case 9:

                    try
                    {

                        S2067 s2067_R = new S2067();
                        s0017 = new S0017("");
                        string current_screen = s0017.GetScreenCode();
                        if (current_screen != "S0017")
                        {
                            MsgBox.ShowMessageWarning("You don't stand at S0017. Please navigate to LAS screen to S0017.");
                            return;
                        }

                        var receipts = DATA_SV51D_Manager.GetAllReceipts();

                        foreach (var receipt in receipts)
                        {
                            string sTransID_N = string.Empty;
                            string sShowHRC = string.Empty;
                            string msg_N = string.Empty;

                            try
                            {
                                screen = new KN.Systems.Screen();

                                s0017 = new S0017(receipt.BranchCode);
                                s0018 = new S0018();

                                if (s0017.IsCurrentScreen() == false)
                                {
                                    MessageBox.Show("Error at receipt: " + receipt.Tax_Invoice + ". Please navigate to LAS screen to S0017 to continue upload");
                                }
                                s0017.Execute();//Branch Code

                                p = GetMenuPosition2(s0017, "Receivables and Payables");

                                if (p != null)
                                {
                                    s0017.Enter(p);//Enter

                                    if (s0018.IsCurrentScreen() == false)
                                    {
                                        MessageBox.Show("Error at receipt: " + receipt.Tax_Invoice + ". Please navigate to LAS screen to S0018 to continue upload");
                                    }
                                    p = GetMenuPosition2(s0018, "Receipts");
                                    if (p != null)
                                    {
                                        //System.Threading.Thread.Sleep(500);
                                        s0018.Enter(p); //S2067
                                    }
                                }
                                //-----------S2067--------------------

                                DATA_S2067 data_s2067 = new DATA_S2067(receipt);
                                s2067_R = new S2067(data_s2067);
                                if (s2067_R.IsCurrentScreen() == false)
                                {
                                    MessageBox.Show("Error at receipt: " + receipt.Tax_Invoice + ". Please navigate to LAS screen to S2067 to continue upload");
                                }
                                s2067_R.Execute();
                                s2067_R.Enter2();

                                if (s2067_R.IsCurrentScreen() == true)
                                {
                                    try
                                    {
                                        msg_N = s2067_R.GetMessage2().Trim();

                                        if (!string.IsNullOrEmpty(msg_N))
                                        {
                                            ErrorLogReceiptManager.ErrorLogInsert(receipt.Tax_Invoice, receipt.Contract_Number, string.Empty, receipt.BranchCode, "Key receipt fail, Error: " + msg_N);
                                            DATA_SV51D_Manager.InsertError(receipt, "Key receipt fail, Error: " + msg_N);
                                            s2067_R.F3();//S0018
                                            s2067_R.F3();//S0017
                                            continue;
                                        }
                                    }
                                    catch
                                    {
                                    }
                                }

                                //SV15U
                                SV15U SV15U = new SV15U (receipt);
                                if (SV15U.IsCurrentScreen() == false)
                                {
                                    MessageBox.Show("Error at receipt: " + receipt.Tax_Invoice + ". Please navigate to LAS screen to SV15U to continue upload");
                                }

                                //try
                                //{
                                //    msg_N = sv51D.GetMessage2().Trim();
                                //}
                                //catch
                                //{
                                //}

                                //if (!string.IsNullOrEmpty(msg_N) && msg_N.ToLower().Trim().StartsWith(">>> hd luu y dac biet") == false)
                                //{
                                //    ErrorLogReceiptManager.ErrorLogInsert(receipt.Tax_Invoice, receipt.Contract_Number, string.Empty, receipt.BranchCode, "Key receipt fail, Error: " + msg_N);
                                //    DATA_SV51D_Manager.InsertError(receipt, "Key receipt fail, Error: " + msg_N);

                                //    s2067_R.F3();//S2067
                                //    s2067_R.F3();//S0018
                                //    s2067_R.F3();//S0017
                                //    continue;
                                //}
                                //sv51D.Waiting();


                                sShowHRC = SV15U.GetValues(new KN.Systems.Point(15, 10), 3);
                                if (sShowHRC == "HRC") // New BS Check HRC(Y/N)
                                    SV15U.SetValues(new KN.Systems.Point(15, 20), "Y");

                                SV15U.Execute();
                                sTransID_N = SV15U.GetValues(new KN.Systems.Point(3, 15), 8);
                                SV15U.F5();

                                if (
                                    //sv51U.GetValues(new KN.Systems.Point(14, 33), 15).StartsWith("Over 50mil VND") == true ||
                                    SV15U.GetValues(new KN.Systems.Point(14, 33), 15).StartsWith("Over 150mil VND") == true)
                                {
                                    SV15U.SetValues(new KN.Systems.Point(14, 56), "Y");
                                }

                                SV15U.Enter();

                                #region PNH => CMT
                                //// LHT added
                                //if (sv51D.screenconfig.items["OR1_Number"].itemconfig.values.ToString().Substring(0, 2).Equals("GA") || sv51D.screenconfig.items["OR1_Number"].itemconfig.values.ToString().Substring(0, 2).Equals("CS"))
                                //{
                                //    DATA_SV021 data_sv021 = new DATA_SV021("", "", "", "", "", "");
                                //    SV021 sv021 = new SV021(data_sv021);
                                //    sv021.Enter();
                                //    sv021.Wait(10);
                                //    sv51D.Enter();
                                //}
                                //// ---------
                                #endregion

                                if (s2067_R.IsCurrentScreen() == true)
                                {
                                    ErrorLogReceiptManager.ErrorLogInsert(receipt.Tax_Invoice, receipt.Contract_Number, sTransID_N, receipt.BranchCode, "Key receipt successfully");
                                    DATA_SV15U_Manager.InsertSuccess(receipt);
                                    s2067_R.F3();//S0018
                                    s2067_R.F3();//S0017                                    
                                    continue;
                                }

                                if (SV15U.IsCurrentScreen() == true)
                                {
                                    msg_N = SV15U.GetMessage2().Trim();
                                    ErrorLogReceiptManager.ErrorLogInsert(receipt.Tax_Invoice, receipt.Contract_Number, string.Empty, receipt.BranchCode, "Key receipt fail. Error: " + msg_N);
                                    DATA_SV15U_Manager.InsertError(receipt, "Key receipt fail. Error: " + msg_N);
                                    SV15U.F3();//S2067
                                    s2067_R.F3();//S0018
                                    s2067_R.F3();//S0017
                                    continue;
                                }

                            }
                            catch (Exception ex)
                            {
                                ErrorLogReceiptManager.ErrorLogInsert(receipt.Tax_Invoice, receipt.Contract_Number, string.Empty, receipt.BranchCode, "Key receipt fail. Error: " + ex.Message);
                                DATA_SV15U_Manager.InsertError(receipt, "Key receipt fail. Error: " + ex.Message);
                                MessageBox.Show("Error at receipt: " + receipt.Tax_Invoice + ". Please navigate to LAS screen to S0017 to continue upload");
                                continue;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        ErrorLogReceiptManager.ErrorLogInsert(string.Empty, string.Empty, string.Empty, string.Empty, "Key receipt error: " + ex.Message);
                    }
                    finally
                    {
                        grdLogs.DataSource = ErrorLogReceiptManager.AllErrorLogLoad2();
                    }

                    break;

                    #endregion
            }

            this.Disconnect();

            object infos = null;
            DataTable sucesses = null;
            DataTable fail = null;
            DataTable log = null;
            //Show result
            switch (iUploadTypeId)
            {
                case 1: //Action C
                    infos = DATA_S2610_ACTION_C_Manager.GetAllClients2(); 
                    //Result
                    sucesses = DATA_S2610_ACTION_C_Manager.GetSuccessClients();                    
                    fail = DATA_S2610_ACTION_C_Manager.GetFailClientsEx();

                    //grdInfo.Columns["NeedToKeyReceipt"].Visible = false;                    
                    grdInfo.DataSource = infos;
                    grdSuccess.DataSource = sucesses;
                    grdFail.DataSource = fail;

                    tabFail.Text = "Fail (" + fail.Rows.Count.ToString() + ")";
                    tabSuccess.Text = "Success (" + sucesses.Rows.Count.ToString() + ")";

                    break;

                case 2: //Action A
                    infos = DATA_S2610_ACTION_A_Manager.GetAllReceipts();
                    
                    //Result                   
                    sucesses = DATA_S2610_ACTION_A_Manager.GetSuccessReceipts();                    
                    fail = DATA_S2610_ACTION_A_Manager.GetFailReceipts();
                    
                    grdInfo.DataSource = infos;
                    grdSuccess.DataSource = sucesses;
                    grdFail.DataSource = fail;

                    tabFail.Text = "Fail (" + fail.Rows.Count.ToString() + ")";
                    tabSuccess.Text = "Success (" + sucesses.Rows.Count.ToString() + ")";
                    break;

                case 3: //Action N
                    infos = DATA_SV51D_Manager.GetAllReceipts();
                    //Result
                    sucesses = DATA_SV51D_Manager.GetSuccessReceipts();
                    fail = DATA_SV51D_Manager.GetFailReceipts();

                    grdInfo.DataSource = infos;
                    grdSuccess.DataSource = sucesses;
                    grdFail.DataSource = fail;

                    tabFail.Text = "Fail (" + fail.Rows.Count.ToString() + ")";
                    tabSuccess.Text = "Success (" + sucesses.Rows.Count.ToString() + ")";

                    break;

                case 4: //Action L
                    infos = DATA_SV51B_Manager.GetAllReceipts();
                    //Result
                    sucesses = DATA_SV51B_Manager.GetSuccessReceipts();
                    fail = DATA_SV51B_Manager.GetFailReceipts();

                    grdInfo.DataSource = infos;
                    grdSuccess.DataSource = sucesses;
                    grdFail.DataSource = fail;

                    tabFail.Text = "Fail (" + fail.Rows.Count.ToString() + ")";
                    tabSuccess.Text = "Success (" + sucesses.Rows.Count.ToString() + ")";
                    break;

                case 5: //Action J
                    infos = DATA_SV50K_Manager.GetAllReceipts();
                    //Result
                    sucesses = DATA_SV50K_Manager.GetSuccessReceipts();
                    fail = DATA_SV50K_Manager.GetFailReceipts();

                    grdInfo.DataSource = infos;
                    grdSuccess.DataSource = sucesses;
                    grdFail.DataSource = fail;

                    tabFail.Text = "Fail (" + fail.Rows.Count.ToString() + ")";
                    tabSuccess.Text = "Success (" + sucesses.Rows.Count.ToString() + ")";
                    break;

                case 6: //Action D
                    infos = DATA_ACTION_D_Manager.GetAllClients2();
                    //Result
                    sucesses = DATA_ACTION_D_Manager.GetSuccessClients();
                    fail = DATA_ACTION_D_Manager.GetFailClients();
                    log = DATA_ACTION_D_Manager.GetLogClients();

                    grdInfo.DataSource = infos;
                    grdSuccess.DataSource = sucesses;
                    grdFail.DataSource = fail;
                    grdLogs.DataSource = log;

                    tabFail.Text = "Fail (" + fail.Rows.Count.ToString() + ")";
                    tabSuccess.Text = "Success (" + sucesses.Rows.Count.ToString() + ")";
                    break;
                case 7: //Action 7- Questionaire
                    infos = DATA_Questionaire_Manager.GetAllQuestionaires();
                    //Result
                    sucesses = DATA_Questionaire_Manager.GetSuccessQuestionaire();
                    fail = DATA_Questionaire_Manager.GetFailQuestionaire();
                    log = DATA_Questionaire_Manager.GetLogQuestionaire();

                    grdInfo.DataSource = infos;
                    grdSuccess.DataSource = sucesses;
                    grdFail.DataSource = fail;
                    grdLogs.DataSource = log;

                    tabFail.Text = "Fail (" + DATA_Questionaire_Manager.CountFailQuestionaire().ToString() + ")";
                    tabSuccess.Text = "Success (" + DATA_Questionaire_Manager.CountSuccessQuestionaire().ToString() + ")";
                    break;
                case 8:
                    tabFail.Text = "Fail (" + grdFail.RowCount + ")";
                    tabSuccess.Text = "Success (" + grdSuccess.RowCount + ")";
                    break;
                case 9: //Action R
                    infos = DATA_SV15U_Manager.GetAllReceipts();
                    //Result
                    sucesses = DATA_SV15U_Manager.GetSuccessReceipts();
                    fail = DATA_SV15U_Manager.GetFailReceipts();

                    grdInfo.DataSource = infos;
                    grdSuccess.DataSource = sucesses;
                    grdFail.DataSource = fail;

                    tabFail.Text = "Fail (" + fail.Rows.Count.ToString() + ")";
                    tabSuccess.Text = "Success (" + sucesses.Rows.Count.ToString() + ")";

                    break;
            }

            MsgBox.ShowMessageInfo("Upload finished");
            cmdUploadGA_Click(null, null);
        }

        private LogItem ImportPolicy(Policy pol)
        {
            CommandScript cmdScript = new CommandScript();
            List<ScreenBlock> blocks = cmdScript.GetScript(pol);
            LogItem logItem = new LogItem();
            KN.BusinessLogic.Proposal.CommandMsg.Clear();

            int i =0;
            try
            {
                foreach (var block in blocks)
                {
                    block.Execute();
                    if (KN.BusinessLogic.Proposal.CommandMsg.HasError())
                    {
                        switch(i)
                        { 
                            case 2:
                                this.F3("S2067");
                                System.Threading.Thread.Sleep(300);
                                this.F3("S0018");
                                break;
                            case 3:
                                this.F3("SV15X");
                                System.Threading.Thread.Sleep(300);
                                this.F3("S2067");
                                System.Threading.Thread.Sleep(300);
                                this.F3("S0018");
                                break;
                        }
                        break;
                    }
                    i++;
                }
                i = 0;

                if (KN.BusinessLogic.Proposal.CommandMsg.HasError())
                {
                    logItem.status = false;
                    logItem.ErrorMessage = KN.BusinessLogic.Proposal.CommandMsg.Error;
                    logItem.TranDate = DateTime.Now.ToString();
                }
                else
                {
                    this.F3("S2067");
                    System.Threading.Thread.Sleep(300);
                    this.F3("S0018");
                    System.Threading.Thread.Sleep(300);

                    logItem.ReceiptNo = KN.BusinessLogic.Proposal.CommandMsg.GetVar("TransID");
                    logItem.status = true;
                    logItem.ErrorMessage = "Success!!!";
                    logItem.TranDate = DateTime.Now.ToString();
                    
                }
                
            }
            catch (Exception ex)
            {
                logItem.status = false;
                logItem.ErrorMessage = ex.Message.ToString();
                logItem.TranDate = DateTime.Now.ToString();
            }
            finally
            {
                KN.BusinessLogic.Proposal.CommandMsg.ClearError();
            }
            return logItem;
        }

        private void F3(string sScreenCode)
        {
            KN.Systems.Screen screen = new KN.Systems.Screen();

            if (screen.GetScreenCode().Contains(sScreenCode))
                screen.F3();
        }

        private string GetMessage(KN.Systems.Screen screen)
        {
            return screen.GetValues(new KN.Systems.Point(24, 2), 70);
        }

        private KN.Systems.Point GetMenuPosition(KN.Systems.Screen screen, string sMenu)
        {
            for (int x = 1; x <= 24; x++)
            {                
                for (int y = 1; y <= 80; y++)
                {                    
                    string sCurrentRow = screen.GetValues(new KN.Systems.Point(x, 1), 80);

                    if (sCurrentRow.Contains(sMenu))
                    {
                        y = sCurrentRow.IndexOf(sMenu);
                        return new KN.Systems.Point(x, y);
                    }
                }
            }

            return null;
        }

        private KN.Systems.Point GetMenuPosition2(KN.Systems.Screen screen, string sMenu)
        {
            var menus = LifeMenuManager.MenuLoad(sMenu);

            foreach (LifeMenu menu in menus)
            {
                System.Threading.Thread.Sleep(200);

                string sCurrentRow = screen.GetValues(new KN.Systems.Point(menu.X, menu.Y), menu.Leng);

                if (sCurrentRow.Contains(sMenu))
                {                    
                    return new KN.Systems.Point(menu.X, menu.Y);
                }
            }           

            return null;
        }

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Disconnect();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Connect()
        {
            if (EhllapiWrapper.Connect(false) != 0)
                MsgBox.ShowMessageError("Can not connect to LAS screen. Please try another session.");
        }

        private void Disconnect()
        {
            EhllapiWrapper.Disconnect();
        }

        private void aToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AppSetting.SESSION = "A";
            ClearCheckMenu();
            aToolStripMenuItem.Checked = true;
        }

        private void bToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AppSetting.SESSION = "B";
            ClearCheckMenu();
            bToolStripMenuItem.Checked = true;
        }

        private void cToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AppSetting.SESSION = "C";
            ClearCheckMenu();
            cToolStripMenuItem.Checked = true;
        }

        private void dToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AppSetting.SESSION = "D";
            ClearCheckMenu();
            dToolStripMenuItem.Checked = true;
        }

        private void eToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AppSetting.SESSION = "E";
            ClearCheckMenu();
            dToolStripMenuItem.Checked = true;
        }

        private void fToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AppSetting.SESSION = "F";
            ClearCheckMenu();
            dToolStripMenuItem.Checked = true;
        }
        private void ClearCheckMenu()
        {
            aToolStripMenuItem.Checked = false;
            bToolStripMenuItem.Checked = false;
            cToolStripMenuItem.Checked = false;
            dToolStripMenuItem.Checked = false;
        }

        private void cmdClearLog_Click(object sender, EventArgs e)
        {
            int iUploadTypeId = ((UploadType)cbbUploadType.SelectedItem).ID;

            switch (iUploadTypeId)
            {
                case 1: //Action C
                    ErrorLog_Action_C_Manager.ErrorLogClear();
                    grdLogs.DataSource = ErrorLog_Action_C_Manager.AllErrorLogLoad();
                    break;

                case 2: //Action A
                    ErrorLog_Action_A_Manager.ErrorLogClear();
                    grdLogs.DataSource = ErrorLog_Action_A_Manager.AllErrorLogLoad();
                    break;

                case 3: //Action N
                case 4: //Action L
                case 5: //Action J
                case 9: //Action R
                    ErrorLogReceiptManager.ErrorLogClear();
                    grdLogs.DataSource = ErrorLogReceiptManager.AllErrorLogLoad();
                    break;
                case 6: //Action D
                    DATA_ACTION_D_Manager.ClearLogs();
                    grdLogs.DataSource = DATA_ACTION_D_Manager.GetLogClients();
                    break;
                case 7: //Action 7- Questionaire
                    DATA_Questionaire_Manager.ClearQuestionaireLogs();
                    grdLogs.DataSource = DATA_Questionaire_Manager.GetLogQuestionaire();
                    break;
            }

        }

        private void btnExportLog_Click(object sender, EventArgs e)
        {
            string sLog = string.Empty;

            if (grdLogs.Columns.Count > 0)
            {
                foreach (DataGridViewColumn col in grdLogs.Columns)
                    sLog += col.HeaderText + ",";

                sLog = sLog.TrimEnd(',') + "\r\n";

                foreach (DataGridViewRow row in grdLogs.Rows)
                {
                    foreach (DataGridViewCell cell in row.Cells)
                        if (cell.Value != null)
                        {
                            sLog += cell.Value.ToString().Replace(',', '.') + ",";
                        }
                        else
                        {
                            sLog += ",";
                        }

                    sLog = sLog.TrimEnd(',') + "\r\n";
                }

                SaveFile(sLog);
            }
        }

        private void SaveFile(string s)
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            //saveFileDialog1.InitialDirectory = @"C:\";
            saveFileDialog1.Title = "Save File";
            saveFileDialog1.DefaultExt = "csv";
            saveFileDialog1.Filter = "CSV files (*.csv)|*.csv";
            saveFileDialog1.FilterIndex = 1;
            saveFileDialog1.RestoreDirectory = true;
            saveFileDialog1.FileName = "Export";//this.cbbUploadType.Text;

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                using (StreamWriter outFile = new StreamWriter(saveFileDialog1.FileName))
                {
                    outFile.Write(s);
                }
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cbbUploadType_SelectedIndexChanged(object sender, EventArgs e)
        {
            grdInfo.DataSource = null; //clear data
        }

        private void cmdSuccessExport_Click(object sender, EventArgs e)
        {
            DataTable dt = null;
            int iUploadTypeId = ((UploadType)cbbUploadType.SelectedItem).ID;
            switch (iUploadTypeId)
            {
                case 1: //Action C
                    dt = DATA_S2610_ACTION_C_Manager.GetSuccessClients();  
                    break;

                case 2: //Action A
                    dt = DATA_S2610_ACTION_A_Manager.GetSuccessReceipts();                    
                    break;

                case 3: //Action N                   
                    dt = DATA_SV51D_Manager.GetSuccessReceipts(); 
                    break;

                case 4: //Action L                   
                    dt = DATA_SV51B_Manager.GetSuccessReceipts();                    
                    break;

                case 5: //Action J                   
                    dt = DATA_SV50K_Manager.GetSuccessReceipts();                    
                    break;

                case 7: //Action 7- Questionaire
                    dt = DATA_Questionaire_Manager.GetSuccessQuestionaire();
                    break;
                case 9: //Action R                   
                    dt = DATA_SV15U_Manager.GetSuccessReceipts();
                    break;
            }

            string sLog = string.Empty;

            if (dt.Columns.Count > 0)
            {
                foreach (DataColumn col in dt.Columns)
                    sLog += col.ColumnName + ",";

                sLog = sLog.TrimEnd(',') + "\r\n";

                foreach (DataRow row in dt.Rows)
                {                   
                    foreach (var cell in row.ItemArray)
                    {
                        if (cell == null)
                            sLog += ",";
                        else
                            sLog += cell.ToString().Trim().Replace(',', '.') + ",";                        
                    }

                    sLog = sLog + "\r\n";
                }

                SaveFile(sLog);
            }
        }

        private void cmdFailExport_Click(object sender, EventArgs e)
        {
            DataTable dt = null;
            //int iUploadTypeId = ((UploadType)cbbUploadType.SelectedItem).ID;
            //switch (iUploadTypeId)
            //{
            //    case 1: //Action C
            //        dt = DATA_S2610_ACTION_C_Manager.GetFailClientsEx();
            //        break;

            //    case 2: //Action A
            //        dt = DATA_S2610_ACTION_A_Manager.GetFailReceiptsEx();
            //        break;

            //    case 3: //Action N                   
            //        dt = DATA_SV51D_Manager.GetFailReceiptsEx();
            //        break;

            //    case 4: //Action L                   
            //        dt = DATA_SV51B_Manager.GetFailReceiptsEx();
            //        break;

            //    case 5: //Action J                   
            //        dt = DATA_SV50K_Manager.GetFailReceiptsEx();
            //        break;
            //}
            dt = (DataTable)grdFail.DataSource;
            string sLog = string.Empty;
            
            if (dt.Columns.Count > 0)
            {
                foreach (DataColumn col in dt.Columns)
                {
                    if (col.ColumnName == "message") continue;
                    sLog += col.ColumnName + ",";
                }
                sLog = sLog.TrimEnd(',') + "\r\n";
                foreach (DataRow row in dt.Rows)
                {
                    for (int i = 1; i < dt.Columns.Count; i++ )
                    {
                        var cell = row[i].ToString();
                        if (cell == null)
                            sLog += ",";
                        else
                            sLog += cell.ToString().Trim().Replace(',', '.') + ",";
                    }

                    sLog = sLog.TrimEnd(',') + "\r\n";
                }
                SaveFile(sLog);
            }
        }

        private void cmdSuccessClear_Click(object sender, EventArgs e)
        {
            grdSuccess.DataSource = null;
            DATA_S2610_ACTION_A_Manager.ClearSuccessReceipts();
            DATA_S2610_ACTION_C_Manager.ClearSuccessClients();
            DATA_SV51B_Manager.ClearSuccessReceipts();
            DATA_SV50K_Manager.ClearSuccessReceipts();
            DATA_SV51D_Manager.ClearSuccessReceipts();
            tabSuccess.Text = "Success";            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            grdFail.DataSource = null;

            DATA_S2610_ACTION_A_Manager.ClearFailReceipts();
            DATA_S2610_ACTION_C_Manager.ClearFailClients();
            DATA_ACTION_D_Manager.ClearFailClients();
            DATA_SV51B_Manager.ClearFailReceipts();
            DATA_SV50K_Manager.ClearFailReceipts();
            DATA_SV51D_Manager.ClearFailReceipts();
            DATA_SV15U_Manager.ClearFailReceipts();
            tabFail.Text = "Fail";
        }

        private void cmdClearAll_Click(object sender, EventArgs e)
        {
            grdInfo.DataSource = null;
            ClearDataLog();
        }

        private void ClearDataLog() {
            grdSuccess.DataSource = null;
            DATA_S2610_ACTION_A_Manager.ClearSuccessReceipts();
            DATA_S2610_ACTION_C_Manager.ClearSuccessClients();
            DATA_ACTION_D_Manager.ClearSuccessClients();
            DATA_SV51B_Manager.ClearSuccessReceipts();
            DATA_SV50K_Manager.ClearSuccessReceipts();
            DATA_SV51D_Manager.ClearSuccessReceipts();
            DATA_SV15U_Manager.ClearSuccessReceipts();
            tabSuccess.Text = "Success";

            grdFail.DataSource = null;
            DATA_S2610_ACTION_A_Manager.ClearFailReceipts();
            DATA_S2610_ACTION_C_Manager.ClearFailClients();
            DATA_ACTION_D_Manager.ClearFailClients();
            DATA_SV51B_Manager.ClearFailReceipts();
            DATA_SV50K_Manager.ClearFailReceipts();
            DATA_SV51D_Manager.ClearFailReceipts();
            DATA_SV15U_Manager.ClearFailReceipts();
            tabFail.Text = "Fail";

            grdLogs.DataSource = null;
            ErrorLog_Action_C_Manager.ErrorLogClear();
            ErrorLogReceiptManager.ErrorLogClear();
            ErrorLog_Action_A_Manager.ErrorLogClear();
        }

        private void grdLogs_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void cmdUploadGA_Click(object sender, EventArgs e)
        {
            DataTable dt = null;
            int iUploadTypeId = ((UploadType)cbbUploadType.SelectedItem).ID;
            switch (iUploadTypeId)
            {
                case 1: //Action C
                    dt = ErrorLog_Action_C_Manager.GetDataForGANET();
                    break;

                case 2: //Action A
                    dt = ErrorLog_Action_A_Manager.GetDataForGANET();
                    break;

                case 3: //Action N                   
                    //MessageBox.Show("Please choose another action!");
                    return;

                case 4: //Action L                   
                    //MessageBox.Show("Please choose another action!");
                    return;

                case 5: //Action J                   
                    //MessageBox.Show("Please choose another action!");
                    return;
                case 6: //Action D                  
                    dt = DATA_ACTION_D_Manager.GetDataForGANET();
                    break;
                case 7: //Action N - Questionaire                  
                    return;
                case 8: //Action N - Questionaire                  
                    return;
                case 9: //Action R                   
                    //MessageBox.Show("Please choose another action!");
                    return;
            }

            string sLog = string.Empty;

            if (dt.Columns.Count > 0)
            {
                foreach (DataColumn col in dt.Columns)
                    sLog += col.ColumnName + ",";

                sLog = sLog.TrimEnd(',') + "\r\n";

                foreach (DataRow row in dt.Rows)
                {
                    foreach (var cell in row.ItemArray)
                    {
                        if (cell == null)
                            sLog += ",";
                        else
                            sLog += cell.ToString().Trim().Replace(',', '.') + ",";
                    }

                    sLog = sLog.Trim().Substring(0, sLog.Length-1) + "\r\n";
                }

                SaveFile(sLog);
            }
        }

        private void cmdKeyProposal_Click(object sender, EventArgs e)
        {
            try
            {
                this.Hide();
                frmProposal obj = new frmProposal();
                obj.ShowDialog();
                this.Show();
            }
            catch { }
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Connect();

            S2465 s2465 = new S2465();
            s2465.SetValues(new KN.Systems.Point(14, 18), "A");
            string msg =s2465.GetMessage();
        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            this.Connect();
            S2465 s2465 = new S2465();
            s2465.SetValues(new KN.Systems.Point(5, 16), "LE HUU THO");
        }     
    }
}
