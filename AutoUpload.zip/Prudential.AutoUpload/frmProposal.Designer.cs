﻿namespace Prudential.AutoUpload
{
    partial class frmProposal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmProposal));
            this.btnSuccessExport = new System.Windows.Forms.Button();
            this.tabSuccess = new System.Windows.Forms.TabPage();
            this.grdSuccess = new System.Windows.Forms.DataGridView();
            this.cmdSuccessClear = new System.Windows.Forms.Button();
            this.tabFail = new System.Windows.Forms.TabPage();
            this.cmdFailExport = new System.Windows.Forms.Button();
            this.grdFail = new System.Windows.Forms.DataGridView();
            this.btnFailClear = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.tabLog = new System.Windows.Forms.TabPage();
            this.grdLogs = new System.Windows.Forms.DataGridView();
            this.btnExportLog = new System.Windows.Forms.Button();
            this.cmdClearLog = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.grdInfo = new System.Windows.Forms.DataGridView();
            this.tabInfo = new System.Windows.Forms.TabPage();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnUpload = new System.Windows.Forms.Button();
            this.btnBrowser = new System.Windows.Forms.Button();
            this.txtFileName = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.oldVersionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cmdFailClear = new System.Windows.Forms.TabControl();
            this.cmdClearAll = new System.Windows.Forms.Button();
            this.chkStopIfError = new System.Windows.Forms.CheckBox();
            this.chkSlow = new System.Windows.Forms.CheckBox();
            this.cmdKeyAction = new System.Windows.Forms.Button();
            this.tabSuccess.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdSuccess)).BeginInit();
            this.tabFail.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdFail)).BeginInit();
            this.tabLog.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdLogs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdInfo)).BeginInit();
            this.tabInfo.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.cmdFailClear.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnSuccessExport
            // 
            this.btnSuccessExport.Location = new System.Drawing.Point(123, 260);
            this.btnSuccessExport.Name = "btnSuccessExport";
            this.btnSuccessExport.Size = new System.Drawing.Size(100, 23);
            this.btnSuccessExport.TabIndex = 12;
            this.btnSuccessExport.Text = "Export Success";
            this.btnSuccessExport.UseVisualStyleBackColor = true;
            this.btnSuccessExport.Click += new System.EventHandler(this.btnSuccessExport_Click);
            // 
            // tabSuccess
            // 
            this.tabSuccess.Controls.Add(this.btnSuccessExport);
            this.tabSuccess.Controls.Add(this.grdSuccess);
            this.tabSuccess.Controls.Add(this.cmdSuccessClear);
            this.tabSuccess.Location = new System.Drawing.Point(4, 22);
            this.tabSuccess.Name = "tabSuccess";
            this.tabSuccess.Padding = new System.Windows.Forms.Padding(3);
            this.tabSuccess.Size = new System.Drawing.Size(653, 294);
            this.tabSuccess.TabIndex = 8;
            this.tabSuccess.Text = "Success";
            this.tabSuccess.UseVisualStyleBackColor = true;
            // 
            // grdSuccess
            // 
            this.grdSuccess.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grdSuccess.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.grdSuccess.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.grdSuccess.DefaultCellStyle = dataGridViewCellStyle2;
            this.grdSuccess.Location = new System.Drawing.Point(-1, 3);
            this.grdSuccess.Name = "grdSuccess";
            this.grdSuccess.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grdSuccess.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.grdSuccess.Size = new System.Drawing.Size(654, 243);
            this.grdSuccess.TabIndex = 10;
            // 
            // cmdSuccessClear
            // 
            this.cmdSuccessClear.Location = new System.Drawing.Point(14, 260);
            this.cmdSuccessClear.Name = "cmdSuccessClear";
            this.cmdSuccessClear.Size = new System.Drawing.Size(100, 23);
            this.cmdSuccessClear.TabIndex = 11;
            this.cmdSuccessClear.Text = "Clear Success";
            this.cmdSuccessClear.UseVisualStyleBackColor = true;
            this.cmdSuccessClear.Click += new System.EventHandler(this.cmdSuccessClear_Click);
            // 
            // tabFail
            // 
            this.tabFail.Controls.Add(this.cmdFailExport);
            this.tabFail.Controls.Add(this.grdFail);
            this.tabFail.Controls.Add(this.btnFailClear);
            this.tabFail.Location = new System.Drawing.Point(4, 22);
            this.tabFail.Name = "tabFail";
            this.tabFail.Padding = new System.Windows.Forms.Padding(3);
            this.tabFail.Size = new System.Drawing.Size(653, 294);
            this.tabFail.TabIndex = 9;
            this.tabFail.Text = "Fail";
            this.tabFail.UseVisualStyleBackColor = true;
            // 
            // cmdFailExport
            // 
            this.cmdFailExport.Location = new System.Drawing.Point(123, 260);
            this.cmdFailExport.Name = "cmdFailExport";
            this.cmdFailExport.Size = new System.Drawing.Size(100, 23);
            this.cmdFailExport.TabIndex = 12;
            this.cmdFailExport.Text = "Export Fail";
            this.cmdFailExport.UseVisualStyleBackColor = true;
            this.cmdFailExport.Click += new System.EventHandler(this.cmdFailExport_Click);
            // 
            // grdFail
            // 
            this.grdFail.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grdFail.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.grdFail.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.grdFail.DefaultCellStyle = dataGridViewCellStyle5;
            this.grdFail.Location = new System.Drawing.Point(-1, 3);
            this.grdFail.Name = "grdFail";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grdFail.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.grdFail.Size = new System.Drawing.Size(654, 243);
            this.grdFail.TabIndex = 10;
            // 
            // btnFailClear
            // 
            this.btnFailClear.Location = new System.Drawing.Point(13, 260);
            this.btnFailClear.Name = "btnFailClear";
            this.btnFailClear.Size = new System.Drawing.Size(100, 23);
            this.btnFailClear.TabIndex = 11;
            this.btnFailClear.Text = "Clear Fail";
            this.btnFailClear.UseVisualStyleBackColor = true;
            this.btnFailClear.Click += new System.EventHandler(this.btnFailClear_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // tabLog
            // 
            this.tabLog.Controls.Add(this.grdLogs);
            this.tabLog.Controls.Add(this.btnExportLog);
            this.tabLog.Controls.Add(this.cmdClearLog);
            this.tabLog.Location = new System.Drawing.Point(4, 22);
            this.tabLog.Name = "tabLog";
            this.tabLog.Size = new System.Drawing.Size(653, 294);
            this.tabLog.TabIndex = 7;
            this.tabLog.Text = "Logs";
            this.tabLog.UseVisualStyleBackColor = true;
            // 
            // grdLogs
            // 
            this.grdLogs.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grdLogs.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.grdLogs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.grdLogs.DefaultCellStyle = dataGridViewCellStyle8;
            this.grdLogs.Location = new System.Drawing.Point(-1, 3);
            this.grdLogs.Name = "grdLogs";
            this.grdLogs.ReadOnly = true;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grdLogs.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.grdLogs.Size = new System.Drawing.Size(654, 243);
            this.grdLogs.TabIndex = 11;
            // 
            // btnExportLog
            // 
            this.btnExportLog.Location = new System.Drawing.Point(123, 260);
            this.btnExportLog.Name = "btnExportLog";
            this.btnExportLog.Size = new System.Drawing.Size(100, 23);
            this.btnExportLog.TabIndex = 9;
            this.btnExportLog.Text = "Export Log";
            this.btnExportLog.UseVisualStyleBackColor = true;
            this.btnExportLog.Click += new System.EventHandler(this.btnExportLog_Click);
            // 
            // cmdClearLog
            // 
            this.cmdClearLog.Location = new System.Drawing.Point(13, 260);
            this.cmdClearLog.Name = "cmdClearLog";
            this.cmdClearLog.Size = new System.Drawing.Size(100, 23);
            this.cmdClearLog.TabIndex = 8;
            this.cmdClearLog.Text = "Clear Log";
            this.cmdClearLog.UseVisualStyleBackColor = true;
            this.cmdClearLog.Click += new System.EventHandler(this.cmdClearLog_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 13);
            this.label2.TabIndex = 20;
            this.label2.Text = "File upload";
            // 
            // grdInfo
            // 
            this.grdInfo.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grdInfo.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.grdInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.grdInfo.DefaultCellStyle = dataGridViewCellStyle11;
            this.grdInfo.Location = new System.Drawing.Point(-1, 3);
            this.grdInfo.Name = "grdInfo";
            this.grdInfo.ReadOnly = true;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grdInfo.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.grdInfo.Size = new System.Drawing.Size(654, 291);
            this.grdInfo.TabIndex = 0;
            // 
            // tabInfo
            // 
            this.tabInfo.Controls.Add(this.grdInfo);
            this.tabInfo.Location = new System.Drawing.Point(4, 22);
            this.tabInfo.Name = "tabInfo";
            this.tabInfo.Padding = new System.Windows.Forms.Padding(3);
            this.tabInfo.Size = new System.Drawing.Size(653, 294);
            this.tabInfo.TabIndex = 0;
            this.tabInfo.Text = "Upload Info";
            this.tabInfo.UseVisualStyleBackColor = true;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.Red;
            this.btnExit.ForeColor = System.Drawing.Color.White;
            this.btnExit.Location = new System.Drawing.Point(687, 402);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(89, 23);
            this.btnExit.TabIndex = 17;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnUpload
            // 
            this.btnUpload.BackColor = System.Drawing.Color.Blue;
            this.btnUpload.ForeColor = System.Drawing.Color.White;
            this.btnUpload.Location = new System.Drawing.Point(687, 128);
            this.btnUpload.Name = "btnUpload";
            this.btnUpload.Size = new System.Drawing.Size(89, 23);
            this.btnUpload.TabIndex = 16;
            this.btnUpload.Text = "Input to LAS";
            this.btnUpload.UseVisualStyleBackColor = false;
            this.btnUpload.Click += new System.EventHandler(this.btnUpload_Click);
            // 
            // btnBrowser
            // 
            this.btnBrowser.Location = new System.Drawing.Point(354, 64);
            this.btnBrowser.Name = "btnBrowser";
            this.btnBrowser.Size = new System.Drawing.Size(75, 23);
            this.btnBrowser.TabIndex = 14;
            this.btnBrowser.Text = "Browser";
            this.btnBrowser.UseVisualStyleBackColor = true;
            this.btnBrowser.Click += new System.EventHandler(this.btnBrowser_Click);
            // 
            // txtFileName
            // 
            this.txtFileName.Location = new System.Drawing.Point(80, 66);
            this.txtFileName.Name = "txtFileName";
            this.txtFileName.Size = new System.Drawing.Size(268, 20);
            this.txtFileName.TabIndex = 13;
            this.txtFileName.Text = "<Please choose a file>";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.oldVersionToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(792, 24);
            this.menuStrip1.TabIndex = 12;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // oldVersionToolStripMenuItem
            // 
            this.oldVersionToolStripMenuItem.Name = "oldVersionToolStripMenuItem";
            this.oldVersionToolStripMenuItem.Size = new System.Drawing.Size(73, 20);
            this.oldVersionToolStripMenuItem.Text = "Old Version";
            this.oldVersionToolStripMenuItem.Visible = false;
            this.oldVersionToolStripMenuItem.Click += new System.EventHandler(this.oldVersionToolStripMenuItem_Click);
            // 
            // cmdFailClear
            // 
            this.cmdFailClear.Controls.Add(this.tabInfo);
            this.cmdFailClear.Controls.Add(this.tabSuccess);
            this.cmdFailClear.Controls.Add(this.tabFail);
            this.cmdFailClear.Controls.Add(this.tabLog);
            this.cmdFailClear.Location = new System.Drawing.Point(12, 105);
            this.cmdFailClear.Name = "cmdFailClear";
            this.cmdFailClear.SelectedIndex = 0;
            this.cmdFailClear.Size = new System.Drawing.Size(661, 320);
            this.cmdFailClear.TabIndex = 15;
            // 
            // cmdClearAll
            // 
            this.cmdClearAll.Location = new System.Drawing.Point(687, 160);
            this.cmdClearAll.Name = "cmdClearAll";
            this.cmdClearAll.Size = new System.Drawing.Size(89, 23);
            this.cmdClearAll.TabIndex = 21;
            this.cmdClearAll.Text = "Clear All";
            this.cmdClearAll.UseVisualStyleBackColor = true;
            this.cmdClearAll.Click += new System.EventHandler(this.cmdClearAll_Click);
            // 
            // chkStopIfError
            // 
            this.chkStopIfError.AutoSize = true;
            this.chkStopIfError.Checked = global::Prudential.AutoUpload.Properties.Settings.Default.StopIfError;
            this.chkStopIfError.DataBindings.Add(new System.Windows.Forms.Binding("Checked", global::Prudential.AutoUpload.Properties.Settings.Default, "StopIfError", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.chkStopIfError.Location = new System.Drawing.Point(687, 208);
            this.chkStopIfError.Name = "chkStopIfError";
            this.chkStopIfError.Size = new System.Drawing.Size(82, 17);
            this.chkStopIfError.TabIndex = 23;
            this.chkStopIfError.Text = "Stop If Error";
            this.chkStopIfError.UseVisualStyleBackColor = true;
            this.chkStopIfError.CheckedChanged += new System.EventHandler(this.chkStopIfError_CheckedChanged);
            // 
            // chkSlow
            // 
            this.chkSlow.AutoSize = true;
            this.chkSlow.Checked = global::Prudential.AutoUpload.Properties.Settings.Default.RunSlowly;
            this.chkSlow.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkSlow.DataBindings.Add(new System.Windows.Forms.Binding("Checked", global::Prudential.AutoUpload.Properties.Settings.Default, "RunSlowly", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.chkSlow.Location = new System.Drawing.Point(687, 189);
            this.chkSlow.Name = "chkSlow";
            this.chkSlow.Size = new System.Drawing.Size(79, 17);
            this.chkSlow.TabIndex = 22;
            this.chkSlow.Text = "Run Slowly";
            this.chkSlow.UseVisualStyleBackColor = true;
            this.chkSlow.CheckedChanged += new System.EventHandler(this.chkSlow_CheckedChanged);
            // 
            // cmdKeyAction
            // 
            this.cmdKeyAction.BackColor = System.Drawing.Color.Blue;
            this.cmdKeyAction.ForeColor = System.Drawing.Color.White;
            this.cmdKeyAction.Location = new System.Drawing.Point(687, 241);
            this.cmdKeyAction.Name = "cmdKeyAction";
            this.cmdKeyAction.Size = new System.Drawing.Size(89, 36);
            this.cmdKeyAction.TabIndex = 24;
            this.cmdKeyAction.Text = "Back Key-in Action";
            this.cmdKeyAction.UseVisualStyleBackColor = false;
            this.cmdKeyAction.Click += new System.EventHandler(this.cmdKeyAction_Click);
            // 
            // frmProposal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(792, 437);
            this.Controls.Add(this.cmdKeyAction);
            this.Controls.Add(this.chkStopIfError);
            this.Controls.Add(this.chkSlow);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnUpload);
            this.Controls.Add(this.btnBrowser);
            this.Controls.Add(this.txtFileName);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.cmdFailClear);
            this.Controls.Add(this.cmdClearAll);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmProposal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Prudential Auto Upload Proposal - v.20130808.16.00.00";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmProposal_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmProposal_FormClosed);
            this.Load += new System.EventHandler(this.frmProposal_Load);
            this.tabSuccess.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdSuccess)).EndInit();
            this.tabFail.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdFail)).EndInit();
            this.tabLog.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdLogs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdInfo)).EndInit();
            this.tabInfo.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.cmdFailClear.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSuccessExport;
        private System.Windows.Forms.TabPage tabSuccess;
        private System.Windows.Forms.DataGridView grdSuccess;
        private System.Windows.Forms.Button cmdSuccessClear;
        private System.Windows.Forms.TabPage tabFail;
        private System.Windows.Forms.Button cmdFailExport;
        private System.Windows.Forms.DataGridView grdFail;
        private System.Windows.Forms.Button btnFailClear;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.TabPage tabLog;
        private System.Windows.Forms.DataGridView grdLogs;
        private System.Windows.Forms.Button btnExportLog;
        private System.Windows.Forms.Button cmdClearLog;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView grdInfo;
        private System.Windows.Forms.TabPage tabInfo;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnUpload;
        private System.Windows.Forms.Button btnBrowser;
        private System.Windows.Forms.TextBox txtFileName;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.TabControl cmdFailClear;
        private System.Windows.Forms.Button cmdClearAll;
        private System.Windows.Forms.CheckBox chkSlow;
        private System.Windows.Forms.CheckBox chkStopIfError;
        private System.Windows.Forms.ToolStripMenuItem oldVersionToolStripMenuItem;
        private System.Windows.Forms.Button cmdKeyAction;
    }
}