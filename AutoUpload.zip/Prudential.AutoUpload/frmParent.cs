﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Prudential.AutoUpload
{
    public partial class frmParent : Form
    {
        public frmParent()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            frmMain obj = new frmMain();
            obj.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmMicroInsurance obj = new frmMicroInsurance();
            obj.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            frmPrinting obj = new frmPrinting();
            obj.Show();
        }
    }
}
