﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using viclib;
using KN.Systems;
namespace Prudential.AutoUpload
{
    public partial class frmPrinting : Form
    {
        public frmPrinting()
        {
            InitializeComponent();
        }

        private void cmdPrint_Click(object sender, EventArgs e)
        {
            vicwin.imgdes img = new vicwin.imgdes();
            string filename = @"D:\TestPrint\ReleaseImages\0024B63E.TIF";
            //vicwin.loadtif(ref filename, ref img);
            //KN.Systems.Vic32Wrapper.mnutifmultipage1(filename);

            var pdoc = new PrintDocument();
            pdoc.DocumentName = filename;
            pdoc.Print();
        }
    }
}
