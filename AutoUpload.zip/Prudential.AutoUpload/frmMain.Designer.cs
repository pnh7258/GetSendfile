﻿namespace Prudential.AutoUpload
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.btnBrowser = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btnUpload = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.systemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sessionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cmdFailClear = new System.Windows.Forms.TabControl();
            this.tabInfo = new System.Windows.Forms.TabPage();
            this.grdInfo = new System.Windows.Forms.DataGridView();
            this.tabSuccess = new System.Windows.Forms.TabPage();
            this.cmdSuccessExport = new System.Windows.Forms.Button();
            this.grdSuccess = new System.Windows.Forms.DataGridView();
            this.cmdSuccessClear = new System.Windows.Forms.Button();
            this.tabFail = new System.Windows.Forms.TabPage();
            this.cmdFailExport = new System.Windows.Forms.Button();
            this.grdFail = new System.Windows.Forms.DataGridView();
            this.button4 = new System.Windows.Forms.Button();
            this.tabLog = new System.Windows.Forms.TabPage();
            this.cmdUploadGA = new System.Windows.Forms.Button();
            this.grdLogs = new System.Windows.Forms.DataGridView();
            this.btnExportLog = new System.Windows.Forms.Button();
            this.cmdClearLog = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.cbbUploadType = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cmdClearAll = new System.Windows.Forms.Button();
            this.cmdKeyProposal = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.cmdFailClear.SuspendLayout();
            this.tabInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdInfo)).BeginInit();
            this.tabSuccess.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdSuccess)).BeginInit();
            this.tabFail.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdFail)).BeginInit();
            this.tabLog.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdLogs)).BeginInit();
            this.SuspendLayout();
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // btnBrowser
            // 
            this.btnBrowser.Location = new System.Drawing.Point(354, 64);
            this.btnBrowser.Name = "btnBrowser";
            this.btnBrowser.Size = new System.Drawing.Size(75, 23);
            this.btnBrowser.TabIndex = 2;
            this.btnBrowser.Text = "Browser";
            this.btnBrowser.UseVisualStyleBackColor = true;
            this.btnBrowser.Click += new System.EventHandler(this.btnBrowser_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(80, 66);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(268, 20);
            this.textBox1.TabIndex = 1;
            this.textBox1.Text = "<Please chose a file>";
            // 
            // btnUpload
            // 
            this.btnUpload.BackColor = System.Drawing.Color.Blue;
            this.btnUpload.ForeColor = System.Drawing.Color.White;
            this.btnUpload.Location = new System.Drawing.Point(687, 128);
            this.btnUpload.Name = "btnUpload";
            this.btnUpload.Size = new System.Drawing.Size(89, 23);
            this.btnUpload.TabIndex = 5;
            this.btnUpload.Text = "Input to LAS";
            this.btnUpload.UseVisualStyleBackColor = false;
            this.btnUpload.Click += new System.EventHandler(this.btnUpload_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.Red;
            this.btnExit.ForeColor = System.Drawing.Color.White;
            this.btnExit.Location = new System.Drawing.Point(687, 402);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(89, 23);
            this.btnExit.TabIndex = 7;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.systemToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(792, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(35, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(92, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // systemToolStripMenuItem
            // 
            this.systemToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sessionToolStripMenuItem});
            this.systemToolStripMenuItem.Name = "systemToolStripMenuItem";
            this.systemToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.systemToolStripMenuItem.Text = "System";
            // 
            // sessionToolStripMenuItem
            // 
            this.sessionToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aToolStripMenuItem,
            this.bToolStripMenuItem,
            this.cToolStripMenuItem,
            this.dToolStripMenuItem,
            this.eToolStripMenuItem,
            this.fToolStripMenuItem});
            this.sessionToolStripMenuItem.Name = "sessionToolStripMenuItem";
            this.sessionToolStripMenuItem.Size = new System.Drawing.Size(110, 22);
            this.sessionToolStripMenuItem.Text = "Session";
            // 
            // aToolStripMenuItem
            // 
            this.aToolStripMenuItem.Checked = true;
            this.aToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.aToolStripMenuItem.Name = "aToolStripMenuItem";
            this.aToolStripMenuItem.Size = new System.Drawing.Size(81, 22);
            this.aToolStripMenuItem.Text = "A";
            this.aToolStripMenuItem.Click += new System.EventHandler(this.aToolStripMenuItem_Click);
            // 
            // bToolStripMenuItem
            // 
            this.bToolStripMenuItem.Name = "bToolStripMenuItem";
            this.bToolStripMenuItem.Size = new System.Drawing.Size(81, 22);
            this.bToolStripMenuItem.Text = "B";
            this.bToolStripMenuItem.Click += new System.EventHandler(this.bToolStripMenuItem_Click);
            // 
            // cToolStripMenuItem
            // 
            this.cToolStripMenuItem.Name = "cToolStripMenuItem";
            this.cToolStripMenuItem.Size = new System.Drawing.Size(81, 22);
            this.cToolStripMenuItem.Text = "C";
            this.cToolStripMenuItem.Click += new System.EventHandler(this.cToolStripMenuItem_Click);
            // 
            // dToolStripMenuItem
            // 
            this.dToolStripMenuItem.Name = "dToolStripMenuItem";
            this.dToolStripMenuItem.Size = new System.Drawing.Size(81, 22);
            this.dToolStripMenuItem.Text = "D";
            this.dToolStripMenuItem.Click += new System.EventHandler(this.dToolStripMenuItem_Click);
            // 
            // eToolStripMenuItem
            // 
            this.eToolStripMenuItem.Name = "eToolStripMenuItem";
            this.eToolStripMenuItem.Size = new System.Drawing.Size(81, 22);
            this.eToolStripMenuItem.Text = "E";
            this.eToolStripMenuItem.Click += new System.EventHandler(this.eToolStripMenuItem_Click);
            // 
            // fToolStripMenuItem
            // 
            this.fToolStripMenuItem.Name = "fToolStripMenuItem";
            this.fToolStripMenuItem.Size = new System.Drawing.Size(81, 22);
            this.fToolStripMenuItem.Text = "F";
            this.fToolStripMenuItem.Click += new System.EventHandler(this.fToolStripMenuItem_Click);
            // 
            // cmdFailClear
            // 
            this.cmdFailClear.Controls.Add(this.tabInfo);
            this.cmdFailClear.Controls.Add(this.tabSuccess);
            this.cmdFailClear.Controls.Add(this.tabFail);
            this.cmdFailClear.Controls.Add(this.tabLog);
            this.cmdFailClear.Location = new System.Drawing.Point(12, 105);
            this.cmdFailClear.Name = "cmdFailClear";
            this.cmdFailClear.SelectedIndex = 0;
            this.cmdFailClear.Size = new System.Drawing.Size(661, 320);
            this.cmdFailClear.TabIndex = 3;
            // 
            // tabInfo
            // 
            this.tabInfo.Controls.Add(this.grdInfo);
            this.tabInfo.Location = new System.Drawing.Point(4, 22);
            this.tabInfo.Name = "tabInfo";
            this.tabInfo.Padding = new System.Windows.Forms.Padding(3);
            this.tabInfo.Size = new System.Drawing.Size(653, 294);
            this.tabInfo.TabIndex = 0;
            this.tabInfo.Text = "Upload Info";
            this.tabInfo.UseVisualStyleBackColor = true;
            // 
            // grdInfo
            // 
            this.grdInfo.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grdInfo.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.grdInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.grdInfo.DefaultCellStyle = dataGridViewCellStyle2;
            this.grdInfo.Location = new System.Drawing.Point(-1, 3);
            this.grdInfo.Name = "grdInfo";
            this.grdInfo.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grdInfo.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.grdInfo.Size = new System.Drawing.Size(654, 291);
            this.grdInfo.TabIndex = 0;
            // 
            // tabSuccess
            // 
            this.tabSuccess.Controls.Add(this.cmdSuccessExport);
            this.tabSuccess.Controls.Add(this.grdSuccess);
            this.tabSuccess.Controls.Add(this.cmdSuccessClear);
            this.tabSuccess.Location = new System.Drawing.Point(4, 22);
            this.tabSuccess.Name = "tabSuccess";
            this.tabSuccess.Padding = new System.Windows.Forms.Padding(3);
            this.tabSuccess.Size = new System.Drawing.Size(653, 294);
            this.tabSuccess.TabIndex = 8;
            this.tabSuccess.Text = "Success";
            this.tabSuccess.UseVisualStyleBackColor = true;
            // 
            // cmdSuccessExport
            // 
            this.cmdSuccessExport.Location = new System.Drawing.Point(123, 266);
            this.cmdSuccessExport.Name = "cmdSuccessExport";
            this.cmdSuccessExport.Size = new System.Drawing.Size(104, 23);
            this.cmdSuccessExport.TabIndex = 12;
            this.cmdSuccessExport.Text = "Export Success";
            this.cmdSuccessExport.UseVisualStyleBackColor = true;
            this.cmdSuccessExport.Click += new System.EventHandler(this.cmdSuccessExport_Click);
            // 
            // grdSuccess
            // 
            this.grdSuccess.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grdSuccess.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.grdSuccess.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.grdSuccess.DefaultCellStyle = dataGridViewCellStyle5;
            this.grdSuccess.Location = new System.Drawing.Point(-1, 6);
            this.grdSuccess.Name = "grdSuccess";
            this.grdSuccess.ReadOnly = true;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grdSuccess.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.grdSuccess.Size = new System.Drawing.Size(654, 243);
            this.grdSuccess.TabIndex = 10;
            // 
            // cmdSuccessClear
            // 
            this.cmdSuccessClear.Location = new System.Drawing.Point(13, 266);
            this.cmdSuccessClear.Name = "cmdSuccessClear";
            this.cmdSuccessClear.Size = new System.Drawing.Size(93, 23);
            this.cmdSuccessClear.TabIndex = 11;
            this.cmdSuccessClear.Text = "Clear Success";
            this.cmdSuccessClear.UseVisualStyleBackColor = true;
            this.cmdSuccessClear.Click += new System.EventHandler(this.cmdSuccessClear_Click);
            // 
            // tabFail
            // 
            this.tabFail.Controls.Add(this.cmdFailExport);
            this.tabFail.Controls.Add(this.grdFail);
            this.tabFail.Controls.Add(this.button4);
            this.tabFail.Location = new System.Drawing.Point(4, 22);
            this.tabFail.Name = "tabFail";
            this.tabFail.Padding = new System.Windows.Forms.Padding(3);
            this.tabFail.Size = new System.Drawing.Size(653, 294);
            this.tabFail.TabIndex = 9;
            this.tabFail.Text = "Fail";
            this.tabFail.UseVisualStyleBackColor = true;
            // 
            // cmdFailExport
            // 
            this.cmdFailExport.Location = new System.Drawing.Point(94, 266);
            this.cmdFailExport.Name = "cmdFailExport";
            this.cmdFailExport.Size = new System.Drawing.Size(75, 23);
            this.cmdFailExport.TabIndex = 12;
            this.cmdFailExport.Text = "Export Fail";
            this.cmdFailExport.UseVisualStyleBackColor = true;
            this.cmdFailExport.Click += new System.EventHandler(this.cmdFailExport_Click);
            // 
            // grdFail
            // 
            this.grdFail.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grdFail.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.grdFail.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.grdFail.DefaultCellStyle = dataGridViewCellStyle8;
            this.grdFail.Location = new System.Drawing.Point(-1, 6);
            this.grdFail.Name = "grdFail";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grdFail.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.grdFail.Size = new System.Drawing.Size(654, 243);
            this.grdFail.TabIndex = 10;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(13, 266);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 11;
            this.button4.Text = "Clear Fail";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // tabLog
            // 
            this.tabLog.Controls.Add(this.cmdUploadGA);
            this.tabLog.Controls.Add(this.grdLogs);
            this.tabLog.Controls.Add(this.btnExportLog);
            this.tabLog.Controls.Add(this.cmdClearLog);
            this.tabLog.Location = new System.Drawing.Point(4, 22);
            this.tabLog.Name = "tabLog";
            this.tabLog.Size = new System.Drawing.Size(653, 294);
            this.tabLog.TabIndex = 7;
            this.tabLog.Text = "Logs";
            this.tabLog.UseVisualStyleBackColor = true;
            // 
            // cmdUploadGA
            // 
            this.cmdUploadGA.Location = new System.Drawing.Point(175, 257);
            this.cmdUploadGA.Name = "cmdUploadGA";
            this.cmdUploadGA.Size = new System.Drawing.Size(75, 23);
            this.cmdUploadGA.TabIndex = 12;
            this.cmdUploadGA.Text = "Upload GA";
            this.cmdUploadGA.UseVisualStyleBackColor = true;
            this.cmdUploadGA.Click += new System.EventHandler(this.cmdUploadGA_Click);
            // 
            // grdLogs
            // 
            this.grdLogs.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grdLogs.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.grdLogs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.grdLogs.DefaultCellStyle = dataGridViewCellStyle11;
            this.grdLogs.Location = new System.Drawing.Point(-4, 3);
            this.grdLogs.Name = "grdLogs";
            this.grdLogs.ReadOnly = true;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grdLogs.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.grdLogs.Size = new System.Drawing.Size(654, 243);
            this.grdLogs.TabIndex = 11;
            this.grdLogs.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grdLogs_CellContentClick);
            // 
            // btnExportLog
            // 
            this.btnExportLog.Location = new System.Drawing.Point(94, 257);
            this.btnExportLog.Name = "btnExportLog";
            this.btnExportLog.Size = new System.Drawing.Size(75, 23);
            this.btnExportLog.TabIndex = 9;
            this.btnExportLog.Text = "Export Log";
            this.btnExportLog.UseVisualStyleBackColor = true;
            this.btnExportLog.Click += new System.EventHandler(this.btnExportLog_Click);
            // 
            // cmdClearLog
            // 
            this.cmdClearLog.Location = new System.Drawing.Point(13, 257);
            this.cmdClearLog.Name = "cmdClearLog";
            this.cmdClearLog.Size = new System.Drawing.Size(75, 23);
            this.cmdClearLog.TabIndex = 8;
            this.cmdClearLog.Text = "Clear Log";
            this.cmdClearLog.UseVisualStyleBackColor = true;
            this.cmdClearLog.Click += new System.EventHandler(this.cmdClearLog_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Upload type";
            // 
            // cbbUploadType
            // 
            this.cbbUploadType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbUploadType.FormattingEnabled = true;
            this.cbbUploadType.Location = new System.Drawing.Point(80, 39);
            this.cbbUploadType.Name = "cbbUploadType";
            this.cbbUploadType.Size = new System.Drawing.Size(268, 21);
            this.cbbUploadType.TabIndex = 9;
            this.cbbUploadType.SelectedIndexChanged += new System.EventHandler(this.cbbUploadType_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "File upload";
            // 
            // cmdClearAll
            // 
            this.cmdClearAll.Location = new System.Drawing.Point(687, 159);
            this.cmdClearAll.Name = "cmdClearAll";
            this.cmdClearAll.Size = new System.Drawing.Size(89, 23);
            this.cmdClearAll.TabIndex = 11;
            this.cmdClearAll.Text = "Clear All";
            this.cmdClearAll.UseVisualStyleBackColor = true;
            this.cmdClearAll.Click += new System.EventHandler(this.cmdClearAll_Click);
            // 
            // cmdKeyProposal
            // 
            this.cmdKeyProposal.BackColor = System.Drawing.Color.Blue;
            this.cmdKeyProposal.ForeColor = System.Drawing.Color.White;
            this.cmdKeyProposal.Location = new System.Drawing.Point(687, 191);
            this.cmdKeyProposal.Name = "cmdKeyProposal";
            this.cmdKeyProposal.Size = new System.Drawing.Size(89, 23);
            this.cmdKeyProposal.TabIndex = 12;
            this.cmdKeyProposal.Text = "Key-in Proposal";
            this.cmdKeyProposal.UseVisualStyleBackColor = false;
            this.cmdKeyProposal.Click += new System.EventHandler(this.cmdKeyProposal_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(792, 437);
            this.Controls.Add(this.cmdKeyProposal);
            this.Controls.Add(this.cmdClearAll);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cbbUploadType);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmdFailClear);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnUpload);
            this.Controls.Add(this.btnBrowser);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Prudential Auto Upload - v.20150929.17.17.17";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.cmdFailClear.ResumeLayout(false);
            this.tabInfo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdInfo)).EndInit();
            this.tabSuccess.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdSuccess)).EndInit();
            this.tabFail.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdFail)).EndInit();
            this.tabLog.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdLogs)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button btnBrowser;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button btnUpload;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem systemToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sessionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dToolStripMenuItem;
        private System.Windows.Forms.TabControl cmdFailClear;
        private System.Windows.Forms.TabPage tabInfo;
        private System.Windows.Forms.DataGridView grdInfo;
        private System.Windows.Forms.TabPage tabLog;
        private System.Windows.Forms.Button cmdClearLog;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbbUploadType;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnExportLog;
        private System.Windows.Forms.TabPage tabSuccess;
        private System.Windows.Forms.Button cmdSuccessExport;
        private System.Windows.Forms.DataGridView grdSuccess;
        private System.Windows.Forms.Button cmdSuccessClear;
        private System.Windows.Forms.TabPage tabFail;
        private System.Windows.Forms.Button cmdFailExport;
        private System.Windows.Forms.DataGridView grdFail;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button cmdClearAll;
        private System.Windows.Forms.DataGridView grdLogs;
        private System.Windows.Forms.Button cmdUploadGA;
        private System.Windows.Forms.ToolStripMenuItem eToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fToolStripMenuItem;
        private System.Windows.Forms.Button cmdKeyProposal;
    }
}