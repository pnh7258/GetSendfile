﻿using KN.SmallAdvancePolicy;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Prudential.AutoUpload.Classes.Models
{
    public class RcptDisc2LA: LogItem
    {
        public string Bank_Code { get; set; }
        public string Tax_Invoice { get; set; }

        private string contract_Number;
        public string Contract_Number
        {
            get
            {
                string temp = string.Empty;
                if (contract_Number.Length < 8)
                {
                    for (int i = 0; i < (8 - contract_Number.Length); i++)
                    {
                        temp += "0";
                    }
                    contract_Number = string.Format("{0}{1}", temp, contract_Number);
                    return contract_Number;
                }
                else
                    return contract_Number;
            }
            set
            {
                contract_Number = value;
            }
        }

        public string Action { get; set; }
        public string OR1_Number { get; set; }
        public string Collected_Agent_Collector { get; set; }
        public string OR2_Number { get; set; }
        public string Payment_Type { get; set; }
        public string Received_From { get; set; }
        public string Amount { get; set; }
        public string TR_NO { get; set; }
        public string Receipt_Date { get; set; }
        public string GL_Amount { get; set; }
        public string BSB_Code { get; set; }
        public string Cheque_No { get; set; }
        public string Cheque_Date { get; set; }
        public string InterID { get; set; }
        public string SubCode1 { get; set; }
        public string SubType1 { get; set; }
        public string Contract_Number1 { get; set; }
        public string GASubType { get; set; }
        public string Desc1 { get; set; }
        public string SubAmount1 { get; set; }
        public string SubCode2 { get; set; }
        public string SubType2 { get; set; }
        public string Contract_Number2 { get; set; }
        public string Desc2 { get; set; }
        public string SubAmount2 { get; set; }
        public string SubCode3 { get; set; }
        public string SubType3 { get; set; }
        public string Contract_Number3 { get; set; }
        public string Desc3 { get; set; }
        public string SubAmount3 { get; set; }
        public string PTD_ADV { get; set; }
        public string InsPrem { get; set; }
        public string branchcode { get; set; }
        public string AlertMsg { get; set; }
    }
    
}
