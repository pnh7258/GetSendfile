﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Prudential.AutoUpload.Classes.Controllers
{
    public class RcptDisc2LA
    {
        public RcptDisc2LA() { }

        public IList<Models.RcptDisc2LA> Process(string PathFile)
        {
            IList<Models.RcptDisc2LA> RcptDisc2LAs = new List<Models.RcptDisc2LA>();
            string[] csvData = System.IO.File.ReadAllLines(PathFile);
            int i = 0;
            foreach (string line in csvData)
            {
                if (i > 0)
                {
                    string[] items = line.Split(new char[] { ',' });
                    if (items.Length >= 37)
                    {
                        RcptDisc2LAs.Add(new Models.RcptDisc2LA
                        {
                            Bank_Code = items[0],
                            Tax_Invoice = items[1],
                            Contract_Number = items[2],
                            Action = items[3],
                            OR1_Number = items[4],
                            Collected_Agent_Collector = items[5],
                            OR2_Number = items[6],
                            Payment_Type = items[7],
                            Received_From = items[8],
                            Amount = items[9],
                            TR_NO = items[10],
                            Receipt_Date = items[11],
                            GL_Amount = items[12],
                            BSB_Code = items[13],
                            Cheque_No = items[14],
                            Cheque_Date = items[15],
                            InterID = items[16],
                            SubCode1 = items[17],
                            SubType1 = items[18],
                            Contract_Number1 = items[19],
                            GASubType = items[20],
                            Desc1 = items[21],
                            SubAmount1 = items[22],
                            SubCode2 = items[23],
                            SubType2 = items[24],
                            Contract_Number2 = items[25],
                            Desc2 = items[26],
                            SubAmount2 = items[27],
                            SubCode3 = items[28],
                            SubType3 = items[29],
                            Contract_Number3 = items[30],
                            Desc3 = items[31],
                            SubAmount3 = items[32],
                            PTD_ADV = items[33],
                            InsPrem = items[34],
                            branchcode = items[35],
                            AlertMsg = items[36]
                        });
                    }
                }
                i++;
            }
            return RcptDisc2LAs;
        }
    }
}
