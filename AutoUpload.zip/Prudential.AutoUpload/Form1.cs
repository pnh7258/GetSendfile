﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using KN.Systems;
using KN.Screens;
using KN.BusinessLogic;
using KN.Proposals;
namespace Prudential.AutoUpload
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            EhllapiWrapper.Connect(true);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(EhllapiWrapper.Connect(KN.Systems.AppSetting.SESSION).ToString());
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show(EhllapiWrapper.Disconnect(KN.Systems.AppSetting.SESSION).ToString());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            EhllapiWrapper.SetCursorPos(5 * 80  + 53);
            EhllapiWrapper.SendStr(this.textBox1.Text);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            var client = ClientManager.ReadClientFromExcel("");
            
            screen = new S2465(client);            
        }
        S2465 screen;
        private void button5_Click(object sender, EventArgs e)
        {
            screen.Execute();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            screen.F3();
        }

        private void button7_Click(object sender, EventArgs e)
        {            
            var proposal = new KN.Proposals.ULP.Main("222");
            proposal.Fire();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Type mytype = Type.GetType("KN.Screens.S0127", false, true);

            if ((mytype = Type.GetType("KN.Screens.S0127", false, true)) == null)
            {
                System.Reflection.Assembly assembly = System.Reflection.Assembly.LoadFrom(@"C:\khang\Prudential.AutoUpload\Prudential.AutoUpload\bin\Debug\KN.Screen.dll");
                foreach (System.Type type in assembly.GetTypes())
                    if (type.IsClass && type.FullName.CompareTo("KN.Screens.S0127") == 0)
                        mytype = type;
            }


            object S0127= Activator.CreateInstance(mytype, new string[]{"X"} );
            ((KN.Systems.Screen)S0127).Execute();

        }

        private void button9_Click(object sender, EventArgs e)
        {
            EhllapiWrapper.GetSessionAttributes();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            KN.DataAcess.PruDBHelp db = new KN.DataAcess.PruDBHelp(@"C:\khang\test.xls");
            DataTable dt = db.ExecuteDataTable("select * from stores", CommandType.Text);
        }

        private void button11_Click(object sender, EventArgs e)
        {
            string message = "";
            EhllapiWrapper.Connect(true);
            EhllapiWrapper.ReadScreen(23*80 +2, int.Parse( textBox1.Text), out message);
            EhllapiWrapper.Disconnect();
            textBox1.Text = message;
        }

        private void button12_Click(object sender, EventArgs e)
        {
            string ID = textBox1.Text;
            S2480 s2480 = new S2480(ID);
            s2480.Action = "D";
            s2480.SetValues(ID);
            s2480.Execute();

            string msg = s2480.GetMessage();
            if (msg.StartsWith("Client Not On File"))// Khong ton tai
            {
                s2480.Action = "A";
                s2480.SetValues(ID);
                s2480.Execute();
                s2480.Enter();
            }

            var client = ClientManager.ReadClientFromExcel("");

            var s2465 = new S2465(client);            

            ID = s2465.GetValues("ID").Trim();
            if (s2480.Action == "A")
            {                
                s2465.Execute();                
                s2465.Next();
            }
            else
            {
                s2465.F3();
            }
            string LifeNo = "";
            LifeNo = s2465.GetValues("Client").Trim();

            
            textBox1.Text = textBox1.Text + "-" + LifeNo;
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            EhllapiWrapper.Disconnect();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            textBox1.Text = openFileDialog1.FileName;
            KN.Systems.ExcelProcess.UpLoad(textBox1.Text);
        }

        private void button15_Click(object sender, EventArgs e)
        {
            EhllapiWrapper.SetCursorPos(16 * 80 + 37);
            EhllapiWrapper.SendStr(this.textBox1.Text);
        }

        private void button16_Click(object sender, EventArgs e)
        {
            //EhllapiWrapper.SetCursorPos();

            string message = "";
            EhllapiWrapper.ReadScreen(16 * 80 + 37, 8, out message);
            this.textBox1.Text = message;

        }        
    }
}
