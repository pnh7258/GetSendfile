﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml.Serialization;
using KN.BusinessLogic.Proposal;
using KN.BusinessLogic.Proposal.Command;
using KN.Screens;
using KN.Systems;
using log4net;

namespace Prudential.AutoUpload
{
    public partial class frmProposal : Form
    {
        private static ILog log = LogManager.GetLogger(typeof(frmProposal));

        private List<Proposal> proposals;
        private frmMain m_frmMain;
        public frmProposal()
        {
            InitializeComponent();
        }
        public frmMain FrmMain
        {
            get { return m_frmMain; }
            set { m_frmMain = value; }
        }

        private void frmProposal_FormClosing(object sender, FormClosingEventArgs e)
        {
            Properties.Settings.Default.Save();
            this.DisconnectLAS();
        }
        private void frmProposal_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (FrmMain != null)
            {
                FrmMain.Close();
            }
            
        }
        /// <summary>
        /// Find the xml data file, and parse data into list Proposal
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnBrowser_Click(object sender, EventArgs e)
        {
            openFileDialog1.FileName = string.Empty;
            openFileDialog1.Filter = "All Files (*.*)|*.*|ZIP Files (*.zip)|*.zip|XML Files (*.xml)|*.xml"; 

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                txtFileName.Text = openFileDialog1.FileName;
                FileInfo file = new FileInfo(openFileDialog1.FileName);

                if (file.Exists == false)
                {
                    txtFileName.Text = "Invalid file path. Please try again";
                    MsgBox.ShowMessageError("Invalid file path. Please try again");
                    return;
                }

                if (file.Extension.ToUpper().Contains("ZIP") || file.Extension.ToUpper().Contains("XML"))
                {
                    try
                    {
                        this.proposals = ProposalXmlSerializer.Deserialize(txtFileName.Text);
                        UploadApp.LogItems.Clear();
                        UploadApp.ProcessedProposals.Clear();
                        ResetTabs();
                        UpdateInfoTab();
                    }
                    catch (Exception ex)
                    {
                        string str = ex.InnerException.Message;
                        string tag;
                        string row;
                        string msg = "";
                        string format = "";

                        if (str.Contains("does not match the end tag of"))
                        {
                            format = "File bị sai cấu trúc ở tag {0}' dòng {1}";

                            str = str.Substring(str.IndexOf("'"));
                            tag = str.Substring(0, str.IndexOf("start") - 2);
                            str = str.Substring(str.IndexOf("Line") + 5);
                            row = str.Substring(0, str.IndexOf(","));
                            msg = String.Format(format,tag,row).ToString();
                        }
                        else if (ex.Message.Contains("There is an error in XML document"))
                        {
                            str = ex.Message.Replace("There is an error in XML document (", "");
                            format = "File bị sai cấu trúc ở dòng {0}";
                            msg = String.Format(format, str.Split(',')[0]).ToString();
                        }
                        else
                        {
                            msg = ex.InnerException.Message;
                        }
                        MessageBox.Show(msg, "Prudential Auto Upload");
                    }
                }
                else
                {
                    MessageBox.Show("Vui lòng sử dụng file có định dạng XML hoặc ZIP.", "Prudential Auto Upload");
                }
            }
        }

        /// <summary>
        /// Input data to LAS
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnUpload_Click(object sender, EventArgs e)
        {
            if (grdInfo.Rows.Count <= 0)
            {
                MessageBox.Show("Vui lòng chọn file để nhập.","Prudential Auto Upload");
                txtFileName.Focus();
                return;
            }
            if (!this.ConnectLAS())
            {
                return;
            }
            log.Debug("=====================================");
            log.Debug("Start Uploading...");

            foreach (var proposal in this.proposals)
            {
                ImportProposal(proposal);
            }

            log.Debug("End Uploading...");
            log.Debug("=====================================");
            this.DisconnectLAS();

            UpdateResults();
        }
        private void chkSlow_CheckedChanged(object sender, EventArgs e)
        {
            UploadApp.RunSlow = chkSlow.Checked;
        }
        private void chkStopIfError_CheckedChanged(object sender, EventArgs e)
        {
            UploadApp.StopIfError = chkStopIfError.Checked;
        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
            //this.Close();
        }
        private void btnSuccessExport_Click(object sender, EventArgs e)
        {
            ExportSuccessProposal();
        }

        private void ExportSuccessProposal()
        {
            List<LogItem> lstSuccessLogs = UploadApp.ProcessedProposals.ToSuccessLog();

            SaveFileDialog saveFileDialog1 = new SaveFileDialog();

            saveFileDialog1.Title = "Save File";
            saveFileDialog1.DefaultExt = "zip";
            saveFileDialog1.Filter = "ZIP files (*.zip)|*.zip";
            saveFileDialog1.FilterIndex = 1;
            saveFileDialog1.RestoreDirectory = true;
            saveFileDialog1.FileName = "ProposalSuccessExport";

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                ProposalXmlSerializer.ExportLog(saveFileDialog1.FileName, lstSuccessLogs);
            }
        }
        private void cmdSuccessClear_Click(object sender, EventArgs e)
        {
            grdSuccess.DataSource = null;
            UploadApp.ProcessedProposals.Clear(true);
            tabSuccess.Text = "Success";
        }
        private void btnFailClear_Click(object sender, EventArgs e)
        {
            grdFail.DataSource = null;
            UploadApp.ProcessedProposals.Clear(false);
            tabFail.Text = "Fail";
        }
        private void cmdFailExport_Click(object sender, EventArgs e)
        {
            ExportProposal(false);
        }
        private void cmdClearLog_Click(object sender, EventArgs e)
        {
            grdLogs.DataSource = null;
            UploadApp.LogItems.Clear();
        }

        /// <summary>
        /// Write Logs to XML file
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnExportLog_Click(object sender, EventArgs e)
        {
            ExportLog();
        }

        private void ExportLog()
        {
            List<LogItem> lstLogs = UploadApp.LogItems;

            SaveFileDialog saveFileDialog1 = new SaveFileDialog();

            saveFileDialog1.Title = "Save File";
            saveFileDialog1.DefaultExt = "zip";
            saveFileDialog1.Filter = "ZIP files (*.zip)|*.zip";
            saveFileDialog1.FilterIndex = 1;
            saveFileDialog1.RestoreDirectory = true;
            saveFileDialog1.FileName = "ProposalLogExport";

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                ProposalXmlSerializer.ExportLog(saveFileDialog1.FileName, lstLogs);
            }
        }
        private void cmdClearAll_Click(object sender, EventArgs e)
        {
            grdInfo.DataSource = null;

            grdSuccess.DataSource = null;
            UploadApp.ProcessedProposals.Clear(true);
            tabSuccess.Text = "Success";

            grdFail.DataSource = null;
            UploadApp.ProcessedProposals.Clear(false);
            tabFail.Text = "Fail";

            grdLogs.DataSource = null;
            txtFileName.Text = "<Please choose a file>";
        }

        private void ResetTabs()
        {
            grdInfo.DataSource = null;
            grdSuccess.DataSource = null;
            grdFail.DataSource = null;
            grdLogs.DataSource = null;

            tabSuccess.Text = "Success";
            tabFail.Text = "Fail";
        }
        private void UpdateInfoTab()
        {
            grdInfo.DataSource = this.proposals;
            if (grdInfo.Columns[0].Name == "ErrorMessage")
            {
                grdInfo.Columns[0].Visible = false;
            }
        }
        private void UpdateResults()
        {
            grdFail.DataSource = UploadApp.ProcessedProposals.ToLog(false);
            grdSuccess.DataSource = UploadApp.ProcessedProposals.ToLog(true);
            grdLogs.DataSource = UploadApp.LogItems;

            grdSuccess.Columns[3].Visible = false;
            tabFail.Text = "Fail (" + grdFail.Rows.Count.ToString() + ")";
            tabSuccess.Text = "Success (" + grdSuccess.Rows.Count.ToString() + ")";

            string msg = "Upload thất bại.\nVui lòng kiểm tra lại thông tin.";

            if (grdSuccess.Rows.Count > 0)
            {
                //msg = "Upload thành công.\nVui lòng tải file thành công về để Upload lên GA.Net";
                ExportLog();
            }
            else
            {
                MsgBox.ShowMessageInfo(msg);
            }
        }

        private void ImportProposal(Proposal proposal)
        {
            CommandScript cmdScript = new CommandScript();

            List<ScreenBlock> blocks = cmdScript.GetScript(proposal);
            foreach (var block in blocks)
            {
                block.Execute();

                if (CommandMsg.HasError())
                {
                    break;
                }
            }

            if (CommandMsg.HasError())
            {
                UploadApp.ImportFail(proposal, CommandMsg.Error);
                CommandMsg.Clear();
            }
            else
            {
                string policyNumber = CommandMsg.GetVar("Contract");
                UploadApp.ImportSuccess(proposal, policyNumber);
                CommandMsg.Clear();
            }
        }
        private void ExportProposal(bool success)
        {
            List<ProcessedProposal> processedProps = UploadApp.ProcessedProposals.GetProposals(success);
            List<Proposal> lstProps = new List<Proposal>();
            foreach (ProcessedProposal processedProp in processedProps)
            {
                lstProps.Add(processedProp.GetProposal());
            }

            SaveFileDialog saveFileDialog1 = new SaveFileDialog();

            saveFileDialog1.Title = "Save File";
            saveFileDialog1.DefaultExt = "zip";
            saveFileDialog1.Filter = "ZIP files (*.zip)|*.zip";
            saveFileDialog1.FilterIndex = 1;
            saveFileDialog1.RestoreDirectory = true;
            saveFileDialog1.FileName = "ProposalFailExport";

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                ProposalXmlSerializer.Serialize(saveFileDialog1.FileName, lstProps);
            }
        }

        private bool ConnectLAS()
        {
            //Check Whether Sesssion A active
            if (AppSetting.SESSION != "A")
            {
                MessageBox.Show("You did not select session A.\nPlease select session A to continute.","Prudential Auto Upload");
                return false;
            }
            if (EhllapiWrapper.Connect(false) != 0)
            {
                MsgBox.ShowMessageError("Can not connect to LAS screen. Please try another session.", "Prudential Auto Upload");
                return false;
            }
            return true;
        }
        private void DisconnectLAS()
        {
            EhllapiWrapper.Disconnect();
        }
        private void oldVersionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmMain.Location = this.Location;
            FrmMain.Show();
            this.Hide();
        }

        private void cmdKeyAction_Click(object sender, EventArgs e)
        {
            this.Close();            
        }

        private void frmProposal_Load(object sender, EventArgs e)
        {
            this.Text = "Prudential Auto Upload - Proposal - " + Program.version;
        }

    }
}
