﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using KN.BusinessLogic;
using KN.Screens;
using KN.Systems;

namespace Prudential.AutoUpload
{
    public partial class frmMicroInsurance : Form
    {
        public frmMicroInsurance()
        {
            InitializeComponent();            
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            EhllapiWrapper.Connect(true);
            Display();
        }

        private void cmdUpload_Click(object sender, EventArgs e)
        {
            try
            {
                openFileDialog1.ShowDialog();
                textBox1.Text = openFileDialog1.FileName;
                FileInfo file = new FileInfo(openFileDialog1.FileName);

                if (file.Exists == false)
                {
                    textBox1.Text = "Invalid file path. Please try again";
                    MessageBox.Show("Invalid file path. Please try again", "Error", MessageBoxButtons.OK);
                    return;
                }
                KN.Proposals.MI.ExcelProcess.UpLoad(textBox1.Text);
                DATA_S2610Manager.DATA_S2610UpdateForCS();
                DATA_S2067Manager.DATA_S2067UpdateForCS();

                Display();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Upload has a issue. Please try again. Error detail: " + ex.Message);
            }               
        }

        private void Display()
        {
            grdClients.DataSource = ClientManager.AllClientLoad();
            //grdS5005.DataSource = LifeAssureManager.AllLifeAssureLoad();
            //grdSJ566_ATS.DataSource = DATA_SJ.AllProductLoad();
            grdSV51L_ATS.DataSource = DATA_SV51LManager.AllDATA_SV51LLoad();
            grdS2067.DataSource = DATA_S2067Manager.AllDATA_S2067Load();
            grdS2610.DataSource = DATA_S2610Manager.AllDATA_S2610Load();            
            grdLogs.DataSource = ErrorLogManager.AllErrorLogLoad();
        }
        private void cmdClient_Click(object sender, EventArgs e)
        {
            string ProposalNo = "";
            string ID = "";
            try
            {
                MessageBox.Show("Trước khi chọn OK, vui lòng chuyển LAS đến màn hình S2480 -  Client Maintenance Submenu.", "Warning", MessageBoxButtons.OK);
                S2480 s2480 = new S2480("");
                string current_screen = s2480.GetScreenCode();
                if (current_screen != "S2480")
                {
                    MessageBox.Show("Bạn đã chọn sai màn hình upload dữ liệu, vui lòng chọn lại màn hình Client Maintenance Submenu.", "Warning", MessageBoxButtons.OK);
                    return;
                }

                var clients = ClientManager.AllClientLoad();                
                string ClientNo = "";
                string msg = "";
                S2465 s2465;
                
                foreach (var client in clients)
                {
                    ClientNo = "";
                    ProposalNo = client.ProposalNo;
                    ID = client.ID;
                    s2480 = new S2480(ID);
                    s2480.Action = "D";
                    s2480.SetValues(ID);
                    s2480.Execute();

                    msg = s2480.GetMessage();
                    if (msg.StartsWith("Client Not On File"))// Khong ton tai
                    {
                        s2480.Action = "A";
                        s2480.SetValues(ID);
                        s2480.Execute();
                        s2480.Enter();
                        s2480.WaitingToNextScreen();
                    }

                    s2465 = new S2465(client);

                    //ID = s2465.GetValues("ID").Trim();
                    if (s2480.Action == "A")
                    {
                        s2465.Execute();
                        ClientNo = s2465.GetValues("Client").Trim();
                        s2465.Next();
                        msg = s2465.GetMessage2();
                        if (msg.Substring(0, 10).Trim() != "")
                        {
                            ClientNo = "";
                            ErrorLogManager.ErrorLogInsert(ID, "Upload Client ID " + ID + ". Error detail: " + msg);
                            s2480.F3();
                            continue;
                        }
                        s2465.Enter();
                        s2465.Execute("CheckDuplicate");
                        s2465.Enter();
                    }
                    else
                    {
                        ClientNo = s2465.GetValues("Client").Trim();
                        s2465.F3();
                    }
                                        
                    s2465.WaitingToNextScreen();
                    
                    ClientManager.ClientUpdate(ID, ClientNo);
                    DATA_S2610Manager.ClientUpdate(ID, ClientNo);
                }
                ExcelProcess.PreProcess();
                Display();
                MessageBox.Show("Giao dịch đã upload thành công.", "Information", MessageBoxButtons.OK);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Giao dịch upload không thành công. Vui long chọn thẻ Logs để biết thêm chi tiết.", "Information", MessageBoxButtons.OK);
                ErrorLogManager.ErrorLogInsert(ID, "Upload Client ID " + ID + " Detail: " +ex.Message);                
            }
            grdLogs.DataSource = ErrorLogManager.AllErrorLogLoad();
        }

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            EhllapiWrapper.Disconnect();
        }

        private void cmdExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(EhllapiWrapper.Connect(true)==0)
                MessageBox.Show("Connect to LAS screen successfully.");
            else
                MessageBox.Show("Can not connect to LAS screen. Please try another session.");
                
        }

        private void aToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AppSetting.SESSION = "A";
            ClearCheckMenu();
            aToolStripMenuItem.Checked = true;
            EhllapiWrapper.Connect(true);
        }

        private void bToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AppSetting.SESSION = "B";
            ClearCheckMenu();
            bToolStripMenuItem.Checked = true;
            EhllapiWrapper.Connect(true);
        }

        private void cToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AppSetting.SESSION = "C";
            ClearCheckMenu();
            cToolStripMenuItem.Checked = true;
            EhllapiWrapper.Connect(true);
        }

        private void dToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AppSetting.SESSION = "D";
            ClearCheckMenu();
            dToolStripMenuItem.Checked = true;
            EhllapiWrapper.Connect(true);
        }

        private void ClearCheckMenu()
        {
            aToolStripMenuItem.Checked = false;
            bToolStripMenuItem.Checked = false;
            cToolStripMenuItem.Checked = false;
            dToolStripMenuItem.Checked = false;
        }        
        
        private void cmdClearLog_Click(object sender, EventArgs e)
        {
            ErrorLogManager.ErrorLogClear();
            grdLogs.DataSource = ErrorLogManager.AllErrorLogLoad();
        }

        private void cmdBulkData_Click(object sender, EventArgs e)
        {
            string ApplicationNumber = "";
            ApplicationNumber = "";
            MessageBox.Show("Trước khi chọn OK, vui lòng chuyển LAS đến màn hình SJ566 -  Bulk Data Entry.", "Warning", MessageBoxButtons.OK);
            var sv51l_datas = DATA_SV51LManager.AllDATA_SV51LLoad();
            int error = 0;
            foreach (var sv51l_data in sv51l_datas)
            {
                try
                {
                    ApplicationNumber = sv51l_data.ApplicationNumber;
                    var sj566 = new SJ566("A");
                    string current_screen = sj566.GetScreenCode();
                    if (current_screen != "SJ566")
                    {
                        MessageBox.Show("Bạn đã chọn sai màn hình upload dữ liệu, vui lòng chọn lại màn hình Bulk Data Entry.", "Warning", MessageBoxButtons.OK);
                        return;
                    }

                    string msg = "";

                    sj566.Execute();
                    sj566.Enter();
                    sj566.WaitingToNextScreen();
                    //msg = sj566.GetMessage();
                    //if (msg.Trim() != "")
                    //{
                    //    //log error
                    //    sj566.WaitingToNextScreen();
                    //    ErrorLogManager.ErrorLogInsert("MI", "SJ566 Bulk Data Entry: " + msg.Trim());
                    //    continue;
                    //}
                    var sv51l = new SV51L(sv51l_data);
                    sv51l.Execute();
                    msg = sv51l.GetMessage();
                    
                    if (msg.Trim().StartsWith("Contract already exists") == true )
                    {
                        sv51l.F3();
                        sv51l.WaitingToNextScreen();
                        ErrorLogManager.ErrorLogInsert(ApplicationNumber, "Bulk Data Error. Application ID " + ApplicationNumber + ". Error detail: " + msg);
                        continue; 
                    }

                    if (sv51l_data.ContractType.Trim() == "")
                    {
                        sv51l.Enter();
                    }
                    sv51l.Enter();
                    sv51l.WaitingToNextScreen();
                }
                catch (Exception ex)
                {
                    error++;
                    ErrorLogManager.ErrorLogInsert(ApplicationNumber, "Bulk Data error. Application ID " + ApplicationNumber + ". Error detail: " + ex.Message);                
                }
            }
            grdLogs.DataSource = ErrorLogManager.AllErrorLogLoad();
            if (error > 0)
                MessageBox.Show("Có "+error.ToString()+" giao dịch upload không thành công. Vui lòng chọn thẻ Logs để biết thêm chi tiết.", "Information", MessageBoxButtons.OK);            
            else
                MessageBox.Show("Upload Bulk Data to LAS sucessfully.", "Information", MessageBoxButtons.OK);
        }

        private void cmdReceipt_Click(object sender, EventArgs e)
        {
            var obj = MessageBox.Show("Vui lòng kiểm tra thông tin trước khi thực hiện upload. Bạn có muốn tiếp tục?", "Question", MessageBoxButtons.YesNo);
            if (obj == System.Windows.Forms.DialogResult.No)
            {
                return;
            }
            var s2067_datas = DATA_S2067Manager.AllDATA_S2067Load();
            
            KN.Systems.Screen screen = new KN.Systems.Screen();
            string current_screen = screen.GetScreenCode();

            if (current_screen != "S2067")
            {
                MessageBox.Show("Bạn đã chọn sai màn hình upload dữ liệu, vui lòng chọn lại màn hình Cash Receipt Submenu.", "Warning", MessageBoxButtons.OK);
                return;
            }
            string msg = "";
            string ID="";
            int error = 0;
            foreach (var s2067_data in s2067_datas)
            {
                try
                {
                    msg = "";
                    ID = s2067_data.ID;
                    var s2067 = new S2067(s2067_data);
                    s2067.Execute();
                    msg = s2067.GetMessage();
                    if (msg.Trim() != "")
                    {
                        //log error
                        s2067.WaitingToNextScreen();
                        ErrorLogManager.ErrorLogInsert(ID, "S2067 Receipt with ID " + ID +". Error Detail " + msg.Trim());
                        continue;
                    }
                    s2067.Enter();
                    s2067.WaitingToNextScreen();
                    
                    DATA_S2610 s2610_data = DATA_S2610Manager.DATA_S2610Load(s2067_data.ID);
                    var s2610 = new S2610(s2610_data);
                    s2610.Execute();
                    msg = s2610.GetMessage();
                    if (msg.Trim() != "")
                    {
                        //log error
                        s2610.F3();
                        s2610.WaitingToNextScreen();
                        ErrorLogManager.ErrorLogInsert(ID, "S2610 Application Received at CS with ID " + ID + ". Error Detail " + msg.Trim());
                        continue;
                    }
                    s2610.Enter();
                    s2610.WaitingToNextScreen();
                }
                catch (Exception ex)
                {
                    error++;
                    ErrorLogManager.ErrorLogInsert(ID, "Reciept Error ID " + ID + ". Error detail: " + ex.Message);
                }                
            }
            grdLogs.DataSource = ErrorLogManager.AllErrorLogLoad();
            if (error > 0)
                MessageBox.Show("Có " + error.ToString() + " giao dịch upload không thành công. Vui lòng chọn thẻ Logs để biết thêm chi tiết.", "Information", MessageBoxButtons.OK);
            else
                MessageBox.Show("Upload Bulk Data to LAS sucessfully.", "Information", MessageBoxButtons.OK);
        }

        private void cmdExport_Click(object sender, EventArgs e)
        {
            var obj = ErrorLogManager.AllErrorLogLoad();
            string data="";
            
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            saveFileDialog1.Filter = "CSV |*.csv";
            saveFileDialog1.Title = "Save an CSV File";
            saveFileDialog1.ShowDialog();

            data = "ProposalNo, Description\n";
            data += "ProposalNo, Description\n";
            // If the file name is not an empty string open it for saving.
            if (saveFileDialog1.FileName != "")
            {
                TextWriter tw = new StreamWriter(saveFileDialog1.FileName);

                foreach (var item in obj)
                {
                    data = item.ProposalNo + "," + item.Description;
                    // write a line of text to the file
                    tw.WriteLine(data);
                }
                // close the stream
                tw.Close();
            }
        }        
    }
}
