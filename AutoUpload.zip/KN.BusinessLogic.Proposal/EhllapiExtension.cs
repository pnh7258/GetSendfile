﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KN.Systems;

namespace KN.BusinessLogic.Proposal
{
    public class EhllapiExtension
    {
        public const int SCREEN_NAME_DEFAULT_ROW = 1;
        public const int SCREEN_NAME_DEFAULT_COLUMN = 72;

        // This is a clone method of Screen.Wait(int time)
        public static void Wait(int time)
        {
            try
            {
                int orb_int_TimeOut = 0;
                bool orb_flg_Restart = false;


                orb_int_TimeOut = 1;

            RoutineRestart:

                int orb_mlng_ReturnCode = 0;
                uint orb_mlng_CallStatus = EhllapiWrapper.Wait();

                if (orb_mlng_CallStatus == 4 && orb_int_TimeOut < time)
                {
                    EhllapiWrapper.SendStr("@R");
                    orb_int_TimeOut = orb_int_TimeOut + 1;
                    goto RoutineRestart;
                }

                if (orb_mlng_CallStatus == 5 && orb_flg_Restart == false)
                {
                    EhllapiWrapper.SendStr("@R");
                    orb_flg_Restart = true;
                    goto RoutineRestart;
                }

                switch (orb_mlng_CallStatus)
                {
                    case 0: break;
                    case 1: throw new Exception("[  1] Session not connected; ");

                    case 4: throw new Exception("[  4] TimeOut occured after; ");

                    case 5: EhllapiWrapper.SendStr("@R"); break;//throw new Exception("[  5] Keyboard remains locked");

                    case 9: throw new Exception("[  9] Client Access System Error");

                    default: throw new Exception("[" + orb_mlng_ReturnCode + "] *CODE ERROR");

                }
            }
            catch
            {
                throw;
            }
        }
        public static void WaitingToNextScreen()
        {
            Wait(5);
        }

        /// <summary>
        /// Read text from LAS screen
        /// </summary>
        /// <param name="point">the postion of the text</param>
        /// <param name="length">length of the text</param>
        /// <returns></returns>
        public static string ReadScreen(Point point, int length)
        {
            string result = "";
            EhllapiWrapper.ReadScreen(point.cursor, length, out result);

            return (result.Length > length) ? result.Substring(0, length) : result;
        }

        /// <summary>
        /// Get the current screen name
        /// </summary>
        /// <returns></returns>
        public static string ReadScreenName()
        {
            var position = new Point(SCREEN_NAME_DEFAULT_ROW, SCREEN_NAME_DEFAULT_COLUMN);

            return EhllapiExtension.ReadScreenName(position);
        }

        public static string ReadScreenName(Point point)
        {
            return EhllapiExtension.ReadScreen(point, 6).Trim();
        }

        /// <summary>
        /// Read error message from the screen.
        /// </summary>
        /// <returns></returns>
        public static string ReadError()
        {
            var ScreenMessagePos = new Point(24, 2);

            string message = EhllapiExtension.ReadScreen(ScreenMessagePos, 70);
            return message.TrimEnd(new char[] { ' ', '¦' });
        }
    }
}
