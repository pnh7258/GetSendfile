﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KN.BusinessLogic.Proposal
{
    /// <summary>
    /// Collection of ProcessedProposal objects.
    /// </summary>
    public class ProcessedProposals
    {
        private List<ProcessedProposal> processed;

        public ProcessedProposals()
        {
            processed = new List<ProcessedProposal>();
        }

        public ProcessedProposal Fail(Proposal proposal, string error)
        {
            proposal.ErrorMessage = error;
            var result = new ProcessedProposal(proposal, false, error, "");
            processed.Add(result);

            return result;
        }
        public ProcessedProposal Success(Proposal proposal, string policyNumber)
        {
            proposal.ErrorMessage = null;
            var result = new ProcessedProposal(proposal, true, "", policyNumber);
            processed.Add(result);

            return result;
        }

        public List<ProcessedProposal> GetProposals(bool success)
        {
            List<ProcessedProposal> result = new List<ProcessedProposal>();
            foreach (ProcessedProposal item in processed)
            {
                if (item.Success == success)
                {
                    result.Add(item);
                }
            }
            return result;
        }

        public void Clear()
        {
            this.processed.Clear();
        }
        public void Clear(bool success)
        {
            List<ProcessedProposal> tmp = GetProposals(success);
            foreach (ProcessedProposal item in tmp)
            {
                processed.Remove(item);
            }
        }

        public List<LogItem> ToLog()
        {
            List<LogItem> result = new List<LogItem>();
            foreach (var p in processed)
            {
                result.Add(p.ToLogItem());
            }

            return result;
        }
        public List<LogItem> ToLog(bool success)
        {
            List<LogItem> result = new List<LogItem>();
            List<ProcessedProposal> lstProps = GetProposals(success);

            foreach (ProcessedProposal item in lstProps)
            {
                result.Add(item.ToLogItem());
            }
            return result;
        }
        public List<LogItem> ToSuccessLog()
        {
            List<LogItem> result = new List<LogItem>();
            foreach (var p in processed)
            {
                if (p.Success == true)
                {
                    result.Add(p.ToLogItem());
                }
            }

            return result;
        }
    }
}
