﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KN.BusinessLogic.Proposal {
    /// <summary>
    /// List error message dismiss
    /// </summary>
    public static class ErrorDismiss {
        public static List<string> Msg = new List<string>(){
        "RcptDate < today 3 days",
        "Check LN/VP & LP/S"
        };
    }
}
