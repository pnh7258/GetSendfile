﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KN.BusinessLogic.Proposal.Command;
using System.Collections.Specialized;

namespace KN.BusinessLogic.Proposal
{
    public class CommandMsg
    {
        private static string errorLas = "";
        private static NameValueCollection vars = new NameValueCollection();
        private static Dictionary<string, string> tags = new Dictionary<string, string>();

        public static string ErrorLas
        {
            get { return CommandMsg.errorLas; }
            set { CommandMsg.errorLas = value; }
        }
        public static string Error
        {
            get
            {
                if (tags.Count == 0)
                {
                    return errorLas;
                }

                List<string> taglines = new List<string>();
                foreach (var kvp in tags)
                {
                    taglines.Add(string.Format("{0}: {1}", kvp.Key, kvp.Value));
                }

                return string.Join(", ", taglines.ToArray()) + " - " + errorLas;
            }
        }

        public static ErrorType ErrorType { get; set; }

        public static bool HasError()
        {
            return (errorLas.Length > 0 && !ErrorDismiss.Msg.Exists(p => p == errorLas.Trim()));
        }
        public static void ClearError()
        {
            errorLas = "";
        }

        public static void AddVar(string name, string value)
        {
            //vars.Add(name, value);
            vars[name] = value;
        }
        public static string GetVar(string name)
        {
            return vars.Get(name);
        }

        public static void Tag(string name, string value)
        {
            tags[name] = value;
        }
        public static void Untag(string name)
        {
            tags.Remove(name);
        }

        public static void Clear()
        {
            ClearError();
            vars.Clear();
            tags.Clear();
        }
    }
}
