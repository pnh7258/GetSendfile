﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KN.BusinessLogic.Proposal
{
    /// <summary>
    /// A class represents proposal which imported to LAS. 
    /// The importing process can be fail or success.
    /// </summary>
    public class ProcessedProposal
    {
        private Proposal proposal;
        private bool success;
        private string error;
        private string policyNumber;

        public ProcessedProposal(Proposal proposal, bool success, string error, string policyNumber)
        {
            this.proposal = proposal;
            this.success = success;
            this.error = error;
            this.policyNumber = policyNumber;
        }

        public Proposal GetProposal()
        {
            return proposal;
        }
        public string ContractType
        {
            get { return proposal.ContractType; }
        }
        public string PolOwner
        {
            get { return proposal.PolOwner; }
        }
        public string Error
        {
            get { return error; }
        }
        public bool Success
        {
            get { return success; }
        }

        public LogItem ToLogItem()
        {
            return new LogItem()
            {
                PolicyNum = this.policyNumber,
                PropNum = this.proposal.PropNum,
                TranDate = DateTime.Today.ToString("dd/MM/yyyy"),
                ErrorMessage = this.error
            };
        }
    }
}
