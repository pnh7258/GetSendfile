﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace KN.BusinessLogic.Proposal
{
    [Serializable]
    public class Agency
    {
        public string Number { get; set; }
        public string Commission { get; set; }
        public string Bonus { get; set; }
    }

    [Serializable]
    public class Ben
    {
        public string Number { get; set; }
        public string BenName { get; set; }
        public string Relationship { get; set; }
        public string Rate { get; set; }
        public string EffectiveDate { get; set; }
    }

    [Serializable]
    public class Receipt
    {
        public string ReceiptNum { get; set; }
    }

    [Serializable]
    public class Rider
    {
        public string RiderNum { get; set; }
        public string RiderCode { get; set; }
        public string RiderSA { get; set; }
        public string RiderPolicyTerm { get; set; }
        public string RiderPremiumTerm { get; set; }
        public string RiderOption { get; set; }
        public string RiderRate { get; set; }
    }

    [Serializable]
    public class La
    {
        public string Life { get; set; }
        public string LaNum { get; set; }
        public string LaName { get; set; }
        public string LaID { get; set; }
        public string Height { get; set; }
        public string Weight { get; set; }
        public string Smoke { get; set; }
        public string Occrate { get; set; }
        public List<Rider> Riders { get; set; }
    }

    [Serializable]
    public class Proposal
    {
        public string ErrorMessage { get; set; }
        public string ContractType { get; set; }
        public string PolOwner { get; set; }
        public string PoName { get; set; }
        public string IncomeRange { get; set; }
        public string IncomeAmount { get; set; }
        public string RiskCommDate { get; set; }
        public string PropDate { get; set; }
        public string BillingFrequency { get; set; }
        public string MethodOfPayment { get; set; }
        public string TempRcptNo { get; set; }
        public string TemporaryReceiptDate { get; set; }
        public string SoldUnit { get; set; }
        public string PropNum { get; set; }    
        public string DespatchAddress { get; set; }
        public string SumAssured { get; set; }
        public string Option { get; set; }
        public string PremiumTerm { get; set; }
        public string PolicyTerm { get; set; }

        [XmlIgnore]
        public string Agency
        {
            get
            {
                if (this.Agencies == null || this.Agencies.Count == 0)
                {
                    return "";
                }
                return this.Agencies[0].Number;
            }
        }
        
        public List<Agency> Agencies { get; set; }
        public List<Ben> Bens { get; set; }
        public List<Receipt> Receipts { get; set; }
        //[XmlArray("Receipts"), XmlArrayItem("ReceiptNum")]
        //public List<string> Receipts { get; set; }
        public List<La> Las { get; set; }
    }
}
