﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KN.BusinessLogic.Proposal
{
    public class UploadApp
    {
        private static ProcessedProposals processed;
        private static List<LogItem> log;
        private static bool runSlow;
        private static bool stopIfError;

        static UploadApp()
        {
            processed = new ProcessedProposals();
            log = new List<LogItem>();
            runSlow = true;
            stopIfError = true;
        }

        public static ProcessedProposals ProcessedProposals
        {
            get { return processed; }
        }
        public static List<LogItem> LogItems
        {
            get { return log; }
        }

        public static bool RunSlow
        {
            get { return runSlow; }
            set { runSlow = value; }
        }
        public static bool StopIfError
        {
            get { return stopIfError; }
            set { stopIfError = value; }
        }

        public static void ImportFail(Proposal proposal, string error)
        {
            var result = processed.Fail(proposal, error);
            log.Add(result.ToLogItem());
        }
        public static void ImportSuccess(Proposal proposal, string policyNumber)
        {
            var result = processed.Success(proposal, policyNumber);
            log.Add(result.ToLogItem());
        }
    }
}
