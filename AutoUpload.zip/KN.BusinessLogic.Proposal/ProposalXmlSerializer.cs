﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Serialization;
using System.IO;

namespace KN.BusinessLogic.Proposal
{
    public class ProposalXmlSerializer
    {
        /// <summary>
        /// Put data from xml file into list Proposal
        /// </summary>
        /// <param name="filename"></param>
        /// <returns></returns>
        public static List<Proposal> Deserialize(string filename)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(List<Proposal>), new XmlRootAttribute("Proposals"));// { Namespace = "http://vn/com/prudential/proposal/req" }

            using (Stream stream = File.OpenRead(filename))
            {
                return serializer.Deserialize(stream) as List<Proposal>;
            }
        }

        /// <summary>
        /// Write Proposals to XML file
        /// </summary>
        /// <param name="filename"></param>
        /// <param name="proposals"></param>
        public static void Serialize(string filename, List<Proposal> proposals)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(List<Proposal>), new XmlRootAttribute("Proposals") { Namespace = "" });
            Encoding utf8WithoutBom = new UTF8Encoding(false);
            using (TextWriter writer = new StreamWriter(filename, false, utf8WithoutBom))
            {
                serializer.Serialize(writer, proposals);
            }
        }

        /// <summary>
        /// Write LogItems into XML file
        /// </summary>
        /// <param name="filename"></param>
        /// <param name="lstLogs"></param>
        public static void ExportLog(string filename, List<LogItem> lstLogs)
        {
            XmlSerializer SerializerObj = new XmlSerializer(typeof(List<LogItem>), new XmlRootAttribute("LogItems") { Namespace = "" });

            XmlWriterSettings settings = new XmlWriterSettings();

            Encoding utf8WithoutBom = new UTF8Encoding(false);

            TextWriter WriteFileStream = new StreamWriter(filename, false, utf8WithoutBom);
            SerializerObj.Serialize(WriteFileStream, lstLogs);

        }
    }
}
