﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KN.BusinessLogic.Proposal.Compiliing;

namespace KN.BusinessLogic.Proposal.Command
{
    public class GotoIfCommand : ICommand
    {
        private IScreenBlockData block;

        private string attribute;
        private string key;
        private string value;
        private string label;

        public GotoIfCommand(string expression, string value, string label)
        {
            int dotIndex = expression.IndexOf('.');
            if (dotIndex >= 0) {
                this.attribute = expression.Substring(0, dotIndex);
                this.key = expression.Substring(dotIndex + 1);
            }
            else {
                this.attribute = expression;
                this.key = "";
            }

            this.value = value;
            this.label = label;
        }

        public void Execute()
        {
            bool match = false;
            switch (attribute.ToLower())
            {
                case "error":
                    match = (CommandMsg.ErrorLas == value);
                    break;
                case "vars":
                    string varkey = CommandMsg.GetVar(key);
                    match = value == varkey;
                    break;
            }

            if (match)
            {
                block.GoTo(label);
            }
        }
        public void SetBlockData(IScreenBlockData data)
        {
            this.block = data;
        }

        public override string ToString()
        {
            return string.Format("GotoIf {0} {1} {2}", attribute, value, label);
        }
        public static ICommand Make(string[] @params)
        {
            Parameters p = new Parameters(@params);

            return new GotoIfCommand(p.Get(0), p.Get(1), p.Get(2));
        }
    }
}
