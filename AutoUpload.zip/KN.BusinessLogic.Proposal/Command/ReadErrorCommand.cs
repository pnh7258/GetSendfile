﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KN.BusinessLogic.Proposal.Command
{
    public class ReadErrorCommand : ICommand
    {
        public void Execute()
        {
            CommandMsg.ErrorLas = EhllapiExtension.ReadError();
        }

        public void SetBlockData(IScreenBlockData data)
        {
        }

        public override string ToString()
        {
            return "ReadError";
        }
    }
}
