﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KN.Systems;

namespace KN.BusinessLogic.Proposal.Command
{
    public class WaitCommand:ICommand
    {
        public void Execute()
        {
            EhllapiExtension.Wait(5);
        }
        public void SetBlockData(IScreenBlockData data)
        {
        }
    }
}
