﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KN.BusinessLogic.Proposal.Compiliing;

namespace KN.BusinessLogic.Proposal.Command
{
    public class UntagCommand : ICommand
    {
        private string name;

        public UntagCommand(string name)
        {
            this.name = name;
        }

        public void Execute()
        {
            CommandMsg.Untag(name);
        }
        public void SetBlockData(IScreenBlockData data)
        {
        }

        public static UntagCommand Make(string[] @params)
        {
            Parameters p = new Parameters(@params);

            return new UntagCommand(p.GetString(0, ""));
        }
        public override string ToString()
        {
            return "Untag " + name;
        }
    }
}
