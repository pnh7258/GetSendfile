﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KN.BusinessLogic.Proposal.Compiliing;
using KN.Systems;
using log4net;

namespace KN.BusinessLogic.Proposal.Command {
    public class EnterMenuCommand : ICommand {
        private static readonly ILog log = LogManager.GetLogger(typeof(EnterMenuCommand));
        
        private int top;
        private int left;
        private int bottom;
        private int right;
        private int columns;
        private string menu;

        public EnterMenuCommand(int top, int left, int bottom, int right, int columns, string menu) {
            this.top = Math.Min(top, bottom);
            this.left = Math.Min(left, right);
            this.bottom = Math.Max(top, bottom);
            this.right = Math.Max(left, right);
            this.columns = columns;
            this.menu = menu;
        }

        public void Execute() {
            Point point = FindMenuPosition();
            if (point == null) {
                log.WarnFormat("Can not find menu \"{0}\"", this.menu);
                return;
            }

            EhllapiWrapper.SetCursorPos(point.cursor);
            EhllapiWrapper.SendStr("@E");
            EhllapiWrapper.Wait();
        }

        private Point FindMenuPosition() {
            Point result = null;
            int columnWidth = (right - left) / columns;

            for (int column = 1; column <= this.columns; column++) {
                int startColumn = left + columnWidth * (column - 1);
                result = FindMenuPosition(top, bottom, startColumn, columnWidth);
                if (result != null) {
                    return result;
                }
            }
            return null;
        }
        private Point FindMenuPosition(int startRow, int endRow, int startColumn, int length) {
            Point point = null;
            for (int row = startRow; row <= endRow; row++) {
                point = new Point(row, startColumn);
                string text = EhllapiWrapper.ReadScreen(point, length).Trim();
                if (text == menu) {
                    return point;
                }
            }
            return null;
        }
        public void SetBlockData(IScreenBlockData data) {
        }

        public override string ToString() {
            return string.Format("EnterMenu {0} {1} {2} {3} \"{4}\"", this.top, this.left, this.bottom, this.right, this.menu);
        }

        public static EnterMenuCommand Make(string[] @params) {
            Parameters p = new Parameters(@params);

            return new EnterMenuCommand(p.GetInt32(0), p.GetInt32(1), p.GetInt32(2), p.GetInt32(3), p.GetInt32(4), p.GetString(5));
        }
    }
}
