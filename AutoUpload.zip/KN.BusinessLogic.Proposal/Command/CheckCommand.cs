﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KN.BusinessLogic.Proposal.Compiliing;

namespace KN.BusinessLogic.Proposal.Command
{
    public class CheckCommand : ICommand
    {
        private IScreenBlockData block;

        private string attribute;
        private string value;
        private string trueLabel;
        private string falseLabel;

        public CheckCommand(string attribute, string value, string trueLabel, string falseLabel)
        {
            this.attribute = attribute;
            this.value = value;
            this.trueLabel = trueLabel;
            this.falseLabel = falseLabel;
        }
        public void Execute()
        {
            bool match = false;
            switch (attribute) {
                case "Error":
                    match = (CommandMsg.ErrorLas == value);
                    break;
                case "Screen":
                    match = (GetScreenName(value) == value);
                    break;
                default:
                    return;
            }

            this.block.GoTo(match ? trueLabel : falseLabel);
        }
        private string GetScreenName(string screen)
        {
            if (screen == "S5003")
            {
                return EhllapiExtension.ReadScreenName(new Systems.Point(1, 71));
            }
            else
            {
                return EhllapiExtension.ReadScreenName();
            }
        }
        public void SetBlockData(IScreenBlockData data)
        {
            this.block = data;
        }

        public override string ToString()
        {
            return string.Format("Check \"{0}\" \"{1}\" {2} {3}", attribute, value, trueLabel, falseLabel);
        }
        public static CheckCommand Make(string[] @params)
        {
            Parameters p = new Parameters(@params);
            return new CheckCommand(p.Get(0), p.Get(1), p.Get(2), p.Get(3));
        }

    }
}
