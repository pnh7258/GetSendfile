﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KN.Systems;
using KN.Screens;
using KN.BusinessLogic.Proposal.Compiliing;

namespace KN.BusinessLogic.Proposal.Command
{
    public class BeginScreenCommand : ICommand
    {
        public class BeginScreen : BeginScreenCommand
        {
            private IScreenBlockData block;

            private string expectedScreen;
            private int x;
            private int y;

            public BeginScreen(string screen, int x, int y)
            {
                this.expectedScreen = screen;
                this.x = x;
                this.y = y;
            }

            public override void Execute()
            {
                if (expectedScreen.Contains("Optional"))
                {
                    return;
                }

                string actualScreen = EhllapiExtension.ReadScreenName(new Point(x, y));

                if (actualScreen != expectedScreen)
                {
                    if (expectedScreen == "S5002")
                    {
                        EhllapiExtension.Wait(5);
                        actualScreen = EhllapiExtension.ReadScreenName(new Point(x, y));
                    }
                }

                if (actualScreen != expectedScreen)
                {
                    string format = "You stand at {0} instead of {1}. Please navigate to LAS screen to {1} - Client Maintenance Submenu.";

                    CommandMsg.ErrorLas = String.Format(format, actualScreen, expectedScreen);
                    CommandMsg.ErrorType = ErrorType.Tool;

                    block.GoEnd();
                }

            }
            public override void SetBlockData(IScreenBlockData data)
            {
                this.block = data;
            }
            public override string ToString()
            {
                return "BeginScreen " + expectedScreen;
            }
        }
        public class BeginScreenSetup : BeginScreenCommand
        {
            public override void Execute()
            {
                // Do nothing
            }
            public override void SetBlockData(IScreenBlockData data)
            {
            }
            public override string ToString()
            {
                return "BeginScreen Setup";
            }
        }

        public virtual void Execute()
        {
            throw new NotImplementedException();
        }
        public virtual void SetBlockData(IScreenBlockData data)
        {
            throw new NotImplementedException();
        }

        public static BeginScreenCommand Make(string[] @params)
        {
            Parameters p = new Parameters(@params);
            string screen = p.Get(0).ToLower();

            return (screen == "setup") 
                ? new BeginScreenSetup() as BeginScreenCommand
                : new BeginScreen(p.Get(0), p.GetInt32(1, EhllapiExtension.SCREEN_NAME_DEFAULT_ROW), p.GetInt32(2, EhllapiExtension.SCREEN_NAME_DEFAULT_COLUMN));
        }
    }
}
