﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using System.Threading;

namespace KN.BusinessLogic.Proposal.Command
{
    public interface IScreenBlockData
    {
        void GoEnd();
        void GoTo(string label);
    }

    public class ScreenBlock
    {
        public class ScreenBlockData : IScreenBlockData
        {
            private ScreenBlock block;

            private int current;
            private int next;
            private int commands;

            public ScreenBlockData(ScreenBlock block)
            {
                this.block = block;

                this.current = 0;
                this.next = 0;
                this.commands = this.block.block.Count;
            }

            public int CurrentPoint { get { return current; } }
            public int Commands { get { return commands; } }

            public bool Next()
            {
                if (this.next < this.commands)
                {
                    this.current = this.next;
                    this.next += 1;
                    return true;
                }
                return false;
            }

            public void GoTo(int label)
            {
                next = label;
            }
            public void GoTo(string label)
            {
                int index = FindLabel(label);
                if (index < 0)
                {
                    throw new Exception(string.Format("Label \"{0}\" is not found", label));
                }

                GoTo(index);
            }

            private int FindLabel(string label)
            {
                if (label == "@EndScreen")
                {
                    return commands - 1;
                }

                for (int i = 0; i < block.block.Count; i++)
                {
                    LabelCommand lc = (block.block[i] as LabelCommand);
                    if (lc != null && lc.Name == label)
                    {
                        return i;
                    }
                }
                return -1;
            }
            public void GoEnd()
            {
                next = commands - 1;
            }
        }

        private static ILog log = LogManager.GetLogger(typeof(ScreenBlock));
        private List<ICommand> block;
        private ScreenBlockData data;

        public ScreenBlock(BeginScreenCommand begin, List<ICommand> body, EndScreenCommand end)
        {
            block = new List<ICommand>();
            block.Add(begin);
            block.AddRange(body);
            block.Add(end);

            data = new ScreenBlockData(this);

            this.block.ForEach(c => c.SetBlockData(data));
        }
        public void Execute()
        {
            while (data.Next())
            {
                var command = this.block[data.CurrentPoint];

                command.Execute();

                if (UploadApp.RunSlow) { Thread.Sleep(300); }

                log.Info(command.ToString());
                if (CommandMsg.HasError()) { log.Debug("Error: " + CommandMsg.ErrorLas); }
            }
        }
    }
}
