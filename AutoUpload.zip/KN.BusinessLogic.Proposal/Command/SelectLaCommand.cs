﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KN.Systems;
using KN.BusinessLogic.Proposal.Compiliing;

namespace KN.BusinessLogic.Proposal.Command
{
    public class SelectLaCommand : ICommand
    {
        private IScreenBlockData block;
        private string label;
        private string value;
        private string la;
        private int column;

        /// <summary>
        /// Find the LA, and put "2" to add new LA
        /// </summary>
        public void Execute()
        {
            bool selectDone = false;
            do
            {
                selectDone = SelectOnCurrentPage();
            }
            while (!selectDone && NextPage());

            if (!selectDone)
            {
                SetError();
            }
        }

        /// <summary>
        /// Find the possion of the LA at the current page.
        /// </summary>
        /// <returns></returns>
        private bool SelectOnCurrentPage()
        {
            int laRow = FindLaRow();

            if (laRow > 0)
            {
                SelectLa(laRow);
                return true;
            }
            return false;
        }
        public SelectLaCommand(string label, string value, string la, int column)
        {
            this.label = label;
            this.value = value;
            this.la = la;
            this.column = column;
        }

        /// <summary>
        /// Find the row contain the LA
        /// </summary>
        /// <returns></returns>
        private int FindLaRow()
        {
            const int LA_ROW_MIN = 9;
            const int LA_ROW_MAX = 22;

            for (int y = LA_ROW_MIN; y <= LA_ROW_MAX; y++)
            {
                string laOnScreen = EhllapiExtension.ReadScreen(new Point(y, this.column), 2);
                if (laOnScreen == this.la)
                {
                    return y;
                }
            }

            return -1;
        }
        /// <summary>
        /// Input 2 to the LA to add new rider 
        /// </summary>
        /// <param name="laRow"></param>
        private void SelectLa(int laRow)
        {
            int LA_CHECKBOX_COLUMN = 3;

            EhllapiWrapper.SetCursorPos(new Point(laRow, LA_CHECKBOX_COLUMN).cursor);
            EhllapiWrapper.SendStr(this.value);
        }
        private void SetError()
        {
            string format = "LA Code {0} Not Found";
            CommandMsg.ErrorLas = String.Format(format, this.la);
            CommandMsg.ErrorType = ErrorType.Tool;
        }

        /// <summary>
        /// Move to next page incase cannot find the LA at the current page
        /// </summary>
        /// <returns></returns>
        private bool NextPage()
        {
            if (!HasNextPage())
            {
                return false;
            }

            EhllapiWrapper.SendStr("@v");
            EhllapiExtension.Wait(5);
            return true;
        }
        /// <summary>
        /// Check whether the page has next page
        /// </summary>
        /// <returns></returns>
        private bool HasNextPage()
        {
            string sign = EhllapiExtension.ReadScreen(new Point(22, 79), 1);
            return (sign == "+");
        }

        public void SetBlockData(IScreenBlockData data)
        {
            this.block = data;
        }
        public static ICommand Make(string[] @params)
        {
            Parameters p = new Parameters(@params);
            return new SelectLaCommand(p.Get(0), p.Get(1), p.Get(2), p.GetInt32(3));
        }

        public override string ToString()
        {
            return string.Format("SelectLa {0} {1} {2}  {3}", label, value, la, column);
        }
    }
}
