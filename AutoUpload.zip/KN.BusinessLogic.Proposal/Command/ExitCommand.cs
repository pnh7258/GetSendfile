﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KN.BusinessLogic.Proposal.Compiliing;
using KN.Systems;

namespace KN.BusinessLogic.Proposal.Command
{
    public class ExitCommand : ICommand
    {
        private IScreenBlockData block;

        private string message;
        private string value;

        public ExitCommand(string message, string value)
        {
            this.message = message;
            this.value = value;
        }
        public void Execute()
        {
            bool match = false;
            switch (this.message.ToLower())
            {
                case "nolas":
                    CommandMsg.ErrorLas = "Không có thông tin về người được bảo hiểm.";
                    match = true;
                    break;
                case "nolanum":
                    CommandMsg.ErrorLas = "Chưa có mã khách hàng.";
                    match = true;
                    break;
                case "lanorider":
                    CommandMsg.ErrorLas = "Chưa nhập sản phẩm phụ cho người được bảo hiểm.";
                    match = true;
                    break;
                case "usingforautoupload":
                    match = true;
                    break;
                case "noscreen":
                    CommandMsg.ErrorLas = "Please Go To System Menu Screen";
                    break;
                case "noerror":
                    match = true;
                    break;
            }

            if (match)
            {
                EhllapiExtension.Wait(10);
                EhllapiWrapper.SendStr("@3"); // F3
            }
        }

        public void SetBlockData(IScreenBlockData data)
        {
            this.block = data;
        }

        /// <summary>
        /// Parse parametter from script
        /// </summary>
        /// <param name="params"></param>
        /// <returns></returns>
        public static ICommand Make(string[] @params)
        {
            Parameters p = new Parameters(@params);
            string value = string.Empty;
            if (@params.Length > 1)
            {
                value = p.Get(1);
            }
            return new ExitCommand(p.Get(0), value);
        }

    }
}
