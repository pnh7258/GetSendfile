﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KN.BusinessLogic.Proposal.Compiliing;

namespace KN.BusinessLogic.Proposal.Command
{
    /// <summary>
    /// Use for show LA, Rider in error message
    /// </summary>
    public class TagCommand : ICommand
    {
        private string name;
        private string value;

        /// <summary>
        /// Initialization function
        /// </summary>
        /// <param name="name">Tag name</param>
        /// <param name="value">Tag Value</param>
        public TagCommand(string name, string value)
        {
            this.name = name;
            this.value = value;
        }

        public void Execute()
        {
            CommandMsg.Tag(name, value);
        }
        public void SetBlockData(IScreenBlockData data)
        {
        }

        public static TagCommand Make(string[] @params)
        {
            Parameters p = new Parameters(@params);

            return new TagCommand(p.GetString(0, ""), p.GetString(1, ""));
        }
        public override string ToString()
        {
            return string.Format("Tag {0}, {1}", name, value);
        }
    }
}
