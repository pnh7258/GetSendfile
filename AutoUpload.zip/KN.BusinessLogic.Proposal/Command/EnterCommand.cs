﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KN.Systems;
using KN.BusinessLogic.Proposal.Command;

namespace KN.BusinessLogic.Proposal.Command
{
    public class EnterCommand : ICommand
    {
        public EnterCommand()
        {
        }

        public void Execute()
        {
            EhllapiWrapper.SendStr("@E");
            EhllapiExtension.Wait(5);
        }
        public void SetBlockData(IScreenBlockData data)
        {
        }

        public override string ToString()
        {
            return "Enter";
        }
    }
}
