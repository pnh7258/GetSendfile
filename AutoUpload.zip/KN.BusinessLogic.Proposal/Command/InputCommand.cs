﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KN.Systems;
using KN.BusinessLogic.Proposal.Compiliing;

namespace KN.BusinessLogic.Proposal.Command
{
    public class InputCommand : ICommand
    {
        private string label;
        private Point point;
        private string text;

        public InputCommand(int x, int y, string text) : this ("", x, y, text)
        {
        }
        public InputCommand(string label, int x, int y, string text)
        {
            this.label = label;
            this.point = new KN.Systems.Point(x, y);
            this.text = text;
        }

        public void Execute()
        {
            EhllapiWrapper.SetCursorPos(this.point.cursor);
            EhllapiWrapper.SendStr(this.text);
        }
        public void SetBlockData(IScreenBlockData data)
        {
        }

        public override string ToString()
        {
            return "Input " + "\"" + label + "\" " + point.X + " " + point.Y + " " + text;
        }
        public static InputCommand Make(string[] @params)
        {
            Parameters p = new Parameters(@params);

            return new InputCommand(p.Get(0), p.GetInt32(1, 0), p.GetInt32(2, 0), p.GetString(3, ""));
        }
    }
}
