﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KN.Systems;
using KN.BusinessLogic.Proposal.Compiliing;

namespace KN.BusinessLogic.Proposal.Command
{
    public class SelectProposalItemsCommand:ICommand
    {
        private IScreenBlockData block;
        private string label;
        private string value;
        private int selectColumn;

        public SelectProposalItemsCommand(string label, string value, int selectColumn)
        {
            this.label = label;
            this.value = value;
            this.selectColumn = selectColumn;
        }

        /// <summary>
        /// Select all items (LA, basic, riders) on screen S5003
        /// </summary>
        public void Execute()
        {
            do
            {
                SelectOnCurrentPage();
            }
            while (NextPage());
        }
        private void SelectOnCurrentPage()
        {
            const int LA_ROW_MIN = 9;
            const int LA_ROW_MAX = 22;
            const int LA_COLUMN = 23;

            for (int y = LA_ROW_MIN; y <= LA_ROW_MAX; y++)
            {
                string laOnScreen = EhllapiExtension.ReadScreen(new Point(y, LA_COLUMN), 3);
                if (laOnScreen.Trim() == "")
                {
                    return;
                }
                SelectItem(y);
            }
        }
        private void SelectItem(int laRow)
        {
            EhllapiWrapper.SetCursorPos(new Point(laRow, this.selectColumn).cursor);
            EhllapiWrapper.SendStr(this.value);
        }

        private bool NextPage()
        {
            if (!HasNextPage())
            {
                return false;
            }

            EhllapiWrapper.SendStr("@v");
            EhllapiExtension.Wait(5);
            return true;
        }
        private bool HasNextPage()
        {
            string sign = EhllapiExtension.ReadScreen(new Point(22, 79), 1);
            return (sign == "+");
        }
        public void SetBlockData(IScreenBlockData data)
        {
            this.block = data;
        }

        public override string ToString()
        {
            return string.Format("SelectProposalItems {0}, {1}, {2}", label, value, selectColumn);
        }
        public static ICommand Make(string[] @params)
        {
            Parameters p = new Parameters(@params);
            return new SelectProposalItemsCommand(p.Get(0), p.Get(1), p.GetInt32(2));
        }
    }
}
