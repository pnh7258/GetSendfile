﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KN.Systems;

namespace KN.BusinessLogic.Proposal.Command
{
    public class ClearTextboxCommand : ICommand
    {
        public ClearTextboxCommand()
        {
        }

        public void Execute()
        {
            EhllapiWrapper.SendStr("@F"); // Key "End"
            EhllapiExtension.Wait(5);
        }

        public void SetBlockData(IScreenBlockData data)
        {
        }

        public override string ToString()
        {
            return "ClearTextbox";
        }
    }
}
