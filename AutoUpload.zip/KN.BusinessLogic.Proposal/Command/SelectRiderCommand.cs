﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KN.Systems;
using KN.BusinessLogic.Proposal.Compiliing;

namespace KN.BusinessLogic.Proposal.Command
{
    public class SelectRiderCommand : ICommand
    {
        private IScreenBlockData block;
        private string label;
        private string riderCode;
        private int column;

        public SelectRiderCommand(string label, string riderCode, int column)
        {
            this.label = label;
            this.riderCode = riderCode;
            this.column = column;
        }

        /// <summary>
        /// Find the rider and input X to add new rider
        /// </summary>
        public void Execute()
        {
            int riderCodePos = FindRiderY();

            if (riderCodePos > 0)
            {
                SelectRider(riderCodePos);
                return;
            }

            NextPage();
            riderCodePos = FindRiderY();

            if (riderCodePos > 0)
            {
                SelectRider(riderCodePos);
                return;
            }

            SetError();
        }
        /// <summary>
        /// Find the postion of the row that contain the rider
        /// </summary>
        /// <returns></returns>
        private int FindRiderY()
        {
            int Y_MIN = 8;
            int Y_MAX = 21;

            for (int y = Y_MIN; y <= Y_MAX; y++)
            {
                string riderOnScreen = EhllapiExtension.ReadScreen(new Point(y, this.column), 4);
                if (riderOnScreen == this.riderCode)
                {
                    return y;
                }
            }

            return -1;
        }
        /// <summary>
        /// Input "X" to the row contain the rider
        /// </summary>
        /// <param name="riderRow"></param>
        private static void SelectRider(int riderRow)
        {
            const int RIDER_CHECKBOX_COLUMN = 9;

            EhllapiWrapper.SetCursorPos(new Point(riderRow, RIDER_CHECKBOX_COLUMN).cursor);
            EhllapiWrapper.SendStr("X");
        }
        private void SetError()
        {
            string format = "Rider Code {0} Not Found";
            CommandMsg.ErrorLas = String.Format(format, this.riderCode);
            CommandMsg.ErrorType = ErrorType.Tool;
        }

        /// <summary>
        /// Check whether the screen has next page
        /// </summary>
        private void NextPage()
        {
            EhllapiWrapper.SendStr("@v");
            EhllapiExtension.Wait(5);
        }
        public void SetBlockData(IScreenBlockData data)
        {
            this.block = data;
        }

        public override string ToString()
        {
            return string.Format("SelectRider {0}, {1}, {2}", label, riderCode, column);
        }
        public static ICommand Make(string[] @params)
        {
            Parameters p = new Parameters(@params);
            return new SelectRiderCommand(p .Get(0), p.Get(1), p.GetInt32(2));
        }
    }
}
