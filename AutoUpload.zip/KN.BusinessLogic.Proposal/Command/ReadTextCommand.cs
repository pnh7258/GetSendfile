﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KN.BusinessLogic.Proposal.Compiliing;

namespace KN.BusinessLogic.Proposal.Command
{
    public class ReadTextCommand : ICommand
    {
        private string name;
        private int row;
        private int column;
        private int length;

        public ReadTextCommand(string name, int row, int column, int length)
        {
            this.name = name;
            this.row = row;
            this.column = column;
            this.length = length;
        }

        public void Execute()
        {
            CommandMsg.AddVar(name, EhllapiExtension.ReadScreen(new Systems.Point(row, column), length));
        }
        public void SetBlockData(IScreenBlockData data)
        {
        }

        public override string ToString()
        {
            return string.Format("ReadText {0}, {1}, {2}, {3}", name, row, column, length);
        }
        public static ICommand Make(string[] @params)
        {
            Parameters p = new Parameters(@params);

            return new ReadTextCommand(p.Get(0), p.GetInt32(1), p.GetInt32(2), p.GetInt32(3));
        }
    }
}
