﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KN.Systems;

namespace KN.BusinessLogic.Proposal.Command
{
    public class ValidateCommand : ICommand
    {
        private string screen;

        public ValidateCommand(string screen = null)
        {
            this.screen = screen;
        }

        public void Execute()
        {
            bool match = (screen == null) || (screen != null && this.screen == EhllapiExtension.ReadScreenName());
            if (!match)
            {
                return;
            }

            EhllapiWrapper.SendStr("@5");
            EhllapiExtension.Wait(10);
            CommandMsg.ErrorLas = EhllapiExtension.ReadError();
        }
        public void SetBlockData(IScreenBlockData data)
        {
        }

        public override string ToString()
        {
            return "Validate " + screen;
        }
    }
}
