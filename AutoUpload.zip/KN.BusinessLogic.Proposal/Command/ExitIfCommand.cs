﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KN.BusinessLogic.Proposal.Compiliing;

namespace KN.BusinessLogic.Proposal.Command
{
    public class ExitIfCommand : ICommand
    {
        private IScreenBlockData block;

        private string attribute;
        private string value;

        public ExitIfCommand(string attribute, string value)
        {
            this.attribute = attribute;
            this.value = value;
        }
        public void Execute()
        {
            bool match = false;
            switch (attribute.ToLower())
            {
                case "error":
                    match = (value == null && CommandMsg.HasError()) || (CommandMsg.ErrorLas == value);
                    break;
            }

            if (match)
            {
                block.GoEnd();
            }
        }
        public void SetBlockData(IScreenBlockData data)
        {
            this.block = data;
        }

        public static ICommand Make(string[] @params)
        {
            Parameters p = new Parameters(@params);

            return new ExitIfCommand(p.Get(0), p.GetString(1, null));
        }
        public override string ToString()
        {
            return string.Format("ExitIf \"{0}\", \"{1}\"", attribute, value);
        }
    }
}
