﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KN.Systems;
using KN.BusinessLogic.Proposal.Command;

namespace KN.BusinessLogic.Proposal.Command
{
    public class ClearErrorCommand : ICommand
    {
        public ClearErrorCommand()
        {
        }

        public void Execute()
        {
            CommandMsg.ClearError();
        }
        public void SetBlockData(IScreenBlockData data)
        {
        }

        public override string ToString()
        {
            return "ClearError";
        }
    }
}
