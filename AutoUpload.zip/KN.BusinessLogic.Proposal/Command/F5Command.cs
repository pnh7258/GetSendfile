﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KN.Systems;
using KN.BusinessLogic.Proposal.Command;

namespace KN.BusinessLogic.Proposal.Command
{
    public class F5Command : ICommand
    {
        public F5Command()
        {
        }

        public void Execute()
        {
            EhllapiWrapper.SendStr("@5");
            EhllapiExtension.Wait(5);
        }
        public void SetBlockData(IScreenBlockData data)
        {
        }

        public override string ToString()
        {
            return "F5";
        }
    }
}
