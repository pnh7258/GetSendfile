﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KN.Systems;

namespace KN.BusinessLogic.Proposal.Command
{
    public class LabelCommand : ICommand
    {
        private string name;

        public LabelCommand(string name)
        {
            this.name = name;
        }
        public string Name { get { return name; } }

        public void Execute()
        {
            string actualScreen = EhllapiExtension.ReadScreenName(new Point(1, 72));
            string scrceenTile = EhllapiExtension.ReadScreen(new Point(1, 40), 21);
            if (actualScreen == "SR516" && (this.name == "@ValidateCurrentScreen" || this.name == "@TryValidate"))
            {
                if (scrceenTile.Contains("Child Dependent Supp") == false)
                {
                    EhllapiWrapper.SetCursorPos(new Point(8, 24).cursor);
                    EhllapiWrapper.SendStr("@F"); // Key "End"

                    EhllapiWrapper.SetCursorPos(new Point(17, 58).cursor);
                    EhllapiWrapper.SendStr("@F");
                }
            }
        }
        public void SetBlockData(IScreenBlockData data)
        {
        }
        public override string ToString()
        {
            return string.Format("Label \"{0}\"", this.name);
        }
    }
}
