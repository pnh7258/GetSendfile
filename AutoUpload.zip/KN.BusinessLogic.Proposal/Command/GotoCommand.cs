﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KN.BusinessLogic.Proposal.Compiliing;

namespace KN.BusinessLogic.Proposal.Command
{
    public class GotoCommand : ICommand
    {
        private IScreenBlockData block;
        private string label;

        public GotoCommand(string label)
        {
            this.label = label;
        }

        public void Execute()
        {
            this.block.GoTo(label);
        }
        public void SetBlockData(IScreenBlockData data)
        {
            this.block = data;
        }
        public override string ToString()
        {
            return string.Format("Goto \"{0}\"", label);
        }

        /// <summary>
        /// Parse parametter from script
        /// </summary>
        /// <param name="params"></param>
        /// <returns></returns>
        public static GotoCommand Make(string[] @params)
        {
            Parameters p = new Parameters(@params);
            return new GotoCommand(p.Get(0));
        }
    }
}
