﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KN.Systems;
using KN.BusinessLogic.Proposal.Compiliing;

namespace KN.BusinessLogic.Proposal.Command
{
    public class EndScreenCommand : ICommand
    {
        public class EndScreen : EndScreenCommand
        {
            private string mode;

            public EndScreen(string mode)
            {
                this.mode = mode;
            }

            public override void Execute()
            {
                if (mode == "Silent")
                {
                    Execute_Silent();
                }
                else
                {
                    Execute_Normal();
                }
            }
            private void Execute_Normal()
            {
                if (CommandMsg.HasError())
                {
                    if (UploadApp.StopIfError) { return; }

                    ExitScreen();
                    return;
                }

                EhllapiWrapper.SendStr("@E");
                EhllapiExtension.WaitingToNextScreen();
            }
            private void Execute_Silent()
            {
                EhllapiExtension.WaitingToNextScreen();
            }
            private void ExitScreen()
            {
                string screen = EhllapiExtension.ReadScreenName();
                if (screen == "S5003")
                {
                    return;
                }

                EhllapiExtension.Wait(10);
                EhllapiWrapper.SendStr("@3"); // F3
            }

            public override void SetBlockData(IScreenBlockData data)
            {
            }

            public override string ToString()
            {
                return "EndScreen " + mode;
            }
        }

        public class EndScreenSetup : EndScreenCommand
        {
            public override void Execute()
            {
                // Do nothing
            }
            public override void SetBlockData(IScreenBlockData data)
            {
            }
            public override string ToString()
            {
                return "EndScreen";
            }
        }

        public virtual void Execute()
        {
            throw new NotImplementedException();
        }
        public virtual void SetBlockData(IScreenBlockData data)
        {
            throw new NotImplementedException();
        }

        public static EndScreenCommand Make(string[] @params)
        {
            Parameters p = new Parameters(@params);

            return new EndScreen(p.GetString(0, ""));
        }
    }
}
