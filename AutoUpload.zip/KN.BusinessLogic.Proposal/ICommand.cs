﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KN.BusinessLogic.Proposal.Command;

namespace KN.BusinessLogic.Proposal
{
    public interface ICommand
    {
        void Execute();

        /// <summary>
        /// Use for Goto statement in script file
        /// </summary>
        /// <param name="data"></param>
        void SetBlockData(IScreenBlockData data);
    }
}
