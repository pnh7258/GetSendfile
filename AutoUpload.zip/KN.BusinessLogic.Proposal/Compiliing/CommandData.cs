﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KN.BusinessLogic.Proposal.Compiliing
{
    public class CommandData
    {
        private string[] @params = new string []{};
        private string name;

        public string[] Parameters
        {
            get { return @params; }
            set { @params = value; }
        }      
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
    }
}
