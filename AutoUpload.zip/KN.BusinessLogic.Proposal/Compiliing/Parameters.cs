﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KN.BusinessLogic.Proposal.Compiliing
{
    public class Parameters
    {
        private string[] @params;
        public Parameters(string[] @params)
        {
            this.@params = @params;
        }

        public string Get(int index)
        {
            return this.@params[index];
        }
        public int GetInt32(int index)
        {
            return Convert.ToInt32(@params[index]);
        }
        public int GetInt32(int index, int @default)
        {
            if (@params.Length <= index)
            {
                return @default;
            }

            return Convert.ToInt32(@params[index]);
        }
        public string GetString(int index, string @default)
        {
            if (@params.Length <= index)
            {
                return @default;
            }

            return @params[index];
        }
        public string GetString(int index) {
            return @params[index];
        }
    }
}
