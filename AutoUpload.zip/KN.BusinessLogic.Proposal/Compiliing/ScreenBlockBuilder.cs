﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KN.BusinessLogic.Proposal.Command;

namespace KN.BusinessLogic.Proposal.Compiliing
{
    /// <summary>
    /// An implementation of Builder pattern to build ScreenBlock object.
    /// </summary>
    public class ScreenBlockBuilder
    {
        private BeginScreenCommand begin;
        private List<ICommand> body;
        private EndScreenCommand end;

        public ScreenBlockBuilder()
        {
            Initialize();
        }
        private void Initialize()
        {
            this.begin = null;
            this.body = new List<ICommand>();
            this.end = null;
        }

        public bool Complete
        {
            get
            {
                return (this.begin != null && this.end != null);
            }
        }

        public void Begin(BeginScreenCommand command)
        {
            this.begin = command;
        }
        public void End(EndScreenCommand command)
        {
            this.end = command;
        }
        public void Add(ICommand command)
        {
            body.Add(command);
        }
        public void Clear()
        {
            Initialize();
        }

        public ScreenBlock ToScreenBlock()
        {
            if (begin is BeginScreenCommand.BeginScreen)
            {
                return new ScreenBlock(begin, body, end);
            }
            else
            {
                return new ScreenBlock(begin, body, new EndScreenCommand.EndScreenSetup());
            }
        }
    }
}
