﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KN.DataAcess
{
    public class PruDBConn
    {
        private static string _ConnString = string.Empty;

        public static string ConnString
        {
            get
            {
                if (_ConnString == string.Empty)
                    _ConnString = @"Provider=Microsoft.Jet.OleDb.4.0;Data Source=" + Environment.CurrentDirectory + "\\Database.mdb;Persist Security Info=False;";

                return _ConnString;
            }
        }
    }
}
