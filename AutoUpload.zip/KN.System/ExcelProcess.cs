﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using KN.DataAcess;

namespace KN.Systems
{
    public static class ExcelProcess
    {
        static string[] sheets = new string[] { "S2465_LAInfo", "S5004_ProIn", "S5005_LAInfo", "S5007_ISInfo", "Plan", "S5417_Plan", "S5010_BenInfo" };
        static string[] tables = new string[] { "S2465", "S5004", "S5005", "S5007", "Products", "S5417", "S5010" };

        public static DataTable ReadCSV(string csvFilePath, bool isfirstRowHeader)
        {
            DataTable dt = new DataTable();
            DataRow dr;
            int index = 0;

            string[] csvData = System.IO.File.ReadAllLines(csvFilePath);

            for (int i = 0; i < csvData.Length; i++)
            {
                string s = csvData[i];

                
                int iBegin = s.IndexOf('"');

                if (iBegin >= 0)
                {
                    int iEnd = s.LastIndexOf('"');

                    if (iEnd > iBegin)
                    {
                        string sAddress = s.Substring(iBegin, iEnd - iBegin + 1);
                        string sAddressNew = sAddress.Substring(1, sAddress.Length - 2).Replace(',', '|');
                        csvData[i] = s.Replace(sAddress, sAddressNew);
                    }
                }
            }

            if (csvData.Length == 0)
            {
                return dt;
            }

            String[] headings = csvData[0].Split(',');

            if (isfirstRowHeader)
            {
                index = 1;
                for (int i = 0; i < headings.Length; i++)
                {
                    headings[i] = headings[i].Replace(' ', '_');
                    dt.Columns.Add(headings[i], typeof(string));
                }

            }
            else
            {
                for (int i = 0; i < headings.Length; i++)
                {
                    headings[i] = headings[i].Replace(' ', '_');
                    dt.Columns.Add("Column" + (i + 1).ToString(), typeof(string));
                }
            }

            for (int i = index; i < csvData.Length; i++)
            {
                string[] arrsData = csvData[i].Split(',');

                dr = dt.NewRow();

                for (int j = 0; j < headings.Length; j++)
                {
                    dr[j] = arrsData[j];
                }

                dt.Rows.Add(dr);
            }

            return dt;
        }

        public static void UpLoad(string filename)
        {
            try
            {
                PruDBHelp db;
                for (int i = 0; i < sheets.Length; i++)
                {
                    db = new PruDBHelp(filename);
                    var dt = db.ExecuteDataTable("select * from [" + sheets[i] + "$]", CommandType.Text);
                    if (dt == null) continue;
                    if (dt.Rows.Count == 0) continue;
                    Table_Import(tables[i], dt);
                }
            }
            catch { throw; }
        }

        public static void Table_Import(string table, DataTable tabledata)
        {
            PruDBHelp db = new PruDBHelp();
            db.ExecuteNonQuery("delete from " + "DATA_" + table, CommandType.Text);

            StringBuilder sqlColumns = new StringBuilder(1024);
            StringBuilder sqlValues = new StringBuilder(1024);
            string columname = "";
            for (int i = 0; i < tabledata.Columns.Count; i++)
            {
                columname = FormatParameter(tabledata.Columns[i].ColumnName);
                sqlColumns.AppendFormat("[{0}]{1}", columname, i < tabledata.Columns.Count - 1 ? ", " : String.Empty);
                sqlValues.AppendFormat("{0}{1}", "@" + columname, i < tabledata.Columns.Count - 1 ? ", " : String.Empty);
            }

            string sql = String.Format("INSERT INTO {0} ({1}) VALUES ({2})", "DATA_" + table, sqlColumns.ToString(), sqlValues.ToString());

            foreach (DataRow dr in tabledata.Rows)
            {
                db = new PruDBHelp();
                string values = "";
                for (int i = 0; i < tabledata.Columns.Count; i++)
                {
                    columname = FormatParameter(tabledata.Columns[i].ColumnName);
                    values = dr[i].ToString().Trim();// (dr[i] == null || dr[i] == DBNull.Value ? DBNull.Value : (tabledata.Columns[i].DataType == typeof(DateTime) ? ((DateTime)dr[i]).Date : dr[i]))
                    db.AddParameter("@" + columname, values);
                }
                db.ExecuteNonQuery(sql, CommandType.Text);
            }
        }

        static string[] preprocess = new string[] { "S5004", "S5005", "Products", "S5010" };
        public static void PreProcess()
        {
            try
            {
                PruDBHelp db;
                foreach (var table in preprocess)
                {
                    db = new PruDBHelp();
                    db.ExecuteNonQuery("updateDATA_" + table, CommandType.StoredProcedure);
                }
            }
            catch
            { }
        }

        public static string FormatParameter(string name)
        {
            return name.Replace(" ", "").Replace("(", "").Replace(")", "").Replace("#", "").Replace(".", "").Replace("@", "").Replace("%", "").Replace("/", "");
        }
    }
}



