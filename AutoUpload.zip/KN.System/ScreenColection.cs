﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KN.Systems
{
    public class ScreenColection : Dictionary<String, Screen>
    {
    }
   
}
