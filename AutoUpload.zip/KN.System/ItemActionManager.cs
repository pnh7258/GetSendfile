﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using KN.DataAcess;

namespace KN.Systems
{
    public static class ItemActionManager
    {
        private static ItemAction GetItemActionFromReader(IDataReader dataReader)
        {
            try
            {
                ItemAction itemaction = new ItemAction();
                itemaction.id = KNDataHelper.GetInt(dataReader, "id");
                itemaction.name = KNDataHelper.GetString(dataReader, "name");
                itemaction.type = KNDataHelper.GetString(dataReader, "type");
                itemaction.value = KNDataHelper.GetString(dataReader, "value"); 
                return itemaction;
            }
            catch
            {
                throw;
            }
        }

        public static ItemAction ItemActionLoad(int ID)
        {
            PruDBHelp db = new PruDBHelp();
            try
            {
                db.AddParameter("@ID", ID);


                using (IDataReader dataReader = db.ExecuteReader("select * from ItemAction where [ID]=@ID", CommandType.Text))
                {
                    while (dataReader.Read())
                    {
                        return GetItemActionFromReader(dataReader);                       
                    }
                }
                return null;
            }
            catch
            {
                throw;
            }
        }
    }
}
