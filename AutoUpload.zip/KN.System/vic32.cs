﻿
using System;
using System.Runtime.InteropServices;
using System.Text;
using System.Drawing;
using System.Drawing.Printing;
using System.Drawing.Imaging;
using viclib;
namespace KN.Systems
{


    public static class Vic32Wrapper
    {
        //................. helper functions .............
        [DllImport("kernel32.dll", EntryPoint = "RtlMoveMemory")]
        public static extern void RtlMoveMemory(int des, int src, int count);
        [DllImport("kernel32.dll", EntryPoint = "RtlMoveMemory")]
        public static extern void Copybmh(ref vicwin.BITMAPINFOHEADER des, int src, int count);
        [DllImport("kernel32.dll", EntryPoint = "RtlMoveMemory")]
        public static extern void Copytobuffer(int des, ref byte src, int count);
        [DllImport("kernel32.dll", EntryPoint = "RtlMoveMemory")]
        public static extern void Copyfrombuffer(ref byte src, int des, int count);
        [DllImport("kernel32.dll", EntryPoint = "GlobalAlloc")]
        public static extern int GlobalAlloc(int flag, int bytes);
        [DllImport("kernel32.dll", EntryPoint = "GlobalHandle")]
        public static extern int GlobalHandle(ref byte first_elem);
        [DllImport("kernel32.dll", EntryPoint = "LocalHandle")]
        public static extern int LocalHandle(ref byte first_elem);
        [DllImport("kernel32.dll", EntryPoint = "GlobalLock")]
        public static extern int GlobalLock(int hMem);
        [DllImport("kernel32.dll", EntryPoint = "GlobalSize")]
        public static extern int GlobalSize(int hMem);
        [DllImport("kernel32.dll", EntryPoint = "GlobalFree")]
        public static extern int GlobalFree(int hMem);
        [DllImport("user32.dll")]
        public static extern int SetRect(ref vicwin.RECT lpRect, int X1, int Y1, int X2, int Y2);


        public static int loadtiffdata(ref byte bd, ref vicwin.imgdes timage, int pindex, int magnification)
        {
            int rcode;
            vicwin.TiffData tinfo;
            int tpages = 0;
            int noull = 0;
            int lpage;
            vicwin.imgdes tempimage;
            int bpp = 0;


            tinfo = new vicwin.TiffData();
            tempimage = new vicwin.imgdes();
            // Determine total pages in the file, put value in tpages		
            rcode = vicwin.tiffgetpageinfofrombuffer(ref bd, ref tpages, ref noull, (int)0);
            if (rcode == vicwin.NO_ERROR)
            {
                //numpages.Text = tpages.ToString("0");
                lpage = tpages - 1;
                //lastpage.Text = lpage.ToString("0");

                // Get the image dimensions for the page of interest, put values into tinfo data structure
                rcode = vicwin.tiffinfopagebyindexfrombuffer(ref bd, ref tinfo, pindex);
                if (rcode == vicwin.NO_ERROR)
                {
                    // Allocate space for the image in memory, timage is the image descriptor
                    rcode = vicwin.allocimage(ref timage, tinfo.width, tinfo.length, tinfo.vbitcount);
                    if (rcode == vicwin.NO_ERROR)
                    {
                        // Load the image from the tiff file into the image buffer described by timage
                        rcode = vicwin.loadtifpagebyindexfrombuffer(ref bd, ref timage, pindex);
                        if (rcode == vicwin.NO_ERROR || rcode == vicwin.BAD_DATA)
                        {
                            //dimensions.Text = tinfo.width.ToString("0") + " x " + tinfo.length.ToString("0") + "  " + tinfo.vbitcount.ToString("0") + "-bit";

                            if (tinfo.vbitcount == 16)
                            { // Replace 16-bit grayscale image with 8-bit grayscale
                                rcode = vicwin.allocimage(ref tempimage, tinfo.width, tinfo.length, 8);
                                rcode = vicwin.convertgray16to8(ref timage, ref tempimage);
                                if (rcode == vicwin.NO_ERROR)
                                {
                                    vicwin.freeimage(ref timage);
                                    vicwin.copyimgdes(ref tempimage, ref timage);
                                }
                            }
                            if (magnification != 100)
                            {      // Resize if necessary
                                bpp = getbpp(ref timage);
                                rcode = vicwin.allocimage(ref tempimage, tinfo.width * magnification / 100, tinfo.length * magnification / 100, bpp);
                                if (rcode == vicwin.NO_ERROR)
                                { // The Victor Library resize will be faster and better quality than a browser resize
                                    rcode = vicwin.resizeex(ref timage, ref tempimage, 1);
                                    if (rcode == vicwin.NO_ERROR)
                                    {
                                        vicwin.freeimage(ref timage);
                                        vicwin.copyimgdes(ref tempimage, ref timage);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            else  // Error loading tiff file
            {
                //numpages.Text = "0";
                //lastpage.Text = "0";
            }
            return (rcode);
        }



        // This function receives an image descriptor and sets up the gif or jpeg to be displayed   
        public static int setup_to_displayimage(ref vicwin.imgdes lsrcimg)
        {
            int outbuff = 0;
            int mode = 0;
            int transcolor = 0;
            int rcode;
            int quality = 75;
            string ftype = "image/gif";
            int buffsize = 0;
            byte[] imgbytearray = { 0, 0, 0 };
            int bpp;



            bpp = getbpp(ref lsrcimg);

            // Ready to display image. Use jpg for 24-bit images, gif for all others   
            if (bpp == 24)
            {
                rcode = vicwin.savejpgtobuffer(ref outbuff, ref lsrcimg, quality);
                ftype = "image/jpeg";
            }
            else
            {
                rcode = vicwin.savegiftobufferex(ref outbuff, ref lsrcimg, mode, transcolor);
            }

            // Copy the jpeg or gif data into a byte array for sending to the browser      
            if (rcode == vicwin.NO_ERROR)
            {
                //imgbytearray = transferbuffertobytearray(outbuff);
                vicwin.freebuffer(outbuff);
            }

            // Store the image and file type in session variables   
            //Session["outfilebinarydata"] = imgbytearray;
            //Session["outfilecontent"] = ftype;

            // viewimage_cs.aspx will simply binary write the image to the browser   
            //image1.ImageUrl = "viewimage_cs.aspx";
            return (rcode);
        }

        public static int getbpp(ref vicwin.imgdes timage)
        {
            vicwin.BITMAPINFOHEADER bmh = new vicwin.BITMAPINFOHEADER();

            Copybmh(ref bmh, timage.bmh, 40);
            return (bmh.biBitCount);
        }

        //public static void mnutifmultipage(string filename)
        //{
        //    int rcode, rcode2;
        //    vicwin.imgdes tempimage1;
        //    vicwin.imgdes tempimage2;
        //    vicwin.RECT prtrect;
        //    vicwin.TiffData fileinfo; 
        //    int page1;
        //    int page2;
        //    int maxPages=10;
        //    int tmp=0;
        //    rcode=0;
        //    //Determine number of pages in the file
        //    rcode = vicwin.tiffgetpageinfo(ref filename, ref maxPages, ref tmp, 0);
        //    PrintDocument pdoc = new PrintDocument();

        //    if (rcode == 0)
        //    { 
        //        page1 = 0;// ' Start printing on page 1
        //        page2 = 1;
        //        while(page1 <= maxPages - 1)
        //        {
        //            do{        
        //                //' Load the next odd and even pages
        //                rcode = vicwin.tiffinfopagebyindex(ref filename, ref fileinfo, page1);
        //                rcode = vicwin.allocimage(ref tempimage1, fileinfo.width, fileinfo.length, fileinfo.vbitcount);
        //                rcode = vicwin.loadtifpagebyindex(ref filename, ref tempimage1, page1);
            
        //                //Printer.CurrentX = 0 ; //' One inch from left
        //                //Printer.CurrentY = 0;
        //                //Printer.Print ("");

        //                //prtrect.top = 0;
        //                //prtrect.right = 0;
        //                //prtrect.bottom = 0;
        //                //prtrect.left = 0;

        //                rcode = SetRect(ref prtrect, 0, 0, 6800, 6800 * fileinfo.length / fileinfo.width);
                        
            
        //                //' Print the first image
        //                rcode = vicwin.printimagenoeject(hwnd, Printer.hDC, 2, tempimage1, prtrect, 0, 0);
        //                //Printer.NewPage
            
        //                //' Print the second image on the second page
        //                rcode = vicwin.tiffinfopagebyindex(ref filename, ref fileinfo, page2);
        //                if (rcode == vicwin.NO_ERROR) 
        //                {
        //                    rcode = vicwin.allocimage(ref tempimage2, fileinfo.width, fileinfo.length, fileinfo.vbitcount);
        //                    rcode = vicwin.loadtifpagebyindex(ref filename, ref tempimage2, page2);
        //                    rcode = SetRect(ref prtrect, 0, 0, 6800, 6800 * fileinfo.length / fileinfo.width);

        //                    rcode = vicwin.printimagenoeject(hwnd, Printer.hDC, 2, tempimage2, prtrect, 0, 0);
        //                    //Printer.NewPage;
        //                }
        //                page2 = page2 + 2;
        //            }while (page2 == page1 + 1);
        //            page1 = page1 + 2;
        //        }
        //        //Printer.EndDoc;      
        //        vicwin.freeimage(ref tempimage1);//After all the pages are printed release page buffers
        //        vicwin.freeimage(ref tempimage2);
        //    }     
        //}

        public static void mnutifmultipage1(string filename)
        {
            int rcode;
            vicwin.imgdes tempimage;             
            vicwin.RECT prtrect;
            vicwin.TiffData fileinfo;
            int maxPages = 10;            
            int tmp = 0;
            // Determine number of pages in the file
            rcode = vicwin.tiffgetpageinfo(ref filename, ref maxPages, ref tmp, 0);
            PrintDocument pdoc = new PrintDocument();
            fileinfo = new vicwin.TiffData();
            tempimage = new vicwin.imgdes();

            if (rcode == vicwin.NO_ERROR) 
            {          
               //' For each page in the file
                for(int j = 0 ;j<(maxPages - 1);j++)
                {
                    //' Determine the image dimensions and pixel depth
                    rcode = vicwin.tiffinfopagebyindex(ref filename, ref fileinfo, j);

                    //' Allocate space for the image
                    rcode = vicwin.allocimage(ref tempimage, fileinfo.width, fileinfo.length, fileinfo.vbitcount);

                    if (rcode == vicwin.NO_ERROR)
                    {
                        //' Load the image
                        rcode = vicwin.loadtifpagebyindex(ref filename, ref tempimage, j);

                        //' Print the image
                        if (rcode == vicwin.NO_ERROR)   //' Print 8 inches wide, adjust length to maintain aspect ratio
                        {                                
                            //rcode = SetRect(ref prtrect, 0, 0, 6800, 6800 * fileinfo.length / fileinfo.width);
                            prtrect.top = 0;
                            prtrect.left = 0;
                            prtrect.right = 6800; 
                            prtrect.bottom = 6800 * fileinfo.length / fileinfo.width;

                            //rcode = vicwin.printimage(hwnd, Printer.hDC, 0, tempimage, prtrect, 0, 0);
                            rcode = vicwin.printimage(0, 0, 0, ref tempimage,ref prtrect, 0, 0);
                        }

                        //' Free the image buffer
                        vicwin.freeimage(ref tempimage);
                    }
                } //' Go to the next page
            } 
        }
    }
}
