﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace KN.Systems
{
    public static class AppSetting
    {
        public static readonly System.Reflection.Assembly ASM_RUNNING = System.Reflection.Assembly.GetExecutingAssembly();
        public static readonly System.Version APP_VERSION = ASM_RUNNING.GetName().Version;
        public static readonly string APP_PATH = ASM_RUNNING.Location;

        public static readonly char[] SLASHES = new char[] { '\\', '/' };
        public static string FOLDER_ROOT = Path.GetDirectoryName(APP_PATH).TrimEnd(SLASHES);

        public static string SESSION = "A";

        public static int NUM_COL = 80;
    }
}
