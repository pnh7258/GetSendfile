﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KN.Systems
{
    public class Item
    {
        public ItemConfig itemconfig { get; set; }
        public int priority { get; set; }    
    }

    public class ItemConfig
    {
        public string id { get; set; }
        public string name { get; set; }
        public Point point { get; set; }
        public object values { get; set; }
        public int action_id { get; set; }
        public ItemAction action { get { return ItemActionManager.ItemActionLoad(action_id); } }
        public string typename { get; set; }
        public int length { get; set; }
    }
}
