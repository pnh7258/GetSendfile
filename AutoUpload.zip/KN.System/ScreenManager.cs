﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using KN.DataAcess;

namespace KN.Systems
{
    public abstract class ScreenManager
    {
        private static Screen GetScreenFromReader(IDataReader dataReader)
        {
            try
            {
                Screen screen = new Screen();
                ScreenConfig screenconfig = new ScreenConfig(KNDataHelper.GetString(dataReader, "Code"), KNDataHelper.GetString(dataReader, "Name"));
                            
                screen.screenconfig = screenconfig;               
                return screen;
            }
            catch
            {
                throw;
            }
        }

        public static Screen ScreenLoad(string code)
        {
            PruDBHelp db = new PruDBHelp();            
            try
            {
                db.AddParameter("@Code", code);

                using (IDataReader dataReader = db.ExecuteReader("select * from Screens where Code = @Code", CommandType.Text))
                {
                    while (dataReader.Read())
                    {
                        return GetScreenFromReader(dataReader);                        
                    }
                }
                return null;
            }
            catch
            {                 
                throw;
            }
        }

        public static ScreenColection GetScreens(string Proposal_Code)
        {
            var screens = new ScreenColection();

            PruDBHelp db = new PruDBHelp();

            try
            {
                db.AddParameter("@Proposal_Code", Proposal_Code);

                using (IDataReader dataReader = db.ExecuteReader("select Screen_Code, Priority from ProposalScreenMap where Proposal_Code = @Proposal_Code", CommandType.Text))
                {
                    while (dataReader.Read())
                    {
                        string Screen_Code = KNDataHelper.GetString(dataReader, "Screen_Code");
                        int Priority = KNDataHelper.GetInt(dataReader, "Priority");
                        if(Screen_Code.Trim()!="")
                        {
                            Screen screen = ScreenLoad(Screen_Code);
                            screen.priority = Priority;
                            screens.Add(Screen_Code, screen);
                        }
                    }
                }
                
            }
            catch
            {                
                throw;
            }
            return screens;
        }
    }
}
