﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Data;
using System.Data.Common;
using KN.DataAcess;
namespace KN.Systems
{
    public static class ItemManager
    {
        private static Item GetItemFromReader(IDataReader dataReader)
        {
            try
            {
                Item item = new Item();
                ItemConfig itemconfig = new ItemConfig();

                itemconfig.name = KNDataHelper.GetString(dataReader, "Name");
                itemconfig.point = new Point(KNDataHelper.GetInt(dataReader, "X"), KNDataHelper.GetInt(dataReader, "Y"));
                itemconfig.action_id = KNDataHelper.GetInt(dataReader, "Action_id");
                itemconfig.typename = KNDataHelper.GetString(dataReader, "typename");
                itemconfig.length = KNDataHelper.GetInt(dataReader, "Length");
                item.itemconfig = itemconfig;
                item.priority = KNDataHelper.GetInt(dataReader, "Priority"); ;
                return item;
            }
            catch
            {
                throw;
            }
        }

        public static ItemColection ScreenConfigLoad(string code)
        {
            PruDBHelp db = new PruDBHelp();
            var result = new ItemColection();
            try
            {
                db.AddParameter("@Code", code);

                using (IDataReader dataReader = db.ExecuteReader("select c.*,b.Priority from (Screens a inner join ScreenItemMap b on a.Code= b.Screen_Code) inner join Items c on b.Item_id= c.ID   where a.Code=@Code order by b.Priority asc", CommandType.Text))
                {
                    while (dataReader.Read())
                    {
                        var item = GetItemFromReader(dataReader);
                        result.Add(item.itemconfig.name, item);
                    }
                }
                return result;
            }
            catch
            {
                throw;
            }
        }
    }
}
