﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using KN.DataAcess;
namespace KN.Systems
{
    public static class ProposalManager
    {
        

        private static Proposal GetProposalFromReader(IDataReader dataReader)
        {
            try
            {
                Proposal proposal = new Proposal(KNDataHelper.GetString(dataReader, "Code"),KNDataHelper.GetString(dataReader, "Name"));
                               
                return proposal;
            }
            catch
            {
                throw;
            }
        }

        public static Proposal ProposalLoad(string code)
        {
            PruDBHelp db = new PruDBHelp();
            try
            {
                db.AddParameter("@Code", code);

                using (IDataReader dataReader = db.ExecuteReader("select * from Proposals where Code = @Code", CommandType.Text))
                {
                    while (dataReader.Read())
                    {
                        return GetProposalFromReader(dataReader);
                    }
                }
                return null;
            }
            catch
            {
                throw;
            }
        }
    }
}
