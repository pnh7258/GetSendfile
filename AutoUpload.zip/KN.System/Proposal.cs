﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KN.BusinessLogic;

namespace KN.Systems
{
    public class Proposal
    {       
        public string code { get; set; }
        public string name { get; set; }

        public Proposal()
        {
            
        }

        public Proposal(string Code, string Name)
        {
            this.code = Code;
            this.name = Name;            
        }

        

        public virtual void Fire()
        {
            
        }
    }
}
