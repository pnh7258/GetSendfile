﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KN.Systems
{
    public class Point
    {
        public int X { get; set; }
        public int Y { get; set; }
        public int cursor { get { return (X - 1) * 80 + Y; } }

        public Point(int x, int y)
        {
            this.X = x;
            this.Y = y;
        }
    }
}
