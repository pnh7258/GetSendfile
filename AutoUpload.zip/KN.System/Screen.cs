﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using KN.Systems;
namespace KN.Systems
{
    public class Screen
    {
        public ScreenConfig screenconfig { get; set; }
        public int priority { get; set; }

        public Screen()
        {
            
        }

        public virtual Point NamePos
        {
            get { return new Point(1, 72); }
        }        

        public virtual Point MessagePos
        {
            get { return new Point(24, 2); }
        }

        public void Waiting_Old()
        {
            try
            {
                string screen_code = "";
                int count_retry = 0;
                while (screen_code != screenconfig.code)
                {
                    System.Threading.Thread.Sleep(1000);
                    screen_code = "";
                    //EhllapiWrapper.SendStr("@R");
                    UInt32 status = EhllapiWrapper.Wait();
                    EhllapiWrapper.ReadScreen(NamePos.cursor, screenconfig.code.Length, out screen_code);
                    screen_code = screen_code.Substring(0, screenconfig.code.Length);
                    
                    if (count_retry == 1)
                    {
                        //EhllapiWrapper.Disconnect();
                        throw new Exception("Can not connect to LAS. LAS can not change screen.");
                    }

                    count_retry++;
                }
            }
            catch
            {
                throw;
            }
        }

        public void Waiting()
        {
            Waiting(5);
        }

        public void Waiting(int time)
        {
            Wait(time);
        }

        public void Waiting_Old(int time)
        {
            try
            {
                string screen_code = "";
                int count_retry = 0;
                while (screen_code != screenconfig.code)
                {
                    System.Threading.Thread.Sleep(1000);
                    screen_code = "";
                    //EhllapiWrapper.SendStr("@R");
                    UInt32 status = EhllapiWrapper.Wait();
                    EhllapiWrapper.ReadScreen(NamePos.cursor, screenconfig.code.Length, out screen_code);
                    screen_code = screen_code.Substring(0, screenconfig.code.Length);

                    if (count_retry == time)
                    {
                        //EhllapiWrapper.Disconnect();
                        throw new Exception("Can not connect to LAS. LAS can not change screen.");
                    }

                    count_retry++;
                }
            }
            catch
            {
                throw;
            }
        }

        public void Wait(int time)
        {
            try
            {
                int orb_int_TimeOut = 0;
                bool orb_flg_Restart = false;


                orb_int_TimeOut = 1;

            RoutineRestart:

                int orb_mlng_ReturnCode = 0;
                uint orb_mlng_CallStatus = EhllapiWrapper.Wait();                

                if (orb_mlng_CallStatus == 4 && orb_int_TimeOut < time)
                {
                    EhllapiWrapper.SendStr("@R");
                    orb_int_TimeOut = orb_int_TimeOut + 1;
                    goto RoutineRestart;
                }


                if (orb_mlng_CallStatus == 5 && orb_flg_Restart == false)
                {
                    EhllapiWrapper.SendStr("@R");
                    orb_flg_Restart = true;
                    goto RoutineRestart;
                }

                switch (orb_mlng_CallStatus)
                {
                    case 0: break;
                    case 1: throw new Exception("[  1] Session not connected; ");
                        
                    case 4: throw new Exception("[  4] TimeOut occured after; ");

                    case 5: EhllapiWrapper.SendStr("@R"); break;//throw new Exception("[  5] Keyboard remains locked");
                        
                    case 9: throw new Exception("[  9] Client Access System Error");
                        
                    default: throw new Exception("[" + orb_mlng_ReturnCode + "] *CODE ERROR");
                        
                }
            }
            catch
            {
                throw;
            }
        }

        public void WaitingToNextScreen()
        {
            Wait(5);
        }

        public void WaitingToNextScreen_Old()
        {
            try
            {
                string screen_code = "";

                int count_retry = 0;
                while (screen_code == screenconfig.code)
                {
                    //System.Threading.Thread.Sleep(1000);
                    screen_code = "";
                    //EhllapiWrapper.SendStr("@R");
                    UInt32 status = EhllapiWrapper.Wait();
                    EhllapiWrapper.ReadScreen(NamePos.cursor, screenconfig.code.Length, out screen_code);
                    screen_code = screen_code.Substring(0, screenconfig.code.Length);
                    if (count_retry == 10)
                    {
                        //EhllapiWrapper.Disconnect();
                        throw new Exception("Can not go to next screen.");
                    }
                    count_retry++;
                }
            }
            catch
            {
                throw;
            }
        }

        public void WaitingToScreen(string screen, int time)
        {
            string screen_code_tmp = "";
            UInt32 status = EhllapiWrapper.Wait();
            EhllapiWrapper.ReadScreen(NamePos.cursor, screenconfig.code.Length, out screen_code_tmp);
            screen_code_tmp = screen_code_tmp.Substring(0, screenconfig.code.Length);

            for (int i = 0; i < time; i++)
            {
                if (screen_code_tmp == screen) return;
                System.Threading.Thread.Sleep(1000);
                status = EhllapiWrapper.Wait();
                EhllapiWrapper.ReadScreen(NamePos.cursor, screenconfig.code.Length, out screen_code_tmp);
                screen_code_tmp = screen_code_tmp.Substring(0, screenconfig.code.Length);
            }
        }

        public Screen(string code, string name)
        {
            screenconfig = new ScreenConfig(code, name);
        }

        public virtual void SetValues(object obj)
        {

        }

        public virtual void SetValues(object obj, string  code)
        {

        }

        public virtual string GetValues(string keyname)
        {
            try
            {
                int pos = this.screenconfig.items[keyname].itemconfig.point.cursor;
                int len = this.screenconfig.items[keyname].itemconfig.length;
                string message = "";
                EhllapiWrapper.ReadScreen(pos, len, out message);
                return message.Substring(0,len);
            }
            catch
            {
                return "";
            }
        }

        public virtual string GetValues(Point point, int length)
        {
            try
            {
                int pos = point.cursor;
                int len = length;
                string message = "";
                Wait(1);
                EhllapiWrapper.ReadScreen(pos, len, out message);
                Wait(1);
                return message.Substring(0, len);
            }
            catch
            {
                return "";
            }
        }

        public virtual void SetValues(Point point, string strValue)
        {
            Wait(2);
            EhllapiWrapper.SetCursorPos(point.cursor);
            Wait(2);
            EhllapiWrapper.SendStr("@F");
            Wait(2);
            EhllapiWrapper.SendStr(strValue);
            Wait(2);
        }

        public virtual void Enter(Point point)
        {
            Wait(2);
            EhllapiWrapper.SetCursorPos(point.cursor);
            Wait(2);           
            EhllapiWrapper.SendStr("@E");
            Wait(2);
        }

        public virtual string GetScreenCode()
        {
            try
            {
                string screen_code = "";
                EhllapiWrapper.ReadScreen(NamePos.cursor, 5, out screen_code);
                return screen_code.Substring(0, 5);
            }
            catch
            {
                return "";
            }
        }

        public virtual void Execute()
        {           
            Waiting();

            foreach (var item in screenconfig.items)
            {
                if (item.Value.itemconfig.values == null && item.Value.itemconfig.action.id!=2)
                { 
                    continue; 
                }
                EhllapiWrapper.SetCursorPos(item.Value.itemconfig.point.cursor);
                //EhllapiWrapper.SendStr("@F");
                //EhllapiWrapper.SendStr(item.Value.itemconfig.values.ToString());               

               // System.Threading.Thread.Sleep(500);
                switch (item.Value.itemconfig.action.id)
                {
                    case -1:
                        continue;                        
                    case 0:
                        break;
                    case 1:
                        EhllapiWrapper.SendStr(item.Value.itemconfig.action.value);
                        break;
                    case 2:
                        EhllapiWrapper.SendStr(item.Value.itemconfig.action.value);
                        Type mytype=null;

                        if ((mytype = Type.GetType(item.Value.itemconfig.typename, false, true)) == null)
                        {
                            System.Reflection.Assembly assembly = System.Reflection.Assembly.LoadFrom(AppSetting.FOLDER_ROOT + @"\KN.Screen.dll");
                            foreach (System.Type type in assembly.GetTypes())
                                if (type.IsClass && type.FullName.CompareTo(item.Value.itemconfig.typename) == 0)
                                    mytype = type;
                        }

                        KN.Systems.Screen subscreen = (KN.Systems.Screen)Activator.CreateInstance(mytype, new string[] { "X" });
                        subscreen.Waiting();
                        subscreen.Execute();
                        Next();
                        break;
                }
                Waiting();
                EhllapiWrapper.SetCursorPos(item.Value.itemconfig.point.cursor);
                EhllapiWrapper.SendStr("@F");
                EhllapiWrapper.SendStr(item.Value.itemconfig.values.ToString());     
                
                //delay
                //System.Threading.Thread.Sleep(500);
            }
            
        }

        public virtual void Execute(string keyname)
        {
            Waiting();
            var item = screenconfig.items[keyname];
            if (item.itemconfig.values == null) return;
            if (item.itemconfig.values == "") return;
            
            EhllapiWrapper.SetCursorPos(item.itemconfig.point.cursor);
            //EhllapiWrapper.SendStr("@F");
            //EhllapiWrapper.SendStr(item.Value.itemconfig.values.ToString());               

            //System.Threading.Thread.Sleep(500);
            switch (item.itemconfig.action.id)
            {
                case -1:
                    return;
                case 0:
                    break;
                case 1:
                    //EhllapiWrapper.SendStr(item.itemconfig.values.ToString());
                    break;
                case 2:
                    EhllapiWrapper.SendStr(item.itemconfig.action.value);
                    Type mytype = null;

                    if ((mytype = Type.GetType(item.itemconfig.typename, false, true)) == null)
                    {
                        System.Reflection.Assembly assembly = System.Reflection.Assembly.LoadFrom(AppSetting.FOLDER_ROOT);
                        foreach (System.Type type in assembly.GetTypes())
                            if (type.IsClass && type.FullName.CompareTo(item.itemconfig.typename) == 0)
                                mytype = type;
                    }

                    KN.Systems.Screen subscreen = (KN.Systems.Screen)Activator.CreateInstance(mytype, new string[] { "X" });
                    subscreen.Waiting();
                    subscreen.Execute();
                    Next();
                    break;
            }
            EhllapiWrapper.SendStr("@F");
            EhllapiWrapper.SendStr(item.itemconfig.values.ToString());
        }

        public virtual void Next()
        {
            EhllapiWrapper.SendStr("@E");           
        }

        public virtual void F9()
        {
            EhllapiWrapper.SendStr("@9");
        }

        public virtual string GetMessage()
        {
            F5();
            string message = "";
            //UInt32 status = EhllapiWrapper.Wait();
            Waiting();
            EhllapiWrapper.ReadScreen(MessagePos.cursor, 70, out message);
            message = message.Trim();
            if (message.Length > 10)
                return message;
            else
                return "";
        }

        public virtual string GetMessage2()
        {            
            string message = "";
            //UInt32 status = EhllapiWrapper.Wait();
            Waiting();
            EhllapiWrapper.ReadScreen(MessagePos.cursor, 70, out message);
            message = message.Trim();
            if (message.Length > 10)
                return message;
            else
                return "";
        }

        public virtual void F3()
        {
            //if (GetScreenCode() != this.screenconfig.code) return;
            EhllapiWrapper.SendStr("@3");
        }

        public virtual void Home()
        {            
            F3();
        }

        public virtual void F5()
        {
            if (GetScreenCode() != this.screenconfig.code) return;

            EhllapiWrapper.SendStr("@5");
        }

        public virtual void Enter()
        {
            if (GetScreenCode() != this.screenconfig.code) return;
            EhllapiWrapper.SendStr("@E");
        }

        public virtual void Enter2()
        {
            EhllapiWrapper.SendStr("@E");
        }

        public virtual void F12()
        {
            if (GetScreenCode() != this.screenconfig.code) return;
            EhllapiWrapper.SendStr("@b");       
        }

        public virtual bool IsCurrentScreen()
        {
            if (GetValues(NamePos, 5) == screenconfig.code)
                return true;

            return false;
        }
    }
    public class ScreenConfig
    {
        public string code { get; set; }
        public string name { get; set; }
        public ItemColection items { get; set; } 
        public ScreenConfig()
        {
           
        }

        public ScreenConfig(string code, string name)
        {
            this.code = code.Trim();
            this.name = name.Trim();
            this.items = LoadConfig(code);
        }

        protected ItemColection LoadConfig(string code)
        {
            return ItemManager.ScreenConfigLoad(code);            
        }
        
    }
}
